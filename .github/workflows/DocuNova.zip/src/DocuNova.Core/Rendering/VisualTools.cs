using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace DocuNova.Core
{
    /// <summary>Отрисовка визуалов WPF в растр и извлечение текста из глифов.</summary>
    public static class VisualTools
    {
        public const double MaxPixels = 64_000_000;

        public static double ClampScale(Size size, double scale)
        {
            double px = size.Width * scale * size.Height * scale;
            if (px > MaxPixels) scale *= Math.Sqrt(MaxPixels / px);
            return Math.Max(0.01, scale);
        }

        public static BitmapSource Render(Visual visual, Size pageSize, double scale, Brush background = null)
        {
            scale = ClampScale(pageSize, scale);
            int w = Math.Max(1, (int)Math.Ceiling(pageSize.Width * scale));
            int h = Math.Max(1, (int)Math.Ceiling(pageSize.Height * scale));
            var rtb = new RenderTargetBitmap(w, h, 96 * scale, 96 * scale, PixelFormats.Pbgra32);
            var bg = new DrawingVisual();
            using (var dc = bg.RenderOpen())
                dc.DrawRectangle(background ?? Brushes.White, null, new Rect(0, 0, pageSize.Width, pageSize.Height));
            rtb.Render(bg);
            rtb.Render(visual);
            rtb.Freeze();
            return rtb;
        }

        /// <summary>Извлекает символы из всех GlyphRun в дереве визуалов с их координатами.</summary>
        public static List<PageChar> ExtractChars(Visual root)
        {
            var list = new List<PageChar>();
            try { WalkVisual(root, Matrix.Identity, list, 0); } catch { }
            return list;
        }

        private static void WalkVisual(Visual v, Matrix parent, List<PageChar> list, int depth)
        {
            if (v == null || depth > 200) return;
            Matrix local = Matrix.Identity;
            var t = VisualTreeHelper.GetTransform(v);
            if (t != null) local = t.Value;
            var off = VisualTreeHelper.GetOffset(v);
            local.Translate(off.X, off.Y);
            Matrix total = local * parent;

            DrawingGroup dg = null;
            try { dg = VisualTreeHelper.GetDrawing(v); } catch { }
            if (dg != null) WalkDrawing(dg, total, list, 0);

            int n = VisualTreeHelper.GetChildrenCount(v);
            for (int i = 0; i < n; i++)
            {
                if (VisualTreeHelper.GetChild(v, i) is Visual child)
                    WalkVisual(child, total, list, depth + 1);
            }
        }

        private static void WalkDrawing(Drawing d, Matrix m, List<PageChar> list, int depth)
        {
            if (d == null || depth > 200) return;
            if (d is DrawingGroup g)
            {
                Matrix gm = g.Transform != null ? g.Transform.Value * m : m;
                foreach (var child in g.Children) WalkDrawing(child, gm, list, depth + 1);
            }
            else if (d is GlyphRunDrawing grd && grd.GlyphRun != null)
            {
                AddRun(grd.GlyphRun, m, list);
            }
        }

        private static void AddRun(GlyphRun run, Matrix m, List<PageChar> list)
        {
            var chars = run.Characters;
            var adv = run.AdvanceWidths;
            if (chars == null || adv == null || chars.Count == 0) return;
            double em = run.FontRenderingEmSize;
            double ascent = em * 0.8, descent = em * 0.2;
            try
            {
                var gt = run.GlyphTypeface;
                if (gt != null) { ascent = gt.Baseline * em; descent = Math.Max(0.1, (gt.Height - gt.Baseline) * em); }
            }
            catch { }
            var prefix = new double[adv.Count + 1];
            for (int i = 0; i < adv.Count; i++) prefix[i + 1] = prefix[i] + adv[i];
            var cmap = run.ClusterMap;
            var o = run.BaselineOrigin;
            bool rtl = (run.BidiLevel & 1) == 1;
            for (int i = 0; i < chars.Count; i++)
            {
                int gi = cmap != null && i < cmap.Count ? cmap[i] : i;
                if (gi >= adv.Count) gi = adv.Count - 1;
                if (gi < 0) continue;
                double x0 = rtl ? o.X - prefix[gi + 1] : o.X + prefix[gi];
                double w = adv[gi];
                // символы одного кластера делят ширину глифа
                int clusterStart = i, clusterEnd = i;
                if (cmap != null)
                {
                    while (clusterStart > 0 && cmap[clusterStart - 1] == gi) clusterStart--;
                    while (clusterEnd + 1 < chars.Count && cmap[clusterEnd + 1] == gi) clusterEnd++;
                    int cnt = clusterEnd - clusterStart + 1;
                    if (cnt > 1) { w /= cnt; x0 += w * (i - clusterStart); }
                }
                var r = new Rect(x0, o.Y - ascent, Math.Max(0.5, w), ascent + descent);
                r = TransformRect(r, m);
                char c = chars[i];
                if (c == '\u00A0') c = ' ';
                list.Add(new PageChar(c, r));
            }
        }

        public static Rect TransformRect(Rect r, Matrix m)
        {
            var p1 = m.Transform(r.TopLeft); var p2 = m.Transform(r.TopRight);
            var p3 = m.Transform(r.BottomLeft); var p4 = m.Transform(r.BottomRight);
            double l = Math.Min(Math.Min(p1.X, p2.X), Math.Min(p3.X, p4.X));
            double t = Math.Min(Math.Min(p1.Y, p2.Y), Math.Min(p3.Y, p4.Y));
            double rr = Math.Max(Math.Max(p1.X, p2.X), Math.Max(p3.X, p4.X));
            double b = Math.Max(Math.Max(p1.Y, p2.Y), Math.Max(p3.Y, p4.Y));
            return new Rect(new Point(l, t), new Point(rr, b));
        }

        /// <summary>Приводит любое изображение к непрозрачному Pbgra32 на белом фоне.</summary>
        public static BitmapSource Flatten(BitmapSource src)
        {
            if (src == null) return null;
            var dv = new DrawingVisual();
            double w = src.PixelWidth, h = src.PixelHeight;
            using (var dc = dv.RenderOpen())
            {
                dc.DrawRectangle(Brushes.White, null, new Rect(0, 0, w, h));
                dc.DrawImage(src, new Rect(0, 0, w, h));
            }
            var rtb = new RenderTargetBitmap((int)w, (int)h, 96, 96, PixelFormats.Pbgra32);
            rtb.Render(dv);
            rtb.Freeze();
            return rtb;
        }

        /// <summary>Масштабирует изображение так, чтобы большая сторона была равна maxSide (высокое качество).</summary>
        public static BitmapSource FitTo(BitmapSource src, int maxSide, bool border)
        {
            double k = (double)maxSide / Math.Max(src.PixelWidth, src.PixelHeight);
            int w = Math.Max(1, (int)Math.Round(src.PixelWidth * k));
            int h = Math.Max(1, (int)Math.Round(src.PixelHeight * k));
            var dv = new DrawingVisual();
            RenderOptions.SetBitmapScalingMode(dv, BitmapScalingMode.HighQuality);
            using (var dc = dv.RenderOpen())
            {
                dc.DrawRectangle(Brushes.White, null, new Rect(0, 0, w, h));
                dc.DrawImage(src, new Rect(0, 0, w, h));
                if (border && w > 24 && h > 24)
                    dc.DrawRectangle(null, new Pen(new SolidColorBrush(Color.FromRgb(200, 200, 205)), 1), new Rect(0.5, 0.5, w - 1, h - 1));
            }
            var rtb = new RenderTargetBitmap(w, h, 96, 96, PixelFormats.Pbgra32);
            rtb.Render(dv);
            rtb.Freeze();
            return rtb;
        }
    }
}
