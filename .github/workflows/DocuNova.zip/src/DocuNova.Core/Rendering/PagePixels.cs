using System;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace DocuNova.Core
{
    /// <summary>
    /// «Сырые» пиксели отрисованной страницы (BGRA, 4 байта на пиксель).
    /// Между потоками передаются только эти байты, а не объекты WPF: картинку для экрана создаёт
    /// сам UI-поток (<see cref="ToBitmap"/>), поэтому ошибки «объект принадлежит другому потоку» исключены.
    /// Здесь же применяются режим страницы (ночь/сепия) и поворот на 90/180/270° — без потери качества.
    /// </summary>
    public sealed class PagePixels
    {
        public int Width { get; private set; }
        public int Height { get; private set; }
        public int Stride => Width * 4;
        public bool Alpha { get; private set; }
        public byte[] Data { get; private set; }

        private static bool HasAlpha(PixelFormat f) =>
            f == PixelFormats.Bgra32 || f == PixelFormats.Pbgra32 || f == PixelFormats.Prgba64 || f == PixelFormats.Rgba64 ||
            f == PixelFormats.Rgba128Float || f == PixelFormats.Prgba128Float ||
            f == PixelFormats.Indexed1 || f == PixelFormats.Indexed2 || f == PixelFormats.Indexed4 || f == PixelFormats.Indexed8;

        /// <summary>
        /// Копирует пиксели картинки. Вызывается в том же потоке, где картинка создана.
        /// mode: normal / night / sepia; rotation: 0, 90, 180, 270 (по часовой стрелке).
        /// </summary>
        public static PagePixels From(BitmapSource src, string mode, int rotation)
        {
            if (src == null || src.PixelWidth < 1 || src.PixelHeight < 1) return null;
            bool alpha = HasAlpha(src.Format);
            var target = alpha ? PixelFormats.Pbgra32 : PixelFormats.Bgr32;
            BitmapSource conv = src.Format == target ? src : new FormatConvertedBitmap(src, target, null, 0);
            int w = conv.PixelWidth, h = conv.PixelHeight;
            var data = new byte[(long)w * h * 4];
            conv.CopyPixels(data, w * 4, 0);
            if (!alpha)
                for (int i = 3; i < data.Length; i += 4) data[i] = 255;
            if (mode == "night" || mode == "sepia") Tint(data, mode == "night");
            var p = new PagePixels { Width = w, Height = h, Alpha = alpha, Data = data };
            rotation = Normalize(rotation);
            if (rotation != 0) p.Rotate(rotation);
            return p;
        }

        /// <summary>
        /// Пиксели, уже прочитанные в формате BGRA/BGRX (строки без выравнивания, Width * 4 байта).
        /// Массив не копируется: режим страницы и поворот применяются прямо к нему.
        /// </summary>
        public static PagePixels FromRaw(byte[] bgra, int width, int height, bool alpha, string mode, int rotation)
        {
            if (bgra == null || width < 1 || height < 1 || bgra.Length < (long)width * height * 4) return null;
            if (mode == "night" || mode == "sepia") Tint(bgra, mode == "night");
            var p = new PagePixels { Width = width, Height = height, Alpha = alpha, Data = bgra };
            rotation = Normalize(rotation);
            if (rotation != 0) p.Rotate(rotation);
            return p;
        }

        /// <summary>
        /// Быстрое чтение несжатого BMP (так его отдаёт движок PDF Windows) прямо в массив пикселей —
        /// без декодера изображений и промежуточных копий. Возвращает null, если формат не подходит
        /// (тогда используется обычный декодер). Пиксели считаются непрозрачными (Bgr32).
        /// </summary>
        public static PagePixels ReadBmp(System.IO.Stream s, long length, string mode, int rotation)
        {
            try
            {
                if (s == null || length < 54) return null;
                var head = new byte[54];
                s.ReadExactly(head, 0, 54);
                if (head[0] != (byte)'B' || head[1] != (byte)'M') return null;
                uint off = BitConverter.ToUInt32(head, 10);
                uint dib = BitConverter.ToUInt32(head, 14);
                int w = BitConverter.ToInt32(head, 18);
                int hRaw = BitConverter.ToInt32(head, 22);
                int bpp = BitConverter.ToUInt16(head, 28);
                uint comp = BitConverter.ToUInt32(head, 30);
                if (dib < 40 || w < 1 || hRaw == 0 || hRaw == int.MinValue || off < 54 || off > 4096 || off >= length) return null;
                int h = Math.Abs(hRaw);
                bool bottomUp = hRaw > 0;
                if (bpp != 32 && bpp != 24) return null;
                if ((long)w * h > 400_000_000L) return null;

                // остаток заголовка (маски цветов для BI_BITFIELDS)
                var rest = new byte[off - 54];
                if (rest.Length > 0) s.ReadExactly(rest, 0, rest.Length);
                if (comp == 3 || comp == 6)
                {
                    if (bpp != 32) return null;
                    // маски лежат сразу после 40-байтового заголовка (в V4/V5 — внутри него, по тому же смещению 54)
                    if (rest.Length < 12) return null;
                    uint rm = BitConverter.ToUInt32(rest, 0), gm = BitConverter.ToUInt32(rest, 4), bm = BitConverter.ToUInt32(rest, 8);
                    if (rm != 0x00FF0000u || gm != 0x0000FF00u || bm != 0x000000FFu) return null;
                }
                else if (comp != 0) return null;

                int srcStride = bpp == 32 ? w * 4 : ((w * 3 + 3) & ~3);
                if (off + (long)srcStride * h > length) return null;
                int dstStride = w * 4;
                var data = new byte[(long)dstStride * h];
                if (bpp == 32)
                {
                    if (!bottomUp) s.ReadExactly(data, 0, data.Length);
                    else
                        for (int y = h - 1; y >= 0; y--) s.ReadExactly(data, y * dstStride, dstStride);
                }
                else
                {
                    var row = new byte[srcStride];
                    for (int i = 0; i < h; i++)
                    {
                        s.ReadExactly(row, 0, srcStride);
                        int y = bottomUp ? h - 1 - i : i;
                        int d = y * dstStride;
                        for (int x = 0, si = 0; x < w; x++, si += 3, d += 4)
                        {
                            data[d] = row[si]; data[d + 1] = row[si + 1]; data[d + 2] = row[si + 2]; data[d + 3] = 255;
                        }
                    }
                }
                return FromRaw(data, w, h, false, mode, rotation);
            }
            catch { return null; }
        }

        public static int Normalize(int rotation) => ((rotation % 360) + 360) % 360 / 90 * 90;

        /// <summary>Картинка для показа. Вызывать только в UI-потоке. Байты после этого освобождаются.</summary>
        public BitmapSource ToBitmap()
        {
            if (Data == null) return null;
            var wb = new WriteableBitmap(Width, Height, 96, 96, Alpha ? PixelFormats.Pbgra32 : PixelFormats.Bgr32, null);
            wb.WritePixels(new Int32Rect(0, 0, Width, Height), Data, Stride, 0);
            wb.Freeze();
            Data = null;
            return wb;
        }

        private void Rotate(int rotation)
        {
            int w = Width, h = Height;
            var dst = new byte[Data.Length];
            int nw = rotation == 180 ? w : h, nh = rotation == 180 ? h : w;
            // по 4 байта (один пиксель) за операцию
            var src32 = System.Runtime.InteropServices.MemoryMarshal.Cast<byte, uint>(Data.AsSpan());
            var dst32 = System.Runtime.InteropServices.MemoryMarshal.Cast<byte, uint>(dst.AsSpan());
            for (int y = 0; y < h; y++)
            {
                int srow = y * w;
                switch (rotation)
                {
                    case 90:
                        for (int x = 0; x < w; x++) dst32[x * nw + (h - 1 - y)] = src32[srow + x];
                        break;
                    case 180:
                    {
                        int drow = (h - 1 - y) * nw;
                        for (int x = 0; x < w; x++) dst32[drow + (w - 1 - x)] = src32[srow + x];
                        break;
                    }
                    default: // 270
                        for (int x = 0; x < w; x++) dst32[(w - 1 - x) * nw + y] = src32[srow + x];
                        break;
                }
            }
            Data = dst;
            Width = nw; Height = nh;
        }

        private static void Tint(byte[] p, bool night)
        {
            if (night)
            {
                for (int i = 0; i < p.Length; i += 4)
                {
                    p[i] = (byte)(28 + ((255 - p[i]) * 205 >> 8));
                    p[i + 1] = (byte)(28 + ((255 - p[i + 1]) * 205 >> 8));
                    p[i + 2] = (byte)(30 + ((255 - p[i + 2]) * 205 >> 8));
                }
            }
            else
            {
                for (int i = 0; i < p.Length; i += 4)
                {
                    p[i] = (byte)(p[i] * 205 >> 8);
                    p[i + 1] = (byte)(p[i + 1] * 238 >> 8);
                    p[i + 2] = (byte)(p[i + 2] * 253 >> 8);
                }
            }
        }
    }
}
