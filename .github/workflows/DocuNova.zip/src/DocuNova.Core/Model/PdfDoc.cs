using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Media.Imaging;
using WinPdf = global::Windows.Data.Pdf;
using WinStreams = global::Windows.Storage.Streams;
using WinImaging = global::Windows.Graphics.Imaging;
using Pig = UglyToad.PdfPig;

namespace DocuNova.Core
{
    /// <summary>
    /// PDF: отрисовка встроенным в Windows движком Windows.Data.Pdf (без JavaScript, без сети),
    /// текстовый слой и метаданные — управляемой библиотекой PdfPig (безопасна по памяти).
    /// </summary>
    public sealed class PdfDoc : DocumentBase
    {
        private WinPdf.PdfDocument _doc;
        private WinStreams.IRandomAccessStream _stream;
        private Stream _renderSource;
        private SharedFile _file;
        private Pig.PdfDocument _pig;
        private Stream _pigSource;
        private bool _pigFailed;
        private bool _detailsLoaded;
        private readonly object _lock = new object();
        private readonly object _pigLock = new object();
        private Size[] _sizes;
        private int[] _rot;
        private readonly Dictionary<int, List<PageChar>> _charCache = new Dictionary<int, List<PageChar>>();
        public string Password { get; private set; }

        // Второй экземпляр движка отрисовки: две страницы рисуются одновременно (движок Windows не допускает
        // параллельной работы с одним документом, а с разными — допускает). Создаётся по требованию.
        private WinPdf.PdfDocument _doc2;
        private WinStreams.IRandomAccessStream _stream2;
        private Stream _src2;
        private readonly object _lock2 = new object();
        private readonly object _secLock = new object();
        private bool _secDisabled;

        // Фоновая догрузка: метаданные, оглавление, текстовый слой и размеры дальних страниц
        // не задерживают показ первой страницы.
        /// <summary>Сколько страниц измеряется сразу при открытии; размеры остальных уточняются в фоне.</summary>
        private const int SyncSizePages = 64;
        private bool _light;
        private volatile bool _disposed;
        private int _sizesKnown;
        private bool _sizesChanged;
        private readonly object _completeLock = new object();
        private volatile bool _deferredDone;
        private bool _deferredApplied;
        private InfoSection _stagedDocInfo;
        private List<TocItem> _stagedToc;
        private string _stagedNotice, _stagedTitle, _stagedAuthor;

        public override int PageCount => _sizes?.Length ?? 0;
        public override bool CanRenderOffThread => true;
        public override bool IsPdf => true;

        /// <summary>
        /// WinRT-операции выполняются в MTA-потоке: блокирующее ожидание асинхронных операций
        /// в STA-потоке (UI, эскизы Проводника) могло бы привести к взаимоблокировке.
        /// </summary>
        private static T OnMta<T>(Func<T> f)
        {
            if (System.Threading.Thread.CurrentThread.GetApartmentState() == System.Threading.ApartmentState.STA)
                return System.Threading.Tasks.Task.Run(f).GetAwaiter().GetResult();
            return f();
        }

        /// <summary>Открытие из массива байтов (эскизы Проводника, объединённые PDF).</summary>
        public static PdfDoc Open(byte[] bytes, string password, bool light) => OnMta(() => OpenCore(bytes, null, password, light));

        /// <summary>
        /// Открытие из файла без копирования его в память: страницы и текст читаются с диска по мере надобности.
        /// Владение <paramref name="file"/> переходит к документу только при успешном открытии.
        /// </summary>
        public static PdfDoc Open(SharedFile file, string password, bool light) => OnMta(() => OpenCore(null, file, password, light));

        private static PdfDoc OpenCore(byte[] bytes, SharedFile file, string password, bool light)
        {
            var d = new PdfDoc { Kind = DocKind.Fixed, Bytes = file == null ? bytes : null, Password = password, _light = light };
            // второй движок отрисовки — только при достаточном числе ядер и не для эскизов Проводника
            d._secDisabled = light || Environment.ProcessorCount < 4;
            // Поток поверх уже имеющихся данных — без второй (неуправляемой) копии всего файла
            d._renderSource = file != null ? file.CreateStream() : new MemoryStream(bytes, 0, bytes.Length, false, true);
            d._stream = d._renderSource.AsRandomAccessStream();
            try
            {
                d._doc = string.IsNullOrEmpty(password)
                    ? WinPdf.PdfDocument.LoadFromStreamAsync(d._stream).AsTask().GetAwaiter().GetResult()
                    : WinPdf.PdfDocument.LoadFromStreamAsync(d._stream, password).AsTask().GetAwaiter().GetResult();
            }
            catch (Exception ex)
            {
                d.ReleaseStreams();
                int hr = ex.HResult;
                // 0x8007052B = ERROR_WRONG_PASSWORD
                if (hr == unchecked((int)0x8007052B) || ex.Message.IndexOf("password", StringComparison.OrdinalIgnoreCase) >= 0)
                    throw new PasswordRequiredException(!string.IsNullOrEmpty(password));
                throw new UnsupportedFormatException("PDF повреждён или не поддерживается: " + ex.Message);
            }

            try
            {
                int n = (int)d._doc.PageCount;
                if (n <= 0) throw new UnsupportedFormatException("PDF не содержит страниц.");
                d._sizes = new Size[n];
                d._rot = new int[n];
                // Измерение каждой страницы — обращение к движку; у толстых документов это заметные секунды.
                // Сразу измеряем только начало документа, остальным временно даём размер последней измеренной
                // страницы (обычно он и есть), а точные размеры дочитываются в фоне.
                int sync = light ? 1 : Math.Min(n, SyncSizePages);
                for (int i = 0; i < sync; i++) d.MeasurePage(d._doc, i, out d._sizes[i], out d._rot[i]);
                for (int i = sync; i < n; i++) d._sizes[i] = d._sizes[sync - 1];
                d._sizesKnown = light ? n : sync;
            }
            catch
            {
                d.ReleaseStreams();
                throw;
            }

            d._file = file;
            // Текстовый слой, метаданные и оглавление читаются в фоне (CompleteLoading) — уже после показа страницы.
            return d;
        }

        private void MeasurePage(WinPdf.PdfDocument doc, int i, out Size size, out int rot)
        {
            using (var p = doc.GetPage((uint)i))
            {
                var s = p.Size;
                size = new Size(Math.Max(1, s.Width), Math.Max(1, s.Height));
                switch (p.Rotation)
                {
                    case WinPdf.PdfPageRotation.Rotate90: rot = 90; break;
                    case WinPdf.PdfPageRotation.Rotate180: rot = 180; break;
                    case WinPdf.PdfPageRotation.Rotate270: rot = 270; break;
                    default: rot = 0; break;
                }
            }
        }

        // ================== фоновая догрузка ==================

        public override bool HasPendingLoad => !_light && !_deferredApplied && !_disposed;

        public override void CompleteLoading()
        {
            if (_light || _disposed) return;
            OnMta(() =>
            {
                lock (_completeLock)
                {
                    if (_deferredDone || _disposed) return 0;
                    try
                    {
                        // 1) текстовый слой, метаданные и оглавление
                        lock (_pigLock)
                        {
                            if (_disposed) return 0;
                            if (EnsurePig() == null)
                                _stagedNotice = "Текстовый слой PDF не удалось прочитать — поиск и копирование текста недоступны (можно распознать текст через OCR).";
                            StageMetadata();
                        }
                        // 2) точные размеры дальних страниц; блокировка берётся на каждую страницу отдельно,
                        //    чтобы отрисовка видимых страниц не ждала окончания измерения
                        int n = _sizes.Length;
                        for (int i = _sizesKnown; i < n; i++)
                        {
                            if (_disposed) return 0;
                            lock (_lock)
                            {
                                if (_doc == null) return 0;
                                MeasurePage(_doc, i, out var sz, out var rot);
                                if (Math.Abs(sz.Width - _sizes[i].Width) > 0.01 || Math.Abs(sz.Height - _sizes[i].Height) > 0.01)
                                {
                                    _sizes[i] = sz;
                                    _sizesChanged = true;
                                }
                                _rot[i] = rot;
                            }
                            _sizesKnown = i + 1;
                            // короткая пауза: ожидающая отрисовка страницы успевает занять движок
                            if ((i & 3) == 3) System.Threading.Thread.Sleep(1);
                        }
                    }
                    catch { }
                    finally { if (!_disposed) _deferredDone = true; }
                }
                return 0;
            });
        }

        public override bool ApplyCompletedLoading()
        {
            if (_light || _deferredApplied || _disposed) return false;
            // UI-поток не блокируется: если фоновая догрузка ещё идёт, перенесём данные при следующем вызове
            if (!_deferredDone || _disposed) return false;
            _deferredApplied = true;
            if (!string.IsNullOrWhiteSpace(_stagedTitle) && string.IsNullOrWhiteSpace(Title)) Title = _stagedTitle;
            if (!string.IsNullOrWhiteSpace(_stagedAuthor) && string.IsNullOrWhiteSpace(Author)) Author = _stagedAuthor;
            var secs = new List<InfoSection>();
            if (_stagedDocInfo != null) secs.Add(_stagedDocInfo);
            secs.Add(BuildPagesSection());
            lock (Info) Info.InsertRange(0, secs);
            if (_stagedToc != null && Toc.Count == 0) Toc.AddRange(_stagedToc);
            if (_stagedNotice != null) Notices.Add(_stagedNotice);
            _stagedDocInfo = null; _stagedToc = null;
            return _sizesChanged;
        }

        /// <summary>Источник для повторного чтения исходного PDF (сохранение с пометками, контрольные суммы).</summary>
        public override Stream OpenSource()
        {
            var f = _file;
            if (f != null) return f.CreateStream();
            return base.OpenSource();
        }

        /// <summary>PdfPig открывается по требованию и освобождается при сворачивании/переключении вкладок.</summary>
        private Pig.PdfDocument EnsurePig()
        {
            if (_pig != null || _pigFailed) return _pig;
            Stream src = null;
            try
            {
                var opts = new Pig.ParsingOptions { UseLenientParsing = true };
                if (!string.IsNullOrEmpty(Password)) opts.Password = Password;
                if (_file != null)
                {
                    src = _file.CreateStream();
                    _pig = Pig.PdfDocument.Open(src, opts);
                    _pigSource = src;
                }
                else if (Bytes != null) _pig = Pig.PdfDocument.Open(Bytes, opts);
            }
            catch
            {
                try { src?.Dispose(); } catch { }
                _pig = null;
                _pigSource = null;
                _pigFailed = true;
            }
            return _pig;
        }

        public override void TrimMemory()
        {
            lock (_pigLock)
            {
                try { _pig?.Dispose(); } catch { }
                _pig = null;
                try { _pigSource?.Dispose(); } catch { }
                _pigSource = null;
            }
            lock (_charCache) _charCache.Clear();
            ReleaseSecondary(false);
        }

        public override Size GetPageSize(int index) => _sizes[Math.Max(0, Math.Min(index, _sizes.Length - 1))];

        public override BitmapSource RenderPage(int index, double scale) => OnMta(() => RenderCore(index, scale, null));

        public override bool CanRenderRegion => true;

        public override BitmapSource RenderRegion(int index, double scale, Rect region) => OnMta(() => RenderCore(index, scale, region));

        public override PagePixels RenderPagePixels(int index, double scale, string mode, int rotation) =>
            OnMta(() => RenderPixelsCore(index, scale, null, mode, rotation));

        public override PagePixels RenderRegionPixels(int index, double scale, Rect region, string mode, int rotation) =>
            OnMta(() => RenderPixelsCore(index, scale, region, mode, rotation));

        /// <summary>Размер результата в пикселях и исходный прямоугольник страницы.</summary>
        private bool Plan(int index, ref double scale, Rect? region, out Rect src, out uint w, out uint h)
        {
            var size = GetPageSize(index);
            src = new Rect(0, 0, size.Width, size.Height);
            w = h = 0;
            if (region.HasValue)
            {
                src.Intersect(region.Value);
                if (src.IsEmpty || src.Width < 1 || src.Height < 1) return false;
            }
            scale = VisualTools.ClampScale(src.Size, scale);
            w = (uint)Math.Max(1, Math.Round(src.Width * scale));
            h = (uint)Math.Max(1, Math.Round(src.Height * scale));
            return true;
        }

        /// <summary>
        /// Отрисовка страницы движком Windows в поток BMP. Свободный движок выбирается сам: основной,
        /// а если он занят другой страницей — второй экземпляр, так что две страницы рисуются одновременно.
        /// </summary>
        private bool RenderTo(WinStreams.IRandomAccessStream outStream, int index, Rect src, bool region, uint w, uint h)
        {
            if (System.Threading.Monitor.TryEnter(_lock))
            {
                try { return RenderWith(_doc, outStream, index, src, region, w, h); }
                finally { System.Threading.Monitor.Exit(_lock); }
            }
            if (EnsureSecondary() && System.Threading.Monitor.TryEnter(_lock2))
            {
                try
                {
                    if (_doc2 != null) return RenderWith(_doc2, outStream, index, src, region, w, h);
                }
                finally { System.Threading.Monitor.Exit(_lock2); }
            }
            lock (_lock) return RenderWith(_doc, outStream, index, src, region, w, h);
        }

        private bool RenderWith(WinPdf.PdfDocument doc, WinStreams.IRandomAccessStream outStream, int index, Rect src, bool region, uint w, uint h)
        {
            if (doc == null || _disposed || index < 0 || index >= PageCount) return false;
            using (var page = doc.GetPage((uint)index))
            {
                var opts = new WinPdf.PdfPageRenderOptions
                {
                    DestinationWidth = w,
                    DestinationHeight = h,
                    // BMP — без сжатия: кодирование и чтение почти ничего не стоят
                    BitmapEncoderId = WinImaging.BitmapEncoder.BmpEncoderId
                };
                if (region) opts.SourceRect = new global::Windows.Foundation.Rect(src.X, src.Y, src.Width, src.Height);
                page.RenderToStreamAsync(outStream, opts).AsTask().GetAwaiter().GetResult();
            }
            return true;
        }

        /// <summary>Второй экземпляр движка поверх того же файла (без копирования файла в память).</summary>
        private bool EnsureSecondary()
        {
            if (_doc2 != null) return true;
            if (_secDisabled || _disposed) return false;
            lock (_secLock)
            {
                if (_doc2 != null) return true;
                if (_secDisabled || _disposed) return false;
                Stream src = null;
                WinStreams.IRandomAccessStream rs = null;
                try
                {
                    var f = _file;
                    var b = Bytes;
                    if (f != null) src = f.CreateStream();
                    else if (b != null) src = new MemoryStream(b, 0, b.Length, false, true);
                    else { _secDisabled = true; return false; }
                    rs = src.AsRandomAccessStream();
                    var d = string.IsNullOrEmpty(Password)
                        ? WinPdf.PdfDocument.LoadFromStreamAsync(rs).AsTask().GetAwaiter().GetResult()
                        : WinPdf.PdfDocument.LoadFromStreamAsync(rs, Password).AsTask().GetAwaiter().GetResult();
                    lock (_lock2)
                    {
                        if (_disposed) { try { rs.Dispose(); } catch { } try { src.Dispose(); } catch { } return false; }
                        _src2 = src; _stream2 = rs; _doc2 = d;
                    }
                    return true;
                }
                catch
                {
                    try { rs?.Dispose(); } catch { }
                    try { src?.Dispose(); } catch { }
                    _secDisabled = true;
                    return false;
                }
            }
        }

        /// <summary>Освобождает второй движок. wait = false — если он сейчас рисует, не ждём (освободим в следующий раз).</summary>
        private void ReleaseSecondary(bool wait = true)
        {
            if (wait) System.Threading.Monitor.Enter(_lock2);
            else if (!System.Threading.Monitor.TryEnter(_lock2)) return;
            try
            {
                _doc2 = null;
                try { _stream2?.Dispose(); } catch { }
                _stream2 = null;
                try { _src2?.Dispose(); } catch { }
                _src2 = null;
            }
            finally { System.Threading.Monitor.Exit(_lock2); }
        }

        /// <summary>Быстрый путь для экрана: пиксели BMP читаются прямо в итоговый массив, без декодера и лишних копий.</summary>
        private PagePixels RenderPixelsCore(int index, double scale, Rect? region, string mode, int rotation)
        {
            if (!Plan(index, ref scale, region, out var src, out var w, out var h)) return null;
            using (var outStream = new WinStreams.InMemoryRandomAccessStream())
            {
                if (!RenderTo(outStream, index, src, region.HasValue, w, h)) return null;
                long len = (long)outStream.Size;
                outStream.Seek(0);
                using (var s = outStream.AsStream())
                {
                    var px = PagePixels.ReadBmp(s, len, mode, rotation);
                    if (px != null) return px;
                    // необычный вариант BMP — обычный декодер
                    s.Position = 0;
                    var dec = BitmapDecoder.Create(s, BitmapCreateOptions.PreservePixelFormat | BitmapCreateOptions.IgnoreColorProfile, BitmapCacheOption.OnLoad);
                    return PagePixels.From(dec.Frames[0], mode, rotation);
                }
            }
        }

        private BitmapSource RenderCore(int index, double scale, Rect? region)
        {
            if (!Plan(index, ref scale, region, out var src, out var w, out var h)) return null;
            using (var outStream = new WinStreams.InMemoryRandomAccessStream())
            {
                if (!RenderTo(outStream, index, src, region.HasValue, w, h)) return null;
                outStream.Seek(0);
                using (var s = outStream.AsStream())
                {
                    var dec = BitmapDecoder.Create(s, BitmapCreateOptions.PreservePixelFormat | BitmapCreateOptions.IgnoreColorProfile, BitmapCacheOption.OnLoad);
                    // страница PDF непрозрачна: сразу родной для WPF формат Bgr32, одна копия в памяти
                    return BitmapUtil.Prepare(dec.Frames[0], "normal", true);
                }
            }
        }

        protected override IReadOnlyList<PageChar> GetPageCharsCore(int index)
        {
            if (_pigFailed || index < 0 || index >= PageCount) return Array.Empty<PageChar>();
            lock (_charCache)
                if (_charCache.TryGetValue(index, out var cached)) return cached;

            var list = new List<PageChar>();
            lock (_pigLock)
            {
                var pig = EnsurePig();
                if (pig == null) return Array.Empty<PageChar>();
                var page = pig.GetPage(index + 1);
                var sz = GetPageSize(index);
                int rot = _rot[index];
                // размеры неповёрнутой страницы в пунктах
                double Wpt = (rot == 90 || rot == 270 ? sz.Height : sz.Width) * 72.0 / 96.0;
                double Hpt = (rot == 90 || rot == 270 ? sz.Width : sz.Height) * 72.0 / 96.0;
                double k = 96.0 / 72.0;
                foreach (var letter in page.Letters)
                {
                    var v = letter.Value;
                    if (string.IsNullOrEmpty(v)) continue;
                    var g = letter.GlyphRectangle;
                    double l = g.Left, r = g.Right, b = g.Bottom, t = g.Top;
                    if (r - l <= 0.01 || t - b <= 0.01)
                    {
                        // нулевая рамка (пробел) — оцениваем по базовой линии
                        l = letter.StartBaseLine.X; r = letter.EndBaseLine.X;
                        b = letter.StartBaseLine.Y - letter.PointSize * 0.2; t = letter.StartBaseLine.Y + letter.PointSize * 0.8;
                        if (r <= l) r = l + letter.PointSize * 0.3;
                    }
                    var p1 = Map(l, b, rot, Wpt, Hpt); var p2 = Map(r, t, rot, Wpt, Hpt);
                    var rect = new Rect(new Point(p1.X * k, p1.Y * k), new Point(p2.X * k, p2.Y * k));
                    if (v.Length == 1) list.Add(new PageChar(v[0], rect));
                    else
                    {
                        double cw = rect.Width / v.Length;
                        for (int i = 0; i < v.Length; i++)
                            list.Add(new PageChar(v[i], new Rect(rect.X + cw * i, rect.Y, cw, rect.Height)));
                    }
                }
            }
            lock (_charCache)
            {
                if (_charCache.Count > 24) _charCache.Clear();
                _charCache[index] = list;
            }
            return list;
        }

        private static Point Map(double x, double y, int rot, double W, double H)
        {
            switch (rot)
            {
                case 90: return new Point(y, x);
                case 180: return new Point(W - x, y);
                case 270: return new Point(H - y, W - x);
                default: return new Point(x, H - y);
            }
        }

        /// <summary>Метаданные и оглавление — в промежуточные поля (переносятся в UI-потоке в ApplyCompletedLoading).</summary>
        private void StageMetadata()
        {
            var doc = new InfoSection("Документ PDF");
            try
            {
                if (_pig != null)
                {
                    var inf = _pig.Information;
                    _stagedTitle = inf.Title; _stagedAuthor = inf.Author;
                    doc.Add("Заголовок", inf.Title);
                    doc.Add("Автор", inf.Author);
                    doc.Add("Тема", inf.Subject);
                    doc.Add("Ключевые слова", inf.Keywords);
                    doc.Add("Создано в программе", inf.Creator);
                    doc.Add("PDF-производитель", inf.Producer);
                    doc.Add("Дата создания", PdfDate(inf.CreationDate));
                    doc.Add("Дата изменения", PdfDate(inf.ModifiedDate));
                    doc.Add("Версия PDF", _pig.Version.ToString("0.0", CultureInfo.InvariantCulture));
                    doc.Add("Зашифрован", _pig.IsEncrypted ? "Да" : "Нет");
                }
                var d = _doc;
                if (d != null) doc.Add("Защита паролем", d.IsPasswordProtected ? "Да" : "Нет");
            }
            catch { }
            _stagedDocInfo = doc;

            var toc = new List<TocItem>();
            if (_pig != null)
            {
                try
                {
                    if (_pig.TryGetBookmarks(out var bm) && bm != null)
                        foreach (var node in bm.Roots) AddBookmark(node, toc, 0);
                }
                catch { }
            }
            _stagedToc = toc;
        }

        private InfoSection BuildPagesSection()
        {
            var pages = new InfoSection("Страницы");
            pages.Add("Количество страниц", PageCount);
            var groups = _sizes.GroupBy(s => PaperName(s)).OrderByDescending(g => g.Count()).Take(6);
            foreach (var g in groups) pages.Add("Формат: " + g.Key, g.Count() + " стр.");
            int rotated = _rot.Count(r => r != 0);
            if (rotated > 0) pages.Add("Повёрнутых страниц", rotated);
            return pages;
        }

        /// <summary>
        /// Статистика содержимого (шрифты, изображения, аннотации) — собирается только при открытии окна свойств,
        /// чтобы не разбирать десятки страниц и не занимать память при каждом открытии документа.
        /// </summary>
        public override void LoadDetails()
        {
            if (_detailsLoaded) return;
            _detailsLoaded = true;
            try
            {
                var content = new InfoSection("Содержимое");
                var fonts = new HashSet<string>();
                int images = 0, letters = 0, annots = 0, links = 0;
                int scan = Math.Min(PageCount, 40);
                lock (_pigLock)
                {
                    var pig = EnsurePig();
                    if (pig == null) return;
                    for (int i = 1; i <= scan; i++)
                    {
                        var p = pig.GetPage(i);
                        foreach (var l in p.Letters) { letters++; if (!string.IsNullOrEmpty(l.FontName)) fonts.Add(CleanFont(l.FontName)); }
                        try { images += p.GetImages().Count(); } catch { }
                        try
                        {
                            foreach (var an in p.ExperimentalAccess.GetAnnotations())
                            {
                                annots++;
                                if (an.Type == UglyToad.PdfPig.Annotations.AnnotationType.Link) links++;
                            }
                        }
                        catch { }
                    }
                }
                string suffix = scan < PageCount ? $" (первые {scan} стр.)" : "";
                content.Add("Символов текста" + suffix, letters);
                content.Add("Изображений" + suffix, images);
                content.Add("Аннотаций" + suffix, annots);
                content.Add("Ссылок" + suffix, links);
                content.Add("Текстовый слой", letters > 0 ? "Есть" : "Нет (скан — используйте OCR)");
                content.Add("Шрифты", fonts.Count == 0 ? "—" : string.Join(", ", fonts.OrderBy(f => f).Take(40)));
                lock (Info) Info.Add(content);
            }
            catch { }
        }

        private void AddBookmark(Pig.Outline.BookmarkNode node, List<TocItem> target, int level)
        {
            if (level > 8) return;
            var item = new TocItem { Title = node.Title, Level = level, PageIndex = -1 };
            if (node is Pig.Outline.DocumentBookmarkNode dn) item.PageIndex = Math.Max(0, dn.PageNumber - 1);
            target.Add(item);
            foreach (var c in node.Children) AddBookmark(c, item.Children, level + 1);
        }

        private static string CleanFont(string f)
        {
            int plus = f.IndexOf('+');
            if (plus == 6) f = f.Substring(7);
            return f;
        }

        public static string PdfDate(string s)
        {
            if (string.IsNullOrWhiteSpace(s)) return null;
            var t = s.Trim();
            if (t.StartsWith("D:")) t = t.Substring(2);
            if (t.Length >= 14 && DateTime.TryParseExact(t.Substring(0, 14), "yyyyMMddHHmmss", CultureInfo.InvariantCulture, DateTimeStyles.None, out var dt))
                return dt.ToString("dd.MM.yyyy HH:mm:ss");
            if (t.Length >= 8 && DateTime.TryParseExact(t.Substring(0, 8), "yyyyMMdd", CultureInfo.InvariantCulture, DateTimeStyles.None, out dt))
                return dt.ToString("dd.MM.yyyy");
            return s;
        }

        public static string PaperName(Size dip)
        {
            double wmm = dip.Width / 96 * 25.4, hmm = dip.Height / 96 * 25.4;
            double a = Math.Min(wmm, hmm), b = Math.Max(wmm, hmm);
            string orient = wmm > hmm ? " альбомная" : "";
            (string n, double w, double h)[] std = {
                ("A3", 297, 420), ("A4", 210, 297), ("A5", 148, 210), ("A6", 105, 148), ("B5", 176, 250),
                ("Letter", 215.9, 279.4), ("Legal", 215.9, 355.6), ("Tabloid", 279.4, 431.8) };
            foreach (var p in std)
                if (Math.Abs(a - p.w) < 3 && Math.Abs(b - p.h) < 3) return p.n + orient;
            return $"{wmm:0}×{hmm:0} мм";
        }

        private void ReleaseStreams()
        {
            try { _stream?.Dispose(); } catch { }
            _stream = null;
            try { _renderSource?.Dispose(); } catch { }
            _renderSource = null;
        }

        public override void Dispose()
        {
            _disposed = true;
            _secDisabled = true;
            ReleaseSecondary();
            lock (_pigLock)
            {
                try { _pig?.Dispose(); } catch { }
                _pig = null;
                try { _pigSource?.Dispose(); } catch { }
                _pigSource = null;
                _pigFailed = true;
            }
            lock (_lock)
            {
                _doc = null;
                ReleaseStreams();
                _file?.Dispose();
                _file = null;
            }
            lock (_charCache) _charCache.Clear();
            base.Dispose();
        }
    }
}
