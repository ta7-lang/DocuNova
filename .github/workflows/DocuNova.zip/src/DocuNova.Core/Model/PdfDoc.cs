using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Media.Imaging;
using WinPdf = global::Windows.Data.Pdf;
using WinStreams = global::Windows.Storage.Streams;
using Pig = UglyToad.PdfPig;

namespace DocuNova.Core
{
    /// <summary>
    /// PDF: отрисовка встроенным в Windows движком Windows.Data.Pdf (без JavaScript, без сети),
    /// текстовый слой и метаданные — управляемой библиотекой PdfPig (безопасна по памяти).
    /// </summary>
    public sealed class PdfDoc : DocumentBase
    {
        private WinPdf.PdfDocument _doc;
        private WinStreams.InMemoryRandomAccessStream _stream;
        private Pig.PdfDocument _pig;
        private readonly object _lock = new object();
        private readonly object _pigLock = new object();
        private Size[] _sizes;
        private int[] _rot;
        private readonly Dictionary<int, List<PageChar>> _charCache = new Dictionary<int, List<PageChar>>();
        public string Password { get; private set; }

        public override int PageCount => _sizes?.Length ?? 0;
        public override bool CanRenderOffThread => true;
        public override bool IsPdf => true;

        /// <summary>
        /// WinRT-операции выполняются в MTA-потоке: блокирующее ожидание асинхронных операций
        /// в STA-потоке (UI, эскизы Проводника) могло бы привести к взаимоблокировке.
        /// </summary>
        private static T OnMta<T>(Func<T> f)
        {
            if (System.Threading.Thread.CurrentThread.GetApartmentState() == System.Threading.ApartmentState.STA)
                return System.Threading.Tasks.Task.Run(f).GetAwaiter().GetResult();
            return f();
        }

        public static PdfDoc Open(byte[] bytes, string password, bool light) => OnMta(() => OpenCore(bytes, password, light));

        private static PdfDoc OpenCore(byte[] bytes, string password, bool light)
        {
            var d = new PdfDoc { Kind = DocKind.Fixed, Bytes = bytes, Password = password };
            d._stream = new WinStreams.InMemoryRandomAccessStream();
            using (var w = new WinStreams.DataWriter(d._stream.GetOutputStreamAt(0)))
            {
                w.WriteBytes(bytes);
                w.StoreAsync().AsTask().GetAwaiter().GetResult();
                w.FlushAsync().AsTask().GetAwaiter().GetResult();
                w.DetachStream();
            }
            d._stream.Seek(0);
            try
            {
                d._doc = string.IsNullOrEmpty(password)
                    ? WinPdf.PdfDocument.LoadFromStreamAsync(d._stream).AsTask().GetAwaiter().GetResult()
                    : WinPdf.PdfDocument.LoadFromStreamAsync(d._stream, password).AsTask().GetAwaiter().GetResult();
            }
            catch (Exception ex)
            {
                int hr = ex.HResult;
                // 0x8007052B = ERROR_WRONG_PASSWORD
                if (hr == unchecked((int)0x8007052B) || ex.Message.IndexOf("password", StringComparison.OrdinalIgnoreCase) >= 0)
                    throw new PasswordRequiredException(!string.IsNullOrEmpty(password));
                throw new UnsupportedFormatException("PDF повреждён или не поддерживается: " + ex.Message);
            }

            int n = (int)d._doc.PageCount;
            d._sizes = new Size[n];
            d._rot = new int[n];
            for (int i = 0; i < n; i++)
            {
                if (light && i > 0) { d._sizes[i] = d._sizes[0]; continue; }
                using (var p = d._doc.GetPage((uint)i))
                {
                    var s = p.Size;
                    d._sizes[i] = new Size(Math.Max(1, s.Width), Math.Max(1, s.Height));
                    switch (p.Rotation)
                    {
                        case WinPdf.PdfPageRotation.Rotate90: d._rot[i] = 90; break;
                        case WinPdf.PdfPageRotation.Rotate180: d._rot[i] = 180; break;
                        case WinPdf.PdfPageRotation.Rotate270: d._rot[i] = 270; break;
                        default: d._rot[i] = 0; break;
                    }
                }
            }

            if (!light)
            {
                try
                {
                    var opts = new Pig.ParsingOptions { UseLenientParsing = true };
                    if (!string.IsNullOrEmpty(password)) opts.Password = password;
                    d._pig = Pig.PdfDocument.Open(bytes, opts);
                }
                catch
                {
                    d._pig = null;
                    d.Notices.Add("Текстовый слой PDF не удалось прочитать — поиск и копирование текста недоступны (можно распознать текст через OCR).");
                }
                d.ReadMetadata();
            }
            return d;
        }

        public override Size GetPageSize(int index) => _sizes[Math.Max(0, Math.Min(index, _sizes.Length - 1))];

        public override BitmapSource RenderPage(int index, double scale) => OnMta(() => RenderCore(index, scale));

        private BitmapSource RenderCore(int index, double scale)
        {
            var size = GetPageSize(index);
            scale = VisualTools.ClampScale(size, scale);
            uint w = (uint)Math.Max(1, Math.Round(size.Width * scale));
            uint h = (uint)Math.Max(1, Math.Round(size.Height * scale));
            byte[] png;
            lock (_lock)
            {
                using (var page = _doc.GetPage((uint)index))
                using (var outStream = new WinStreams.InMemoryRandomAccessStream())
                {
                    var opts = new WinPdf.PdfPageRenderOptions
                    {
                        DestinationWidth = w,
                        DestinationHeight = h
                    };
                    page.RenderToStreamAsync(outStream, opts).AsTask().GetAwaiter().GetResult();
                    png = ReadAll(outStream);
                }
            }
            using (var ms = new MemoryStream(png, false))
            {
                var dec = BitmapDecoder.Create(ms, BitmapCreateOptions.PreservePixelFormat | BitmapCreateOptions.IgnoreColorProfile, BitmapCacheOption.OnLoad);
                var f = dec.Frames[0];
                f.Freeze();
                return f;
            }
        }

        private static byte[] ReadAll(WinStreams.InMemoryRandomAccessStream s)
        {
            ulong size = s.Size;
            var result = new byte[size];
            s.Seek(0);
            using (var r = new WinStreams.DataReader(s.GetInputStreamAt(0)))
            {
                r.LoadAsync((uint)size).AsTask().GetAwaiter().GetResult();
                r.ReadBytes(result);
                r.DetachStream();
            }
            return result;
        }

        protected override IReadOnlyList<PageChar> GetPageCharsCore(int index)
        {
            if (_pig == null) return Array.Empty<PageChar>();
            lock (_charCache)
                if (_charCache.TryGetValue(index, out var cached)) return cached;

            var list = new List<PageChar>();
            lock (_pigLock)
            {
                var page = _pig.GetPage(index + 1);
                var sz = GetPageSize(index);
                int rot = _rot[index];
                // размеры неповёрнутой страницы в пунктах
                double Wpt = (rot == 90 || rot == 270 ? sz.Height : sz.Width) * 72.0 / 96.0;
                double Hpt = (rot == 90 || rot == 270 ? sz.Width : sz.Height) * 72.0 / 96.0;
                double k = 96.0 / 72.0;
                foreach (var letter in page.Letters)
                {
                    var v = letter.Value;
                    if (string.IsNullOrEmpty(v)) continue;
                    var g = letter.GlyphRectangle;
                    double l = g.Left, r = g.Right, b = g.Bottom, t = g.Top;
                    if (r - l <= 0.01 || t - b <= 0.01)
                    {
                        // нулевая рамка (пробел) — оцениваем по базовой линии
                        l = letter.StartBaseLine.X; r = letter.EndBaseLine.X;
                        b = letter.StartBaseLine.Y - letter.PointSize * 0.2; t = letter.StartBaseLine.Y + letter.PointSize * 0.8;
                        if (r <= l) r = l + letter.PointSize * 0.3;
                    }
                    var p1 = Map(l, b, rot, Wpt, Hpt); var p2 = Map(r, t, rot, Wpt, Hpt);
                    var rect = new Rect(new Point(p1.X * k, p1.Y * k), new Point(p2.X * k, p2.Y * k));
                    if (v.Length == 1) list.Add(new PageChar(v[0], rect));
                    else
                    {
                        double cw = rect.Width / v.Length;
                        for (int i = 0; i < v.Length; i++)
                            list.Add(new PageChar(v[i], new Rect(rect.X + cw * i, rect.Y, cw, rect.Height)));
                    }
                }
            }
            lock (_charCache)
            {
                if (_charCache.Count > 60) _charCache.Clear();
                _charCache[index] = list;
            }
            return list;
        }

        private static Point Map(double x, double y, int rot, double W, double H)
        {
            switch (rot)
            {
                case 90: return new Point(y, x);
                case 180: return new Point(W - x, y);
                case 270: return new Point(H - y, W - x);
                default: return new Point(x, H - y);
            }
        }

        private void ReadMetadata()
        {
            var doc = new InfoSection("Документ PDF");
            try
            {
                if (_pig != null)
                {
                    var inf = _pig.Information;
                    Title = inf.Title; Author = inf.Author;
                    doc.Add("Заголовок", inf.Title);
                    doc.Add("Автор", inf.Author);
                    doc.Add("Тема", inf.Subject);
                    doc.Add("Ключевые слова", inf.Keywords);
                    doc.Add("Создано в программе", inf.Creator);
                    doc.Add("PDF-производитель", inf.Producer);
                    doc.Add("Дата создания", PdfDate(inf.CreationDate));
                    doc.Add("Дата изменения", PdfDate(inf.ModifiedDate));
                    doc.Add("Версия PDF", _pig.Version.ToString("0.0", CultureInfo.InvariantCulture));
                    doc.Add("Зашифрован", _pig.IsEncrypted ? "Да" : "Нет");
                }
                doc.Add("Защита паролем", _doc.IsPasswordProtected ? "Да" : "Нет");
            }
            catch { }
            Info.Add(doc);

            var pages = new InfoSection("Страницы");
            pages.Add("Количество страниц", PageCount);
            var groups = _sizes.GroupBy(s => PaperName(s)).OrderByDescending(g => g.Count()).Take(6);
            foreach (var g in groups) pages.Add("Формат: " + g.Key, g.Count() + " стр.");
            int rotated = _rot.Count(r => r != 0);
            if (rotated > 0) pages.Add("Повёрнутых страниц", rotated);
            Info.Add(pages);

            if (_pig != null)
            {
                try
                {
                    var content = new InfoSection("Содержимое");
                    var fonts = new HashSet<string>();
                    int images = 0, letters = 0, annots = 0, links = 0;
                    int scan = Math.Min(PageCount, 40);
                    lock (_pigLock)
                    {
                        for (int i = 1; i <= scan; i++)
                        {
                            var p = _pig.GetPage(i);
                            foreach (var l in p.Letters) { letters++; if (!string.IsNullOrEmpty(l.FontName)) fonts.Add(CleanFont(l.FontName)); }
                            try { images += p.GetImages().Count(); } catch { }
                            try
                            {
                                foreach (var a in p.ExperimentalAccess.GetAnnotations())
                                {
                                    annots++;
                                    if (a.Type == UglyToad.PdfPig.Annotations.AnnotationType.Link) links++;
                                }
                            }
                            catch { }
                        }
                    }
                    string suffix = scan < PageCount ? $" (первые {scan} стр.)" : "";
                    content.Add("Символов текста" + suffix, letters);
                    content.Add("Изображений" + suffix, images);
                    content.Add("Аннотаций" + suffix, annots);
                    content.Add("Ссылок" + suffix, links);
                    content.Add("Текстовый слой", letters > 0 ? "Есть" : "Нет (скан — используйте OCR)");
                    content.Add("Шрифты", fonts.Count == 0 ? "—" : string.Join(", ", fonts.OrderBy(f => f).Take(40)));
                    Info.Add(content);
                }
                catch { }

                try { ReadOutline(); } catch { }
            }
        }

        private void ReadOutline()
        {
            if (!_pig.TryGetBookmarks(out var bm) || bm == null) return;
            foreach (var node in bm.Roots) AddBookmark(node, Toc, 0);
        }

        private void AddBookmark(Pig.Outline.BookmarkNode node, List<TocItem> target, int level)
        {
            if (level > 8) return;
            var item = new TocItem { Title = node.Title, Level = level, PageIndex = -1 };
            if (node is Pig.Outline.DocumentBookmarkNode dn) item.PageIndex = Math.Max(0, dn.PageNumber - 1);
            target.Add(item);
            foreach (var c in node.Children) AddBookmark(c, item.Children, level + 1);
        }

        private static string CleanFont(string f)
        {
            int plus = f.IndexOf('+');
            if (plus == 6) f = f.Substring(7);
            return f;
        }

        public static string PdfDate(string s)
        {
            if (string.IsNullOrWhiteSpace(s)) return null;
            var t = s.Trim();
            if (t.StartsWith("D:")) t = t.Substring(2);
            if (t.Length >= 14 && DateTime.TryParseExact(t.Substring(0, 14), "yyyyMMddHHmmss", CultureInfo.InvariantCulture, DateTimeStyles.None, out var dt))
                return dt.ToString("dd.MM.yyyy HH:mm:ss");
            if (t.Length >= 8 && DateTime.TryParseExact(t.Substring(0, 8), "yyyyMMdd", CultureInfo.InvariantCulture, DateTimeStyles.None, out dt))
                return dt.ToString("dd.MM.yyyy");
            return s;
        }

        public static string PaperName(Size dip)
        {
            double wmm = dip.Width / 96 * 25.4, hmm = dip.Height / 96 * 25.4;
            double a = Math.Min(wmm, hmm), b = Math.Max(wmm, hmm);
            string orient = wmm > hmm ? " альбомная" : "";
            (string n, double w, double h)[] std = {
                ("A3", 297, 420), ("A4", 210, 297), ("A5", 148, 210), ("A6", 105, 148), ("B5", 176, 250),
                ("Letter", 215.9, 279.4), ("Legal", 215.9, 355.6), ("Tabloid", 279.4, 431.8) };
            foreach (var p in std)
                if (Math.Abs(a - p.w) < 3 && Math.Abs(b - p.h) < 3) return p.n + orient;
            return $"{wmm:0}×{hmm:0} мм";
        }

        public override void Dispose()
        {
            lock (_lock)
            {
                try { _pig?.Dispose(); } catch { }
                _pig = null;
                _doc = null;
                try { _stream?.Dispose(); } catch { }
                _stream = null;
            }
            _charCache.Clear();
            base.Dispose();
        }
    }
}
