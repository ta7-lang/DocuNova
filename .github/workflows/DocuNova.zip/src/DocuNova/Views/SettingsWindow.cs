using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using DocuNova.Services;
using DocuNova.Themes;

namespace DocuNova.Views
{
    /// <summary>Настройки: темы и их кастомизация, чтение, вид, интеграция и кэш, безопасность.</summary>
    public sealed class SettingsWindow : ThemedWindow
    {
        private AppSettings S => App.Settings;
        private readonly WrapPanel _gallery = new WrapPanel();
        private ThemeDef _edit;
        private readonly List<Action> _refreshEditor = new List<Action>();
        private TextBlock _preview;

        public SettingsWindow(int tab)
        {
            Heading = "Настройки DocuNova";
            Width = 860; Height = 720; MinWidth = 640; MinHeight = 480;
            _edit = (S.CustomTheme ?? ThemeManager.Current).Clone();

            var dock = new DockPanel { Margin = new Thickness(16, 0, 16, 14) };
            var buttons = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right, Margin = new Thickness(0, 10, 0, 0) };
            var ok = MakeButton("Готово", true); ok.IsDefault = true; ok.Click += (s, e) => Close();
            buttons.Children.Add(ok);
            DockPanel.SetDock(buttons, Dock.Bottom);
            dock.Children.Add(buttons);

            var tabs = new TabControl();
            tabs.Items.Add(new TabItem { Header = "Оформление", Content = Scroll(AppearanceTab()) });
            tabs.Items.Add(new TabItem { Header = "Чтение книг", Content = Scroll(ReadingTab()) });
            tabs.Items.Add(new TabItem { Header = "Просмотр", Content = Scroll(ViewTab()) });
            tabs.Items.Add(new TabItem { Header = "Проводник и кэш", Content = Scroll(IntegrationTab()) });
            tabs.Items.Add(new TabItem { Header = "Безопасность", Content = Scroll(SecurityTab()) });
            tabs.SelectedIndex = Math.Max(0, Math.Min(4, tab));
            dock.Children.Add(tabs);
            Body.Children.Add(dock);
            Closed += (s, e) => S.Save();
        }

        private static ScrollViewer Scroll(UIElement c) => new ScrollViewer { Content = c, VerticalScrollBarVisibility = ScrollBarVisibility.Auto, Padding = new Thickness(0, 4, 8, 0) };

        private static TextBlock SectionHead(string t)
        {
            var tb = new TextBlock { Text = t };
            tb.SetResourceReference(StyleProperty, "SectionTitle");
            return tb;
        }

        private static TextBlock Hint(string t)
        {
            var tb = new TextBlock { Text = t, Margin = new Thickness(0, 0, 0, 6) };
            tb.SetResourceReference(StyleProperty, "Hint");
            return tb;
        }

        private static Border Card(UIElement content)
        {
            var b = new Border { Child = content, Margin = new Thickness(0, 4, 0, 8) };
            b.SetResourceReference(StyleProperty, "Card");
            return b;
        }

        private static FrameworkElement SliderRow(string label, double min, double max, double value, string fmt, Action<double> changed, string tip = null)
        {
            var g = new Grid { Margin = new Thickness(0, 4, 0, 4) };
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(220) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(70) });
            var l = new TextBlock { Text = label, VerticalAlignment = VerticalAlignment.Center, ToolTip = tip };
            var sl = new Slider { Minimum = min, Maximum = max, Value = Math.Max(min, Math.Min(max, value)), ToolTip = tip };
            var v = new TextBlock { VerticalAlignment = VerticalAlignment.Center, HorizontalAlignment = HorizontalAlignment.Right, Text = sl.Value.ToString(fmt) };
            v.SetResourceReference(TextBlock.ForegroundProperty, "SubFgBrush");
            sl.ValueChanged += (s, e) => { v.Text = sl.Value.ToString(fmt); changed(sl.Value); };
            Grid.SetColumn(sl, 1); Grid.SetColumn(v, 2);
            g.Children.Add(l); g.Children.Add(sl); g.Children.Add(v);
            return g;
        }

        private static CheckBox Check(string text, bool value, Action<bool> changed, string tip = null)
        {
            var c = new CheckBox { Content = text, IsChecked = value, ToolTip = tip };
            c.Checked += (s, e) => changed(true);
            c.Unchecked += (s, e) => changed(false);
            return c;
        }

        // ===================== Оформление =====================

        private UIElement AppearanceTab()
        {
            var sp = new StackPanel();
            sp.Children.Add(SectionHead("Готовые темы"));
            sp.Children.Add(Hint("Щёлкните по теме — она применится сразу. Неоновые темы светятся градиентами и мягким свечением кнопок."));
            BuildGallery();
            sp.Children.Add(_gallery);

            sp.Children.Add(SectionHead("Своя тема"));
            sp.Children.Add(Hint("Настройте любые цвета, градиент фона, силу неонового свечения и скругление углов. Изменения видны сразу."));
            var editor = new StackPanel();
            editor.Children.Add(ColorRow("Фон — начало градиента", () => _edit.Bg1, v => _edit.Bg1 = v));
            editor.Children.Add(ColorRow("Фон — конец градиента", () => _edit.Bg2, v => _edit.Bg2 = v));
            editor.Children.Add(ColorRow("Панели", () => _edit.Panel, v => _edit.Panel = v));
            editor.Children.Add(ColorRow("Область документа", () => _edit.ViewerBg, v => _edit.ViewerBg = v));
            editor.Children.Add(ColorRow("Текст", () => _edit.Text, v => _edit.Text = v));
            editor.Children.Add(ColorRow("Второстепенный текст", () => _edit.SubText, v => _edit.SubText = v));
            editor.Children.Add(ColorRow("Акцент 1 (неон)", () => _edit.Accent1, v => _edit.Accent1 = v));
            editor.Children.Add(ColorRow("Акцент 2 (неон)", () => _edit.Accent2, v => _edit.Accent2 = v));
            editor.Children.Add(SliderRow("Сила свечения", 0, 1, _edit.Glow, "P0", v => { _edit.Glow = v; ApplyEdit(); }, "Яркость неонового ореола вокруг кнопок и заголовков"));
            editor.Children.Add(SliderRow("Скругление углов", 0, 22, _edit.Radius, "0", v => { _edit.Radius = v; ApplyEdit(); }));
            editor.Children.Add(SliderRow("Угол градиента фона", 0, 360, _edit.GradientAngle, "0°", v => { _edit.GradientAngle = v; ApplyEdit(); }));
            editor.Children.Add(SliderRow("Непрозрачность панелей", 0.4, 1, _edit.PanelOpacity, "P0", v => { _edit.PanelOpacity = v; ApplyEdit(); }));
            editor.Children.Add(Check("Тёмная тема (влияет на тени и поля ввода)", _edit.IsDark, v => { _edit.IsDark = v; ApplyEdit(); }));
            var row = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 8, 0, 0) };
            var fromCurrent = MakeButton("Взять за основу текущую тему", false);
            fromCurrent.Click += (s, e) => { _edit = ThemeManager.Current.Clone(); _edit.Name = "Своя тема"; foreach (var a in _refreshEditor) a(); ApplyEdit(); };
            var reset = MakeButton("Сбросить к стандартной", false);
            reset.Click += (s, e) =>
            {
                S.CustomTheme = null; S.ThemeName = ThemeManager.Presets[0].Name;
                ThemeManager.Apply(ThemeManager.Presets[0]); _edit = ThemeManager.Presets[0].Clone(); _edit.Name = "Своя тема";
                foreach (var a in _refreshEditor) a();
                BuildGallery();
            };
            row.Children.Add(fromCurrent); row.Children.Add(reset);
            editor.Children.Add(row);
            sp.Children.Add(Card(editor));
            return sp;
        }

        private void BuildGallery()
        {
            _gallery.Children.Clear();
            var all = ThemeManager.Presets.ToList();
            if (S.CustomTheme != null) all.Add(S.CustomTheme);
            foreach (var t in all)
            {
                var theme = t;
                bool selected = S.ThemeName == t.Name;
                var bg1 = ThemeManager.C(t.Bg1, Colors.Black); var bg2 = ThemeManager.C(t.Bg2, Colors.Black);
                var a1 = ThemeManager.C(t.Accent1, Colors.Magenta); var a2 = ThemeManager.C(t.Accent2, Colors.Cyan);
                var card = new Border
                {
                    Width = 156, Height = 98, Margin = new Thickness(0, 0, 10, 10), CornerRadius = new CornerRadius(12), Cursor = Cursors.Hand,
                    Background = ThemeManager.Gradient(bg1, bg2, t.GradientAngle), BorderThickness = new Thickness(selected ? 3 : 1),
                    ToolTip = t.Name
                };
                card.BorderBrush = selected ? (Brush)ThemeManager.Gradient(a1, a2, 0) : new SolidColorBrush(Color.FromArgb(90, 128, 128, 128));
                if (selected) card.Effect = new System.Windows.Media.Effects.DropShadowEffect { Color = a1, BlurRadius = 18, ShadowDepth = 0, Opacity = 0.8 };
                var g = new Grid { Margin = new Thickness(12) };
                var bar = new Border { Height = 10, CornerRadius = new CornerRadius(5), VerticalAlignment = VerticalAlignment.Top, Background = ThemeManager.Gradient(a1, a2, 0), Margin = new Thickness(0, 4, 30, 0) };
                bar.Effect = new System.Windows.Media.Effects.DropShadowEffect { Color = a1, BlurRadius = 10 * t.Glow + 1, ShadowDepth = 0, Opacity = t.Glow };
                var bar2 = new Border { Height = 6, CornerRadius = new CornerRadius(3), VerticalAlignment = VerticalAlignment.Top, Background = new SolidColorBrush(Color.FromArgb(110, ThemeManager.C(t.Text, Colors.White).R, ThemeManager.C(t.Text, Colors.White).G, ThemeManager.C(t.Text, Colors.White).B)), Margin = new Thickness(0, 22, 60, 0) };
                var name = new TextBlock { Text = t.Name, VerticalAlignment = VerticalAlignment.Bottom, FontWeight = FontWeights.SemiBold, Foreground = new SolidColorBrush(ThemeManager.C(t.Text, Colors.White)), TextTrimming = TextTrimming.CharacterEllipsis };
                g.Children.Add(bar); g.Children.Add(bar2); g.Children.Add(name);
                card.Child = g;
                card.MouseLeftButtonUp += (s, e) =>
                {
                    S.ThemeName = theme.Name;
                    ThemeManager.Apply(theme);
                    BuildGallery();
                };
                _gallery.Children.Add(card);
            }
        }

        private void ApplyEdit()
        {
            _edit.Name = "Своя тема";
            S.CustomTheme = _edit.Clone();
            S.ThemeName = "Своя тема";
            ThemeManager.Apply(S.CustomTheme);
            BuildGallery();
        }

        private FrameworkElement ColorRow(string label, Func<string> get, Action<string> set)
        {
            var g = new Grid { Margin = new Thickness(0, 3, 0, 3) };
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(220) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(120) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            var l = new TextBlock { Text = label, VerticalAlignment = VerticalAlignment.Center };
            var sw = new Border { Width = 46, Height = 26, CornerRadius = new CornerRadius(6), BorderThickness = new Thickness(1), Cursor = Cursors.Hand, ToolTip = "Выбрать цвет в палитре", Margin = new Thickness(0, 0, 8, 0) };
            sw.SetResourceReference(Border.BorderBrushProperty, "DividerBrush");
            var box = new TextBox { Height = 28, Padding = new Thickness(6, 2, 6, 2), FontFamily = new FontFamily("Consolas") };
            bool updating = false;
            void Refresh()
            {
                updating = true;
                var c = ThemeManager.C(get(), Colors.Black);
                sw.Background = new SolidColorBrush(c);
                box.Text = $"#{c.R:X2}{c.G:X2}{c.B:X2}";
                updating = false;
            }
            _refreshEditor.Add(Refresh);
            Refresh();
            box.LostKeyboardFocus += (s, e) =>
            {
                if (updating) return;
                var t = box.Text.Trim();
                if (!t.StartsWith("#")) t = "#" + t;
                try { if (ColorConverter.ConvertFromString(t) is Color) { set(t); Refresh(); ApplyEdit(); } else Refresh(); }
                catch { Refresh(); }
            };
            box.KeyDown += (s, e) => { if (e.Key == Key.Enter) Keyboard.ClearFocus(); };
            sw.MouseLeftButtonUp += (s, e) =>
            {
                var c = ThemeManager.C(get(), Colors.Black);
                using (var dlg = new System.Windows.Forms.ColorDialog { FullOpen = true, Color = System.Drawing.Color.FromArgb(c.R, c.G, c.B) })
                {
                    if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                    {
                        set($"#{dlg.Color.R:X2}{dlg.Color.G:X2}{dlg.Color.B:X2}");
                        Refresh();
                        ApplyEdit();
                    }
                }
            };
            Grid.SetColumn(sw, 1); Grid.SetColumn(box, 2);
            g.Children.Add(l); g.Children.Add(sw); g.Children.Add(box);
            return g;
        }

        // ===================== Чтение =====================

        private UIElement ReadingTab()
        {
            var r = S.Reflow;
            var sp = new StackPanel();
            sp.Children.Add(SectionHead("Параметры книг и текстовых документов"));
            sp.Children.Add(Hint("Применяются к EPUB, FB2, MOBI/AZW, TXT, HTML и Markdown: страницы перестраиваются под выбранный шрифт и размер. Документы с собственной вёрсткой (PDF, DOCX, XPS) сохраняют оригинальный вид."));
            var card = new StackPanel();

            var fontRow = new Grid { Margin = new Thickness(0, 4, 0, 4) };
            fontRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(220) });
            fontRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            fontRow.Children.Add(new TextBlock { Text = "Шрифт", VerticalAlignment = VerticalAlignment.Center });
            var fonts = new ComboBox();
            var preferred = new[] { "Georgia", "Cambria", "Constantia", "Times New Roman", "Palatino Linotype", "Book Antiqua", "Segoe UI", "Calibri", "Verdana", "Arial", "Tahoma", "Candara", "Corbel", "Consolas" };
            var installed = new HashSet<string>(Fonts.SystemFontFamilies.Select(f => f.Source), StringComparer.OrdinalIgnoreCase);
            foreach (var f in preferred.Where(installed.Contains)) fonts.Items.Add(f);
            foreach (var f in installed.OrderBy(x => x).Where(x => !preferred.Contains(x)).Take(300)) fonts.Items.Add(f);
            fonts.SelectedItem = fonts.Items.Contains(r.FontFamily) ? r.FontFamily : (fonts.Items.Count > 0 ? fonts.Items[0] : null);
            fonts.SelectionChanged += (s, e) => { if (fonts.SelectedItem is string f) { r.FontFamily = f; UpdatePreview(); } };
            Grid.SetColumn(fonts, 1);
            fontRow.Children.Add(fonts);
            card.Children.Add(fontRow);
            card.Children.Add(SliderRow("Размер шрифта", 10, 40, r.FontSize, "0", v => { r.FontSize = Math.Round(v); UpdatePreview(); }));
            card.Children.Add(SliderRow("Межстрочный интервал", 1.0, 2.4, r.LineHeight, "0.00", v => { r.LineHeight = Math.Round(v, 2); UpdatePreview(); }));
            card.Children.Add(SliderRow("Поля страницы", 12, 120, r.Margin, "0", v => r.Margin = Math.Round(v)));
            card.Children.Add(SliderRow("Ширина страницы", 420, 1100, r.PageWidth, "0", v => { r.PageWidth = Math.Round(v); r.PageHeight = Math.Round(r.PageWidth * 1.38); }, "Высота подбирается автоматически (пропорции книжной страницы)"));
            card.Children.Add(Check("Выравнивание по ширине", r.Justify, v => r.Justify = v));
            card.Children.Add(Check("Автоматические переносы слов", r.Hyphenation, v => r.Hyphenation = v));
            _preview = new TextBlock { TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 10, 0, 0), Padding = new Thickness(18), Background = Brushes.White, Foreground = Brushes.Black,
                Text = "Съешь же ещё этих мягких французских булок, да выпей чаю. — Образец текста книги: так будут выглядеть страницы после применения настроек." };
            card.Children.Add(_preview);
            UpdatePreview();
            sp.Children.Add(Card(card));
            return sp;
        }

        private void UpdatePreview()
        {
            if (_preview == null) return;
            var r = S.Reflow;
            try { _preview.FontFamily = new FontFamily(r.FontFamily); } catch { }
            _preview.FontSize = r.FontSize;
            _preview.LineHeight = r.FontSize * r.LineHeight;
            _preview.TextAlignment = r.Justify ? TextAlignment.Justify : TextAlignment.Left;
        }

        // ===================== Просмотр =====================

        private UIElement ViewTab()
        {
            var sp = new StackPanel();
            sp.Children.Add(SectionHead("Отображение страниц"));
            var card = new StackPanel();
            card.Children.Add(SliderRow("Промежуток между страницами", 0, 60, S.PageGap, "0", v => S.PageGap = Math.Round(v)));
            card.Children.Add(Check("Тени и свечение вокруг страниц", S.PageShadows, v => S.PageShadows = v));
            card.Children.Add(new TextBlock { Text = "Цвет страниц", Margin = new Thickness(0, 10, 0, 4) });
            var modes = new StackPanel { Orientation = Orientation.Horizontal };
            foreach (var (code, name) in new[] { ("normal", "Обычный"), ("night", "Ночной"), ("sepia", "Сепия") })
            {
                var rb = new RadioButton { Content = name, GroupName = "pm", IsChecked = S.PageMode == code };
                rb.SetResourceReference(StyleProperty, "Segment");
                var c = code;
                rb.Checked += (s, e) => S.PageMode = c;
                modes.Children.Add(rb);
            }
            card.Children.Add(modes);
            card.Children.Add(new TextBlock { Text = "Масштаб при открытии", Margin = new Thickness(0, 12, 0, 4) });
            var fits = new StackPanel { Orientation = Orientation.Horizontal };
            foreach (var (code, name) in new[] { ("width", "По ширине"), ("page", "Страница целиком"), ("none", "Как было") })
            {
                var rb = new RadioButton { Content = name, GroupName = "fit", IsChecked = (S.FitMode ?? "width") == code };
                rb.SetResourceReference(StyleProperty, "Segment");
                var c = code;
                rb.Checked += (s, e) => S.FitMode = c;
                fits.Children.Add(rb);
            }
            card.Children.Add(fits);
            card.Children.Add(new TextBlock { Text = "Качество экспорта изображений и PDF (растровые страницы)", Margin = new Thickness(0, 12, 0, 4) });
            var dpis = new StackPanel { Orientation = Orientation.Horizontal };
            foreach (var d in new[] { 150, 200, 300, 450, 600 })
            {
                var rb = new RadioButton { Content = d + " DPI", GroupName = "dpi", IsChecked = S.ExportDpi == d };
                rb.SetResourceReference(StyleProperty, "Segment");
                var dd = d;
                rb.Checked += (s, e) => S.ExportDpi = dd;
                dpis.Children.Add(rb);
            }
            card.Children.Add(dpis);
            sp.Children.Add(Card(card));
            return sp;
        }

        // ===================== Интеграция =====================

        private UIElement IntegrationTab()
        {
            var sp = new StackPanel();
            sp.Children.Add(SectionHead("Эскизы в Проводнике Windows"));
            var regs = ShellIntegration.RegisteredExtensions();
            var status = new StackPanel();
            status.Children.Add(new TextBlock
            {
                Text = regs.Length > 0 ? $"✔ Эскизы DocuNova включены для {regs.Length} типов файлов:" : "Эскизы DocuNova не зарегистрированы (запустите установщик и отметьте пункт «Эскизы в Проводнике»).",
                TextWrapping = TextWrapping.Wrap, FontWeight = FontWeights.SemiBold
            });
            if (regs.Length > 0) status.Children.Add(Hint(string.Join("  ", regs)));
            status.Children.Add(Hint("Эскизы строятся в изолированном процессе Windows: файл передаётся только для чтения, никакие скрипты не выполняются, временные файлы не создаются. Обложки книг (EPUB, FB2, MOBI) показываются как настоящие обложки."));
            var row = new WrapPanel { Margin = new Thickness(0, 6, 0, 0) };
            var clear = MakeButton("Очистить кэш эскизов Windows", true);
            clear.ToolTip = "Удаляет устаревшие и «битые» эскизы. Проводник ненадолго перезапустится, затем эскизы построятся заново.";
            clear.Click += (s, e) =>
            {
                if (MessageBox.Show(this, "Проводник Windows будет перезапущен (окна папок закроются), кэш эскизов будет очищен. Продолжить?", "DocuNova", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes) return;
                Mouse.OverrideCursor = Cursors.Wait;
                int n;
                try { n = ShellIntegration.ClearThumbnailCache(); } finally { Mouse.OverrideCursor = null; }
                MessageBox.Show(this, n > 0 ? $"Кэш эскизов очищен (удалено файлов: {n})." : "Кэш эскизов уже был пуст или используется системой. Попробуйте ещё раз после перезагрузки.", "DocuNova");
            };
            var def = MakeButton("Приложения по умолчанию…", false);
            def.ToolTip = "Открывает параметры Windows, где DocuNova можно выбрать программой по умолчанию для PDF, EPUB, FB2 и других форматов.";
            def.Click += (s, e) => ShellIntegration.OpenDefaultAppsSettings();
            row.Children.Add(clear); row.Children.Add(def);
            status.Children.Add(row);
            sp.Children.Add(Card(status));

            sp.Children.Add(SectionHead("Кэш и следы работы"));
            var cache = new StackPanel();
            cache.Children.Add(Hint("DocuNova не создаёт кэш на диске: страницы отрисовываются в памяти, невидимые страницы сразу выгружаются, после закрытия документа память освобождается полностью. На диске хранится только небольшой файл настроек."));
            cache.Children.Add(Check("Запоминать недавние документы", S.RememberRecent, v => { S.RememberRecent = v; if (!v) S.Recent.Clear(); }));
            cache.Children.Add(Check("Очищать список недавних при выходе", S.ClearRecentOnExit, v => S.ClearRecentOnExit = v));
            var clr = MakeButton("Очистить список недавних сейчас", false);
            clr.HorizontalAlignment = HorizontalAlignment.Left;
            clr.Click += (s, e) => { S.Recent.Clear(); S.Save(); clr.Content = "Список очищен ✓"; };
            cache.Children.Add(clr);
            sp.Children.Add(Card(cache));
            return sp;
        }

        // ===================== Безопасность =====================

        private UIElement SecurityTab()
        {
            var sp = new StackPanel();
            sp.Children.Add(SectionHead("Защищённый просмотр"));
            var c = new StackPanel();
            c.Children.Add(Hint("Эти механизмы всегда включены и не могут быть отключены: DocuNova — только просмотрщик, он не исполняет содержимое документов."));
            foreach (var line in Hardening.Status) c.Children.Add(new TextBlock { Text = line, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 3, 0, 3) });
            sp.Children.Add(Card(c));
            sp.Children.Add(SectionHead("Предупреждения"));
            var w = new StackPanel();
            w.Children.Add(Check("Показывать предупреждение для файлов из Интернета и при подозрительном содержимом", S.WarnInternetFiles, v => S.WarnInternetFiles = v));
            w.Children.Add(Hint("Исполняемые файлы (.exe, .scr и др.), замаскированные под документы, блокируются всегда. Документы с макросами, JavaScript, OLE-объектами, DDE и внешними шаблонами открываются в безопасном режиме — активные элементы вырезаются или игнорируются, а в окне «Свойства → Безопасность» показывается подробный отчёт."));
            sp.Children.Add(Card(w));
            return sp;
        }
    }
}
