using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using DocuNova.Core;
using DocuNova.Services;

namespace DocuNova.Views
{
    /// <summary>Окно свойств: файл, метаданные, статистика, страницы, безопасность.</summary>
    public sealed class PropertiesWindow : ThemedWindow
    {
        private readonly DocumentBase _doc;
        private readonly string _path;
        private readonly StringBuilder _report = new StringBuilder();

        public PropertiesWindow(DocumentBase doc, string path, int viewPages, int tab)
        {
            _doc = doc; _path = path;
            Heading = "Свойства документа";
            Width = 760; Height = 720; MinWidth = 560; MinHeight = 480;

            var dock = new DockPanel { Margin = new Thickness(16, 0, 16, 14) };

            // шапка с эскизом
            var head = new DockPanel { Margin = new Thickness(0, 0, 0, 12) };
            var thumbBorder = new Border { Width = 96, Height = 124, Background = Brushes.White, Margin = new Thickness(0, 0, 16, 0), CornerRadius = new CornerRadius(4) };
            thumbBorder.SetResourceReference(EffectProperty, "GlowEffect");
            var img = new Image { Stretch = Stretch.Uniform };
            RenderOptions.SetBitmapScalingMode(img, BitmapScalingMode.HighQuality);
            thumbBorder.Child = img;
            head.Children.Add(thumbBorder);
            var hs = new StackPanel { VerticalAlignment = VerticalAlignment.Center };
            hs.Children.Add(new TextBlock { Text = Path.GetFileName(path), FontSize = 19, FontWeight = FontWeights.SemiBold, TextWrapping = TextWrapping.Wrap });
            if (!string.IsNullOrWhiteSpace(doc.Title)) hs.Children.Add(new TextBlock { Text = doc.Title, FontSize = 14, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 2, 0, 0) });
            if (!string.IsNullOrWhiteSpace(doc.Author)) hs.Children.Add(Sub(doc.Author));
            var badges = new WrapPanel { Margin = new Thickness(0, 8, 0, 0) };
            badges.Children.Add(Badge(doc.FormatName));
            badges.Children.Add(Badge($"{viewPages} стр."));
            try { badges.Children.Add(Badge(HumanSize(new FileInfo(path).Length))); } catch { }
            badges.Children.Add(Badge(doc.Kind == DocKind.Reflow ? "перетекаемый текст" : doc.Kind == DocKind.Fixed ? "фиксированная вёрстка" : "изображения"));
            hs.Children.Add(badges);
            head.Children.Add(hs);
            DockPanel.SetDock(head, Dock.Top);
            dock.Children.Add(head);

            // кнопки
            var buttons = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right, Margin = new Thickness(0, 10, 0, 0) };
            var copy = MakeButton("Копировать отчёт", false);
            copy.Click += (s, e) => { try { Clipboard.SetText(_report.ToString()); copy.Content = "Скопировано ✓"; } catch { } };
            var folder = MakeButton("Показать в папке", false);
            folder.Click += (s, e) => ShellIntegration.ShowInExplorer(_path);
            var close = MakeButton("Закрыть", true); close.IsCancel = true; close.Click += (s, e) => Close();
            buttons.Children.Add(copy); buttons.Children.Add(folder); buttons.Children.Add(close);
            DockPanel.SetDock(buttons, Dock.Bottom);
            dock.Children.Add(buttons);

            var tabs = new TabControl();
            tabs.Items.Add(new TabItem { Header = "Файл", Content = Scroll(FileTab()) });
            tabs.Items.Add(new TabItem { Header = "Документ", Content = Scroll(DocTab()) });
            tabs.Items.Add(new TabItem { Header = "Статистика", Content = Scroll(StatsTab(viewPages)) });
            tabs.Items.Add(new TabItem { Header = "Безопасность", Content = Scroll(SecurityTab()) });
            tabs.SelectedIndex = Math.Max(0, Math.Min(3, tab));
            dock.Children.Add(tabs);
            Body.Children.Add(dock);

            Loaded += async (s, e) =>
            {
                try
                {
                    var sz = doc.GetPageSize(0);
                    var bmp = doc.CanRenderOffThread ? await Task.Run(() => doc.RenderPage(0, 240 / Math.Max(sz.Width, sz.Height))) : doc.RenderPage(0, 240 / Math.Max(sz.Width, sz.Height));
                    img.Source = doc.Cover ?? bmp;
                }
                catch { }
                ComputeStats();
                ComputeHashes();
            };
        }

        private static ScrollViewer Scroll(UIElement content) => new ScrollViewer { Content = content, VerticalScrollBarVisibility = ScrollBarVisibility.Auto, Padding = new Thickness(0, 4, 6, 0) };

        private static TextBlock Sub(string t)
        {
            var tb = new TextBlock { Text = t, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 2, 0, 0) };
            tb.SetResourceReference(TextBlock.ForegroundProperty, "SubFgBrush");
            return tb;
        }

        private static Border Badge(string text)
        {
            var b = new Border { CornerRadius = new CornerRadius(10), Padding = new Thickness(10, 3, 10, 3), Margin = new Thickness(0, 0, 6, 4) };
            b.SetResourceReference(Border.BackgroundProperty, "AccentSoftBrush");
            b.SetResourceReference(Border.BorderBrushProperty, "PanelBorderBrush");
            b.BorderThickness = new Thickness(1);
            b.Child = new TextBlock { Text = text, FontSize = 12 };
            return b;
        }

        public static string HumanSize(long b)
        {
            string[] u = { "байт", "КБ", "МБ", "ГБ" };
            double v = b; int i = 0;
            while (v >= 1024 && i < u.Length - 1) { v /= 1024; i++; }
            return i == 0 ? $"{b:N0} байт" : $"{v:0.##} {u[i]} ({b:N0} байт)";
        }

        /// <summary>Карточка «ключ — значение».</summary>
        private Border Card(string title, IEnumerable<KeyValuePair<string, string>> items, Dictionary<string, Action<TextBlock>> hooks = null)
        {
            var card = new Border { Margin = new Thickness(0, 6, 0, 6) };
            card.SetResourceReference(StyleProperty, "Card");
            var sp = new StackPanel();
            var t = new TextBlock { Text = title, FontWeight = FontWeights.SemiBold, FontSize = 14.5, Margin = new Thickness(0, 0, 0, 8) };
            t.SetResourceReference(TextBlock.ForegroundProperty, "Accent2Brush");
            sp.Children.Add(t);
            _report.AppendLine("== " + title + " ==");
            var grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(210) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            int row = 0;
            foreach (var kv in items)
            {
                grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
                var k = new TextBlock { Text = kv.Key, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 3, 10, 3) };
                k.SetResourceReference(TextBlock.ForegroundProperty, "SubFgBrush");
                var v = new TextBox
                {
                    Text = kv.Value ?? "—", IsReadOnly = true, TextWrapping = TextWrapping.Wrap, BorderThickness = new Thickness(0),
                    Background = Brushes.Transparent, Padding = new Thickness(0), Margin = new Thickness(0, 3, 0, 3)
                };
                v.Template = PlainTextBoxTemplate();
                Grid.SetRow(k, row); Grid.SetRow(v, row);
                if (string.IsNullOrEmpty(kv.Key)) Grid.SetColumnSpan(v, 2);
                else { Grid.SetColumn(v, 1); grid.Children.Add(k); }
                grid.Children.Add(v);
                _report.AppendLine(kv.Key + ": " + kv.Value);
                row++;
            }
            if (row == 0)
            {
                var none = Sub("Нет данных.");
                sp.Children.Add(none);
            }
            sp.Children.Add(grid);
            card.Child = sp;
            _report.AppendLine();
            return card;
        }

        private static ControlTemplate _plainTpl;
        private static ControlTemplate PlainTextBoxTemplate()
        {
            if (_plainTpl != null) return _plainTpl;
            var t = new ControlTemplate(typeof(TextBox));
            var sv = new FrameworkElementFactory(typeof(ScrollViewer));
            sv.Name = "PART_ContentHost";
            sv.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);
            sv.SetValue(ScrollViewer.VerticalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);
            t.VisualTree = sv;
            _plainTpl = t;
            return t;
        }

        private static KeyValuePair<string, string> KV(string k, string v) => new KeyValuePair<string, string>(k, v);

        private UIElement FileTab()
        {
            var sp = new StackPanel();
            try
            {
                var fi = new FileInfo(_path);
                var attrs = new List<string>();
                if (fi.IsReadOnly) attrs.Add("только чтение");
                if ((fi.Attributes & FileAttributes.Hidden) != 0) attrs.Add("скрытый");
                if ((fi.Attributes & FileAttributes.System) != 0) attrs.Add("системный");
                if ((fi.Attributes & FileAttributes.Archive) != 0) attrs.Add("архивный");
                if ((fi.Attributes & FileAttributes.Compressed) != 0) attrs.Add("сжатый NTFS");
                if ((fi.Attributes & FileAttributes.Encrypted) != 0) attrs.Add("зашифрован EFS");
                if ((fi.Attributes & FileAttributes.ReparsePoint) != 0) attrs.Add("ссылка/точка повторной обработки");
                if ((fi.Attributes & FileAttributes.Offline) != 0) attrs.Add("в облаке (не загружен)");
                sp.Children.Add(Card("Файл", new[]
                {
                    KV("Имя", fi.Name),
                    KV("Папка", fi.DirectoryName),
                    KV("Расширение", fi.Extension),
                    KV("Тип содержимого", _doc.FormatName),
                    KV("Размер", HumanSize(fi.Length)),
                    KV("Создан", fi.CreationTime.ToString("dd.MM.yyyy HH:mm:ss")),
                    KV("Изменён", fi.LastWriteTime.ToString("dd.MM.yyyy HH:mm:ss")),
                    KV("Открыт", fi.LastAccessTime.ToString("dd.MM.yyyy HH:mm:ss")),
                    KV("Атрибуты", attrs.Count == 0 ? "обычный" : string.Join(", ", attrs)),
                }));
                int zone = SecurityScanner.ReadZone(_path, out var url);
                string zoneText = zone < 0 ? "Локальный файл (метки происхождения нет)" :
                    zone == 0 ? "Компьютер" : zone == 1 ? "Локальная сеть (интранет)" : zone == 2 ? "Надёжные сайты" : zone == 3 ? "Интернет" : zone == 4 ? "Опасные сайты" : "Зона " + zone;
                sp.Children.Add(Card("Происхождение", new[] { KV("Зона безопасности Windows", zoneText), KV("Источник загрузки", url) }.Where(x => x.Value != null)));

                var hashGrid = Card("Контрольные суммы", new[] { KV("SHA-256", "вычисляется…"), KV("SHA-1", "вычисляется…"), KV("MD5", "вычисляется…") });
                var boxes = FindTextBoxes(hashGrid);
                if (boxes.Count >= 3) { _sha256Box = boxes[0]; _sha1Box = boxes[1]; _md5Box = boxes[2]; }
                sp.Children.Add(hashGrid);
            }
            catch (Exception ex) { sp.Children.Add(Sub("Сведения о файле недоступны: " + ex.Message)); }
            return sp;
        }

        private TextBox _sha256Box, _sha1Box, _md5Box;

        private static List<TextBox> FindTextBoxes(DependencyObject root)
        {
            var list = new List<TextBox>();
            void Walk(object o)
            {
                if (o is TextBox tb) list.Add(tb);
                if (o is Panel p) foreach (var c in p.Children) Walk(c);
                if (o is Decorator d) Walk(d.Child);
                if (o is ContentControl cc) Walk(cc.Content);
            }
            Walk(root);
            return list;
        }

        private async void ComputeHashes()
        {
            var data = _doc.Bytes;
            if (data == null || _sha256Box == null) return;
            var res = await Task.Run(() =>
            {
                using (var a = SHA256.Create()) using (var b = SHA1.Create()) using (var c = MD5.Create())
                    return (Hex(a.ComputeHash(data)), Hex(b.ComputeHash(data)), Hex(c.ComputeHash(data)));
            });
            _sha256Box.Text = res.Item1; _sha1Box.Text = res.Item2; _md5Box.Text = res.Item3;
            _report.AppendLine("SHA-256: " + res.Item1);
        }

        private static string Hex(byte[] b) => BitConverter.ToString(b).Replace("-", "").ToLowerInvariant();

        private UIElement DocTab()
        {
            var sp = new StackPanel();
            if (_doc.Info.Count == 0) sp.Children.Add(Sub("Документ не содержит метаданных."));
            foreach (var sec in _doc.Info) sp.Children.Add(Card(sec.Title, sec.Items));
            if (_doc.Toc.Count > 0)
            {
                int total = 0;
                void Count(List<TocItem> l) { foreach (var t in l) { total++; Count(t.Children); } }
                Count(_doc.Toc);
                sp.Children.Add(Card("Структура", new[] { KV("Пунктов оглавления", total.ToString("N0")), KV("Верхний уровень", _doc.Toc.Count.ToString("N0")) }));
            }
            if (_doc.Notices.Count > 0) sp.Children.Add(Card("Примечания", _doc.Notices.Select((n, i) => KV("•", n))));
            return sp;
        }

        private UIElement StatsTab(int viewPages)
        {
            var sp = new StackPanel();
            var sizes = Enumerable.Range(0, _doc.PageCount).Select(i => _doc.GetPageSize(i)).ToList();
            var first = sizes.FirstOrDefault();
            var card = Card("Текст", new[]
            {
                KV("Страниц в документе", _doc.PageCount.ToString("N0")),
                KV("Страниц в просмотре", viewPages.ToString("N0")),
                KV("Слов", "подсчёт…"),
                KV("Символов (без пробелов)", "подсчёт…"),
                KV("Время чтения", "подсчёт…"),
            });
            var boxes = FindTextBoxes(card);
            if (boxes.Count >= 5) { _words = boxes[2]; _chars = boxes[3]; _time = boxes[4]; }
            sp.Children.Add(card);
            var groups = sizes.GroupBy(s => PdfDoc.PaperName(s)).OrderByDescending(g => g.Count()).Take(8)
                .Select(g => KV(g.Key, $"{g.Count()} стр."));
            var pageItems = new List<KeyValuePair<string, string>>
            {
                KV("Первая страница", $"{first.Width / 96 * 25.4:0} × {first.Height / 96 * 25.4:0} мм ({first.Width / 96:0.##} × {first.Height / 96:0.##} дюйма)"),
                KV("Ориентация", first.Width > first.Height ? "альбомная" : "книжная"),
            };
            pageItems.AddRange(groups);
            sp.Children.Add(Card("Страницы", pageItems));
            return sp;
        }

        private TextBox _words, _chars, _time;

        private async void ComputeStats()
        {
            if (_words == null) return;
            int maxPages = Math.Min(_doc.PageCount, 600);
            long words = 0, chars = 0;
            for (int i = 0; i < maxPages; i++)
            {
                string t;
                try
                {
                    if (_doc.CanRenderOffThread) { var d = _doc; int idx = i; t = await Task.Run(() => d.GetPageText(idx)); }
                    else { t = _doc.GetPageText(i); if (i % 10 == 0) await System.Windows.Threading.Dispatcher.Yield(System.Windows.Threading.DispatcherPriority.Background); }
                }
                catch { continue; }
                if (!IsLoaded) return;
                words += t.Split(new[] { ' ', '\n', '\t', '\r' }, StringSplitOptions.RemoveEmptyEntries).Length;
                chars += t.Count(c => !char.IsWhiteSpace(c));
            }
            string suffix = maxPages < _doc.PageCount ? $" (по первым {maxPages} стр.)" : "";
            _words.Text = words.ToString("N0") + suffix;
            _chars.Text = chars.ToString("N0") + suffix;
            double minutes = words / 200.0;
            _time.Text = words == 0 ? "нет текстового слоя (используйте OCR)" : minutes < 1 ? "меньше минуты" : minutes < 60 ? $"≈ {Math.Ceiling(minutes)} мин" : $"≈ {Math.Floor(minutes / 60)} ч {Math.Ceiling(minutes % 60)} мин";
            _report.AppendLine($"Слов: {_words.Text}; символов: {_chars.Text}");
        }

        private UIElement SecurityTab()
        {
            var sp = new StackPanel();
            foreach (var f in _doc.Security)
            {
                var b = new Border { Margin = new Thickness(0, 5, 0, 5), Padding = new Thickness(12), CornerRadius = new CornerRadius(8), BorderThickness = new Thickness(1) };
                Color c = f.Severity == Severity.Danger ? Color.FromRgb(255, 70, 90) : f.Severity == Severity.Warning ? Color.FromRgb(255, 190, 40) : f.Severity == Severity.Safe ? Color.FromRgb(60, 230, 140) : Color.FromRgb(90, 170, 255);
                b.Background = new SolidColorBrush(Color.FromArgb(38, c.R, c.G, c.B));
                b.BorderBrush = new SolidColorBrush(Color.FromArgb(150, c.R, c.G, c.B));
                var dp = new DockPanel();
                var icon = new TextBlock
                {
                    Text = f.Severity == Severity.Danger ? "\uEA39" : f.Severity == Severity.Warning ? "\uE7BA" : f.Severity == Severity.Safe ? "\uEA18" : "\uE946",
                    FontFamily = (FontFamily)FindResource("IconFont"), FontSize = 20, Foreground = new SolidColorBrush(c), Margin = new Thickness(0, 0, 12, 0), VerticalAlignment = VerticalAlignment.Top
                };
                DockPanel.SetDock(icon, Dock.Left);
                dp.Children.Add(icon);
                var tsp = new StackPanel();
                tsp.Children.Add(new TextBlock { Text = f.Title, FontWeight = FontWeights.SemiBold, TextWrapping = TextWrapping.Wrap });
                tsp.Children.Add(Sub(f.Detail));
                dp.Children.Add(tsp);
                b.Child = dp;
                sp.Children.Add(b);
                _report.AppendLine($"[{f.Severity}] {f.Title}: {f.Detail}");
            }
            sp.Children.Add(Card("Защита процесса DocuNova", Hardening.Status.Select(s => KV("", s))));
            return sp;
        }
    }
}
