using System.ComponentModel;
using System.Windows;
using System.Windows.Media;
using DocuNova.Viewer;

namespace DocuNova
{
    public sealed class ThumbItem : INotifyPropertyChanged
    {
        private ImageSource _thumb;
        public PageRef Ref { get; set; }
        public int Index { get; set; }
        public string Label { get; set; }
        public double BoxWidth { get; set; }
        public double BoxHeight { get; set; }
        public bool Loading { get; set; }
        public bool Visible { get; set; }
        public ImageSource Thumb { get => _thumb; set { _thumb = value; Notify(nameof(Thumb)); } }
        public Visibility BookmarkVisibility => Ref != null && Ref.Bookmarked ? Visibility.Visible : Visibility.Collapsed;
        public event PropertyChangedEventHandler PropertyChanged;
        public void Notify(string name) => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }

    public sealed class TocRow
    {
        public string Title { get; set; }
        public string PageLabel { get; set; }
        public Thickness Indent { get; set; }
        public FontWeight Weight { get; set; }
        public int View { get; set; }
    }

    public sealed class SearchHit
    {
        public int View { get; set; }
        public Rect Rect { get; set; }
        public string PageLabel { get; set; }
        public string Snippet { get; set; }
    }

    public sealed class AnnRow
    {
        public PageRef Page { get; set; }
        public Annotation Ann { get; set; }
        public int View { get; set; }
        public override string ToString()
        {
            var t = string.IsNullOrWhiteSpace(Ann.Text) ? "" : " — " + (Ann.Text.Length > 40 ? Ann.Text.Substring(0, 40) + "…" : Ann.Text);
            return $"Стр. {View + 1} · {Ann.KindName}{t}";
        }
    }

    public sealed class BookmarkRow
    {
        public PageRef Page { get; set; }
        public int View { get; set; }
        public string Text { get; set; }
        public override string ToString() => Text;
    }
}
