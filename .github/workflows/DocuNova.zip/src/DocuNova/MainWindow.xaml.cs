using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using DocuNova.Core;
using DocuNova.Services;
using DocuNova.Viewer;
using DocuNova.Views;
using Microsoft.Win32;

namespace DocuNova
{
    public partial class MainWindow : Window
    {
        private readonly DocViewer _viewer = new DocViewer();
        private DocumentBase _doc;
        private string _path;
        private bool _ready;
        private bool _fullscreen;
        private WindowState _stateBeforeFull;
        private Color _color;
        private readonly ObservableCollection<ThumbItem> _thumbs = new ObservableCollection<ThumbItem>();
        private List<SearchHit> _hits = new List<SearchHit>();
        private int _hitIndex = -1;
        private int _searchGen;
        private readonly DispatcherTimer _bannerTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(14) };

        private static readonly string[] Palette = { "#FFFF2BD6", "#FF00F0FF", "#FFFFE600", "#FF39FF14", "#FFFF7A00", "#FFFF1E3C", "#FF7B61FF", "#FF2E9BFF", "#FF000000", "#FFFFFFFF" };
        private static readonly string[] Stamps = { "ОДОБРЕНО", "ПРОВЕРЕНО", "ЧЕРНОВИК", "КОПИЯ", "КОНФИДЕНЦИАЛЬНО", "ОТКЛОНЕНО", "СРОЧНО", "ОПЛАЧЕНО", "ПОЛУЧЕНО", "УТВЕРЖДАЮ" };

        private AppSettings S => App.Settings;

        public MainWindow()
        {
            InitializeComponent();
            ViewerHost.Children.Insert(0, _viewer);
            _viewer.Visibility = Visibility.Collapsed;
            _viewer.CurrentPageChanged += OnCurrentPageChanged;
            _viewer.ZoomChanged += UpdateZoomText;
            _viewer.AnnotationsChanged += OnAnnotationsChanged;
            _viewer.StatusMessage += m => StatusText.Text = m;
            _viewer.NewAnnotation = NewAnnotationStyle;
            _viewer.AskText = (title, initial) => InputDialog.Ask(this, title, "Введите текст. Ctrl+Enter — готово.", initial, true);
            _viewer.ContextMenu = BuildPageMenu();

            ThumbList.ItemsSource = _thumbs;
            _bannerTimer.Tick += (s, e) => { _bannerTimer.Stop(); Banner.Visibility = Visibility.Collapsed; };

            // параметры пометок
            _color = ThemeColor(S.PenColor, Color.FromRgb(255, 43, 214));
            ThicknessSlider.Value = S.PenThickness;
            OpacitySlider.Value = S.AnnOpacity;
            FontSlider.Value = S.TextSize;
            foreach (var st in Stamps) StampBox.Items.Add(st);
            StampBox.SelectedItem = Stamps.Contains(S.Stamp) ? S.Stamp : Stamps[0];
            BuildSwatches();

            // параметры вида
            ApplyViewSettings();
            TwoPageBtn.IsChecked = S.TwoPage;
            if (!S.ShowSidebar) SetSidebar(false);
            Width = Math.Max(MinWidth, S.WindowWidth);
            Height = Math.Max(MinHeight, S.WindowHeight);
            if (S.WindowMaximized) WindowState = WindowState.Maximized;

            Drop += OnDrop;
            DragOver += (s, e) => { e.Effects = e.Data.GetDataPresent(DataFormats.FileDrop) ? DragDropEffects.Copy : DragDropEffects.None; e.Handled = true; };
            StateChanged += (s, e) => UpdateMaxState();
            Closing += OnClosing;
            Loaded += (s, e) => { UpdateMaxState(); RefreshRecent(); };
            UpdateDocButtons();
            _ready = true;
        }

        private static Color ThemeColor(string s, Color fallback) => Themes.ThemeManager.C(s, fallback);

        private void ApplyViewSettings()
        {
            _viewer.Gap = S.PageGap;
            _viewer.Shadows = S.PageShadows;
            _viewer.FitMode = S.FitMode ?? "width";
            _viewer.PageMode = S.PageMode ?? "normal";
            _viewer.TwoPage = S.TwoPage;
        }

        // ======================= Окно =======================

        private void Min_Click(object sender, RoutedEventArgs e) => WindowState = WindowState.Minimized;
        private void Max_Click(object sender, RoutedEventArgs e) => WindowState = WindowState == WindowState.Maximized ? WindowState.Normal : WindowState.Maximized;
        private void Close_Click(object sender, RoutedEventArgs e) => Close();

        private void UpdateMaxState()
        {
            bool max = WindowState == WindowState.Maximized;
            Root.Margin = max && !_fullscreen ? new Thickness(7) : new Thickness(0);
            MaxBtn.Content = max ? "\uE923" : "\uE922";
        }

        private void OnClosing(object sender, CancelEventArgs e)
        {
            if (!ConfirmDiscard()) { e.Cancel = true; return; }
            S.WindowMaximized = WindowState == WindowState.Maximized;
            if (WindowState == WindowState.Normal) { S.WindowWidth = ActualWidth; S.WindowHeight = ActualHeight; }
            S.Save();
            CloseDocument();
        }

        private void OnDrop(object sender, DragEventArgs e)
        {
            if (e.Data.GetData(DataFormats.FileDrop) is string[] files && files.Length > 0) OpenFile(files[0]);
        }

        // ======================= Открытие =======================

        private void Open_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new OpenFileDialog
            {
                Filter = DocumentLoader.OpenFileFilter(),
                Title = "Открыть документ",
                CheckFileExists = true,
                DereferenceLinks = false // ярлык не подменяет файл
            };
            if (dlg.ShowDialog(this) == true) OpenFile(dlg.FileName);
        }

        public async void OpenFile(string path)
        {
            if (string.IsNullOrEmpty(path)) return;
            try { path = Path.GetFullPath(path); } catch { }
            if (!File.Exists(path)) { MessageBox.Show(this, "Файл не найден:\n" + path, "DocuNova", MessageBoxButton.OK, MessageBoxImage.Warning); return; }
            if (!ConfirmDiscard()) return;

            ShowLoading("Открытие «" + Path.GetFileName(path) + "»…");
            byte[] data;
            try { data = await Task.Run(() => SafeIO.ReadFile(path)); }
            catch (Exception ex) { HideLoading(); ShowError("Не удалось прочитать файл", ex); return; }

            var rs = S.Reflow.Clone();
            rs.Light = false;
            string password = null;
            DocumentBase doc = null;
            bool isPdf = DocumentLoader.Detect(data, Path.GetExtension(path)) == "pdf";
            while (true)
            {
                try
                {
                    if (isPdf) doc = await Task.Run(() => DocumentLoader.Load(path, data, rs, password));
                    else
                    {
                        await Dispatcher.Yield(DispatcherPriority.Background);
                        doc = DocumentLoader.Load(path, data, rs, password);
                    }
                    break;
                }
                catch (PasswordRequiredException ex)
                {
                    HideLoading();
                    password = PasswordDialog.Ask(this, Path.GetFileName(path), ex.WrongPassword);
                    if (password == null) return;
                    ShowLoading("Расшифровка…");
                }
                catch (Exception ex)
                {
                    HideLoading();
                    ShowError("Документ не удалось открыть", ex);
                    return;
                }
            }

            CloseDocument();
            _doc = doc;
            _path = path;
            Welcome.Visibility = Visibility.Collapsed;
            _viewer.Visibility = Visibility.Visible;
            _viewer.SetDocument(doc);
            TitleText.Text = Path.GetFileName(path) + (string.IsNullOrWhiteSpace(doc.Title) ? "" : "  —  " + doc.Title);
            Title = Path.GetFileName(path) + " — DocuNova";
            FormatText.Text = doc.FormatName;
            RebuildSidebar();
            UpdateSecurityBadge();
            UpdateDocButtons();
            UpdateZoomText();
            HideLoading();
            S.AddRecent(path);
            S.Save();
            _viewer.Scroll.Focus();

            var warn = doc.Security.Where(f => f.Severity == Severity.Danger || f.Severity == Severity.Warning).ToList();
            if (warn.Count > 0 && S.WarnInternetFiles)
            {
                var top = warn.First();
                ShowBanner($"Обнаружено и заблокировано: {top.Title}" + (warn.Count > 1 ? $" (и ещё {warn.Count - 1})" : "") + ". Документ показан в защищённом режиме. Подробности — кнопка щита внизу.", true);
            }
            else if (doc.Notices.Count > 0) ShowBanner(doc.Notices[0], false);
        }

        private void CloseDocument()
        {
            _searchGen++;
            _hits.Clear(); SearchResults.ItemsSource = null; SearchStatus.Text = "";
            _thumbs.Clear();
            TocList.ItemsSource = null;
            BookmarkList.Items.Clear();
            AnnList.Items.Clear();
            _viewer.SetDocument(null);
            _doc?.Dispose();
            _doc = null;
            _path = null;
            _viewer.Visibility = Visibility.Collapsed;
            Welcome.Visibility = Visibility.Visible;
            TitleText.Text = "";
            Title = "DocuNova";
            FormatText.Text = "";
            PageBox.Text = "";
            PageCountText.Text = "/ 0";
            SecurityBtn.Visibility = Visibility.Collapsed;
            Banner.Visibility = Visibility.Collapsed;
            RefreshRecent();
            UpdateDocButtons();
            GC.Collect(2, GCCollectionMode.Optimized, false);
        }

        /// <summary>Спрашивает о несохранённых пометках. false — отменить действие.</summary>
        private bool ConfirmDiscard()
        {
            if (_doc == null || !_viewer.Modified) return true;
            var r = MessageBox.Show(this, "В документе есть несохранённые пометки или изменения страниц.\n\nСохранить их в новый PDF?",
                "DocuNova", MessageBoxButton.YesNoCancel, MessageBoxImage.Question);
            if (r == MessageBoxResult.Cancel) return false;
            if (r == MessageBoxResult.Yes) return SavePdf(_viewer.Pages);
            return true;
        }

        private void ShowLoading(string text) { LoadingText.Text = text; Loading.Visibility = Visibility.Visible; }
        private void HideLoading() => Loading.Visibility = Visibility.Collapsed;

        private void ShowError(string title, Exception ex)
        {
            string msg = ex is UnsupportedFormatException ? ex.Message : ex.Message + "\n\nФайл может быть повреждён или иметь неподдерживаемый формат.";
            MessageBox.Show(this, title + ".\n\n" + msg, "DocuNova", MessageBoxButton.OK, MessageBoxImage.Warning);
        }

        private void ShowBanner(string text, bool danger)
        {
            BannerText.Text = text;
            BannerIcon.Text = danger ? "\uEA18" : "\uE946";
            Banner.Visibility = Visibility.Visible;
            _bannerTimer.Stop(); _bannerTimer.Start();
        }

        private void BannerClose_Click(object sender, RoutedEventArgs e) => Banner.Visibility = Visibility.Collapsed;

        private void RefreshRecent()
        {
            RecentList.Items.Clear();
            var items = S.RememberRecent ? S.Recent.Where(File.Exists).Take(8).ToList() : new List<string>();
            RecentTitle.Visibility = items.Count > 0 ? Visibility.Visible : Visibility.Collapsed;
            foreach (var p in items)
            {
                var b = new Button { HorizontalContentAlignment = HorizontalAlignment.Left, Margin = new Thickness(0, 2, 0, 2), ToolTip = p };
                b.SetResourceReference(StyleProperty, "GhostBtn");
                var sp = new StackPanel();
                sp.Children.Add(new TextBlock { Text = Path.GetFileName(p), FontWeight = FontWeights.SemiBold, TextTrimming = TextTrimming.CharacterEllipsis });
                var dir = new TextBlock { Text = Path.GetDirectoryName(p), FontSize = 11.5, TextTrimming = TextTrimming.CharacterEllipsis };
                dir.SetResourceReference(TextBlock.ForegroundProperty, "SubFgBrush");
                sp.Children.Add(dir);
                b.Content = sp;
                var path = p;
                b.Click += (s, e) => OpenFile(path);
                RecentList.Items.Add(b);
            }
        }

        private void UpdateDocButtons()
        {
            bool has = _doc != null;
            SaveBtn.IsEnabled = ExportBtn.IsEnabled = PrintBtn.IsEnabled = has;
            UndoBtn.IsEnabled = has && _viewer.CanUndo;
            RedoBtn.IsEnabled = has && _viewer.CanRedo;
            ReadSettingsBtn.IsEnabled = true;
        }

        private void UpdateSecurityBadge()
        {
            if (_doc == null) { SecurityBtn.Visibility = Visibility.Collapsed; return; }
            int danger = _doc.Security.Count(f => f.Severity == Severity.Danger);
            int warn = _doc.Security.Count(f => f.Severity == Severity.Warning);
            SecurityBtn.Visibility = Visibility.Visible;
            if (danger > 0)
            {
                SecurityIcon.Text = "\uEA18"; SecurityText.Text = $"Заблокировано угроз: {danger}";
                SecurityIcon.Foreground = new SolidColorBrush(Color.FromRgb(255, 70, 90));
            }
            else if (warn > 0)
            {
                SecurityIcon.Text = "\uEA18"; SecurityText.Text = $"Защищено · предупреждений: {warn}";
                SecurityIcon.Foreground = new SolidColorBrush(Color.FromRgb(255, 190, 40));
            }
            else
            {
                SecurityIcon.Text = "\uEA18"; SecurityText.Text = "Защищено · угроз нет";
                SecurityIcon.Foreground = new SolidColorBrush(Color.FromRgb(60, 230, 140));
            }
        }

        private void SecurityBtn_Click(object sender, RoutedEventArgs e) => ShowProperties(3);

        // ======================= Боковая панель =======================

        private void Sidebar_Click(object sender, RoutedEventArgs e) => SetSidebar(Sidebar.Visibility != Visibility.Visible);

        private void SetSidebar(bool show)
        {
            Sidebar.Visibility = show ? Visibility.Visible : Visibility.Collapsed;
            SideSplitter.Visibility = Sidebar.Visibility;
            SidebarCol.Width = show ? new GridLength(Math.Max(220, S.ShowSidebar ? 290 : 290)) : new GridLength(0);
            S.ShowSidebar = show;
        }

        private void SideTab_Checked(object sender, RoutedEventArgs e)
        {
            if (ThumbList == null || TocList == null) return;
            ThumbList.Visibility = TabThumbs.IsChecked == true ? Visibility.Visible : Visibility.Collapsed;
            bool toc = TabToc.IsChecked == true;
            TocList.Visibility = toc && TocList.Items.Count > 0 ? Visibility.Visible : Visibility.Collapsed;
            TocEmpty.Visibility = toc && TocList.Items.Count == 0 ? Visibility.Visible : Visibility.Collapsed;
            BookmarkPanel.Visibility = TabBookmarks.IsChecked == true ? Visibility.Visible : Visibility.Collapsed;
            SearchPanel.Visibility = TabSearch.IsChecked == true ? Visibility.Visible : Visibility.Collapsed;
            AnnPanel.Visibility = TabAnns.IsChecked == true ? Visibility.Visible : Visibility.Collapsed;
            if (TabSearch.IsChecked == true) Dispatcher.BeginInvoke(new Action(() => { SearchBox.Focus(); SearchBox.SelectAll(); }), DispatcherPriority.Input);
        }

        private void RebuildSidebar()
        {
            RebuildThumbs();
            RebuildToc();
            RebuildBookmarks();
            RebuildAnnList();
        }

        private void RebuildThumbs()
        {
            _thumbs.Clear();
            if (_doc == null) return;
            for (int i = 0; i < _viewer.Pages.Count; i++)
            {
                var r = _viewer.Pages[i];
                var s = _doc.GetPageSize(r.Doc);
                if (r.Rotation % 180 != 0) s = new Size(s.Height, s.Width);
                double k = Math.Min(150 / s.Width, 190 / s.Height);
                _thumbs.Add(new ThumbItem { Ref = r, Index = i, Label = (i + 1).ToString(), BoxWidth = Math.Max(20, s.Width * k), BoxHeight = Math.Max(20, s.Height * k) });
            }
        }

        private async void ThumbItem_Loaded(object sender, RoutedEventArgs e)
        {
            if (!(sender is ListBoxItem li) || !(li.DataContext is ThumbItem item)) return;
            item.Visible = true;
            if (item.Thumb != null || item.Loading) return;
            item.Loading = true;
            try
            {
                await Task.Delay(60);
                if (!item.Visible || _doc == null) return;
                var bmp = await _viewer.RenderThumbAsync(item.Ref, 160);
                if (bmp != null && item.Ref.Rotation != 0)
                {
                    var tb = new TransformedBitmap(bmp, new RotateTransform(item.Ref.Rotation));
                    tb.Freeze();
                    bmp = tb;
                }
                if (item.Visible) item.Thumb = DocViewer.ApplyMode(bmp, _viewer.PageMode);
            }
            catch { }
            finally { item.Loading = false; }
        }

        private void ThumbItem_Unloaded(object sender, RoutedEventArgs e)
        {
            if (sender is ListBoxItem li && li.DataContext is ThumbItem item)
            {
                item.Visible = false;
                item.Thumb = null; // освобождаем память
            }
        }

        private bool _syncingThumbs;
        private void ThumbList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (_syncingThumbs) return;
            if (ThumbList.SelectedItem is ThumbItem t) _viewer.GoTo(t.Index);
        }

        private void RebuildToc()
        {
            var rows = new List<TocRow>();
            if (_doc != null) Flatten(_doc.Toc, rows, 0);
            TocList.ItemsSource = rows;
            SideTab_Checked(null, null);
        }

        private void Flatten(List<TocItem> items, List<TocRow> rows, int depth)
        {
            foreach (var t in items)
            {
                if (rows.Count > 5000) return;
                int view = t.PageIndex >= 0 ? _viewer.Pages.FindIndex(p => p.Doc == t.PageIndex) : -1;
                rows.Add(new TocRow
                {
                    Title = t.Title,
                    View = view,
                    PageLabel = view >= 0 ? (view + 1).ToString() : "",
                    Indent = new Thickness(depth * 14, 0, 0, 0),
                    Weight = depth == 0 ? FontWeights.SemiBold : FontWeights.Normal
                });
                Flatten(t.Children, rows, depth + 1);
            }
        }

        private void TocList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (TocList.SelectedItem is TocRow r && r.View >= 0) _viewer.GoTo(r.View);
        }

        private void RebuildBookmarks()
        {
            BookmarkList.Items.Clear();
            for (int i = 0; i < _viewer.Pages.Count; i++)
                if (_viewer.Pages[i].Bookmarked)
                {
                    var text = "";
                    try { text = _doc.GetPageText(_viewer.Pages[i].Doc); } catch { }
                    text = FlowSinkPreview(text);
                    BookmarkList.Items.Add(new BookmarkRow { Page = _viewer.Pages[i], View = i, Text = $"★ Стр. {i + 1}" + (text.Length > 0 ? " — " + text : "") });
                }
        }

        private static string FlowSinkPreview(string t)
        {
            t = (t ?? "").Replace('\n', ' ').Trim();
            return t.Length > 50 ? t.Substring(0, 50) + "…" : t;
        }

        private void BookmarkList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (BookmarkList.SelectedItem is BookmarkRow r) _viewer.GoTo(_viewer.Pages.IndexOf(r.Page));
        }

        private void Bookmark_Click(object sender, RoutedEventArgs e)
        {
            if (_doc == null) return;
            var p = _viewer.Pages[_viewer.CurrentPage];
            p.Bookmarked = !p.Bookmarked;
            var ti = _thumbs.FirstOrDefault(t => t.Ref == p);
            ti?.Notify(nameof(ThumbItem.BookmarkVisibility));
            RebuildBookmarks();
            StatusText.Text = p.Bookmarked ? $"Страница {_viewer.CurrentPage + 1} добавлена в закладки." : "Закладка удалена.";
        }

        private void RebuildAnnList()
        {
            AnnList.Items.Clear();
            for (int i = 0; i < _viewer.Pages.Count; i++)
                foreach (var a in _viewer.Pages[i].Anns)
                    AnnList.Items.Add(new AnnRow { Page = _viewer.Pages[i], Ann = a, View = i });
        }

        private void AnnList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (AnnList.SelectedItem is AnnRow r)
            {
                var b = r.Ann.Bounds;
                if (!b.IsEmpty) _viewer.ShowRect(_viewer.Pages.IndexOf(r.Page), b); else _viewer.GoTo(r.View);
            }
        }

        private void AnnDelete_Click(object sender, RoutedEventArgs e)
        {
            if (AnnList.SelectedItem is AnnRow r) _viewer.RemoveAnnotation(r.Page, r.Ann);
        }

        private void AnnClearPage_Click(object sender, RoutedEventArgs e)
        {
            if (_doc == null) return;
            _viewer.ClearAnnotations(_viewer.Pages[_viewer.CurrentPage]);
        }

        private void OnAnnotationsChanged()
        {
            RebuildAnnList();
            UpdateDocButtons();
            if (_thumbs.Count != _viewer.Pages.Count) RebuildThumbs();
        }

        // ======================= Навигация =======================

        private void OnCurrentPageChanged(int i)
        {
            PageBox.Text = (i + 1).ToString();
            PageCountText.Text = "/ " + _viewer.Pages.Count;
            if (i >= 0 && i < _thumbs.Count)
            {
                _syncingThumbs = true;
                ThumbList.SelectedIndex = i;
                if (ThumbList.IsVisible) ThumbList.ScrollIntoView(_thumbs[i]);
                _syncingThumbs = false;
            }
        }

        private void PageBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key != Key.Enter) return;
            if (int.TryParse(PageBox.Text.Trim(), out var n)) _viewer.GoTo(Math.Max(1, Math.Min(n, _viewer.Pages.Count)) - 1);
            _viewer.Scroll.Focus();
            e.Handled = true;
        }

        private void PrevPage_Click(object sender, RoutedEventArgs e) => _viewer.Prev();
        private void NextPage_Click(object sender, RoutedEventArgs e) => _viewer.Next();

        // ======================= Масштаб и вид =======================

        private void UpdateZoomText() => ZoomBtn.Content = Math.Round(_viewer.Zoom * 100) + " %";

        private void ZoomIn_Click(object sender, RoutedEventArgs e) => _viewer.SetZoom(NextZoom(_viewer.Zoom, true));
        private void ZoomOut_Click(object sender, RoutedEventArgs e) => _viewer.SetZoom(NextZoom(_viewer.Zoom, false));

        private static readonly double[] Steps = { 0.1, 0.25, 0.33, 0.5, 0.67, 0.75, 0.9, 1, 1.1, 1.25, 1.5, 1.75, 2, 2.5, 3, 4, 5, 6, 8 };
        private static double NextZoom(double z, bool up)
        {
            if (up) { foreach (var s in Steps) if (s > z + 0.01) return s; return 8; }
            for (int i = Steps.Length - 1; i >= 0; i--) if (Steps[i] < z - 0.01) return Steps[i];
            return 0.1;
        }

        private void ZoomBtn_Click(object sender, RoutedEventArgs e)
        {
            var m = new ContextMenu();
            foreach (var z in new[] { 0.5, 0.75, 1.0, 1.25, 1.5, 2.0, 3.0, 4.0 })
            {
                var zz = z;
                var mi = new MenuItem { Header = Math.Round(z * 100) + " %" };
                mi.Click += (s, a) => _viewer.SetZoom(zz);
                m.Items.Add(mi);
            }
            var fw = new MenuItem { Header = "По ширине" }; fw.Click += (s, a) => FitWidth_Click(null, null); m.Items.Add(fw);
            var fp = new MenuItem { Header = "Страница целиком" }; fp.Click += (s, a) => FitPage_Click(null, null); m.Items.Add(fp);
            m.PlacementTarget = ZoomBtn; m.Placement = PlacementMode.Bottom; m.IsOpen = true;
        }

        private void FitWidth_Click(object sender, RoutedEventArgs e) { _viewer.FitMode = "width"; S.FitMode = "width"; _viewer.ApplyFit(); }
        private void FitPage_Click(object sender, RoutedEventArgs e) { _viewer.FitMode = "page"; S.FitMode = "page"; _viewer.ApplyFit(); }

        private void RotateLeft_Click(object sender, RoutedEventArgs e) => Rotate(-90);
        private void RotateRight_Click(object sender, RoutedEventArgs e) => Rotate(90);
        private void Rotate(int d)
        {
            if (_doc == null) return;
            bool all = (Keyboard.Modifiers & ModifierKeys.Shift) != 0;
            _viewer.Rotate(d, all);
            RebuildThumbs();
            StatusText.Text = all ? "Все страницы повёрнуты." : $"Страница {_viewer.CurrentPage + 1} повёрнута. Shift — повернуть все.";
        }

        private void TwoPage_Click(object sender, RoutedEventArgs e)
        {
            S.TwoPage = TwoPageBtn.IsChecked == true;
            _viewer.TwoPage = S.TwoPage;
            if (_viewer.FitMode != "none") _viewer.ApplyFit();
        }

        private void PageMode_Click(object sender, RoutedEventArgs e)
        {
            var next = _viewer.PageMode == "normal" ? "night" : _viewer.PageMode == "night" ? "sepia" : "normal";
            S.PageMode = next;
            _viewer.PageMode = next;
            foreach (var t in _thumbs) t.Thumb = null;
            RebuildThumbs();
            StatusText.Text = next == "night" ? "Ночной режим страниц." : next == "sepia" ? "Режим «Сепия»." : "Обычный режим страниц.";
        }

        private void FullScreen_Click(object sender, RoutedEventArgs e) => SetFullScreen(!_fullscreen);

        private void SetFullScreen(bool on)
        {
            if (on == _fullscreen) return;
            _fullscreen = on;
            var vis = on ? Visibility.Collapsed : Visibility.Visible;
            TitleBar.Visibility = vis; ToolbarBar.Visibility = vis; StatusBar.Visibility = vis;
            OptionsBar.Visibility = on ? Visibility.Collapsed : (IsAnnotationTool(_viewer.Tool) ? Visibility.Visible : Visibility.Collapsed);
            Root.RowDefinitions[0].Height = on ? new GridLength(0) : new GridLength(40);
            Root.RowDefinitions[4].Height = on ? new GridLength(0) : new GridLength(32);
            if (on)
            {
                _stateBeforeFull = WindowState;
                Sidebar.Visibility = Visibility.Collapsed; SideSplitter.Visibility = Visibility.Collapsed; SidebarCol.Width = new GridLength(0);
                WindowState = WindowState.Normal; WindowState = WindowState.Maximized;
                ShowBanner("Полноэкранный режим. Выход — F11 или Esc.", false);
            }
            else
            {
                SetSidebar(S.ShowSidebar);
                WindowState = _stateBeforeFull;
            }
            UpdateMaxState();
        }

        // ======================= Инструменты =======================

        private static bool IsAnnotationTool(Tool t) => t != Tool.Hand && t != Tool.Select && t != Tool.Eraser;

        private void Tool_Checked(object sender, RoutedEventArgs e)
        {
            if (!(sender is FrameworkElement fe) || !(fe.Tag is string tag) || !Enum.TryParse<Tool>(tag, out var tool)) return;
            if (_viewer == null || OptionsBar == null) return;
            _viewer.Tool = tool;
            _viewer.ClearSelection();
            var info = ToolCatalog.Get(tag);
            OptTitle.Text = info?.Title ?? "";
            OptHint.Text = info?.Description ?? "";
            bool ann = tool != Tool.Hand && tool != Tool.Select;
            OptionsBar.Visibility = ann && !_fullscreen ? Visibility.Visible : Visibility.Collapsed;
            bool colored = tool != Tool.Redact && tool != Tool.WhiteOut && tool != Tool.Eraser;
            Swatches.Visibility = colored ? Visibility.Visible : Visibility.Collapsed;
            ThicknessPanel.Visibility = tool == Tool.Pen || tool == Tool.Marker || tool == Tool.Rect || tool == Tool.Ellipse || tool == Tool.Arrow || tool == Tool.Line || tool == Tool.Underline || tool == Tool.Strike ? Visibility.Visible : Visibility.Collapsed;
            OpacityPanel.Visibility = colored && tool != Tool.Text && tool != Tool.Note ? Visibility.Visible : Visibility.Collapsed;
            FontPanel.Visibility = tool == Tool.Text || tool == Tool.Stamp ? Visibility.Visible : Visibility.Collapsed;
            StampPanel.Visibility = tool == Tool.Stamp ? Visibility.Visible : Visibility.Collapsed;
            if (tool == Tool.Highlight && _color == Colors.Black) SetColor(Color.FromRgb(255, 230, 0));
            if (_doc != null && IsAnnotationTool(tool) && _doc.IsReflowable)
                StatusText.Text = "Пометки в книгах привязаны к текущей разбивке страниц: изменение шрифта книги удалит их.";
        }

        private Annotation NewAnnotationStyle()
        {
            return new Annotation
            {
                Color = _color,
                Thickness = ThicknessSlider.Value,
                Opacity = OpacitySlider.Value,
                FontSize = FontSlider.Value,
                Text = _viewer.Tool == Tool.Stamp ? (StampBox.SelectedItem as string ?? "ОДОБРЕНО") : null
            };
        }

        private void BuildSwatches()
        {
            Swatches.Children.Clear();
            foreach (var hex in Palette)
            {
                var c = ThemeColor(hex, Colors.Black);
                var b = new Button { Width = 24, Height = 24, Margin = new Thickness(2, 0, 2, 0), Cursor = Cursors.Hand, ToolTip = hex.Substring(3), Focusable = false, Tag = c };
                var tpl = new ControlTemplate(typeof(Button));
                var el = new FrameworkElementFactory(typeof(Border));
                el.SetValue(Border.CornerRadiusProperty, new CornerRadius(12));
                el.SetValue(Border.BackgroundProperty, new SolidColorBrush(c));
                el.SetValue(Border.BorderThicknessProperty, new Thickness(2));
                el.SetBinding(Border.BorderBrushProperty, new System.Windows.Data.Binding("BorderBrush") { RelativeSource = new System.Windows.Data.RelativeSource(System.Windows.Data.RelativeSourceMode.TemplatedParent) });
                tpl.VisualTree = el;
                b.Template = tpl;
                b.Click += (s, e) => SetColor((Color)((Button)s).Tag);
                Swatches.Children.Add(b);
            }
            SetColor(_color);
        }

        private void SetColor(Color c)
        {
            _color = c;
            S.PenColor = c.ToString();
            foreach (Button b in Swatches.Children)
            {
                bool sel = b.Tag is Color bc && bc == c;
                b.BorderBrush = sel ? (Brush)FindResource("AccentBrush") : new SolidColorBrush(Color.FromArgb(80, 128, 128, 128));
            }
        }

        private void CustomColor_Click(object sender, RoutedEventArgs e)
        {
            using (var dlg = new System.Windows.Forms.ColorDialog { FullOpen = true, Color = System.Drawing.Color.FromArgb(_color.R, _color.G, _color.B) })
            {
                if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                    SetColor(Color.FromRgb(dlg.Color.R, dlg.Color.G, dlg.Color.B));
            }
        }

        private void Opt_Changed(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (!_ready) return;
            S.PenThickness = ThicknessSlider.Value;
            S.AnnOpacity = OpacitySlider.Value;
            S.TextSize = FontSlider.Value;
        }

        private void Stamp_Changed(object sender, SelectionChangedEventArgs e)
        {
            if (!_ready) return;
            S.Stamp = StampBox.SelectedItem as string ?? S.Stamp;
        }

        private void Undo_Click(object sender, RoutedEventArgs e) { _viewer.Undo(); UpdateDocButtons(); }
        private void Redo_Click(object sender, RoutedEventArgs e) { _viewer.Redo(); UpdateDocButtons(); }

        private void SelectTool(Tool t)
        {
            foreach (var child in Toolbar.Children.OfType<RadioButton>())
                if (child.Tag as string == t.ToString()) { child.IsChecked = true; return; }
        }

        // ======================= Контекстное меню страницы =======================

        private ContextMenu BuildPageMenu()
        {
            var m = new ContextMenu();
            void Add(string icon, string text, Action a)
            {
                var mi = new MenuItem { Header = text, Icon = new TextBlock { Text = icon, FontFamily = (FontFamily)FindResource("IconFont") } };
                mi.Click += (s, e) => { if (_doc != null) a(); };
                m.Items.Add(mi);
            }
            Add("\uE8C8", "Копировать выделенный текст", CopySelection);
            Add("\uE8B3", "Выделить весь текст страницы", () => { SelectTool(Tool.Select); _viewer.SelectAllOnPage(); });
            Add("\uEB9F", "Копировать страницу как изображение", CopyPageImage);
            Add("\uE722", "Распознать текст на странице (OCR)", () => RunOcr(false));
            Add("\uE734", "Закладка на странице", () => Bookmark_Click(null, null));
            Add("\uE7AD", "Повернуть страницу вправо", () => Rotate(90));
            Add("\uE74D", "Удалить все пометки страницы", () => AnnClearPage_Click(null, null));
            Add("\uE946", "Свойства документа", () => ShowProperties(0));
            return m;
        }

        private ContextMenu BuildThumbMenu()
        {
            var m = new ContextMenu();
            void Add(string icon, string text, Action a)
            {
                var mi = new MenuItem { Header = text, Icon = new TextBlock { Text = icon, FontFamily = (FontFamily)FindResource("IconFont") } };
                mi.Click += (s, e) => { if (_doc != null) a(); };
                m.Items.Add(mi);
            }
            Add("\uE7AD", "Повернуть вправо", () => Rotate(90));
            Add("\uE7AD", "Повернуть влево", () => Rotate(-90));
            Add("\uE74A", "Переместить выше", () => { _viewer.MovePage(_viewer.CurrentPage, -1); RebuildSidebar(); });
            Add("\uE74B", "Переместить ниже", () => { _viewer.MovePage(_viewer.CurrentPage, 1); RebuildSidebar(); });
            Add("\uE74D", "Убрать страницу (в сохраняемом PDF и печати)", () =>
            {
                if (_viewer.Pages.Count <= 1) return;
                _viewer.DeletePage(_viewer.CurrentPage); RebuildSidebar();
                StatusText.Text = "Страница убрана из просмотра. Исходный файл не изменён — сохраните результат в PDF.";
            });
            Add("\uEB9F", "Сохранить страницу как изображение…", ExportCurrentImage);
            Add("\uE749", "Напечатать эту страницу…", () => ShowPrint(true));
            return m;
        }

        protected override void OnContentRendered(EventArgs e)
        {
            base.OnContentRendered(e);
            ThumbList.ContextMenu = BuildThumbMenu();
        }

        // ======================= Буфер обмена =======================

        private void CopySelection()
        {
            if (!string.IsNullOrEmpty(_viewer.SelectedText))
            {
                try { Clipboard.SetText(_viewer.SelectedText); StatusText.Text = "Текст скопирован в буфер обмена."; }
                catch { StatusText.Text = "Буфер обмена занят другой программой."; }
            }
            else StatusText.Text = "Сначала выделите текст инструментом «Выделение текста» (V).";
        }

        private void CopyPageImage()
        {
            try
            {
                var bmp = DocViewer.RenderComposite(_doc, _viewer.Pages[_viewer.CurrentPage], 150, true, false);
                Clipboard.SetImage(bmp);
                StatusText.Text = "Изображение страницы скопировано.";
            }
            catch (Exception ex) { StatusText.Text = "Не удалось скопировать: " + ex.Message; }
        }

        // ======================= Поиск =======================

        private void Search_Click(object sender, RoutedEventArgs e)
        {
            if (Sidebar.Visibility != Visibility.Visible) SetSidebar(true);
            TabSearch.IsChecked = true;
            SearchBox.Focus(); SearchBox.SelectAll();
        }

        private void SearchBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (_hits.Count > 0 && SearchBox.Tag as string == SearchBox.Text + "|" + MatchCase.IsChecked) SearchNext_Click(null, null);
                else RunSearch();
                e.Handled = true;
            }
        }

        private void DoSearch_Click(object sender, RoutedEventArgs e) => RunSearch();

        private async void RunSearch()
        {
            if (_doc == null) return;
            var q = SearchBox.Text.Trim();
            int gen = ++_searchGen;
            _hits = new List<SearchHit>();
            _hitIndex = -1;
            SearchResults.ItemsSource = null;
            _viewer.SetSearchHits(null);
            if (q.Length == 0) { SearchStatus.Text = ""; return; }
            SearchBox.Tag = SearchBox.Text + "|" + MatchCase.IsChecked;
            bool mc = MatchCase.IsChecked == true;
            var byView = new Dictionary<int, List<Rect>>();
            var results = new ObservableCollection<SearchHit>();
            SearchResults.ItemsSource = results;
            int pages = _viewer.Pages.Count;
            bool noText = true;
            for (int i = 0; i < pages; i++)
            {
                if (gen != _searchGen || _doc == null) return;
                if (i % 4 == 0)
                {
                    SearchStatus.Text = $"Поиск… страница {i + 1} из {pages}";
                    await Dispatcher.Yield(DispatcherPriority.Background);
                    if (gen != _searchGen || _doc == null) return;
                }
                var docIdx = _viewer.Pages[i].Doc;
                List<Rect> found;
                string text;
                try
                {
                    if (_doc.CanRenderOffThread)
                    {
                        var d = _doc;
                        var res = await Task.Run(() => (d.Find(docIdx, q, mc), d.GetPageText(docIdx)));
                        found = res.Item1; text = res.Item2;
                    }
                    else { found = _doc.Find(docIdx, q, mc); text = _doc.GetPageText(docIdx); }
                }
                catch { continue; }
                if (gen != _searchGen) return;
                if (!string.IsNullOrEmpty(text)) noText = false;
                if (found.Count == 0) continue;
                byView[i] = found;
                var flat = text.Replace('\n', ' ');
                int pos = 0;
                foreach (var r in found)
                {
                    int at = flat.IndexOf(q, pos, mc ? StringComparison.Ordinal : StringComparison.CurrentCultureIgnoreCase);
                    string snip = flat;
                    if (at >= 0)
                    {
                        int s0 = Math.Max(0, at - 40), e0 = Math.Min(flat.Length, at + q.Length + 50);
                        snip = (s0 > 0 ? "…" : "") + flat.Substring(s0, e0 - s0) + (e0 < flat.Length ? "…" : "");
                        pos = at + q.Length;
                    }
                    else if (snip.Length > 90) snip = snip.Substring(0, 90) + "…";
                    var hit = new SearchHit { View = i, Rect = r, PageLabel = "Страница " + (i + 1), Snippet = snip };
                    _hits.Add(hit);
                    if (results.Count < 1500) results.Add(hit);
                }
                _viewer.SetSearchHits(byView);
            }
            if (gen != _searchGen) return;
            _viewer.SetSearchHits(byView);
            SearchStatus.Text = _hits.Count == 0
                ? (noText ? "В документе нет текстового слоя. Распознайте текст (OCR), затем повторите поиск." : "Ничего не найдено.")
                : $"Найдено: {_hits.Count} на {byView.Count} стр.";
            if (_hits.Count > 0) { _hitIndex = -1; SearchNext_Click(null, null); }
        }

        private void SearchNext_Click(object sender, RoutedEventArgs e) => MoveHit(1);
        private void SearchPrev_Click(object sender, RoutedEventArgs e) => MoveHit(-1);

        private void MoveHit(int d)
        {
            if (_hits.Count == 0) { if (SearchBox.Text.Trim().Length > 0) RunSearch(); return; }
            _hitIndex = ((_hitIndex + d) % _hits.Count + _hits.Count) % _hits.Count;
            var h = _hits[_hitIndex];
            _viewer.SetActiveHit(h.View, h.Rect);
            SearchStatus.Text = $"Совпадение {_hitIndex + 1} из {_hits.Count}";
        }

        private void SearchResults_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (SearchResults.SelectedItem is SearchHit h)
            {
                _hitIndex = _hits.IndexOf(h);
                _viewer.SetActiveHit(h.View, h.Rect);
            }
        }

        // ======================= OCR =======================

        private void Ocr_Click(object sender, RoutedEventArgs e)
        {
            if (_doc == null) return;
            var m = new ContextMenu();
            var a = new MenuItem { Header = "Распознать текущую страницу" }; a.Click += (s, x) => RunOcr(false); m.Items.Add(a);
            var b = new MenuItem { Header = "Распознать все страницы" }; b.Click += (s, x) => RunOcr(true); m.Items.Add(b);
            var info = new MenuItem { Header = "Языки распознавания: " + OcrService.AvailableLanguages(), IsEnabled = false }; m.Items.Add(info);
            m.PlacementTarget = sender as UIElement; m.Placement = PlacementMode.Bottom; m.IsOpen = true;
        }

        private async void RunOcr(bool all)
        {
            if (_doc == null) return;
            var doc = _doc;
            var targets = all ? Enumerable.Range(0, _viewer.Pages.Count).ToList() : new List<int> { _viewer.CurrentPage };
            int done = 0, chars = 0;
            ShowLoading("Распознавание текста…");
            try
            {
                foreach (var v in targets)
                {
                    if (_doc != doc) return;
                    var r = _viewer.Pages[v];
                    LoadingText.Text = $"Распознавание текста: страница {v + 1} ({done + 1} из {targets.Count})";
                    var size = doc.GetPageSize(r.Doc);
                    double scale = Math.Min(3.0, 2600 / Math.Max(size.Width, size.Height));
                    BitmapSource bmp = doc.CanRenderOffThread ? await Task.Run(() => doc.RenderPage(r.Doc, scale)) : doc.RenderPage(r.Doc, scale);
                    var list = await OcrService.RecognizeAsync(bmp, scale);
                    doc.SetOcrChars(r.Doc, list);
                    chars += list.Count;
                    done++;
                }
                StatusText.Text = $"Распознано символов: {chars} на {done} стр. Теперь доступны поиск, выделение и копирование.";
                _searchGen++; _hits.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Распознавание не выполнено:\n\n" + ex.Message, "DocuNova", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            finally { HideLoading(); }
        }

        // ======================= Сохранение и экспорт =======================

        private void SavePdf_Click(object sender, RoutedEventArgs e)
        {
            if (_doc == null) return;
            SavePdf(_viewer.Pages);
        }

        private bool SavePdf(IList<PageRef> pages)
        {
            var dlg = new SaveFileDialog
            {
                Filter = "Документ PDF|*.pdf",
                FileName = Path.GetFileNameWithoutExtension(_path ?? "Документ") + (_doc.IsPdf ? " (с пометками)" : "") + ".pdf",
                Title = "Сохранить как PDF"
            };
            if (dlg.ShowDialog(this) != true) return false;
            if (string.Equals(Path.GetFullPath(dlg.FileName), _path, StringComparison.OrdinalIgnoreCase))
            {
                MessageBox.Show(this, "Для безопасности исходный файл не перезаписывается. Выберите другое имя.", "DocuNova", MessageBoxButton.OK, MessageBoxImage.Information);
                return false;
            }
            try
            {
                Mouse.OverrideCursor = Cursors.Wait;
                PdfExport.Save(_doc, pages, dlg.FileName, S.ExportDpi, (i, n) => StatusText.Text = $"Сохранение: страница {i} из {n}");
                _viewer.Modified = false;
                StatusText.Text = "Сохранено: " + dlg.FileName;
                ShowBanner("PDF сохранён: " + Path.GetFileName(dlg.FileName), false);
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Не удалось сохранить PDF:\n\n" + ex.Message, "DocuNova", MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }
            finally { Mouse.OverrideCursor = null; }
        }

        private void Export_Click(object sender, RoutedEventArgs e)
        {
            var m = new ContextMenu();
            void Add(string icon, string text, Action a, bool needDoc = true)
            {
                var mi = new MenuItem { Header = text, Icon = new TextBlock { Text = icon, FontFamily = (FontFamily)FindResource("IconFont") }, IsEnabled = !needDoc || _doc != null };
                mi.Click += (s, x) => a();
                m.Items.Add(mi);
            }
            Add("\uEB9F", "Текущую страницу как изображение (PNG/JPEG/TIFF)…", ExportCurrentImage);
            Add("\uE8B9", "Все страницы как изображения в папку…", ExportAllImages);
            Add("\uE8A5", "Текст документа в TXT…", ExportText);
            Add("\uE8C8", "Копировать текст всего документа", CopyAllText);
            Add("\uE8A5", "Выбранные страницы в отдельный PDF…", ExportRange);
            Add("\uE8F1", "Объединить несколько PDF в один…", MergePdfs, false);
            m.PlacementTarget = sender as UIElement; m.Placement = PlacementMode.Bottom; m.IsOpen = true;
        }

        private void ExportCurrentImage()
        {
            var dlg = new SaveFileDialog { Filter = "PNG|*.png|JPEG|*.jpg|TIFF|*.tif", FileName = $"{Path.GetFileNameWithoutExtension(_path)} — стр. {_viewer.CurrentPage + 1}.png" };
            if (dlg.ShowDialog(this) != true) return;
            try
            {
                var bmp = DocViewer.RenderComposite(_doc, _viewer.Pages[_viewer.CurrentPage], S.ExportDpi, true, false);
                PdfExport.SaveImage(bmp, dlg.FileName);
                StatusText.Text = "Сохранено: " + dlg.FileName;
            }
            catch (Exception ex) { MessageBox.Show(this, ex.Message, "DocuNova"); }
        }

        private async void ExportAllImages()
        {
            var dlg = new OpenFolderDialog { Title = "Папка для изображений страниц" };
            if (dlg.ShowDialog(this) != true) return;
            var doc = _doc;
            var name = Path.GetFileNameWithoutExtension(_path);
            ShowLoading("Экспорт изображений…");
            try
            {
                for (int i = 0; i < _viewer.Pages.Count; i++)
                {
                    if (_doc != doc) return;
                    LoadingText.Text = $"Экспорт изображений: {i + 1} из {_viewer.Pages.Count}";
                    await Dispatcher.Yield(DispatcherPriority.Background);
                    var bmp = DocViewer.RenderComposite(doc, _viewer.Pages[i], S.ExportDpi, true, false);
                    PdfExport.SaveImage(bmp, Path.Combine(dlg.FolderName, $"{name} — {i + 1:D4}.png"));
                }
                StatusText.Text = "Изображения сохранены в " + dlg.FolderName;
            }
            catch (Exception ex) { MessageBox.Show(this, ex.Message, "DocuNova"); }
            finally { HideLoading(); }
        }

        private string AllText()
        {
            var sb = new StringBuilder();
            for (int i = 0; i < _viewer.Pages.Count; i++)
            {
                sb.AppendLine(_doc.GetPageText(_viewer.Pages[i].Doc));
                sb.AppendLine();
            }
            return sb.ToString();
        }

        private void ExportText()
        {
            var dlg = new SaveFileDialog { Filter = "Текст (UTF-8)|*.txt", FileName = Path.GetFileNameWithoutExtension(_path) + ".txt" };
            if (dlg.ShowDialog(this) != true) return;
            try
            {
                Mouse.OverrideCursor = Cursors.Wait;
                File.WriteAllText(dlg.FileName, AllText(), new UTF8Encoding(true));
                StatusText.Text = "Текст сохранён: " + dlg.FileName;
            }
            catch (Exception ex) { MessageBox.Show(this, ex.Message, "DocuNova"); }
            finally { Mouse.OverrideCursor = null; }
        }

        private void CopyAllText()
        {
            try
            {
                Mouse.OverrideCursor = Cursors.Wait;
                var t = AllText();
                if (string.IsNullOrWhiteSpace(t)) { StatusText.Text = "В документе нет текстового слоя (используйте OCR)."; return; }
                Clipboard.SetText(t);
                StatusText.Text = $"Скопировано символов: {t.Length:N0}";
            }
            catch (Exception ex) { StatusText.Text = ex.Message; }
            finally { Mouse.OverrideCursor = null; }
        }

        private void ExportRange()
        {
            var range = InputDialog.Ask(this, "Страницы в отдельный PDF", $"Укажите номера страниц (1–{_viewer.Pages.Count}), например: 1-3, 5, 8-", $"{_viewer.CurrentPage + 1}");
            if (range == null) return;
            var idx = PrintService.ParseRange(range, _viewer.Pages.Count);
            if (idx.Count == 0) { MessageBox.Show(this, "Не распознан диапазон страниц.", "DocuNova"); return; }
            SavePdf(idx.Select(i => _viewer.Pages[i]).ToList());
        }

        private void MergePdfs()
        {
            var open = new OpenFileDialog { Filter = "PDF|*.pdf", Multiselect = true, Title = "Выберите PDF-файлы (в нужном порядке)" };
            if (open.ShowDialog(this) != true || open.FileNames.Length == 0) return;
            var save = new SaveFileDialog { Filter = "PDF|*.pdf", FileName = "Объединённый документ.pdf" };
            if (save.ShowDialog(this) != true) return;
            try
            {
                Mouse.OverrideCursor = Cursors.Wait;
                PdfExport.Merge(open.FileNames.OrderBy(f => f, new DocumentLoader.NaturalComparer()), save.FileName);
                StatusText.Text = "Объединено файлов: " + open.FileNames.Length;
                if (MessageBox.Show(this, "PDF объединены. Открыть результат?", "DocuNova", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                    OpenFile(save.FileName);
            }
            catch (Exception ex) { MessageBox.Show(this, "Не удалось объединить: " + ex.Message, "DocuNova"); }
            finally { Mouse.OverrideCursor = null; }
        }

        // ======================= Печать, свойства, настройки, справка =======================

        private void Print_Click(object sender, RoutedEventArgs e) => ShowPrint(false);

        private void ShowPrint(bool currentOnly)
        {
            if (_doc == null) return;
            var w = new PrintWindow(_doc, _viewer.Pages, _viewer.CurrentPage, currentOnly) { Owner = this };
            w.ShowDialog();
        }

        private void Properties_Click(object sender, RoutedEventArgs e) => ShowProperties(0);

        private void ShowProperties(int tab)
        {
            if (_doc == null) return;
            var w = new PropertiesWindow(_doc, _path, _viewer.Pages.Count, tab) { Owner = this };
            w.ShowDialog();
        }

        private void Settings_Click(object sender, RoutedEventArgs e) => ShowSettings(0);
        private void ReadSettings_Click(object sender, RoutedEventArgs e) => ShowSettings(1);

        private void ShowSettings(int tab)
        {
            var before = System.Text.Json.JsonSerializer.Serialize(S.Reflow);
            var w = new SettingsWindow(tab) { Owner = this };
            w.ShowDialog();
            ApplyViewSettings();
            BuildSwatches();
            UpdateSecurityBadge();
            if (_doc != null && _doc.IsReflowable && before != System.Text.Json.JsonSerializer.Serialize(S.Reflow))
            {
                if (_viewer.HasAnnotations &&
                    MessageBox.Show(this, "Изменение параметров чтения перестроит страницы книги, и пометки будут удалены. Продолжить?", "DocuNova", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes)
                    return;
                ShowLoading("Перестроение страниц…");
                Dispatcher.BeginInvoke(new Action(() =>
                {
                    try
                    {
                        var rs = S.Reflow.Clone(); rs.Light = false;
                        _doc.Reflow(rs);
                        _viewer.ReloadPagesAfterReflow();
                        RebuildSidebar();
                        OnCurrentPageChanged(_viewer.CurrentPage);
                    }
                    catch (Exception ex) { ShowError("Не удалось перестроить страницы", ex); }
                    finally { HideLoading(); }
                }), DispatcherPriority.Background);
            }
            else _viewer.RerenderAll();
            RefreshRecent();
        }

        private void Help_Click(object sender, RoutedEventArgs e)
        {
            new HelpWindow { Owner = this }.ShowDialog();
        }

        // ======================= Клавиатура =======================

        protected override void OnPreviewKeyDown(KeyEventArgs e)
        {
            base.OnPreviewKeyDown(e);
            if (e.Handled) return;
            var mods = Keyboard.Modifiers;
            bool ctrl = (mods & ModifierKeys.Control) != 0, shift = (mods & ModifierKeys.Shift) != 0, alt = (mods & ModifierKeys.Alt) != 0;
            bool inText = Keyboard.FocusedElement is TextBox || Keyboard.FocusedElement is PasswordBox;
            var key = e.Key == Key.System ? e.SystemKey : e.Key;

            if (ctrl)
            {
                switch (key)
                {
                    case Key.O when shift: RunOcr(false); e.Handled = true; return;
                    case Key.O: Open_Click(null, null); e.Handled = true; return;
                    case Key.S: SavePdf_Click(null, null); e.Handled = true; return;
                    case Key.P: Print_Click(null, null); e.Handled = true; return;
                    case Key.E: if (_doc != null) Export_Click(ExportBtn, null); e.Handled = true; return;
                    case Key.W: if (ConfirmDiscard()) CloseDocument(); e.Handled = true; return;
                    case Key.F: Search_Click(null, null); e.Handled = true; return;
                    case Key.B: Bookmark_Click(null, null); e.Handled = true; return;
                    case Key.Z when !inText: Undo_Click(null, null); e.Handled = true; return;
                    case Key.Y when !inText: Redo_Click(null, null); e.Handled = true; return;
                    case Key.C when !inText: CopySelection(); e.Handled = true; return;
                    case Key.A when !inText: SelectTool(Tool.Select); _viewer.SelectAllOnPage(); e.Handled = true; return;
                    case Key.OemPlus: case Key.Add: ZoomIn_Click(null, null); e.Handled = true; return;
                    case Key.OemMinus: case Key.Subtract: ZoomOut_Click(null, null); e.Handled = true; return;
                    case Key.D0: case Key.NumPad0: _viewer.SetZoom(1); e.Handled = true; return;
                    case Key.D1: FitPage_Click(null, null); e.Handled = true; return;
                    case Key.D2: FitWidth_Click(null, null); e.Handled = true; return;
                    case Key.D3: TwoPageBtn.IsChecked = !(TwoPageBtn.IsChecked == true); TwoPage_Click(null, null); e.Handled = true; return;
                    case Key.L: Rotate(-90); e.Handled = true; return;
                    case Key.R: Rotate(90); e.Handled = true; return;
                    case Key.N: PageMode_Click(null, null); e.Handled = true; return;
                    case Key.OemComma: Settings_Click(null, null); e.Handled = true; return;
                    case Key.Home when !inText: _viewer.GoTo(0); e.Handled = true; return;
                    case Key.End when !inText: _viewer.GoTo(_viewer.Pages.Count - 1); e.Handled = true; return;
                }
                return;
            }
            if (alt && key == Key.Enter) { Properties_Click(null, null); e.Handled = true; return; }

            switch (key)
            {
                case Key.F1: Help_Click(null, null); e.Handled = true; return;
                case Key.F3: if (shift) SearchPrev_Click(null, null); else SearchNext_Click(null, null); e.Handled = true; return;
                case Key.F9: Sidebar_Click(null, null); e.Handled = true; return;
                case Key.F11: SetFullScreen(!_fullscreen); e.Handled = true; return;
                case Key.Escape:
                    if (_fullscreen) { SetFullScreen(false); e.Handled = true; return; }
                    if (!inText) { HandTool.IsChecked = true; _viewer.ClearSelection(); }
                    return;
            }
            if (inText || _doc == null) return;
            switch (key)
            {
                case Key.Right: if (_viewer.Scroll.ScrollableWidth < 1) { _viewer.Next(); e.Handled = true; } return;
                case Key.Left: if (_viewer.Scroll.ScrollableWidth < 1) { _viewer.Prev(); e.Handled = true; } return;
                case Key.Home: _viewer.GoTo(0); e.Handled = true; return;
                case Key.End: _viewer.GoTo(_viewer.Pages.Count - 1); e.Handled = true; return;
                case Key.Delete:
                    if (AnnList.IsKeyboardFocusWithin) { AnnDelete_Click(null, null); e.Handled = true; }
                    return;
            }
            Tool? t = null;
            switch (key)
            {
                case Key.H: t = Tool.Hand; break;
                case Key.V: t = Tool.Select; break;
                case Key.M: t = Tool.Highlight; break;
                case Key.U: t = Tool.Underline; break;
                case Key.K: t = Tool.Strike; break;
                case Key.P: t = Tool.Pen; break;
                case Key.F: t = Tool.Marker; break;
                case Key.R: t = Tool.Rect; break;
                case Key.O: t = Tool.Ellipse; break;
                case Key.A: t = Tool.Arrow; break;
                case Key.L: t = Tool.Line; break;
                case Key.T: t = Tool.Text; break;
                case Key.N: t = Tool.Note; break;
                case Key.S: t = Tool.Stamp; break;
                case Key.D: t = Tool.Redact; break;
                case Key.W: t = Tool.WhiteOut; break;
                case Key.E: t = Tool.Eraser; break;
            }
            if (t.HasValue) { SelectTool(t.Value); e.Handled = true; }
        }
    }
}
