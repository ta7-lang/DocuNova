using System;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;
using DocuNova.Services;
using DocuNova.Themes;

namespace DocuNova
{
    public partial class App : Application
    {
        public static AppSettings Settings { get; private set; }

        protected override void OnStartup(StartupEventArgs e)
        {
            // Усиление защиты процесса — до загрузки любых документов
            Hardening.Apply();

            DispatcherUnhandledException += OnUiException;
            TaskScheduler.UnobservedTaskException += (s, a) => a.SetObserved();
            AppDomain.CurrentDomain.UnhandledException += (s, a) =>
            {
                try { MessageBox.Show("Критическая ошибка: " + (a.ExceptionObject as Exception)?.Message, "DocuNova", MessageBoxButton.OK, MessageBoxImage.Error); } catch { }
            };

            base.OnStartup(e);

            // служебный режим для установщика: очистка системного кэша эскизов
            if (e.Args != null && e.Args.Any(a => string.Equals(a, "/clear-thumbcache", StringComparison.OrdinalIgnoreCase)))
            {
                try { ShellIntegration.ClearThumbnailCache(); } catch { }
                Shutdown();
                return;
            }

            Settings = AppSettings.Load();
            ThemeManager.Apply(ThemeManager.Find(Settings.ThemeName, Settings.CustomTheme));

            var w = new MainWindow();
            MainWindow = w;
            w.Show();
            var file = e.Args?.FirstOrDefault(a => !a.StartsWith("/") && !a.StartsWith("-"));
            if (!string.IsNullOrEmpty(file)) w.OpenFile(file);
        }

        private void OnUiException(object sender, DispatcherUnhandledExceptionEventArgs e)
        {
            e.Handled = true;
            try
            {
                MessageBox.Show(MainWindow, "Произошла ошибка, но приложение продолжает работу:\n\n" + e.Exception.Message,
                    "DocuNova", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
            catch { }
        }

        protected override void OnExit(ExitEventArgs e)
        {
            try
            {
                if (Settings != null)
                {
                    if (Settings.ClearRecentOnExit) Settings.Recent.Clear();
                    Settings.Save();
                }
            }
            catch { }
            base.OnExit(e);
        }
    }
}
