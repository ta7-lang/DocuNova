using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace DocuNova.Services
{
    public sealed class ToolInfo
    {
        public string Key, Icon, Title, Description, Hotkey, Group;
        public ToolInfo(string group, string key, string icon, string title, string hotkey, string description)
        { Group = group; Key = key; Icon = icon; Title = title; Hotkey = hotkey; Description = description; }
    }

    /// <summary>Единый справочник всех инструментов: значок, название, горячая клавиша и понятное пояснение.</summary>
    public static class ToolCatalog
    {
        public static readonly List<ToolInfo> All = new List<ToolInfo>
        {
            // Файл
            new ToolInfo("Файл", "Open", "\uE8E5", "Открыть документ", "Ctrl+O", "Открывает файл PDF, EPUB, FB2, MOBI, DOCX, DOC, RTF, ODT, TXT и других форматов. Можно также перетащить файл в окно."),
            new ToolInfo("Файл", "SavePdf", "\uE74E", "Сохранить как PDF", "Ctrl+S", "Сохраняет документ в новый PDF вместе со всеми пометками, поворотами и удалёнными страницами. Исходный файл не изменяется."),
            new ToolInfo("Файл", "Export", "\uEDE1", "Экспорт", "Ctrl+E", "Экспорт страниц в изображения PNG/JPEG, текста — в TXT, выбранных страниц — в отдельный PDF, а также объединение нескольких PDF в один."),
            new ToolInfo("Файл", "PdfEditor", "\uE8A5", "Редактор PDF", "Ctrl+M", "Объединение нескольких PDF и изображений в один документ, перестановка страниц перетаскиванием, удаление, поворот, дублирование, вставка пустых страниц, извлечение выбранных страниц и разделение на файлы. Результат сохраняется в новый PDF без потери качества — исходные файлы не изменяются."),
            new ToolInfo("Файл", "Print", "\uE749", "Печать", "Ctrl+P", "Печать с выбором принтера, диапазона, числа копий, ориентации, масштаба, нескольких страниц на листе, двусторонней и чёрно-белой печати. Есть предпросмотр."),
            new ToolInfo("Файл", "Properties", "\uE946", "Свойства документа", "Alt+Enter", "Подробные сведения: файл, метаданные, статистика, форматы страниц, шрифты, контрольные суммы и отчёт о безопасности."),
            new ToolInfo("Файл", "CloseDoc", "\uE8BB", "Закрыть вкладку", "Ctrl+W", "Закрывает текущую вкладку и освобождает всю занятую документом память. Также — средняя кнопка мыши по вкладке."),

            // Вкладки и параллельный просмотр
            new ToolInfo("Вкладки", "NextTab", "\uE72A", "Следующая вкладка", "Ctrl+Tab", "Переход к следующему открытому документу. Ctrl+Shift+Tab — к предыдущему. Также Ctrl+PageDown / Ctrl+PageUp."),
            new ToolInfo("Вкладки", "Parallel", "\uE7C4", "Параллельный просмотр", "Ctrl+\\", "Показывает два и более документа рядом в одном окне (до 6). Щёлкните по панели, чтобы сделать её активной — инструменты, поиск и боковая панель работают с ней. Ctrl+щелчок по вкладке добавляет документ в параллельный просмотр. F6 — следующая панель."),
            new ToolInfo("Вкладки", "ParallelLayout", "\uE8AB", "Расположение панелей", "", "Меняет расположение документов в параллельном просмотре: рядом, друг под другом или сеткой. Границу между панелями можно перетаскивать мышью."),
            new ToolInfo("Вкладки", "SyncScroll", "\uE895", "Синхронная прокрутка", "", "При прокрутке активной панели остальные документы листаются вместе с ней — удобно сравнивать версии и переводы."),

            // Правка
            new ToolInfo("Правка", "Undo", "\uE7A7", "Отменить", "Ctrl+Z", "Отменяет последнее действие с пометками."),
            new ToolInfo("Правка", "Redo", "\uE7A6", "Повторить", "Ctrl+Y", "Возвращает отменённое действие."),

            // Инструменты
            new ToolInfo("Инструменты", "Hand", "\uE7C9", "Рука (прокрутка)", "H", "Перетаскивайте страницу мышью для прокрутки. Обычный режим чтения."),
            new ToolInfo("Инструменты", "Select", "\uE8B3", "Выделение текста", "V", "Обведите рамкой текст, чтобы выделить его. Ctrl+C — скопировать. Работает и для сканов после распознавания (OCR)."),
            new ToolInfo("Инструменты", "Highlight", "\uE7E6", "Маркер-выделитель", "M", "Обведите текст — он будет выделен полупрозрачным цветом построчно. На сканах выделяется прямоугольная область."),
            new ToolInfo("Инструменты", "Underline", "\uE8DC", "Подчеркнуть", "U", "Подчёркивает выделенные рамкой строки текста выбранным цветом."),
            new ToolInfo("Инструменты", "Strike", "\uEDE0", "Зачеркнуть", "K", "Зачёркивает выделенные строки — удобно для правок и рецензирования."),
            new ToolInfo("Инструменты", "Pen", "\uE70F", "Перо", "P", "Рисование от руки тонкой линией: подписи, пометки на полях, стрелки."),
            new ToolInfo("Инструменты", "Marker", "\uE76D", "Фломастер", "F", "Широкая полупрозрачная линия от руки — для свободного выделения."),
            new ToolInfo("Инструменты", "Rect", "\uE739", "Прямоугольник", "R", "Рамка вокруг области: удерживайте кнопку мыши и тяните."),
            new ToolInfo("Инструменты", "Ellipse", "\uEA3A", "Овал", "O", "Обвести фрагмент овалом: удерживайте и тяните."),
            new ToolInfo("Инструменты", "Arrow", "\uE72A", "Стрелка", "A", "Стрелка-указатель от точки нажатия к точке отпускания."),
            new ToolInfo("Инструменты", "Line", "\uE738", "Линия", "L", "Прямая линия. Удерживайте Shift для строго горизонтальной или вертикальной линии."),
            new ToolInfo("Инструменты", "Text", "\uE8D2", "Текст", "T", "Щёлкните в нужном месте и введите надпись. Размер и цвет — на панели параметров."),
            new ToolInfo("Инструменты", "Note", "\uE70B", "Заметка", "N", "Жёлтый стикер с комментарием. Щёлкните в нужном месте и введите текст."),
            new ToolInfo("Инструменты", "Stamp", "\uE8EC", "Штамп", "S", "Ставит штамп («ОДОБРЕНО», «ЧЕРНОВИК», «КОПИЯ» и др.) щелчком мыши. Текст штампа выбирается на панели параметров."),
            new ToolInfo("Инструменты", "Redact", "\uE72E", "Скрыть (редактирование)", "D", "Закрашивает область чёрным. При сохранении в PDF страница с такой областью растрируется — скрытый текст удаляется по-настоящему."),
            new ToolInfo("Инструменты", "WhiteOut", "\uE75C", "Замазка", "W", "Закрашивает область белым — как корректор. При сохранении страница растрируется, текст под замазкой удаляется."),
            new ToolInfo("Инструменты", "Eraser", "\uE74D", "Ластик пометок", "E", "Щёлкните по пометке, чтобы удалить её. Сам документ не изменяется."),

            // Вид
            new ToolInfo("Вид", "ZoomOut", "\uE71F", "Уменьшить", "Ctrl+−", "Уменьшает масштаб. Также Ctrl + колесо мыши."),
            new ToolInfo("Вид", "ZoomIn", "\uE8A3", "Увеличить", "Ctrl+=", "Увеличивает масштаб до 800 %. Также Ctrl + колесо мыши."),
            new ToolInfo("Вид", "FitWidth", "\uE9A6", "По ширине", "Ctrl+2", "Подгоняет страницу под ширину окна — удобно для чтения."),
            new ToolInfo("Вид", "FitPage", "\uE73F", "Страница целиком", "Ctrl+1", "Показывает страницу полностью."),
            new ToolInfo("Вид", "RotateLeft", "\uE7AD", "Повернуть влево", "Ctrl+L", "Поворачивает текущую страницу на 90° против часовой стрелки (для всех страниц — с Shift)."),
            new ToolInfo("Вид", "RotateRight", "\uE7AD", "Повернуть вправо", "Ctrl+R", "Поворачивает текущую страницу на 90° по часовой стрелке (для всех страниц — с Shift)."),
            new ToolInfo("Вид", "TwoPage", "\uE8A9", "Разворот", "Ctrl+3", "Показывает по две страницы рядом, как в книге. Режим «с обложкой» выносит первую страницу отдельно (далее пары 2–3, 4–5…), обычный разворот — пары 1–2, 3–4. Ctrl+3 переключает: одна страница → разворот с обложкой → разворот."),
            new ToolInfo("Вид", "PageMode", "\uE708", "Режим страницы", "Ctrl+N", "Переключает цвет страниц: обычный → ночной (инверсия, бережёт глаза) → сепия (тёплый бумажный)."),
            new ToolInfo("Вид", "Sidebar", "\uE700", "Боковая панель", "F9", "Показывает или скрывает панель с эскизами страниц, оглавлением, закладками, поиском и списком пометок."),
            new ToolInfo("Вид", "FullScreen", "\uE740", "Полный экран", "F11", "Режим чтения без отвлекающих элементов. Выход — F11 или Esc."),

            // Сервис
            new ToolInfo("Сервис", "Search", "\uE721", "Поиск в документе", "Ctrl+F", "Ищет текст по всему документу и подсвечивает совпадения. F3 — следующее совпадение."),
            new ToolInfo("Сервис", "Ocr", "\uE722", "Распознать текст (OCR)", "Ctrl+Shift+O", "Распознаёт текст на скане или фото встроенным в Windows офлайн-движком — после этого работают поиск, выделение и копирование."),
            new ToolInfo("Сервис", "Bookmark", "\uE734", "Закладка", "Ctrl+B", "Добавляет текущую страницу в закладки для быстрого перехода."),
            new ToolInfo("Сервис", "ReadSettings", "\uE736", "Параметры чтения", "", "Шрифт, размер, межстрочный интервал и поля для книг (EPUB, FB2, MOBI, TXT, HTML) — страницы перестраиваются мгновенно."),
            new ToolInfo("Сервис", "Settings", "\uE713", "Настройки", "Ctrl+,", "Темы оформления с неоновыми градиентами и собственными цветами, параметры чтения, интеграция с Проводником, очистка кэша и безопасность."),
            new ToolInfo("Сервис", "Help", "\uE897", "Справка", "F1", "Список всех инструментов с пояснениями и горячими клавишами, поддерживаемые форматы."),
        };

        private static Dictionary<string, ToolInfo> _map;
        public static ToolInfo Get(string key)
        {
            if (_map == null) { _map = new Dictionary<string, ToolInfo>(); foreach (var t in All) _map[t.Key] = t; }
            return _map.TryGetValue(key, out var v) ? v : null;
        }

        /// <summary>Строит подсказку: заголовок, горячая клавиша и пояснение.</summary>
        public static object BuildTip(ToolInfo t)
        {
            var sp = new StackPanel { MaxWidth = 340 };
            var head = new DockPanel { LastChildFill = true };
            if (!string.IsNullOrEmpty(t.Hotkey))
            {
                var hk = new Border
                {
                    CornerRadius = new CornerRadius(4),
                    Padding = new Thickness(6, 1, 6, 1),
                    Margin = new Thickness(10, 0, 0, 0),
                    VerticalAlignment = VerticalAlignment.Center,
                    Child = new TextBlock { Text = t.Hotkey, FontSize = 11.5, FontFamily = new FontFamily("Consolas, Segoe UI") }
                };
                hk.SetResourceReference(Border.BackgroundProperty, "HoverBrush");
                DockPanel.SetDock(hk, Dock.Right);
                head.Children.Add(hk);
            }
            var title = new TextBlock { Text = t.Title, FontWeight = FontWeights.SemiBold, FontSize = 14 };
            head.Children.Add(title);
            sp.Children.Add(head);
            var line = new Border { Height = 2, Margin = new Thickness(0, 6, 0, 6), CornerRadius = new CornerRadius(1) };
            line.SetResourceReference(Border.BackgroundProperty, "AccentBrush");
            sp.Children.Add(line);
            var desc = new TextBlock { Text = t.Description, TextWrapping = TextWrapping.Wrap, FontSize = 12.5 };
            desc.SetResourceReference(TextBlock.ForegroundProperty, "SubFgBrush");
            sp.Children.Add(desc);
            return sp;
        }
    }

    /// <summary>Присоединённое свойство: Tip.Key="Highlight" — задаёт значок и подробную подсказку из справочника.</summary>
    public static class Tip
    {
        public static readonly DependencyProperty KeyProperty = DependencyProperty.RegisterAttached(
            "Key", typeof(string), typeof(Tip), new PropertyMetadata(null, OnKeyChanged));

        public static string GetKey(DependencyObject d) => (string)d.GetValue(KeyProperty);
        public static void SetKey(DependencyObject d, string v) => d.SetValue(KeyProperty, v);

        private static void OnKeyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var t = ToolCatalog.Get(e.NewValue as string);
            if (t == null || !(d is ContentControl cc)) return;
            if (cc.Content == null) cc.Content = t.Icon;
            cc.ToolTip = new ToolTip { Content = ToolCatalog.BuildTip(t) };
        }
    }
}
