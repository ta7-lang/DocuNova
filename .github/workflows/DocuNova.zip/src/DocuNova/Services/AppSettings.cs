using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using DocuNova.Core;

namespace DocuNova.Services
{
    /// <summary>Описание темы оформления. Цвета хранятся строками #RRGGBB / #AARRGGBB.</summary>
    public sealed class ThemeDef
    {
        public string Name { get; set; } = "Своя тема";
        public string Bg1 { get; set; } = "#0B0420";
        public string Bg2 { get; set; } = "#1A0B3D";
        public string Panel { get; set; } = "#14102A";
        public string Text { get; set; } = "#F2EEFF";
        public string SubText { get; set; } = "#A9A2C9";
        public string Accent1 { get; set; } = "#FF2BD6";
        public string Accent2 { get; set; } = "#00F0FF";
        public string ViewerBg { get; set; } = "#100A24";
        public double Glow { get; set; } = 0.8;
        public double Radius { get; set; } = 10;
        public double GradientAngle { get; set; } = 135;
        public double PanelOpacity { get; set; } = 0.85;
        public bool IsDark { get; set; } = true;

        public ThemeDef Clone() => (ThemeDef)MemberwiseClone();
    }

    public sealed class AppSettings
    {
        public string ThemeName { get; set; } = "Неон Киберпанк";
        public ThemeDef CustomTheme { get; set; }
        public ReflowSettings Reflow { get; set; } = new ReflowSettings();
        public bool RememberRecent { get; set; } = true;
        public List<string> Recent { get; set; } = new List<string>();
        public string PageMode { get; set; } = "normal"; // normal | night | sepia
        public bool TwoPage { get; set; }
        public bool ShowSidebar { get; set; } = true;
        public double PageGap { get; set; } = 18;
        public bool PageShadows { get; set; } = true;
        public string FitMode { get; set; } = "width"; // width | page | none
        public string PenColor { get; set; } = "#FFFF2BD6";
        public double PenThickness { get; set; } = 3;
        public double AnnOpacity { get; set; } = 1;
        public double TextSize { get; set; } = 16;
        public string Stamp { get; set; } = "ОДОБРЕНО";
        public bool WarnInternetFiles { get; set; } = true;
        public bool ClearRecentOnExit { get; set; }
        public int ExportDpi { get; set; } = 200;
        public double WindowWidth { get; set; } = 1360;
        public double WindowHeight { get; set; } = 860;
        public bool WindowMaximized { get; set; }

        private static string Dir => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "DocuNova");
        private static string FilePath => Path.Combine(Dir, "settings.json");

        public static AppSettings Load()
        {
            try
            {
                if (File.Exists(FilePath))
                {
                    var fi = new FileInfo(FilePath);
                    if (fi.Length < 1024 * 1024)
                    {
                        var s = JsonSerializer.Deserialize<AppSettings>(File.ReadAllText(FilePath));
                        if (s != null)
                        {
                            s.Reflow = s.Reflow ?? new ReflowSettings();
                            s.Reflow.Light = false;
                            s.Recent = s.Recent ?? new List<string>();
                            return s;
                        }
                    }
                }
            }
            catch { }
            return new AppSettings();
        }

        public void Save()
        {
            try
            {
                Directory.CreateDirectory(Dir);
                if (!RememberRecent) Recent.Clear();
                if (Recent.Count > 15) Recent.RemoveRange(15, Recent.Count - 15);
                var tmp = FilePath + ".tmp";
                File.WriteAllText(tmp, JsonSerializer.Serialize(this, new JsonSerializerOptions { WriteIndented = true }));
                File.Copy(tmp, FilePath, true);
                File.Delete(tmp);
            }
            catch { }
        }

        public void AddRecent(string path)
        {
            if (!RememberRecent || string.IsNullOrEmpty(path)) return;
            Recent.RemoveAll(p => string.Equals(p, path, StringComparison.OrdinalIgnoreCase));
            Recent.Insert(0, path);
            if (Recent.Count > 15) Recent.RemoveRange(15, Recent.Count - 15);
        }
    }
}
