using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using DocuNova.Core;
using DocuNova.Services;

namespace DocuNova.Viewer
{
    /// <summary>
    /// Просмотрщик страниц с виртуализацией: в памяти держатся только видимые страницы,
    /// поэтому даже документы на тысячи страниц не расходуют лишнюю память. На диск ничего не кэшируется.
    /// </summary>
    public sealed class DocViewer : Grid
    {
        public ScrollViewer Scroll { get; }
        private readonly Canvas _host;
        private DocumentBase _doc;
        public DocumentBase Document => _doc;
        public List<PageRef> Pages { get; } = new List<PageRef>();
        private Rect[] _rects = Array.Empty<Rect>();
        private readonly Dictionary<PageRef, PageView> _live = new Dictionary<PageRef, PageView>();
        // Очередь отрисовки: видимые страницы — первыми, затем запас для прокрутки, затем эскизы боковой панели.
        private readonly HashSet<PageView> _pendingPages = new HashSet<PageView>();
        private readonly HashSet<PageView> _pendingDetails = new HashSet<PageView>();
        private readonly Queue<(Func<Task> run, Action cancel)> _pendingThumbs = new Queue<(Func<Task> run, Action cancel)>();
        private int _activeJobs, _activeThumbs;
        private bool _pumpScheduled;
        /// <summary>Страница документа отрисована и показана (для фоновой догрузки после первого показа).</summary>
        public event Action PageRendered;
        /// <summary>Размеры страниц уточнены после фоновой догрузки — раскладка перестроена.</summary>
        public event Action PageSizesUpdated;
        private readonly DispatcherTimer _rerender;
        private readonly DispatcherTimer _detailTimer;
        /// <summary>
        /// Предел размера картинки одной страницы на экране (~48 МБ). При большем масштабе страница рисуется
        /// с пониженным разрешением, а видимая часть — отдельным чётким фрагментом.
        /// </summary>
        private const double ScreenMaxPixels = 12_000_000;
        private double _zoom = 1;
        private bool _twoPage;
        private string _pageMode = "normal";
        private double _gap = 18;
        private bool _shadows = true;
        private int _current = -1;

        public double Zoom => _zoom;
        public bool TwoPage { get => _twoPage; set { if (_twoPage == value) return; _twoPage = value; Relayout(true); } }
        private bool _coverPage = true;
        /// <summary>В развороте первая страница (обложка) показывается отдельно, далее пары 2–3, 4–5… — как в бумажной книге.</summary>
        public bool CoverPage { get => _coverPage; set { if (_coverPage == value) return; _coverPage = value; if (_twoPage) Relayout(true); } }
        // Строки раскладки: первая страница строки для каждой страницы и нижняя граница строки (для двоичного поиска).
        private int[] _rowStart = Array.Empty<int>();
        private int[] _rowEnd = Array.Empty<int>();
        private double[] _rowBottom = Array.Empty<double>();
        public string PageMode { get => _pageMode; set { _pageMode = value; RerenderAll(); } }
        public double Gap { get => _gap; set { _gap = value; Relayout(true); } }
        public bool Shadows { get => _shadows; set { _shadows = value; RefreshShadowStyle(); foreach (var pv in _live.Values) ApplyShadow(pv); } }
        public int CurrentPage => Math.Max(0, _current);
        public string FitMode { get; set; } = "width";

        public Tool Tool { get; set; } = Tool.Hand;
        public Func<Annotation> NewAnnotation;          // стиль новой пометки от окна
        public Func<string, string, string> AskText;    // запрос текста (заголовок, начальное значение)

        public event Action<int> CurrentPageChanged;
        public event Action ZoomChanged;
        public event Action AnnotationsChanged;
        public event Action<string> StatusMessage;
        /// <summary>Прокрутка содержимого (для синхронной прокрутки в параллельном просмотре).</summary>
        public event Action Scrolled;

        /// <summary>Просмотрщик скрыт (неактивная вкладка): страницы не держатся в памяти.</summary>
        public bool Suspended { get; private set; }
        private int _resumePage = -1;
        private double _resumeFrac;

        // поиск и выделение
        private readonly Dictionary<PageRef, List<Rect>> _hits = new Dictionary<PageRef, List<Rect>>();
        private PageRef _activeHitPage; private Rect _activeHit = Rect.Empty;
        private PageRef _selPage; private List<Rect> _selRects; public string SelectedText { get; private set; }

        // отмена
        private readonly Stack<(PageRef page, Annotation ann, bool added)> _undo = new Stack<(PageRef, Annotation, bool)>();
        private readonly Stack<(PageRef page, Annotation ann, bool added)> _redo = new Stack<(PageRef, Annotation, bool)>();
        public bool CanUndo => _undo.Count > 0;
        public bool CanRedo => _redo.Count > 0;
        public bool HasAnnotations => Pages.Any(p => p.Anns.Count > 0);
        public bool Modified { get; set; }

        public DocViewer()
        {
            _host = new Canvas { Background = Brushes.Transparent };
            Scroll = new ScrollViewer
            {
                HorizontalScrollBarVisibility = ScrollBarVisibility.Auto,
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                Content = _host,
                Focusable = true,
                CanContentScroll = false,
                PanningMode = PanningMode.Both
            };
            Children.Add(Scroll);
            Scroll.ScrollChanged += (s, e) =>
            {
                if (Suspended) return;
                UpdateVisible();
                if (e.VerticalChange != 0 || e.HorizontalChange != 0 || e.ViewportWidthChange != 0 || e.ViewportHeightChange != 0)
                {
                    _detailTimer.Stop();
                    _detailTimer.Start();
                }
                if (e.VerticalChange != 0 || e.HorizontalChange != 0) Scrolled?.Invoke();
            };
            Scroll.SizeChanged += (s, e) => { if (Suspended) return; if (FitMode != "none") ApplyFit(); else Relayout(true); };
            Scroll.PreviewMouseWheel += OnWheel;
            _host.MouseLeftButtonDown += OnDown;
            _host.MouseMove += OnMove;
            _host.MouseLeftButtonUp += OnUp;
            _host.MouseRightButtonDown += (s, e) => { var pv = FindPage(e.OriginalSource as DependencyObject); if (pv != null) SetCurrent(pv.ViewIndex); };
            // короткая пауза после изменения масштаба (колесо с Ctrl): перерисовка не запускается на каждый шаг
            _rerender = new DispatcherTimer(DispatcherPriority.Background) { Interval = TimeSpan.FromMilliseconds(90) };
            _rerender.Tick += (s, e) => { _rerender.Stop(); foreach (var pv in _live.Values.ToList()) RequestRender(pv, false); };
            _detailTimer = new DispatcherTimer(DispatcherPriority.Background) { Interval = TimeSpan.FromMilliseconds(100) };
            _detailTimer.Tick += (s, e) =>
            {
                _detailTimer.Stop();
                foreach (var pv in _live.Values.ToList()) if (pv.Tiled) RequestDetail(pv, false);
            };
        }

        private double Dpi
        {
            get { try { return VisualTreeHelper.GetDpi(this).DpiScaleX; } catch { return 1; } }
        }

        /// <summary>Окно перенесено на монитор с другим масштабом (или масштаб Windows изменён) — перерисовываем страницы под новую плотность пикселей.</summary>
        protected override void OnDpiChanged(DpiScale oldDpi, DpiScale newDpi)
        {
            base.OnDpiChanged(oldDpi, newDpi);
            if (_doc != null && !Suspended) RerenderAll();
        }

        // ================== документ ==================

        public void SetDocument(DocumentBase doc)
        {
            foreach (var r in _live.Keys.ToList()) RemoveView(r);
            _pendingPages.Clear(); _pendingDetails.Clear(); CancelThumbs();
            _host.Children.Clear();
            _live.Clear();
            Pages.Clear();
            _hits.Clear(); _activeHitPage = null; _selPage = null; _selRects = null; SelectedText = null;
            _undo.Clear(); _redo.Clear();
            Modified = false;
            _doc = doc;
            _current = -1;
            if (doc != null)
                for (int i = 0; i < doc.PageCount; i++) Pages.Add(new PageRef { Doc = i });
            Scroll.ScrollToHome();
            if (FitMode != "none") ApplyFit(); else Relayout(false);
            SetCurrent(0);
        }

        /// <summary>После перестройки перетекаемого документа число страниц меняется.</summary>
        public void ReloadPagesAfterReflow()
        {
            if (_doc == null) return;
            var old = _current;
            foreach (var r in _live.Keys.ToList()) RemoveView(r);
            _host.Children.Clear(); _live.Clear(); Pages.Clear(); _hits.Clear(); _selRects = null; _selPage = null; SelectedText = null;
            _activeHitPage = null; _activeHit = Rect.Empty;
            _undo.Clear(); _redo.Clear();
            for (int i = 0; i < _doc.PageCount; i++) Pages.Add(new PageRef { Doc = i });
            Relayout(false);
            GoTo(Math.Min(Math.Max(0, old), Pages.Count - 1));
        }

        private Size PageSizeRotated(PageRef r)
        {
            var s = _doc.GetPageSize(r.Doc);
            return (r.Rotation % 180 != 0) ? new Size(s.Height, s.Width) : s;
        }

        // ================== раскладка ==================

        public void Relayout(bool keepPosition)
        {
            if (_doc == null) { _host.Width = 0; _host.Height = 0; return; }
            int anchorPage = CurrentPage;
            double anchorFrac = 0;
            if (keepPosition && anchorPage < _rects.Length && _rects[anchorPage].Height > 0)
                anchorFrac = (Scroll.VerticalOffset - _rects[anchorPage].Top) / _rects[anchorPage].Height;

            int n = Pages.Count;
            _rects = new Rect[n];
            _rowStart = new int[n];
            _rowEnd = new int[n];
            _rowBottom = new double[n];
            double vw = Math.Max(100, Scroll.ViewportWidth > 0 ? Scroll.ViewportWidth : ActualWidth);
            double y = _gap;
            var sizes = Pages.Select(p => { var s = PageSizeRotated(p); return new Size(s.Width * _zoom, s.Height * _zoom); }).ToArray();

            // строки раскладки: по одной странице, парами (разворот) или обложка отдельно + пары
            var rows = new List<(int start, int count)>();
            for (int i = 0; i < n;)
            {
                int count = !_twoPage || (_coverPage && i == 0) ? 1 : Math.Min(2, n - i);
                rows.Add((i, count));
                i += count;
            }

            // в развороте ширина строки берётся «на две страницы», чтобы одиночные страницы (обложка, последняя)
            // стояли по центру, не сдвигая общую ширину содержимого
            double maxRow = 0;
            foreach (var (start, count) in rows)
            {
                double wide = Math.Max(sizes[start].Width, count > 1 ? sizes[start + 1].Width : 0);
                double rowW = _twoPage ? wide * 2 + _gap : sizes[start].Width;
                maxRow = Math.Max(maxRow, rowW);
            }
            double total = Math.Max(vw, maxRow + _gap * 2);
            foreach (var (start, count) in rows)
            {
                double w0 = sizes[start].Width, w1 = count > 1 ? sizes[start + 1].Width : 0;
                double rowW = w0 + (count > 1 ? _gap + w1 : 0);
                double h = Math.Max(sizes[start].Height, count > 1 ? sizes[start + 1].Height : 0);
                double x;
                if (count > 1)
                {
                    // пары сходятся у «корешка» — по центру области просмотра
                    x = total / 2 - _gap / 2 - w0;
                    if (x < _gap / 2 || x + rowW > total - _gap / 2) x = (total - rowW) / 2;
                }
                else x = (total - w0) / 2;
                _rects[start] = new Rect(x, y, w0, sizes[start].Height);
                if (count > 1) _rects[start + 1] = new Rect(x + w0 + _gap, y, w1, sizes[start + 1].Height);
                for (int k = start; k < start + count; k++)
                {
                    _rowStart[k] = start;
                    _rowEnd[k] = start + count - 1;
                    _rowBottom[k] = y + h;
                }
                y += h + _gap;
            }
            _host.Width = total;
            _host.Height = y;
            foreach (var kv in _live.ToList())
            {
                int idx = Pages.IndexOf(kv.Key);
                if (idx < 0) { RemoveView(kv.Key); continue; }
                Place(kv.Value, idx);
            }
            if (keepPosition && anchorPage < _rects.Length)
            {
                Scroll.UpdateLayout();
                Scroll.ScrollToVerticalOffset(_rects[anchorPage].Top + anchorFrac * _rects[anchorPage].Height);
            }
            UpdateVisible();
        }

        private void Place(PageView pv, int idx)
        {
            var r = _rects[idx];
            pv.ViewIndex = idx;
            Canvas.SetLeft(pv, r.Left);
            Canvas.SetTop(pv, r.Top);
            pv.Width = r.Width; pv.Height = r.Height;
            pv.SetTransform(_zoom, pv.Ref.Rotation);
            // страницу повернули — перерисовываем её растр в новом положении
            if (pv.HasImage && pv.ImageRotation != pv.CurrentRotation) RequestRender(pv, true);
        }

        private void ApplyShadow(PageView pv)
        {
            pv.Effect = null;
            pv.Shadow = _shadows;
        }

        /// <summary>Цвет и сила тени страниц берутся из текущей темы.</summary>
        public void RefreshShadowStyle()
        {
            try
            {
                if (TryFindResource("PageShadow") is System.Windows.Media.Effects.DropShadowEffect e)
                    PageView.SetShadowStyle(e.Color, Math.Max(0.12, Math.Min(0.8, e.Opacity)), Math.Min(4, e.ShadowDepth));
            }
            catch { }
            foreach (var pv in _live.Values) pv.InvalidateVisual();
        }

        private void UpdateVisible()
        {
            if (_doc == null || _rects.Length == 0 || Suspended) return;
            double top = Scroll.VerticalOffset, h = Math.Max(1, Scroll.ViewportHeight);
            // в памяти — видимые страницы и небольшой запас для плавной прокрутки
            var view = new Rect(Scroll.HorizontalOffset - 150, top - h * 0.5, Math.Max(1, Scroll.ViewportWidth) + 300, h * 2.0);
            var want = new HashSet<PageRef>();
            int first = LowerBound(view.Top);
            for (int i = Math.Max(0, first - 2); i < _rects.Length; i++)
            {
                if (_rects[i].Top > view.Bottom) break;
                if (_rects[i].IntersectsWith(view)) want.Add(Pages[i]);
            }
            foreach (var r in _live.Keys.ToList()) if (!want.Contains(r)) RemoveView(r);
            foreach (var r in want)
            {
                if (_live.ContainsKey(r)) continue;
                int idx = Pages.IndexOf(r);
                var pv = new PageView(r, _doc.GetPageSize(r.Doc)) { Attached = true };
                pv.PixelExact = _doc.Kind == DocKind.Images;
                ApplyShadow(pv);
                pv.Overlay.SearchHits = _hits.TryGetValue(r, out var hits) ? hits : null;
                pv.Overlay.ActiveHit = r == _activeHitPage ? _activeHit : Rect.Empty;
                pv.Overlay.Selection = r == _selPage ? _selRects : null;
                Place(pv, idx);
                _host.Children.Add(pv);
                _live[r] = pv;
                RequestRender(pv, false);
            }
            // текущая страница — та, что пересекает линию на трети экрана
            double line = top + h * 0.33;
            int cur = LowerBound(line);
            for (int i = Math.Max(0, cur - 2); i < Math.Min(_rects.Length, cur + 3); i++)
                if (_rects[i].Top <= line && _rects[i].Bottom + _gap >= line) { cur = i; break; }
            cur = Math.Max(0, Math.Min(_rects.Length - 1, cur));
            SetCurrent(cur);
        }

        /// <summary>Первая страница, нижний край строки которой не выше <paramref name="y"/>.
        /// Нижние края строк монотонны и в развороте (у страниц пары разная высота).</summary>
        private int LowerBound(double y)
        {
            bool rows = _rowBottom.Length == _rects.Length;
            int lo = 0, hi = _rects.Length - 1, ans = 0;
            while (lo <= hi)
            {
                int mid = (lo + hi) / 2;
                double bottom = rows ? _rowBottom[mid] : _rects[mid].Bottom;
                if (bottom < y) { lo = mid + 1; }
                else { ans = mid; hi = mid - 1; }
            }
            return ans;
        }

        private void SetCurrent(int i)
        {
            if (i == _current) return;
            _current = i;
            CurrentPageChanged?.Invoke(i);
        }

        private void RemoveView(PageRef r)
        {
            if (_live.TryGetValue(r, out var pv))
            {
                pv.Attached = false;
                pv.Generation++;
                pv.InFlightScale = 0;
                _pendingPages.Remove(pv);
                _pendingDetails.Remove(pv);
                pv.SetImage(null);
                pv.RenderedScale = 0;
                _host.Children.Remove(pv);
                _live.Remove(r);
                MemoryTrim.Schedule();
            }
        }

        // ================== отрисовка ==================
        //
        // Конвейер: документ рисует страницу (в фоне, если умеет) → пиксели копируются в массив байтов в том же
        // потоке (PagePixels: режим ночь/сепия и поворот) → UI-поток создаёт из них собственную картинку →
        // PageView кладёт её на экран пиксель в пиксель. Объекты WPF между потоками не передаются.

        /// <summary>Отрисовка документа в пиксели — в фоновом потоке, если документ это допускает.</summary>
        private async Task<PagePixels> RenderPixelsAsync(DocumentBase doc, Func<PagePixels> render)
        {
            if (doc.CanRenderOffThread)
                return await Task.Run(render);
            await Dispatcher.Yield(DispatcherPriority.Background);
            return render();
        }

        /// <summary>Сколько страниц рисуется одновременно (PDF — два движка отрисовки; остальное рисует UI-поток).</summary>
        private int MaxJobs => _doc != null ? Math.Max(1, _doc.RenderConcurrency) : 1;

        /// <summary>Масштаб растра страницы на экране и признак «крупный масштаб: видимая часть — отдельным фрагментом».</summary>
        private double TargetScale(DocumentBase doc, PageView pv, out bool tiled)
        {
            double full = _zoom * Dpi;
            var psize = doc.GetPageSize(pv.Ref.Doc);
            double px = psize.Width * full * psize.Height * full;
            double cap = doc.CanRenderRegion ? ScreenMaxPixels : ScreenMaxPixels * 2.5;
            tiled = px > cap;
            return tiled ? full * Math.Sqrt(cap / px) : full;
        }

        /// <summary>Ставит страницу в очередь отрисовки. Сама отрисовка начинается после раскладки, с итоговым масштабом.</summary>
        private void RequestRender(PageView pv, bool force)
        {
            if (_doc == null || !pv.Attached || Suspended) return;
            if (force) pv.ForceRender = true;
            _pendingPages.Add(pv);
            SchedulePump();
        }

        public void RerenderAll() { foreach (var pv in _live.Values.ToList()) RequestRender(pv, true); }

        private void RequestDetail(PageView pv, bool force)
        {
            if (_doc == null || !_doc.CanRenderRegion || !pv.Attached || Suspended) return;
            if (force) pv.ForceDetail = true;
            _pendingDetails.Add(pv);
            SchedulePump();
        }

        /// <summary>
        /// Запуск очереди с приоритетом Loaded: к этому моменту раскладка (и масштаб «по ширине») уже окончательные,
        /// поэтому страница сразу рисуется в нужном разрешении — без промежуточной размытой картинки.
        /// </summary>
        private void SchedulePump()
        {
            if (_pumpScheduled) return;
            _pumpScheduled = true;
            Dispatcher.BeginInvoke(new Action(Pump), DispatcherPriority.Loaded);
        }

        private void Pump()
        {
            _pumpScheduled = false;
            if (_doc == null || Suspended)
            {
                _pendingPages.Clear(); _pendingDetails.Clear(); CancelThumbs();
                return;
            }
            int max = MaxJobs;
            while (_activeJobs < max)
            {
                Func<Task> job = TakePageJob() ?? TakeDetailJob();
                bool thumb = false;
                // эскизы — только когда страницы на экране уже в работе, и всегда с одним свободным местом для страниц
                if (job == null && _pendingThumbs.Count > 0 && (max == 1 || _activeThumbs < max - 1))
                {
                    job = _pendingThumbs.Dequeue().run;
                    thumb = true;
                }
                if (job == null) break;
                _ = RunJob(job, thumb);
            }
        }

        /// <summary>Эскизы, которые больше не нужны (вкладка скрыта, документ сменился), завершаются пустым результатом.</summary>
        private void CancelThumbs()
        {
            while (_pendingThumbs.Count > 0)
            {
                try { _pendingThumbs.Dequeue().cancel(); } catch { }
            }
        }

        private async Task RunJob(Func<Task> job, bool thumb)
        {
            _activeJobs++;
            if (thumb) _activeThumbs++;
            try { await job(); }
            catch { }
            finally
            {
                _activeJobs--;
                if (thumb) _activeThumbs--;
                if (_pendingPages.Count > 0 || _pendingDetails.Count > 0 || _pendingThumbs.Count > 0) SchedulePump();
            }
        }

        /// <summary>Ближайшая к экрану страница из очереди: сначала видимые (сверху вниз), затем запас вокруг.</summary>
        private PageView Nearest(HashSet<PageView> set)
        {
            PageView best = null;
            double bestKey = double.MaxValue;
            double top = Scroll.VerticalOffset, bottom = top + Math.Max(1, Scroll.ViewportHeight);
            double left = Scroll.HorizontalOffset, right = left + Math.Max(1, Scroll.ViewportWidth);
            foreach (var pv in set)
            {
                if (!pv.Attached || pv.ViewIndex < 0 || pv.ViewIndex >= _rects.Length) continue;
                var r = _rects[pv.ViewIndex];
                bool visible = r.Bottom > top && r.Top < bottom && r.Right > left && r.Left < right;
                double key = visible
                    ? Math.Max(0, r.Top - top) * 0.001
                    : 1_000_000 + Math.Min(Math.Abs(r.Top - bottom), Math.Abs(r.Bottom - top));
                if (key < bestKey) { bestKey = key; best = pv; }
            }
            return best;
        }

        private Func<Task> TakePageJob()
        {
            while (_pendingPages.Count > 0)
            {
                var pv = Nearest(_pendingPages);
                if (pv == null) { _pendingPages.Clear(); return null; }
                _pendingPages.Remove(pv);
                var job = MakePageJob(pv);
                if (job != null) return job;
            }
            return null;
        }

        private Func<Task> TakeDetailJob()
        {
            while (_pendingDetails.Count > 0)
            {
                var pv = Nearest(_pendingDetails);
                if (pv == null) { _pendingDetails.Clear(); return null; }
                _pendingDetails.Remove(pv);
                var job = MakeDetailJob(pv);
                if (job != null) return job;
            }
            return null;
        }

        /// <summary>Задание на отрисовку страницы целиком (null — страница уже нарисована в нужном масштабе).</summary>
        private Func<Task> MakePageJob(PageView pv)
        {
            var doc = _doc;
            if (doc == null || !pv.Attached || Suspended) return null;
            double scale = TargetScale(doc, pv, out bool tiled);
            int rot = pv.CurrentRotation;
            bool force = pv.ForceRender;
            pv.ForceRender = false;
            if (!force)
            {
                if (pv.HasImage && Math.Abs(pv.RenderedScale - scale) < 0.001 && pv.ImageRotation == rot)
                {
                    if (pv.Tiled) RequestDetail(pv, false);
                    return null;
                }
                // та же страница уже рисуется в этом масштабе — второй раз не нужно
                if (Math.Abs(pv.InFlightScale - scale) < 0.001 && pv.InFlightRotation == rot) return null;
            }
            int gen = ++pv.Generation;
            int docIdx = pv.Ref.Doc;
            string mode = _pageMode;
            pv.InFlightScale = scale;
            pv.InFlightRotation = rot;
            return async () =>
            {
                try
                {
                    // отрисовка прерывается, как только страница перестала быть нужной (прокрутка, новый масштаб)
                    Func<bool> stale = () => gen != pv.Generation || !pv.Attached || doc != _doc || Suspended;
                    var pix = await RenderPixelsAsync(doc, () => doc.RenderPagePixels(docIdx, scale, mode, rot, stale));
                    if (gen != pv.Generation || !pv.Attached || doc != _doc || Suspended) return;
                    if (pix == null) { pv.SetError("пустая страница"); return; }
                    pv.SetImage(pix.ToBitmap(), rot);
                    pv.RenderedScale = scale;
                    pv.Tiled = tiled && doc.CanRenderRegion;
                    if (pv.Tiled) RequestDetail(pv, force);
                    else pv.ClearDetail();
                    MemoryTrim.Schedule();
                    PageRendered?.Invoke();
                }
                catch (Exception ex)
                {
                    if (gen == pv.Generation) pv.SetError(ex.Message);
                }
                finally
                {
                    if (gen == pv.Generation) pv.InFlightScale = 0;
                }
            };
        }

        /// <summary>Видимая часть страницы в координатах страницы (DIP).</summary>
        private Rect VisibleRegion(PageView pv)
        {
            try
            {
                var view = new Rect(Scroll.HorizontalOffset, Scroll.VerticalOffset, Math.Max(1, Scroll.ViewportWidth), Math.Max(1, Scroll.ViewportHeight));
                var t = _host.TransformToDescendant(pv.Inner);
                if (t == null) return Rect.Empty;
                var r = t.TransformBounds(view);
                r.Intersect(new Rect(0, 0, pv.Inner.Width, pv.Inner.Height));
                return r;
            }
            catch { return Rect.Empty; }
        }

        /// <summary>Задание на чёткий фрагмент видимой части страницы (с запасом для прокрутки).</summary>
        private Func<Task> MakeDetailJob(PageView pv)
        {
            var doc = _doc;
            if (doc == null || !doc.CanRenderRegion || !pv.Attached || Suspended || !pv.Tiled) return null;
            double scale = _zoom * Dpi;
            var region = VisibleRegion(pv);
            bool force = pv.ForceDetail;
            pv.ForceDetail = false;
            if (region.IsEmpty || region.Width < 1 || region.Height < 1) { pv.ClearDetail(); return null; }
            if (!force && pv.DetailCovers(region, scale)) return null;
            var want = region;
            want.Inflate(region.Width * 0.3 + 20, region.Height * 0.3 + 20);
            want.Intersect(new Rect(0, 0, pv.Inner.Width, pv.Inner.Height));
            if (want.IsEmpty) return null;
            int gen = ++pv.DetailGeneration;
            int idx = pv.Ref.Doc;
            string mode = _pageMode;
            int rot = pv.CurrentRotation;
            return async () =>
            {
                Func<bool> stale = () => gen != pv.DetailGeneration || !pv.Attached || doc != _doc || Suspended;
                var pix = await RenderPixelsAsync(doc, () => doc.RenderRegionPixels(idx, scale, want, mode, rot, stale));
                if (gen != pv.DetailGeneration || !pv.Attached || doc != _doc || Suspended || pix == null) return;
                pv.SetDetail(pix.ToBitmap(), want, scale, rot);
                MemoryTrim.Schedule();
            };
        }

        /// <summary>Цветовой режим (ночной / сепия) для картинки UI-потока. Результат — в родном для WPF формате.</summary>
        public static BitmapSource ApplyMode(BitmapSource src, string mode) => BitmapUtil.Prepare(src, mode);

        /// <summary>Небольшой эскиз страницы для боковой панели — в общей очереди, после страниц на экране.</summary>
        public Task<BitmapSource> RenderThumbAsync(PageRef r, double maxSide)
        {
            var doc = _doc;
            if (doc == null) return Task.FromResult<BitmapSource>(null);
            var s = doc.GetPageSize(r.Doc);
            double scale = maxSide * Dpi / Math.Max(s.Width, s.Height);
            int idx = r.Doc;
            var tcs = new TaskCompletionSource<BitmapSource>();
            Func<Task> run = async () =>
            {
                try
                {
                    if (doc != _doc) { tcs.TrySetResult(null); return; }
                    var pix = await RenderPixelsAsync(doc, () => doc.RenderPagePixels(idx, scale, "normal", 0));
                    tcs.TrySetResult(doc != _doc ? null : pix?.ToBitmap());
                }
                catch { tcs.TrySetResult(null); }
            };
            Action cancel = () => tcs.TrySetResult(null);
            _pendingThumbs.Enqueue((run, cancel));
            SchedulePump();
            return tcs.Task;
        }

        /// <summary>
        /// Размеры страниц уточнены фоновой догрузкой документа: виды страниц с изменившимся размером
        /// пересоздаются, раскладка перестраивается с сохранением положения.
        /// </summary>
        public void OnPageSizesChanged()
        {
            if (_doc == null) return;
            foreach (var kv in _live.ToList())
            {
                var real = _doc.GetPageSize(kv.Key.Doc);
                if (Math.Abs(real.Width - kv.Value.Inner.Width) > 0.01 || Math.Abs(real.Height - kv.Value.Inner.Height) > 0.01)
                    RemoveView(kv.Key);
            }
            if (!Suspended)
            {
                if (FitMode != "none") ApplyFit(); else Relayout(true);
            }
            PageSizesUpdated?.Invoke();
        }

        // ================== скрытие / показ (вкладки) ==================

        /// <summary>Скрывает просмотрщик: изображения всех страниц освобождаются, положение запоминается.</summary>
        public void Suspend()
        {
            if (Suspended) return;
            var (page, frac) = GetPosition();
            _resumePage = page; _resumeFrac = frac;
            Suspended = true;
            _rerender.Stop();
            _detailTimer.Stop();
            foreach (var r in _live.Keys.ToList()) RemoveView(r);
            _pendingPages.Clear(); _pendingDetails.Clear(); CancelThumbs();
        }

        /// <summary>Возвращает просмотрщик в работу после показа на экране.</summary>
        public void Resume()
        {
            if (!Suspended) return;
            Suspended = false;
            Dispatcher.BeginInvoke(new Action(() =>
            {
                if (Suspended || _doc == null) return;
                if (FitMode != "none") ApplyFit(); else Relayout(false);
                if (_resumePage >= 0) SetPosition(_resumePage, _resumeFrac);
                UpdateVisible();
            }), DispatcherPriority.Loaded);
        }

        /// <summary>Текущее положение: индекс страницы у верхнего края и доля прокрутки внутри неё.</summary>
        public (int page, double frac) GetPosition()
        {
            if (_doc == null || _rects.Length == 0) return (0, 0);
            double y = Scroll.VerticalOffset;
            int i = Math.Max(0, Math.Min(_rects.Length - 1, LowerBound(y)));
            var r = _rects[i];
            double frac = r.Height > 0 ? (y - r.Top) / (r.Height + _gap) : 0;
            return (i, Math.Max(-1, Math.Min(1, frac)));
        }

        public void SetPosition(int page, double frac)
        {
            if (_doc == null || _rects.Length == 0) return;
            page = Math.Max(0, Math.Min(_rects.Length - 1, page));
            var r = _rects[page];
            Scroll.ScrollToVerticalOffset(Math.Max(0, r.Top + frac * (r.Height + _gap)));
        }

        // ================== масштаб ==================

        public void SetZoom(double z, Point? anchor = null, bool manual = true)
        {
            z = Math.Max(0.1, Math.Min(8, z));
            if (manual) FitMode = "none";
            if (Math.Abs(z - _zoom) < 0.0005) return;
            var a = anchor ?? new Point(Scroll.ViewportWidth / 2, Scroll.ViewportHeight / 2);
            double cx = Scroll.HorizontalOffset + a.X, cy = Scroll.VerticalOffset + a.Y;
            double k = z / _zoom;
            _zoom = z;
            Relayout(false);
            Scroll.UpdateLayout();
            Scroll.ScrollToHorizontalOffset(cx * k - a.X);
            Scroll.ScrollToVerticalOffset(cy * k - a.Y);
            foreach (var pv in _live.Values) pv.SetTransform(_zoom, pv.Ref.Rotation);
            _rerender.Stop(); _rerender.Start();
            ZoomChanged?.Invoke();
        }

        public void ApplyFit()
        {
            if (_doc == null || Pages.Count == 0) { Relayout(false); return; }
            int page = CurrentPage;
            // Два прохода: после первой раскладки может появиться полоса прокрутки и сузить область просмотра.
            // Масштаб пересчитывается до начала отрисовки (очередь запускается после раскладки),
            // поэтому страница сразу рисуется в окончательном разрешении — без размытой промежуточной картинки.
            for (int pass = 0; pass < 2; pass++)
            {
                double vw = Scroll.ViewportWidth > 0 ? Scroll.ViewportWidth : ActualWidth;
                double vh = Scroll.ViewportHeight > 0 ? Scroll.ViewportHeight : ActualHeight;
                if (vw < 50 || vh < 50) { Relayout(false); return; }
                var s = PageSizeRotated(Pages[page < Pages.Count ? page : 0]);
                double w = _twoPage ? s.Width * 2 + _gap : s.Width;
                double z;
                if (FitMode == "page") z = Math.Min((vw - _gap * 2) / w, (vh - _gap * 2) / s.Height);
                else z = (vw - _gap * 2 - 4) / w;
                z = Math.Max(0.1, Math.Min(8, z));
                bool same = Math.Abs(z - _zoom) < 0.0005 && pass > 0;
                _zoom = z;
                if (same) break;
                Relayout(false);
                foreach (var pv in _live.Values) pv.SetTransform(_zoom, pv.Ref.Rotation);
                if (page < _rects.Length) Scroll.ScrollToVerticalOffset(_rects[page].Top - _gap / 2);
                try { Scroll.UpdateLayout(); } catch { break; }
                double nvw = Scroll.ViewportWidth > 0 ? Scroll.ViewportWidth : ActualWidth;
                double nvh = Scroll.ViewportHeight > 0 ? Scroll.ViewportHeight : ActualHeight;
                if (Math.Abs(nvw - vw) < 0.5 && (FitMode != "page" || Math.Abs(nvh - vh) < 0.5)) break;
            }
            UpdateVisible();
            _rerender.Stop(); _rerender.Start();
            ZoomChanged?.Invoke();
        }

        private void OnWheel(object sender, MouseWheelEventArgs e)
        {
            if ((Keyboard.Modifiers & ModifierKeys.Control) != 0)
            {
                e.Handled = true;
                double f = e.Delta > 0 ? 1.12 : 1 / 1.12;
                SetZoom(_zoom * f, e.GetPosition(Scroll));
            }
            else if ((Keyboard.Modifiers & ModifierKeys.Shift) != 0)
            {
                e.Handled = true;
                Scroll.ScrollToHorizontalOffset(Scroll.HorizontalOffset - e.Delta);
            }
            else if (SmoothScrolling && Keyboard.Modifiers == ModifierKeys.None)
            {
                e.Handled = true;
                int lines = SystemParameters.WheelScrollLines;
                double perNotch = lines > 0 ? lines * 20.0 : Math.Max(1, Scroll.ViewportHeight - 40);
                SmoothScrollBy(-e.Delta / 120.0 * perNotch);
            }
        }

        // ================== плавная прокрутка ==================
        //
        // Колесо мыши не перескакивает рывком, а плавно доводит страницу до цели за ~0.15 с.
        // Каждый кадр смещение округляется до целого пикселя монитора — текст остаётся резким и во время движения.

        /// <summary>Плавная прокрутка колесом мыши.</summary>
        public bool SmoothScrolling { get; set; } = true;
        private double _smoothTarget = double.NaN;
        private double _smoothLastSet = double.NaN;
        private bool _smoothHooked;
        private readonly System.Diagnostics.Stopwatch _smoothClock = new System.Diagnostics.Stopwatch();

        private void SmoothScrollBy(double dy)
        {
            double cur = Scroll.VerticalOffset;
            double basis = double.IsNaN(_smoothTarget) ? cur : _smoothTarget;
            // смена направления — от текущего положения, без «отката» к старой цели
            if (!double.IsNaN(_smoothTarget) && Math.Sign(dy) != Math.Sign(_smoothTarget - cur)) basis = cur;
            _smoothTarget = Math.Max(0, Math.Min(Scroll.ScrollableHeight, basis + dy));
            _smoothLastSet = cur;
            if (!_smoothHooked)
            {
                _smoothHooked = true;
                _smoothClock.Restart();
                CompositionTarget.Rendering += OnSmoothFrame;
            }
        }

        private void StopSmooth()
        {
            _smoothTarget = double.NaN;
            _smoothLastSet = double.NaN;
            if (_smoothHooked)
            {
                _smoothHooked = false;
                CompositionTarget.Rendering -= OnSmoothFrame;
            }
        }

        private void OnSmoothFrame(object sender, EventArgs e)
        {
            if (double.IsNaN(_smoothTarget) || Suspended || _doc == null) { StopSmooth(); return; }
            double cur = Scroll.VerticalOffset;
            // прокрутку перехватили (полоса прокрутки, клавиши, переход по оглавлению) — уступаем
            if (!double.IsNaN(_smoothLastSet) && Math.Abs(cur - _smoothLastSet) > 2) { StopSmooth(); return; }
            double dt = Math.Max(1, Math.Min(50, _smoothClock.Elapsed.TotalMilliseconds));
            _smoothClock.Restart();
            double dpi = Math.Max(0.5, Dpi);
            double target = Math.Min(_smoothTarget, Scroll.ScrollableHeight);
            double diff = target - cur;
            if (Math.Abs(diff) * dpi < 1)
            {
                Scroll.ScrollToVerticalOffset(target);
                StopSmooth();
                return;
            }
            // экспоненциальное приближение, не зависящее от частоты кадров
            double k = 1 - Math.Pow(1 - 0.32, dt / 16.667);
            double step = diff * k;
            if (Math.Abs(step) * dpi < 1) step = Math.Sign(diff) / dpi;
            double next = Math.Round((cur + step) * dpi) / dpi;
            if (Math.Abs(next - cur) < 1e-6) next = target;
            _smoothLastSet = next;
            Scroll.ScrollToVerticalOffset(next);
        }

        // ================== навигация ==================

        public void GoTo(int index)
        {
            if (index < 0 || index >= _rects.Length) return;
            Scroll.ScrollToVerticalOffset(Math.Max(0, _rects[index].Top - _gap / 2));
            if (_twoPage) Scroll.ScrollToHorizontalOffset(Math.Max(0, _rects[index].Left - _gap));
            SetCurrent(index);
        }

        /// <summary>Прокрутка к фрагменту страницы (координаты страницы).</summary>
        public void ShowRect(int index, Rect pageRect)
        {
            GoTo(index);
            Scroll.UpdateLayout();
            UpdateVisible();
            Scroll.UpdateLayout();
            if (_live.TryGetValue(Pages[index], out var pv))
            {
                try
                {
                    var r = pv.Inner.TransformToAncestor(_host).TransformBounds(pageRect);
                    Scroll.ScrollToVerticalOffset(Math.Max(0, r.Top - Scroll.ViewportHeight / 3));
                    if (r.Left < Scroll.HorizontalOffset || r.Right > Scroll.HorizontalOffset + Scroll.ViewportWidth)
                        Scroll.ScrollToHorizontalOffset(Math.Max(0, r.Left - 40));
                }
                catch { }
            }
        }

        /// <summary>Следующая страница или, в развороте, следующая пара (с учётом отдельной обложки).</summary>
        public void Next()
        {
            int cur = CurrentPage;
            int end = cur < _rowEnd.Length ? _rowEnd[cur] : cur;
            GoTo(Math.Min(Pages.Count - 1, end + 1));
        }

        public void Prev()
        {
            int cur = CurrentPage;
            int start = cur < _rowStart.Length ? _rowStart[cur] : cur;
            int prev = Math.Max(0, start - 1);
            GoTo(prev < _rowStart.Length ? _rowStart[prev] : prev);
        }

        // ================== поворот и порядок страниц ==================

        public void Rotate(int delta, bool all)
        {
            var targets = all ? Pages.ToList() : (CurrentPage < Pages.Count ? new List<PageRef> { Pages[CurrentPage] } : new List<PageRef>());
            foreach (var p in targets) p.Rotation = ((p.Rotation + delta) % 360 + 360) % 360;
            Modified = true;
            Relayout(true);
        }

        public void DeletePage(int index)
        {
            if (index < 0 || index >= Pages.Count || Pages.Count <= 1) return;
            RemoveView(Pages[index]);
            Pages.RemoveAt(index);
            Modified = true;
            Relayout(false);
            GoTo(Math.Min(index, Pages.Count - 1));
            AnnotationsChanged?.Invoke();
        }

        public void MovePage(int index, int delta)
        {
            int to = index + delta;
            if (index < 0 || index >= Pages.Count || to < 0 || to >= Pages.Count) return;
            var p = Pages[index];
            Pages.RemoveAt(index);
            Pages.Insert(to, p);
            Modified = true;
            Relayout(false);
            GoTo(to);
        }

        // ================== поиск ==================

        public void SetSearchHits(Dictionary<int, List<Rect>> hitsByView)
        {
            _hits.Clear();
            if (hitsByView != null)
                foreach (var kv in hitsByView)
                    if (kv.Key >= 0 && kv.Key < Pages.Count) _hits[Pages[kv.Key]] = kv.Value;
            _activeHitPage = null; _activeHit = Rect.Empty;
            foreach (var pv in _live.Values)
            {
                pv.Overlay.SearchHits = _hits.TryGetValue(pv.Ref, out var h) ? h : null;
                pv.Overlay.ActiveHit = Rect.Empty;
                pv.Overlay.InvalidateVisual();
            }
        }

        public void SetActiveHit(int viewIndex, Rect r)
        {
            _activeHitPage = viewIndex >= 0 && viewIndex < Pages.Count ? Pages[viewIndex] : null;
            _activeHit = r;
            foreach (var pv in _live.Values)
            {
                pv.Overlay.ActiveHit = pv.Ref == _activeHitPage ? r : Rect.Empty;
                pv.Overlay.InvalidateVisual();
            }
            if (_activeHitPage != null) ShowRect(viewIndex, r);
        }

        // ================== пометки ==================

        public void AddAnnotation(PageRef p, Annotation a, bool record = true)
        {
            p.Anns.Add(a);
            if (record) { _undo.Push((p, a, true)); _redo.Clear(); }
            Modified = true;
            Invalidate(p);
            AnnotationsChanged?.Invoke();
        }

        public void RemoveAnnotation(PageRef p, Annotation a, bool record = true)
        {
            if (!p.Anns.Remove(a)) return;
            if (record) { _undo.Push((p, a, false)); _redo.Clear(); }
            Modified = true;
            Invalidate(p);
            AnnotationsChanged?.Invoke();
        }

        public void ClearAnnotations(PageRef p)
        {
            foreach (var a in p.Anns.ToList()) RemoveAnnotation(p, a);
        }

        public void Undo()
        {
            if (_undo.Count == 0) return;
            var (p, a, added) = _undo.Pop();
            if (added) p.Anns.Remove(a); else p.Anns.Add(a);
            _redo.Push((p, a, added));
            Invalidate(p);
            AnnotationsChanged?.Invoke();
        }

        public void Redo()
        {
            if (_redo.Count == 0) return;
            var (p, a, added) = _redo.Pop();
            if (added) p.Anns.Add(a); else p.Anns.Remove(a);
            _undo.Push((p, a, added));
            Invalidate(p);
            AnnotationsChanged?.Invoke();
        }

        public void Invalidate(PageRef p)
        {
            if (p != null && _live.TryGetValue(p, out var pv)) pv.Overlay.InvalidateVisual();
        }

        public void ClearSelection()
        {
            var old = _selPage;
            _selPage = null; _selRects = null; SelectedText = null;
            if (old != null && _live.TryGetValue(old, out var pv)) { pv.Overlay.Selection = null; pv.Overlay.InvalidateVisual(); }
        }

        public void SelectAllOnPage()
        {
            if (_doc == null || Pages.Count == 0) return;
            var p = Pages[CurrentPage];
            var chars = _doc.GetPageChars(p.Doc).ToList();
            SetSelection(p, chars);
        }

        private void SetSelection(PageRef p, List<PageChar> chars)
        {
            ClearSelection();
            if (chars.Count == 0) return;
            _selPage = p;
            _selRects = DocumentBase.LineRects(chars);
            SelectedText = DocumentBase.CharsToText(chars);
            if (_live.TryGetValue(p, out var pv)) { pv.Overlay.Selection = _selRects; pv.Overlay.InvalidateVisual(); }
        }

        // ================== мышь ==================

        private PageView _dragPage;
        private Point _dragStart;
        private Point _panStart;
        private Point _panOffset;
        private bool _panning;
        private Annotation _drawing;

        private static PageView FindPage(DependencyObject d)
        {
            while (d != null && !(d is PageView)) d = d is Visual || d is System.Windows.Media.Media3D.Visual3D ? VisualTreeHelper.GetParent(d) : LogicalTreeHelper.GetParent(d);
            return d as PageView;
        }

        private void OnDown(object sender, MouseButtonEventArgs e)
        {
            Scroll.Focus();
            var pv = FindPage(e.OriginalSource as DependencyObject);
            if (pv != null) SetCurrent(pv.ViewIndex);

            if (Tool == Tool.Hand || pv == null)
            {
                if (pv != null && e.ClickCount == 2) { TryEditAnnotation(pv, e.GetPosition(pv.Inner)); return; }
                _panning = true;
                _panStart = e.GetPosition(Scroll);
                _panOffset = new Point(Scroll.HorizontalOffset, Scroll.VerticalOffset);
                _host.CaptureMouse();
                _host.Cursor = Cursors.ScrollAll;
                return;
            }

            var p = e.GetPosition(pv.Inner);
            _dragPage = pv;
            _dragStart = p;

            switch (Tool)
            {
                case Tool.Eraser:
                {
                    var hit = pv.Ref.Anns.AsEnumerable().Reverse().FirstOrDefault(a => AnnotationPainter.HitTest(a, p));
                    if (hit != null) RemoveAnnotation(pv.Ref, hit);
                    else StatusMessage?.Invoke("Щёлкните точно по пометке, чтобы удалить её.");
                    _dragPage = null;
                    return;
                }
                case Tool.Text:
                case Tool.Note:
                case Tool.Stamp:
                {
                    var a = NewAnnotation?.Invoke() ?? new Annotation();
                    a.Kind = Tool;
                    if (Tool != Tool.Stamp)
                    {
                        var text = AskText?.Invoke(Tool == Tool.Note ? "Текст заметки" : "Текст надписи", "");
                        if (string.IsNullOrWhiteSpace(text)) { _dragPage = null; return; }
                        a.Text = text;
                    }
                    a.Points.Add(p);
                    AddAnnotation(pv.Ref, a);
                    _dragPage = null;
                    return;
                }
            }

            if (Tool != Tool.Select) ClearSelection();
            _drawing = NewAnnotation?.Invoke() ?? new Annotation();
            _drawing.Kind = Tool;
            _drawing.Points.Add(p);
            _host.CaptureMouse();
        }

        private void OnMove(object sender, MouseEventArgs e)
        {
            if (_panning)
            {
                var cur = e.GetPosition(Scroll);
                Scroll.ScrollToHorizontalOffset(_panOffset.X - (cur.X - _panStart.X));
                Scroll.ScrollToVerticalOffset(_panOffset.Y - (cur.Y - _panStart.Y));
                return;
            }
            if (_dragPage == null || _drawing == null) { UpdateCursor(e); return; }
            var p = Clamp(e.GetPosition(_dragPage.Inner), _dragPage);
            var ov = _dragPage.Overlay;
            switch (Tool)
            {
                case Tool.Pen:
                case Tool.Marker:
                    var last = _drawing.Points[_drawing.Points.Count - 1];
                    if ((p - last).Length > 1.2) _drawing.Points.Add(p);
                    ov.Preview = _drawing;
                    break;
                case Tool.Rect: case Tool.Ellipse: case Tool.Arrow: case Tool.Line: case Tool.Redact: case Tool.WhiteOut:
                    if ((Keyboard.Modifiers & ModifierKeys.Shift) != 0 && (Tool == Tool.Line || Tool == Tool.Arrow))
                    {
                        var d = p - _dragStart;
                        p = Math.Abs(d.X) > Math.Abs(d.Y) ? new Point(p.X, _dragStart.Y) : new Point(_dragStart.X, p.Y);
                    }
                    if (_drawing.Points.Count < 2) _drawing.Points.Add(p); else _drawing.Points[1] = p;
                    ov.Preview = _drawing;
                    break;
                default: // Select, Highlight, Underline, Strike
                    ov.DragRect = new Rect(_dragStart, p);
                    if (Tool != Tool.Select)
                    {
                        var chars = _doc.CharsInRect(_dragPage.Ref.Doc, new Rect(_dragStart, p));
                        var preview = NewAnnotation?.Invoke() ?? new Annotation();
                        preview.Kind = Tool;
                        preview.Rects = chars.Count > 0 ? DocumentBase.LineRects(chars) : (Tool == Tool.Highlight ? new List<Rect> { new Rect(_dragStart, p) } : new List<Rect>());
                        ov.Preview = preview;
                    }
                    break;
            }
            ov.InvalidateVisual();
        }

        private static Point Clamp(Point p, PageView pv)
        {
            return new Point(Math.Max(0, Math.Min(pv.Inner.Width, p.X)), Math.Max(0, Math.Min(pv.Inner.Height, p.Y)));
        }

        private void OnUp(object sender, MouseButtonEventArgs e)
        {
            if (_panning)
            {
                _panning = false;
                _host.ReleaseMouseCapture();
                _host.Cursor = null;
                return;
            }
            _host.ReleaseMouseCapture();
            var pv = _dragPage;
            var a = _drawing;
            _dragPage = null; _drawing = null;
            if (pv == null || a == null) return;
            var ov = pv.Overlay;
            ov.Preview = null; ov.DragRect = Rect.Empty;
            ov.InvalidateVisual();
            var p = Clamp(e.GetPosition(pv.Inner), pv);
            var rect = new Rect(_dragStart, p);

            switch (Tool)
            {
                case Tool.Select:
                {
                    if (rect.Width < 3 && rect.Height < 3) { ClearSelection(); return; }
                    var chars = _doc.CharsInRect(pv.Ref.Doc, rect);
                    if (chars.Count == 0) StatusMessage?.Invoke("На этой странице нет текстового слоя. Используйте «Распознать текст (OCR)».");
                    SetSelection(pv.Ref, chars);
                    if (SelectedText != null) StatusMessage?.Invoke($"Выделено символов: {SelectedText.Length}. Ctrl+C — копировать.");
                    return;
                }
                case Tool.Highlight:
                case Tool.Underline:
                case Tool.Strike:
                {
                    if (rect.Width < 3 && rect.Height < 3) return;
                    var chars = _doc.CharsInRect(pv.Ref.Doc, rect);
                    if (chars.Count > 0) a.Rects = DocumentBase.LineRects(chars);
                    else if (Tool == Tool.Highlight) a.Rects = new List<Rect> { rect };
                    else { StatusMessage?.Invoke("Текст не найден в выделенной области (нет текстового слоя)."); return; }
                    a.Points.Clear();
                    AddAnnotation(pv.Ref, a);
                    return;
                }
                case Tool.Pen:
                case Tool.Marker:
                    if (a.Points.Count < 2) a.Points.Add(new Point(a.Points[0].X + 0.5, a.Points[0].Y + 0.5));
                    AddAnnotation(pv.Ref, a);
                    return;
                default:
                    if (a.Points.Count < 2) return;
                    if ((a.Points[1] - a.Points[0]).Length < 3) return;
                    AddAnnotation(pv.Ref, a);
                    return;
            }
        }

        private void UpdateCursor(MouseEventArgs e)
        {
            Cursor c;
            switch (Tool)
            {
                case Tool.Hand: c = Cursors.Hand; break;
                case Tool.Select: c = Cursors.IBeam; break;
                case Tool.Eraser: c = Cursors.Hand; break;
                case Tool.Text: case Tool.Note: case Tool.Stamp: c = Cursors.Pen; break;
                default: c = Cursors.Cross; break;
            }
            if (_host.Cursor != c) _host.Cursor = c;
        }

        private void TryEditAnnotation(PageView pv, Point p)
        {
            var hit = pv.Ref.Anns.AsEnumerable().Reverse().FirstOrDefault(a => (a.Kind == Tool.Text || a.Kind == Tool.Note) && AnnotationPainter.HitTest(a, p));
            if (hit == null || AskText == null) return;
            var t = AskText("Изменить текст", hit.Text);
            if (t == null) return;
            hit.Text = t;
            Modified = true;
            Invalidate(pv.Ref);
            AnnotationsChanged?.Invoke();
        }

        /// <summary>Рендер страницы вместе с пометками и поворотом (для экспорта и печати).</summary>
        public static BitmapSource RenderComposite(DocumentBase doc, PageRef r, double dpi, bool annotations, bool gray)
        {
            var size = doc.GetPageSize(r.Doc);
            double scale = VisualTools.ClampScale(size, dpi / 96.0);
            var page = doc.RenderPage(r.Doc, scale);
            bool rotated = r.Rotation % 180 != 0;
            double W = rotated ? size.Height : size.Width, H = rotated ? size.Width : size.Height;
            int pw = Math.Max(1, (int)Math.Round(W * scale)), ph = Math.Max(1, (int)Math.Round(H * scale));
            var dv = new DrawingVisual();
            RenderOptions.SetBitmapScalingMode(dv, BitmapScalingMode.HighQuality);
            using (var dc = dv.RenderOpen())
            {
                dc.DrawRectangle(Brushes.White, null, new Rect(0, 0, W, H));
                dc.PushTransform(new RotateTransform(r.Rotation, W / 2, H / 2));
                dc.PushTransform(new TranslateTransform((W - size.Width) / 2, (H - size.Height) / 2));
                if (page != null) dc.DrawImage(page, new Rect(0, 0, size.Width, size.Height));
                if (annotations) AnnotationPainter.Draw(dc, r.Anns);
                dc.Pop(); dc.Pop();
            }
            var rtb = new RenderTargetBitmap(pw, ph, 96 * scale, 96 * scale, PixelFormats.Pbgra32);
            rtb.Render(dv);
            rtb.Freeze();
            if (gray)
            {
                var g = new FormatConvertedBitmap(rtb, PixelFormats.Gray8, null, 0);
                g.Freeze();
                return g;
            }
            return rtb;
        }
    }
}
