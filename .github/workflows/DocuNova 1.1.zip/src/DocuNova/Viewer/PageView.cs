using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace DocuNova.Viewer
{
    /// <summary>Страница в порядке просмотра: ссылка на страницу документа, поворот и пометки.</summary>
    public sealed class PageRef
    {
        public int Doc { get; set; }
        public int Rotation { get; set; }
        public List<Annotation> Anns { get; } = new List<Annotation>();
        public bool Bookmarked { get; set; }
    }

    /// <summary>Слой поверх страницы: пометки, найденные фрагменты, выделение, предпросмотр рисования.</summary>
    public sealed class OverlayLayer : FrameworkElement
    {
        public PageRef Ref;
        public List<Rect> SearchHits;
        public Rect ActiveHit = Rect.Empty;
        public List<Rect> Selection;
        public Annotation Preview;
        public Rect DragRect = Rect.Empty;

        private static readonly Brush HitBrush = Frozen(new SolidColorBrush(Color.FromArgb(90, 255, 214, 0)));
        private static readonly Pen ActivePen = FrozenPen(new Pen(new SolidColorBrush(Color.FromRgb(255, 120, 0)), 2));
        private static readonly Brush SelBrush = Frozen(new SolidColorBrush(Color.FromArgb(80, 40, 140, 255)));
        private static readonly Pen DragPen = FrozenPen(new Pen(new SolidColorBrush(Color.FromArgb(200, 40, 140, 255)), 1) { DashStyle = DashStyles.Dash });

        private static Brush Frozen(Brush b) { b.Freeze(); return b; }
        private static Pen FrozenPen(Pen p) { p.Freeze(); return p; }

        public OverlayLayer() { IsHitTestVisible = false; }

        protected override void OnRender(DrawingContext dc)
        {
            if (SearchHits != null)
                foreach (var r in SearchHits) dc.DrawRoundedRectangle(HitBrush, null, Inflate(r, 1.5), 2, 2);
            if (!ActiveHit.IsEmpty) dc.DrawRoundedRectangle(null, ActivePen, Inflate(ActiveHit, 2.5), 3, 3);
            if (Ref != null) AnnotationPainter.Draw(dc, Ref.Anns);
            if (Selection != null)
                foreach (var r in Selection) dc.DrawRectangle(SelBrush, null, r);
            if (Preview != null) AnnotationPainter.Draw(dc, Preview);
            if (!DragRect.IsEmpty) dc.DrawRectangle(null, DragPen, DragRect);
        }

        private static Rect Inflate(Rect r, double d) { r.Inflate(d, d); return r; }
    }

    /// <summary>Визуальное представление одной страницы.</summary>
    public sealed class PageView : Border
    {
        public PageRef Ref { get; }
        public int ViewIndex { get; set; }
        public Grid Inner { get; }
        public Image Img { get; }
        /// <summary>Чёткий фрагмент видимой части страницы при крупном масштабе.</summary>
        public Image Detail { get; }
        private readonly Canvas _detailLayer;
        public Rect DetailRect { get; private set; } = Rect.Empty;
        public double DetailScale { get; private set; }
        public int DetailGeneration { get; set; }
        /// <summary>Страница нарисована с пониженным разрешением, видимая часть дорисовывается фрагментом.</summary>
        public bool Tiled { get; set; }
        public OverlayLayer Overlay { get; }
        public double RenderedScale { get; set; }
        public int Generation { get; set; }
        public bool Attached { get; set; }
        private bool _shadow;
        private readonly ScaleTransform _scale = new ScaleTransform(1, 1);

        // Тень рисуется несколькими полупрозрачными прямоугольниками. Эффект DropShadowEffect здесь не подходит:
        // для каждой страницы он создаёт отдельную растровую поверхность её размера и удваивает расход памяти.
        private static Brush[] _shadowBrushes = MakeShadow(Colors.Black, 0.25);
        private static double _shadowDepth = 3;

        public static void SetShadowStyle(Color color, double opacity, double depth)
        {
            _shadowBrushes = MakeShadow(color, opacity);
            _shadowDepth = depth;
        }

        private static Brush[] MakeShadow(Color c, double opacity)
        {
            const int layers = 6;
            var res = new Brush[layers];
            for (int i = 0; i < layers; i++)
            {
                byte a = (byte)Math.Max(1, Math.Min(255, 255 * opacity / layers * 0.9));
                var b = new SolidColorBrush(Color.FromArgb(a, c.R, c.G, c.B));
                b.Freeze();
                res[i] = b;
            }
            return res;
        }

        public bool Shadow
        {
            get => _shadow;
            set { if (_shadow != value) { _shadow = value; InvalidateVisual(); } }
        }

        protected override void OnRender(DrawingContext dc)
        {
            if (_shadow && RenderSize.Width > 0 && RenderSize.Height > 0)
            {
                var brushes = _shadowBrushes;
                for (int i = brushes.Length; i >= 1; i--)
                {
                    double d = i * 2.2;
                    var r = new Rect(-d, -d + _shadowDepth, RenderSize.Width + d * 2, RenderSize.Height + d * 2);
                    dc.DrawRoundedRectangle(brushes[i - 1], null, r, d, d);
                }
            }
            base.OnRender(dc);
        }
        private readonly RotateTransform _rotate = new RotateTransform(0);
        private readonly TextBlock _placeholder;

        public PageView(PageRef r, Size pageSize)
        {
            Ref = r;
            Background = Brushes.White;
            SnapsToDevicePixels = true;
            UseLayoutRounding = true;
            Inner = new Grid { Width = pageSize.Width, Height = pageSize.Height, ClipToBounds = true };
            var tg = new TransformGroup();
            tg.Children.Add(_scale);
            tg.Children.Add(_rotate);
            Inner.LayoutTransform = tg;
            Img = new Image { Stretch = Stretch.Fill };
            // картинка рисуется в точном размере экрана; режим Linear не строит лишних MIP-уровней в памяти
            RenderOptions.SetBitmapScalingMode(Img, BitmapScalingMode.Linear);
            _placeholder = new TextBlock
            {
                Text = "Загрузка…",
                Foreground = new SolidColorBrush(Color.FromRgb(160, 160, 170)),
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center,
                FontSize = 14
            };
            Overlay = new OverlayLayer { Ref = r };
            Detail = new Image { Stretch = Stretch.Fill, Visibility = Visibility.Collapsed };
            RenderOptions.SetBitmapScalingMode(Detail, BitmapScalingMode.Linear);
            _detailLayer = new Canvas { IsHitTestVisible = false };
            _detailLayer.Children.Add(Detail);
            Inner.Children.Add(_placeholder);
            Inner.Children.Add(Img);
            Inner.Children.Add(_detailLayer);
            Inner.Children.Add(Overlay);
            Child = Inner;
        }

        public void SetTransform(double zoom, int rotation)
        {
            _scale.ScaleX = _scale.ScaleY = zoom;
            _rotate.Angle = rotation;
        }

        public void SetDetail(BitmapSource bmp, Rect region, double scale)
        {
            Detail.Source = bmp;
            if (bmp == null || region.IsEmpty)
            {
                Detail.Source = null;
                Detail.Visibility = Visibility.Collapsed;
                DetailRect = Rect.Empty;
                DetailScale = 0;
                return;
            }
            Canvas.SetLeft(Detail, region.X);
            Canvas.SetTop(Detail, region.Y);
            Detail.Width = region.Width;
            Detail.Height = region.Height;
            Detail.Visibility = Visibility.Visible;
            DetailRect = region;
            DetailScale = scale;
        }

        public void ClearDetail()
        {
            DetailGeneration++;
            SetDetail(null, Rect.Empty, 0);
        }

        public bool DetailCovers(Rect r, double scale) =>
            Detail.Source != null && Math.Abs(DetailScale - scale) < 0.001 && DetailRect.Contains(r);

        public void SetImage(BitmapSource bmp)
        {
            if (bmp == null) ClearDetail();
            Img.Source = bmp;
            _placeholder.Visibility = bmp == null ? Visibility.Visible : Visibility.Collapsed;
        }

        public void SetError(string message)
        {
            _placeholder.Text = "Не удалось отрисовать страницу\n" + message;
            _placeholder.Visibility = Visibility.Visible;
        }
    }
}
