using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Packaging;
using System.Windows;
using System.Windows.Documents;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Xps.Packaging;

namespace DocuNova.Core
{
    /// <summary>
    /// Документ, раскладываемый WPF-пагинатором: перетекаемый текст (FlowDocument) или XPS (FixedDocument).
    /// Отрисовка выполняется в потоке, создавшем документ (UI-поток).
    /// </summary>
    public sealed class PaginatedDoc : DocumentBase
    {
        private FlowDocument _flow;
        private DocumentPaginator _pag;
        private XpsDocument _xps;
        private readonly List<Size> _sizes = new List<Size>();
        private readonly Dictionary<int, List<PageChar>> _chars = new Dictionary<int, List<PageChar>>();
        private Size _fixedPageSize = Size.Empty;
        private Thickness? _fixedPadding;
        private ReflowSettings _settings;

        public FlowDocument Flow => _flow;
        public override int PageCount => _sizes.Count;
        public override bool IsReflowable => _flow != null && _fixedPageSize.IsEmpty;

        /// <summary>Перетекаемый документ. pageSize/padding задаются для форматов с собственной вёрсткой (DOCX/ODT).</summary>
        public static PaginatedDoc FromFlowLazy(FlowDocument fd)
        {
            return new PaginatedDoc { Kind = DocKind.Reflow, _flow = fd };
        }

        public void Configure(Size? pageSize, Thickness? padding)
        {
            _fixedPageSize = pageSize ?? Size.Empty;
            _fixedPadding = padding;
        }

        public static PaginatedDoc FromXps(string path)
        {
            var d = new PaginatedDoc { Kind = DocKind.Fixed };
            d._xps = new XpsDocument(path, FileAccess.Read, CompressionOption.NotCompressed);
            var seq = d._xps.GetFixedDocumentSequence();
            if (seq == null) throw new UnsupportedFormatException("XPS не содержит документов.");
            d._pag = seq.DocumentPaginator;
            d._pag.ComputePageCount();
            for (int i = 0; i < d._pag.PageCount; i++)
            {
                var p = d._pag.GetPage(i);
                var sz = p.Size;
                if (sz.Width < 1 || sz.Height < 1) sz = new Size(816, 1056);
                d._sizes.Add(sz);
            }
            return d;
        }

        public override void Reflow(ReflowSettings s)
        {
            if (_flow == null) return;
            _settings = s.Clone();
            var fd = _flow;
            Size ps = _fixedPageSize.IsEmpty ? new Size(s.PageWidth, s.PageHeight) : _fixedPageSize;
            fd.PageWidth = ps.Width;
            fd.PageHeight = ps.Height;
            fd.ColumnWidth = 100000; // одна колонка
            fd.ColumnGap = 0;
            fd.IsColumnWidthFlexible = false;
            fd.PagePadding = _fixedPadding ?? new Thickness(s.Margin, s.Margin * 0.8, s.Margin, s.Margin * 0.9);
            if (_fixedPageSize.IsEmpty)
            {
                try { fd.FontFamily = new FontFamily(s.FontFamily + ", Segoe UI, Arial"); } catch { }
                fd.FontSize = s.FontSize;
                fd.LineHeight = s.FontSize * s.LineHeight;
                fd.TextAlignment = s.Justify ? TextAlignment.Justify : TextAlignment.Left;
            }
            fd.IsHyphenationEnabled = s.Hyphenation;
            fd.IsOptimalParagraphEnabled = false;
            fd.Background = Brushes.White;
            fd.Foreground = Brushes.Black;

            _pag = ((IDocumentPaginatorSource)fd).DocumentPaginator;
            _pag.PageSize = ps;
            _pag.ComputePageCount();
            _sizes.Clear();
            _chars.Clear();
            int count = Math.Max(1, _pag.PageCount);
            for (int i = 0; i < count; i++) _sizes.Add(ps);
            ResolveToc(Toc);
        }

        private void ResolveToc(List<TocItem> items)
        {
            if (!(_pag is DynamicDocumentPaginator dyn)) return;
            foreach (var t in items)
            {
                if (t.Anchor is TextElement te)
                {
                    try
                    {
                        int pn = dyn.GetPageNumber(te.ContentStart);
                        t.PageIndex = Math.Max(0, pn);
                    }
                    catch { t.PageIndex = 0; }
                }
                ResolveToc(t.Children);
            }
        }

        public override Size GetPageSize(int index) => _sizes[Math.Max(0, Math.Min(index, _sizes.Count - 1))];

        public override BitmapSource RenderPage(int index, double scale)
        {
            var page = _pag.GetPage(index);
            if (page == null || page == DocumentPage.Missing) return null;
            return VisualTools.Render(page.Visual, GetPageSize(index), scale);
        }

        protected override IReadOnlyList<PageChar> GetPageCharsCore(int index)
        {
            if (_chars.TryGetValue(index, out var c)) return c;
            var page = _pag.GetPage(index);
            var list = page?.Visual != null ? VisualTools.ExtractChars(page.Visual) : new List<PageChar>();
            // убираем символы вне страницы
            var sz = GetPageSize(index);
            list.RemoveAll(ch => ch.Box.Bottom < 0 || ch.Box.Top > sz.Height || ch.Box.Right < 0 || ch.Box.Left > sz.Width);
            if (_chars.Count > 30) _chars.Clear();
            _chars[index] = list;
            return list;
        }

        /// <summary>Вектор страницы (для печати без потери качества).</summary>
        public Visual GetPageVisual(int index) => _pag.GetPage(index)?.Visual;

        public override void TrimMemory()
        {
            _chars.Clear();
        }

        public override void Dispose()
        {
            try { _xps?.Close(); } catch { }
            _xps = null;
            _flow = null;
            _pag = null;
            _chars.Clear();
            base.Dispose();
        }
    }
}
