using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using DocuNova.Core;

namespace DocuNova.Viewer
{
    /// <summary>Страница в порядке просмотра: ссылка на страницу документа, поворот и пометки.</summary>
    public sealed class PageRef
    {
        public int Doc { get; set; }
        public int Rotation { get; set; }
        public List<Annotation> Anns { get; } = new List<Annotation>();
        public bool Bookmarked { get; set; }
    }

    /// <summary>Слой поверх страницы: пометки, найденные фрагменты, выделение, предпросмотр рисования.</summary>
    public sealed class OverlayLayer : FrameworkElement
    {
        public PageRef Ref;
        public List<Rect> SearchHits;
        public Rect ActiveHit = Rect.Empty;
        public List<Rect> Selection;
        public Annotation Preview;
        public Rect DragRect = Rect.Empty;

        private static readonly Brush HitBrush = Frozen(new SolidColorBrush(Color.FromArgb(90, 255, 214, 0)));
        private static readonly Pen ActivePen = FrozenPen(new Pen(new SolidColorBrush(Color.FromRgb(255, 120, 0)), 2));
        private static readonly Brush SelBrush = Frozen(new SolidColorBrush(Color.FromArgb(80, 40, 140, 255)));
        private static readonly Pen DragPen = FrozenPen(new Pen(new SolidColorBrush(Color.FromArgb(200, 40, 140, 255)), 1) { DashStyle = DashStyles.Dash });

        private static Brush Frozen(Brush b) { b.Freeze(); return b; }
        private static Pen FrozenPen(Pen p) { p.Freeze(); return p; }

        public OverlayLayer() { IsHitTestVisible = false; }

        protected override void OnRender(DrawingContext dc)
        {
            if (SearchHits != null)
                foreach (var r in SearchHits) dc.DrawRoundedRectangle(HitBrush, null, Inflate(r, 1.5), 2, 2);
            if (!ActiveHit.IsEmpty) dc.DrawRoundedRectangle(null, ActivePen, Inflate(ActiveHit, 2.5), 3, 3);
            if (Ref != null) AnnotationPainter.Draw(dc, Ref.Anns);
            if (Selection != null)
                foreach (var r in Selection) dc.DrawRectangle(SelBrush, null, r);
            if (Preview != null) AnnotationPainter.Draw(dc, Preview);
            if (!DragRect.IsEmpty) dc.DrawRectangle(null, DragPen, DragRect);
        }

        private static Rect Inflate(Rect r, double d) { r.Inflate(d, d); return r; }
    }

    /// <summary>
    /// Визуальное представление одной страницы.
    /// Растр страницы рисуется самим элементом в его собственных координатах (без масштабирующих трансформаций):
    /// начало картинки совмещается с целым пикселем монитора, а если растр отрисован под текущий масштаб,
    /// каждый его пиксель попадает ровно на пиксель экрана — без интерполяции и размытия.
    /// Над растром лежит слой Inner (масштаб и поворот) с пометками, подсветкой поиска и выделением.
    /// </summary>
    public sealed class PageView : Border
    {
        public PageRef Ref { get; }
        public int ViewIndex { get; set; }
        /// <summary>Слой в координатах страницы (DIP): пометки, поиск, выделение, обработка мыши.</summary>
        public Grid Inner { get; }
        public OverlayLayer Overlay { get; }
        public double RenderedScale { get; set; }
        public int Generation { get; set; }
        public int DetailGeneration { get; set; }
        public bool Attached { get; set; }
        /// <summary>Страница нарисована с пониженным разрешением, видимая часть дорисовывается чётким фрагментом.</summary>
        public bool Tiled { get; set; }
        /// <summary>Документ-изображение: при сильном увеличении показывать настоящие пиксели.</summary>
        public bool PixelExact { get; set; }

        private readonly Size _pageSize;          // размер страницы без поворота, DIP
        private double _zoom = 1;
        private int _rotation;
        private readonly ScaleTransform _scale = new ScaleTransform(1, 1);
        private readonly RotateTransform _rotate = new RotateTransform(0);
        private readonly TextBlock _placeholder;

        private BitmapSource _image;
        private int _imageRotation;
        private BitmapSource _detail;
        private Rect _detailRect = Rect.Empty;    // в координатах страницы без поворота
        private double _detailScale;
        private int _detailRotation;

        private Point _lastDevice = new Point(double.NaN, double.NaN);
        private bool _hooked;
        private bool _shadow;

        // Тень рисуется несколькими полупрозрачными прямоугольниками (DropShadowEffect удвоил бы расход памяти).
        private static Brush[] _shadowBrushes = MakeShadow(Colors.Black, 0.25);
        private static double _shadowDepth = 3;

        public static void SetShadowStyle(Color color, double opacity, double depth)
        {
            _shadowBrushes = MakeShadow(color, opacity);
            _shadowDepth = depth;
        }

        private static Brush[] MakeShadow(Color c, double opacity)
        {
            const int layers = 6;
            var res = new Brush[layers];
            for (int i = 0; i < layers; i++)
            {
                byte a = (byte)Math.Max(1, Math.Min(255, 255 * opacity / layers * 0.9));
                var b = new SolidColorBrush(Color.FromArgb(a, c.R, c.G, c.B));
                b.Freeze();
                res[i] = b;
            }
            return res;
        }

        public bool Shadow
        {
            get => _shadow;
            set { if (_shadow != value) { _shadow = value; InvalidateVisual(); } }
        }

        public PageView(PageRef r, Size pageSize)
        {
            Ref = r;
            _pageSize = pageSize;
            Background = Brushes.White;
            UseLayoutRounding = true;
            Inner = new Grid { Width = pageSize.Width, Height = pageSize.Height, ClipToBounds = true, Background = null };
            var tg = new TransformGroup();
            tg.Children.Add(_scale);
            tg.Children.Add(_rotate);
            Inner.LayoutTransform = tg;
            _placeholder = new TextBlock
            {
                Text = "Загрузка…",
                Foreground = new SolidColorBrush(Color.FromRgb(160, 160, 170)),
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center,
                FontSize = 14
            };
            Overlay = new OverlayLayer { Ref = r };
            Inner.Children.Add(_placeholder);
            Inner.Children.Add(Overlay);
            Child = Inner;
            Loaded += (s, e) => Hook(true);
            Unloaded += (s, e) => Hook(false);
        }

        // ================== состояние ==================

        public bool HasImage => _image != null;
        public int ImageRotation => _imageRotation;
        public int CurrentRotation => PagePixels.Normalize(Ref.Rotation);

        public void SetTransform(double zoom, int rotation)
        {
            _scale.ScaleX = _scale.ScaleY = zoom;
            _rotate.Angle = rotation;
            if (Math.Abs(_zoom - zoom) > 1e-9 || _rotation != PagePixels.Normalize(rotation))
            {
                _zoom = zoom;
                _rotation = PagePixels.Normalize(rotation);
                InvalidateVisual();
            }
        }

        /// <summary>Картинка всей страницы (уже повёрнутая на rotation).</summary>
        public void SetImage(BitmapSource bmp, int rotation = 0)
        {
            if (bmp == null) ClearDetail();
            _image = bmp;
            _imageRotation = PagePixels.Normalize(rotation);
            _placeholder.Text = "Загрузка…";
            _placeholder.Visibility = bmp == null ? Visibility.Visible : Visibility.Collapsed;
            InvalidateVisual();
        }

        public void SetError(string message)
        {
            _placeholder.Text = "Не удалось отрисовать страницу\n" + message;
            _placeholder.Visibility = Visibility.Visible;
        }

        /// <summary>Чёткий фрагмент region (координаты страницы без поворота), отрисованный в масштабе scale и повёрнутый на rotation.</summary>
        public void SetDetail(BitmapSource bmp, Rect region, double scale, int rotation)
        {
            if (bmp == null || region.IsEmpty)
            {
                _detail = null; _detailRect = Rect.Empty; _detailScale = 0;
            }
            else
            {
                _detail = bmp; _detailRect = region; _detailScale = scale; _detailRotation = PagePixels.Normalize(rotation);
            }
            InvalidateVisual();
        }

        public void ClearDetail()
        {
            DetailGeneration++;
            if (_detail != null) { _detail = null; _detailRect = Rect.Empty; _detailScale = 0; InvalidateVisual(); }
        }

        public bool DetailCovers(Rect r, double scale) =>
            _detail != null && Math.Abs(_detailScale - scale) < 0.001 && _detailRotation == _rotation && _detailRect.Contains(r);

        // ================== совмещение с пикселями экрана ==================

        private void Hook(bool on)
        {
            if (on == _hooked) return;
            _hooked = on;
            if (on) LayoutUpdated += OnLayoutUpdated;
            else LayoutUpdated -= OnLayoutUpdated;
        }

        /// <summary>Положение на экране изменилось на долю пикселя (прокрутка) — перерисовываемся, чтобы растр оставался на сетке пикселей.</summary>
        private void OnLayoutUpdated(object sender, EventArgs e)
        {
            if (_image == null || double.IsNaN(_lastDevice.X)) return;
            if (!TryDevice(out var m)) return;
            var o = m.Transform(new Point(0, 0));
            if (Math.Abs(Frac(o.X) - Frac(_lastDevice.X)) > 0.01 || Math.Abs(Frac(o.Y) - Frac(_lastDevice.Y)) > 0.01)
                InvalidateVisual();
        }

        private static double Frac(double v) => v - Math.Floor(v);

        /// <summary>Матрица «координаты элемента (DIP) → физические пиксели окна». Только сдвиг и масштаб DPI.</summary>
        private bool TryDevice(out Matrix m)
        {
            m = Matrix.Identity;
            try
            {
                var ps = PresentationSource.FromVisual(this);
                if (ps?.RootVisual == null || ps.CompositionTarget == null) return false;
                if (!(TransformToAncestor(ps.RootVisual) is Transform t)) return false;
                m = t.Value * ps.CompositionTarget.TransformToDevice;
                return Math.Abs(m.M12) < 1e-9 && Math.Abs(m.M21) < 1e-9 && m.M11 > 0 && m.M22 > 0;
            }
            catch { return false; }
        }

        // ================== отрисовка ==================

        protected override void OnRender(DrawingContext dc)
        {
            var size = RenderSize;
            if (_shadow && size.Width > 0 && size.Height > 0)
            {
                var brushes = _shadowBrushes;
                for (int i = brushes.Length; i >= 1; i--)
                {
                    double d = i * 2.2;
                    var r = new Rect(-d, -d + _shadowDepth, size.Width + d * 2, size.Height + d * 2);
                    dc.DrawRoundedRectangle(brushes[i - 1], null, r, d, d);
                }
            }
            base.OnRender(dc); // белый фон страницы
            if (_image == null || size.Width <= 0 || size.Height <= 0) return;
            try { DrawPage(dc, size); }
            catch { /* сбой отрисовки одной страницы не должен мешать работе */ }
        }

        private void DrawPage(DrawingContext dc, Size size)
        {
            double sx = 1, sy = 1, ox = 0, oy = 0;
            bool device = TryDevice(out var m);
            if (device)
            {
                sx = m.M11; sy = m.M22;
                var o = m.Transform(new Point(0, 0));
                _lastDevice = o;
                // сдвиг до ближайшего целого пикселя монитора
                ox = (Math.Round(o.X) - o.X) / sx;
                oy = (Math.Round(o.Y) - o.Y) / sy;
            }
            dc.PushClip(new RectangleGeometry(new Rect(size)));
            dc.PushTransform(new TranslateTransform(ox, oy));
            try
            {
                var full = new Rect(size);
                if (_imageRotation != _rotation)
                {
                    // страницу только что повернули — до перерисовки показываем прежнюю картинку повёрнутой
                    int delta = PagePixels.Normalize(_rotation - _imageRotation);
                    var c = new Point(size.Width / 2, size.Height / 2);
                    dc.PushTransform(new RotateTransform(delta, c.X, c.Y));
                    var rr = delta % 180 == 0 ? full : new Rect(c.X - size.Height / 2, c.Y - size.Width / 2, size.Height, size.Width);
                    DrawBitmap(dc, _image, rr, BitmapScalingMode.HighQuality);
                    dc.Pop();
                    return;
                }

                DrawFitted(dc, _image, full, sx, sy, device);

                if (_detail != null && _detailRotation == _rotation)
                {
                    var dr = PageToView(_detailRect);
                    if (device)
                    {
                        // начало фрагмента — тоже на целом пикселе
                        dr.X = Math.Round(dr.X * sx) / sx;
                        dr.Y = Math.Round(dr.Y * sy) / sy;
                    }
                    DrawFitted(dc, _detail, dr, sx, sy, device);
                }
            }
            finally
            {
                dc.Pop();
                dc.Pop();
            }
        }

        /// <summary>
        /// Рисует растр в прямоугольнике target. Если размер растра совпадает с размером target на экране —
        /// пиксель в пиксель (без интерполяции), иначе — качественное масштабирование.
        /// </summary>
        private void DrawFitted(DrawingContext dc, BitmapSource bmp, Rect target, double sx, double sy, bool device)
        {
            int pw = bmp.PixelWidth, ph = bmp.PixelHeight;
            double dw = target.Width * sx, dh = target.Height * sy;
            double tolW = Math.Max(1.5, dw * 0.002), tolH = Math.Max(1.5, dh * 0.002);
            if (device && Math.Abs(dw - pw) <= tolW && Math.Abs(dh - ph) <= tolH)
            {
                DrawBitmap(dc, bmp, new Rect(target.X, target.Y, pw / sx, ph / sy), BitmapScalingMode.NearestNeighbor);
                return;
            }
            double k = dw / Math.Max(1, pw);
            var mode = PixelExact && k >= 2 ? BitmapScalingMode.NearestNeighbor : BitmapScalingMode.HighQuality;
            DrawBitmap(dc, bmp, target, mode);
        }

        private static void DrawBitmap(DrawingContext dc, BitmapSource bmp, Rect rect, BitmapScalingMode mode)
        {
            var g = new DrawingGroup();
            RenderOptions.SetBitmapScalingMode(g, mode);
            using (var c = g.Open()) c.DrawImage(bmp, rect);
            dc.DrawDrawing(g);
        }

        /// <summary>Прямоугольник в координатах страницы (без поворота, DIP) → координаты элемента на экране.</summary>
        public Rect PageToView(Rect r)
        {
            double z = _zoom, W = _pageSize.Width, H = _pageSize.Height;
            switch (_rotation)
            {
                case 90: return new Rect((H - r.Bottom) * z, r.X * z, r.Height * z, r.Width * z);
                case 180: return new Rect((W - r.Right) * z, (H - r.Bottom) * z, r.Width * z, r.Height * z);
                case 270: return new Rect(r.Y * z, (W - r.Right) * z, r.Height * z, r.Width * z);
                default: return new Rect(r.X * z, r.Y * z, r.Width * z, r.Height * z);
            }
        }
    }
}
