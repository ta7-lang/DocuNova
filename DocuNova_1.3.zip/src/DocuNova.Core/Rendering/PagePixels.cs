using System;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace DocuNova.Core
{
    /// <summary>
    /// «Сырые» пиксели отрисованной страницы (BGRA, 4 байта на пиксель).
    /// Между потоками передаются только эти байты, а не объекты WPF: картинку для экрана создаёт
    /// сам UI-поток (<see cref="ToBitmap"/>), поэтому ошибки «объект принадлежит другому потоку» исключены.
    /// Здесь же применяются режим страницы (ночь/сепия) и поворот на 90/180/270° — без потери качества.
    /// </summary>
    public sealed class PagePixels
    {
        public int Width { get; private set; }
        public int Height { get; private set; }
        public int Stride => Width * 4;
        public bool Alpha { get; private set; }
        public byte[] Data { get; private set; }

        private static bool HasAlpha(PixelFormat f) =>
            f == PixelFormats.Bgra32 || f == PixelFormats.Pbgra32 || f == PixelFormats.Prgba64 || f == PixelFormats.Rgba64 ||
            f == PixelFormats.Rgba128Float || f == PixelFormats.Prgba128Float ||
            f == PixelFormats.Indexed1 || f == PixelFormats.Indexed2 || f == PixelFormats.Indexed4 || f == PixelFormats.Indexed8;

        /// <summary>
        /// Копирует пиксели картинки. Вызывается в том же потоке, где картинка создана.
        /// mode: normal / night / sepia; rotation: 0, 90, 180, 270 (по часовой стрелке).
        /// </summary>
        public static PagePixels From(BitmapSource src, string mode, int rotation)
        {
            if (src == null || src.PixelWidth < 1 || src.PixelHeight < 1) return null;
            bool alpha = HasAlpha(src.Format);
            var target = alpha ? PixelFormats.Pbgra32 : PixelFormats.Bgr32;
            BitmapSource conv = src.Format == target ? src : new FormatConvertedBitmap(src, target, null, 0);
            int w = conv.PixelWidth, h = conv.PixelHeight;
            var data = new byte[(long)w * h * 4];
            conv.CopyPixels(data, w * 4, 0);
            if (!alpha)
                for (int i = 3; i < data.Length; i += 4) data[i] = 255;
            if (mode == "night" || mode == "sepia") Tint(data, mode == "night");
            var p = new PagePixels { Width = w, Height = h, Alpha = alpha, Data = data };
            rotation = Normalize(rotation);
            if (rotation != 0) p.Rotate(rotation);
            return p;
        }

        public static int Normalize(int rotation) => ((rotation % 360) + 360) % 360 / 90 * 90;

        /// <summary>Картинка для показа. Вызывать только в UI-потоке. Байты после этого освобождаются.</summary>
        public BitmapSource ToBitmap()
        {
            if (Data == null) return null;
            var wb = new WriteableBitmap(Width, Height, 96, 96, Alpha ? PixelFormats.Pbgra32 : PixelFormats.Bgr32, null);
            wb.WritePixels(new Int32Rect(0, 0, Width, Height), Data, Stride, 0);
            wb.Freeze();
            Data = null;
            return wb;
        }

        private void Rotate(int rotation)
        {
            int w = Width, h = Height;
            var src = Data;
            var dst = new byte[src.Length];
            int nw = rotation == 180 ? w : h, nh = rotation == 180 ? h : w;
            for (int y = 0; y < h; y++)
            {
                for (int x = 0; x < w; x++)
                {
                    int dx, dy;
                    switch (rotation)
                    {
                        case 90: dx = h - 1 - y; dy = x; break;
                        case 180: dx = w - 1 - x; dy = h - 1 - y; break;
                        default: dx = y; dy = w - 1 - x; break; // 270
                    }
                    long s = ((long)y * w + x) * 4, d = ((long)dy * nw + dx) * 4;
                    dst[d] = src[s]; dst[d + 1] = src[s + 1]; dst[d + 2] = src[s + 2]; dst[d + 3] = src[s + 3];
                }
            }
            Data = dst;
            Width = nw; Height = nh;
        }

        private static void Tint(byte[] p, bool night)
        {
            if (night)
            {
                for (int i = 0; i < p.Length; i += 4)
                {
                    p[i] = (byte)(28 + ((255 - p[i]) * 205 >> 8));
                    p[i + 1] = (byte)(28 + ((255 - p[i + 1]) * 205 >> 8));
                    p[i + 2] = (byte)(30 + ((255 - p[i + 2]) * 205 >> 8));
                }
            }
            else
            {
                for (int i = 0; i < p.Length; i += 4)
                {
                    p[i] = (byte)(p[i] * 205 >> 8);
                    p[i + 1] = (byte)(p[i + 1] * 238 >> 8);
                    p[i + 2] = (byte)(p[i + 2] * 253 >> 8);
                }
            }
        }
    }
}
