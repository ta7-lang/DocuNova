using System;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace DocuNova.Viewer
{
    /// <summary>
    /// Показ растра страницы «пиксель в пиксель».
    /// Обычный Image растягивает картинку под свои размеры в DIP и ставит её по дробным координатам —
    /// при любом несовпадении сетки пикселей WPF пересэмплирует растр, и текст становится мыльным.
    /// Этот элемент вычисляет точное преобразование до пикселей монитора (с учётом масштаба, поворота,
    /// прокрутки и DPI монитора) и, если растр отрисован под текущий масштаб, кладёт каждый его пиксель
    /// ровно на пиксель экрана без какой-либо интерполяции.
    /// </summary>
    public sealed class CrispBitmap : FrameworkElement
    {
        private BitmapSource _source;
        private Point _lastFrac = new Point(double.NaN, double.NaN);
        private double _lastSx = double.NaN, _lastSy = double.NaN;
        private bool _hooked;

        /// <summary>Картинки (фото, сканы): при сильном увеличении показывать настоящие пиксели без размытия.</summary>
        public bool PixelExact { get; set; }

        public CrispBitmap()
        {
            SnapsToDevicePixels = false;
            UseLayoutRounding = false;
            Loaded += (s, e) => Hook(true);
            Unloaded += (s, e) => Hook(false);
        }

        public BitmapSource Source
        {
            get => _source;
            set
            {
                if (ReferenceEquals(_source, value)) return;
                _source = value;
                _lastFrac = new Point(double.NaN, double.NaN);
                InvalidateVisual();
            }
        }

        private void Hook(bool on)
        {
            if (on == _hooked) return;
            _hooked = on;
            if (on) LayoutUpdated += OnLayoutUpdated;
            else LayoutUpdated -= OnLayoutUpdated;
        }

        /// <summary>После прокрутки или изменения раскладки сдвиг относительно сетки пикселей меняется — перерисовываемся.</summary>
        private void OnLayoutUpdated(object sender, EventArgs e)
        {
            if (_source == null || Visibility != Visibility.Visible) return;
            if (!TryDeviceMatrix(out var m)) return;
            var o = m.Transform(new Point(0, 0));
            var frac = new Point(o.X - Math.Floor(o.X), o.Y - Math.Floor(o.Y));
            double sx = Math.Sqrt(m.M11 * m.M11 + m.M12 * m.M12), sy = Math.Sqrt(m.M21 * m.M21 + m.M22 * m.M22);
            if (Math.Abs(frac.X - _lastFrac.X) > 0.001 || Math.Abs(frac.Y - _lastFrac.Y) > 0.001 ||
                Math.Abs(sx - _lastSx) > 1e-6 || Math.Abs(sy - _lastSy) > 1e-6)
                InvalidateVisual();
        }

        /// <summary>Матрица «локальные DIP → физические пиксели окна».</summary>
        private bool TryDeviceMatrix(out Matrix m)
        {
            m = Matrix.Identity;
            try
            {
                var ps = PresentationSource.FromVisual(this);
                if (ps?.RootVisual == null || ps.CompositionTarget == null) return false;
                if (!(TransformToAncestor(ps.RootVisual) is Transform t)) return false;
                m = t.Value * ps.CompositionTarget.TransformToDevice;
                return true;
            }
            catch { return false; }
        }

        private static bool AxisAligned(Matrix m) =>
            (Math.Abs(m.M12) < 1e-9 && Math.Abs(m.M21) < 1e-9) || (Math.Abs(m.M11) < 1e-9 && Math.Abs(m.M22) < 1e-9);

        protected override void OnRender(DrawingContext dc)
        {
            var size = RenderSize;
            if (size.Width <= 0 || size.Height <= 0) return;
            // прозрачная подложка — чтобы щелчки по странице попадали в неё, как раньше в Image
            dc.DrawRectangle(Brushes.Transparent, null, new Rect(size));
            var src = _source;
            if (src == null) return;
            int pw = src.PixelWidth, ph = src.PixelHeight;

            if (TryDeviceMatrix(out var m) && AxisAligned(m) && m.HasInverse)
            {
                double sx = Math.Sqrt(m.M11 * m.M11 + m.M12 * m.M12);
                double sy = Math.Sqrt(m.M21 * m.M21 + m.M22 * m.M22);
                double dw = size.Width * sx, dh = size.Height * sy;
                var o = m.Transform(new Point(0, 0));
                _lastFrac = new Point(o.X - Math.Floor(o.X), o.Y - Math.Floor(o.Y));
                _lastSx = sx; _lastSy = sy;

                double tolW = Math.Max(1.5, dw * 0.0015), tolH = Math.Max(1.5, dh * 0.0015);
                if (Math.Abs(dw - pw) <= tolW && Math.Abs(dh - ph) <= tolH)
                {
                    // растр отрисован ровно под экран: начало — на целый пиксель, размер — родной, без интерполяции
                    var inv = m; inv.Invert();
                    var lo = inv.Transform(new Point(Math.Round(o.X), Math.Round(o.Y)));
                    Draw(dc, src, new Rect(lo.X, lo.Y, pw / sx, ph / sy), BitmapScalingMode.NearestNeighbor);
                    return;
                }

                // растр крупнее или мельче экрана (идёт перерисовка после смены масштаба, сильно увеличенная фотография)
                double k = dw / Math.Max(1, pw);
                var mode = PixelExact && k >= 2 ? BitmapScalingMode.NearestNeighbor : BitmapScalingMode.HighQuality;
                Draw(dc, src, new Rect(size), mode);
                return;
            }
            Draw(dc, src, new Rect(size), BitmapScalingMode.HighQuality);
        }

        private static void Draw(DrawingContext dc, BitmapSource src, Rect rect, BitmapScalingMode mode)
        {
            var g = new DrawingGroup();
            RenderOptions.SetBitmapScalingMode(g, mode);
            using (var c = g.Open()) c.DrawImage(src, rect);
            dc.DrawDrawing(g);
        }
    }
}
