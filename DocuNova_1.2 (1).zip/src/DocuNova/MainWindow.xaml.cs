using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using DocuNova.Core;
using DocuNova.Services;
using DocuNova.Viewer;
using DocuNova.Views;
using Microsoft.Win32;

namespace DocuNova
{
    public partial class MainWindow : Window
    {
        // ---------- вкладки и панели ----------
        private readonly List<DocTab> _tabs = new List<DocTab>();
        private readonly List<DocTab> _split = new List<DocTab>();   // документы в параллельном просмотре
        private DocTab _active;
        private bool _parallel;
        private bool _syncing;
        private const int MaxPanes = 6;
        private readonly SemaphoreSlim _openLock = new SemaphoreSlim(1, 1);

        /// <summary>Пустой просмотрщик, когда нет открытых документов (никогда не показывается).</summary>
        private readonly DocViewer _idle = new DocViewer();
        private DocViewer _viewer => _active?.Viewer ?? _idle;
        private DocumentBase _doc => _active?.Doc;
        private string _path => _active?.Path;

        private Tool _tool = Tool.Hand;
        private bool _ready;
        private bool _fullscreen;
        private WindowState _stateBeforeFull;
        private WindowState _stateBeforeMin = WindowState.Normal;
        private Color _color;
        private double _sidebarWidth = 290;
        private readonly ObservableCollection<ThumbItem> _thumbs = new ObservableCollection<ThumbItem>();
        private int _searchGen;
        private readonly DispatcherTimer _bannerTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(14) };

        private static readonly string[] Palette = { "#FFFF2BD6", "#FF00F0FF", "#FFFFE600", "#FF39FF14", "#FFFF7A00", "#FFFF1E3C", "#FF7B61FF", "#FF2E9BFF", "#FF000000", "#FFFFFFFF" };
        private static readonly string[] Stamps = { "ОДОБРЕНО", "ПРОВЕРЕНО", "ЧЕРНОВИК", "КОПИЯ", "КОНФИДЕНЦИАЛЬНО", "ОТКЛОНЕНО", "СРОЧНО", "ОПЛАЧЕНО", "ПОЛУЧЕНО", "УТВЕРЖДАЮ" };

        private AppSettings S => App.Settings;

        public MainWindow()
        {
            InitializeComponent();
            _idle.NewAnnotation = NewAnnotationStyle;

            ThumbList.ItemsSource = _thumbs;
            _bannerTimer.Tick += (s, e) => { _bannerTimer.Stop(); Banner.Visibility = Visibility.Collapsed; };

            // параметры пометок
            _color = ThemeColor(S.PenColor, Color.FromRgb(255, 43, 214));
            ThicknessSlider.Value = S.PenThickness;
            OpacitySlider.Value = S.AnnOpacity;
            FontSlider.Value = S.TextSize;
            foreach (var st in Stamps) StampBox.Items.Add(st);
            StampBox.SelectedItem = Stamps.Contains(S.Stamp) ? S.Stamp : Stamps[0];
            BuildSwatches();

            // параметры вида
            _sidebarWidth = Math.Max(200, Math.Min(600, S.SidebarWidth > 0 ? S.SidebarWidth : 290));
            SidebarCol.Width = new GridLength(_sidebarWidth);
            ApplyViewSettings();
            TwoPageBtn.IsChecked = S.TwoPage;
            SyncBtn.IsChecked = S.SyncScroll;
            if (!S.ShowSidebar) SetSidebar(false);
            Width = Math.Max(MinWidth, S.WindowWidth);
            Height = Math.Max(MinHeight, S.WindowHeight);
            if (S.WindowMaximized) WindowState = WindowState.Maximized;

            Drop += OnDrop;
            DragOver += (s, e) => { e.Effects = e.Data.GetDataPresent(DataFormats.FileDrop) ? DragDropEffects.Copy : DragDropEffects.None; e.Handled = true; };
            StateChanged += OnStateChanged;
            Closing += OnClosing;
            Loaded += (s, e) => { UpdateMaxState(); RefreshRecent(); };
            Sidebar.SizeChanged += (s, e) => UpdateTabSpacer();
            UpdateDocButtons();
            UpdateParallelUi();
            _ready = true;
        }

        private static Color ThemeColor(string s, Color fallback) => Themes.ThemeManager.C(s, fallback);

        private IEnumerable<DocViewer> AllViewers() => _tabs.Select(t => t.Viewer).Concat(new[] { _idle });

        private void ApplyViewSettings()
        {
            foreach (var v in AllViewers()) ApplyViewSettings(v, false);
        }

        private void ApplyViewSettings(DocViewer v, bool isNew)
        {
            v.Gap = S.PageGap;
            v.Shadows = S.PageShadows;
            v.PageMode = S.PageMode ?? "normal";
            if (isNew || v == _idle)
            {
                v.FitMode = S.FitMode ?? "width";
                v.TwoPage = S.TwoPage;
            }
            v.Tool = _tool;
        }

        // ======================= Окно =======================

        private void Min_Click(object sender, RoutedEventArgs e) => WindowState = WindowState.Minimized;
        private void Max_Click(object sender, RoutedEventArgs e) => WindowState = WindowState == WindowState.Maximized ? WindowState.Normal : WindowState.Maximized;
        private void Close_Click(object sender, RoutedEventArgs e) => Close();

        private void UpdateMaxState()
        {
            bool max = WindowState == WindowState.Maximized;
            Root.Margin = max && !_fullscreen ? new Thickness(7) : new Thickness(0);
            MaxBtn.Content = max ? "" : "";
        }

        private void OnStateChanged(object sender, EventArgs e)
        {
            UpdateMaxState();
            if (WindowState == WindowState.Minimized)
            {
                // свёрнутое окно не держит в памяти изображения страниц и вспомогательные кэши
                foreach (var t in VisibleTabs()) t.Viewer.Suspend();
                foreach (var t in _tabs) { try { t.Doc?.TrimMemory(); } catch { } }
                foreach (var th in _thumbs) th.Thumb = null;
                Dispatcher.BeginInvoke(new Action(() => MemoryTrim.Collect(true)), DispatcherPriority.Background);
            }
            else
            {
                _stateBeforeMin = WindowState;
                bool wasSuspended = false;
                foreach (var t in VisibleTabs()) { if (t.Viewer.Suspended) wasSuspended = true; t.Viewer.Resume(); }
                if (wasSuspended) RebuildThumbs(); // эскизы были освобождены при сворачивании
            }
        }

        private void OnClosing(object sender, CancelEventArgs e)
        {
            foreach (var t in _tabs.ToList())
            {
                if (t.Doc != null && t.Viewer.Modified && !ConfirmDiscard(t)) { e.Cancel = true; return; }
            }
            S.WindowMaximized = WindowState == WindowState.Maximized;
            if (WindowState == WindowState.Normal) { S.WindowWidth = ActualWidth; S.WindowHeight = ActualHeight; }
            if (Sidebar.Visibility == Visibility.Visible && SidebarCol.ActualWidth > 100) S.SidebarWidth = SidebarCol.ActualWidth;
            else S.SidebarWidth = _sidebarWidth;
            S.Save();
            foreach (var t in _tabs.ToList()) DisposeTab(t);
            _tabs.Clear();
            _split.Clear();
            _active = null;
        }

        private void OnDrop(object sender, DragEventArgs e)
        {
            if (e.Data.GetData(DataFormats.FileDrop) is string[] files && files.Length > 0) OpenFiles(files);
        }

        /// <summary>Вывести окно на передний план (документ открыт из Проводника при запущенной программе).</summary>
        private void BringToFront()
        {
            try
            {
                if (WindowState == WindowState.Minimized) WindowState = _stateBeforeMin == WindowState.Maximized ? WindowState.Maximized : WindowState.Normal;
                Show();
                Activate();
                Topmost = true;
                Topmost = false;
                Focus();
            }
            catch { }
        }

        /// <summary>Файлы, переданные повторным запуском программы (двойной щелчок в Проводнике).</summary>
        public void ReceiveFiles(string[] paths)
        {
            BringToFront();
            var files = (paths ?? new string[0]).Where(p =>
            {
                try { return Path.IsPathFullyQualified(p) && File.Exists(p); } catch { return false; }
            }).ToList();
            if (files.Count > 0) OpenFiles(files);
        }

        // ======================= Открытие =======================

        private void Open_Click(object sender, RoutedEventArgs e)
        {
            var files = AskFiles();
            if (files.Count > 0) OpenFiles(files);
        }

        private List<string> AskFiles()
        {
            var dlg = new OpenFileDialog
            {
                Filter = DocumentLoader.OpenFileFilter(),
                Title = "Открыть документы (можно выбрать несколько — откроются во вкладках)",
                CheckFileExists = true,
                Multiselect = true,
                DereferenceLinks = false // ярлык не подменяет файл
            };
            return dlg.ShowDialog(this) == true ? dlg.FileNames.ToList() : new List<string>();
        }

        /// <summary>Открывает файлы по очереди, каждый — в своей вкладке.</summary>
        public async void OpenFiles(IEnumerable<string> files)
        {
            try { await OpenFilesAsync(files); } catch { }
        }

        private async Task OpenFilesAsync(IEnumerable<string> files)
        {
            foreach (var f in (files ?? Enumerable.Empty<string>()).Distinct(StringComparer.OrdinalIgnoreCase).Take(50).ToList())
                await OpenFileAsync(f);
        }

        public async void OpenFile(string path)
        {
            try { await OpenFileAsync(path); } catch { }
        }

        public async Task OpenFileAsync(string path)
        {
            if (string.IsNullOrEmpty(path)) return;
            try { path = Path.GetFullPath(path); } catch { }
            await _openLock.WaitAsync();
            try
            {
                // уже открыт — просто переходим на его вкладку
                var existing = _tabs.FirstOrDefault(t => string.Equals(t.Path, path, StringComparison.OrdinalIgnoreCase));
                if (existing != null) { ActivateTab(existing); return; }
                await OpenCoreAsync(path);
            }
            finally { _openLock.Release(); }
        }

        private async Task OpenCoreAsync(string path)
        {
            if (!File.Exists(path)) { MessageBox.Show(this, "Файл не найден:\n" + path, "DocuNova", MessageBoxButton.OK, MessageBoxImage.Warning); return; }

            ShowLoading("Открытие «" + Path.GetFileName(path) + "»…");
            SharedFile file = null;
            byte[] data;
            try
            {
                (file, data) = await Task.Run(() =>
                {
                    // файл остаётся открытым только для чтения: для PDF данные читаются с диска по мере надобности
                    var f = SharedFile.TryOpen(path);
                    try { return (f, f != null ? f.ReadAll() : SafeIO.ReadFile(path)); }
                    catch { f?.Dispose(); throw; }
                });
            }
            catch (Exception ex) { HideLoading(); ShowError("Не удалось прочитать файл", ex); return; }

            var rs = S.Reflow.Clone();
            rs.Light = false;
            string password = null;
            DocumentBase doc = null;
            bool isPdf = DocumentLoader.Detect(data, Path.GetExtension(path)) == "pdf";
            bool fileOwnedByDoc = false;
            try
            {
                while (true)
                {
                    try
                    {
                        if (isPdf)
                        {
                            var d = data; var f = file; var pw = password;
                            doc = await Task.Run(() => DocumentLoader.Load(path, d, rs, pw, f));
                        }
                        else
                        {
                            await Dispatcher.Yield(DispatcherPriority.Background);
                            doc = DocumentLoader.Load(path, data, rs, password);
                        }
                        break;
                    }
                    catch (PasswordRequiredException ex)
                    {
                        HideLoading();
                        password = PasswordDialog.Ask(this, Path.GetFileName(path), ex.WrongPassword);
                        if (password == null) return;
                        ShowLoading("Расшифровка…");
                    }
                    catch (Exception ex)
                    {
                        HideLoading();
                        ShowError("Документ не удалось открыть", ex);
                        return;
                    }
                }
                fileOwnedByDoc = isPdf && file != null;
            }
            finally
            {
                if (!fileOwnedByDoc) file?.Dispose();
                data = null; // копия файла больше не нужна — память освобождается
            }

            var tab = CreateTab(doc, path);
            // в параллельном режиме новый документ занимает новую панель (или заменяет активную, если места нет)
            ActivateTab(tab, addPane: true);
            HideLoading();
            S.AddRecent(path);
            S.Save();
            MemoryTrim.Schedule();

            var warn = doc.Security.Where(f => f.Severity == Severity.Danger || f.Severity == Severity.Warning).ToList();
            if (warn.Count > 0 && S.WarnInternetFiles)
            {
                var top = warn.First();
                ShowBanner($"«{tab.FileName}»: обнаружено и заблокировано: {top.Title}" + (warn.Count > 1 ? $" (и ещё {warn.Count - 1})" : "") + ". Документ показан в защищённом режиме. Подробности — кнопка щита внизу.", true);
            }
            else if (doc.Notices.Count > 0) ShowBanner(doc.Notices[0], false);
        }

        // ======================= Вкладки =======================

        private DocTab CreateTab(DocumentBase doc, string path)
        {
            var tab = new DocTab { Doc = doc, Path = path };
            var v = tab.Viewer;
            ApplyViewSettings(v, true);
            v.NewAnnotation = NewAnnotationStyle;
            v.AskText = (title, initial) => InputDialog.Ask(this, title, "Введите текст. Ctrl+Enter — готово.", initial, true);
            v.ContextMenu = BuildPageMenu();
            v.CurrentPageChanged += i => { if (tab == _active) OnCurrentPageChanged(i); UpdatePaneTitle(tab); };
            v.ZoomChanged += () => { if (tab == _active) UpdateZoomText(); };
            v.AnnotationsChanged += () => { UpdateTabHeader(tab); if (tab == _active) OnAnnotationsChanged(); };
            v.StatusMessage += m => StatusText.Text = m;
            v.Scrolled += () => OnViewerScrolled(tab);

            BuildTabHeader(tab);
            BuildPane(tab);
            _tabs.Add(tab);
            TabsPanel.Children.Add(tab.Header);
            // пока панель не на экране, страницы не рисуются; LayoutPanes покажет её и подгонит масштаб
            v.Suspend();
            v.SetDocument(doc);
            UpdateTabHeader(tab);
            UpdatePaneTitle(tab);
            return tab;
        }

        private void BuildTabHeader(DocTab tab)
        {
            var text = new TextBlock { Text = tab.FileName, MaxWidth = 220, TextTrimming = TextTrimming.CharacterEllipsis, VerticalAlignment = VerticalAlignment.Center, FontSize = 12.5 };
            var dot = new TextBlock { Text = "●", FontSize = 9, Margin = new Thickness(0, 0, 6, 0), VerticalAlignment = VerticalAlignment.Center, Visibility = Visibility.Collapsed, ToolTip = "Есть несохранённые пометки или изменения страниц" };
            dot.SetResourceReference(TextBlock.ForegroundProperty, "Accent2Brush");
            var close = new Button { Content = "", Width = 20, Height = 20, FontSize = 9, Margin = new Thickness(8, 0, 0, 0), Padding = new Thickness(0), Focusable = false, ToolTip = "Закрыть вкладку (Ctrl+W, средняя кнопка мыши)" };
            close.SetResourceReference(StyleProperty, "ToolBtn");
            close.Click += (s, e) => CloseTab(tab);
            var dp = new DockPanel { LastChildFill = true };
            DockPanel.SetDock(close, Dock.Right);
            dp.Children.Add(close);
            var icon = new TextBlock { Text = "", FontSize = 12, Margin = new Thickness(0, 0, 6, 0), VerticalAlignment = VerticalAlignment.Center };
            icon.SetResourceReference(TextBlock.FontFamilyProperty, "IconFont");
            DockPanel.SetDock(icon, Dock.Left);
            DockPanel.SetDock(dot, Dock.Left);
            dp.Children.Add(icon);
            dp.Children.Add(dot);
            dp.Children.Add(text);
            var header = new Border
            {
                Child = dp,
                Padding = new Thickness(10, 5, 4, 5),
                Margin = new Thickness(0, 0, 3, 0),
                BorderThickness = new Thickness(1, 1, 1, 2),
                CornerRadius = new CornerRadius(7, 7, 0, 0),
                Cursor = Cursors.Hand,
                ToolTip = tab.Path + "\n\nCtrl+щелчок — показать рядом (параллельный просмотр)",
                SnapsToDevicePixels = true
            };
            header.MouseLeftButtonDown += (s, e) =>
            {
                if ((Keyboard.Modifiers & ModifierKeys.Control) != 0) ToggleInSplit(tab);
                else SelectTabFromStrip(tab);
                e.Handled = true;
            };
            header.MouseDown += (s, e) =>
            {
                if (e.ChangedButton == MouseButton.Middle) { CloseTab(tab); e.Handled = true; }
            };
            header.MouseEnter += (s, e) => StyleTabHeader(tab, true);
            header.MouseLeave += (s, e) => StyleTabHeader(tab, false);
            header.ContextMenuOpening += (s, e) => header.ContextMenu = BuildTabMenu(tab);
            header.ContextMenu = new ContextMenu();
            tab.Header = header;
            tab.HeaderText = text;
            tab.HeaderDot = dot;
            StyleTabHeader(tab, false);
        }

        private void StyleTabHeader(DocTab tab, bool hover)
        {
            if (tab.Header == null) return;
            bool active = tab == _active;
            bool shown = _parallel && _split.Contains(tab);
            var h = tab.Header;
            if (active)
            {
                h.SetResourceReference(Border.BackgroundProperty, "PanelSolidBrush");
                h.SetResourceReference(Border.BorderBrushProperty, "Accent1Brush");
                tab.HeaderText.SetResourceReference(TextBlock.ForegroundProperty, "Accent1Brush");
                tab.HeaderText.FontWeight = FontWeights.SemiBold;
            }
            else
            {
                h.SetResourceReference(Border.BackgroundProperty, hover ? "HoverBrush" : "ButtonBgBrush");
                if (shown) h.SetResourceReference(Border.BorderBrushProperty, "Accent2Brush");
                else h.SetResourceReference(Border.BorderBrushProperty, "PanelBorderBrush");
                tab.HeaderText.SetResourceReference(TextBlock.ForegroundProperty, hover ? "FgBrush" : "SubFgBrush");
                tab.HeaderText.FontWeight = FontWeights.Normal;
            }
        }

        private void UpdateTabHeader(DocTab tab)
        {
            if (tab?.HeaderDot == null) return;
            tab.HeaderDot.Visibility = tab.Doc != null && tab.Viewer.Modified ? Visibility.Visible : Visibility.Collapsed;
        }

        private void RestyleAllTabs()
        {
            foreach (var t in _tabs) StyleTabHeader(t, t.Header != null && t.Header.IsMouseOver);
        }

        private ContextMenu BuildTabMenu(DocTab tab)
        {
            var m = new ContextMenu();
            void Add(string icon, string text, Action a, bool enabled = true)
            {
                var mi = new MenuItem { Header = text, IsEnabled = enabled, Icon = new TextBlock { Text = icon, FontFamily = (FontFamily)FindResource("IconFont") } };
                mi.Click += (s, e) => a();
                m.Items.Add(mi);
            }
            bool inSplit = _parallel && _split.Contains(tab);
            if (!inSplit)
                Add("", "Показать рядом (параллельный просмотр)", () => AddToSplit(tab), _tabs.Count > 1 && (!_parallel || _split.Count < MaxPanes));
            else
                Add("", "Убрать из параллельного просмотра", () => RemoveFromSplit(tab));
            Add("", "Показать рядом все вкладки", ShowAllSideBySide, _tabs.Count > 1);
            m.Items.Add(new Separator());
            Add("", "Копировать путь к файлу", () =>
            {
                try { Clipboard.SetText(tab.Path ?? ""); StatusText.Text = "Путь скопирован."; } catch { }
            });
            Add("", "Показать в папке", () => ShellIntegration.ShowInExplorer(tab.Path));
            m.Items.Add(new Separator());
            Add("", "Закрыть", () => CloseTab(tab));
            Add("", "Закрыть другие вкладки", () => { foreach (var t in _tabs.Where(x => x != tab).ToList()) if (!CloseTab(t)) break; }, _tabs.Count > 1);
            Add("", "Закрыть вкладки справа", () =>
            {
                int i = _tabs.IndexOf(tab);
                foreach (var t in _tabs.Skip(i + 1).ToList()) if (!CloseTab(t)) break;
            }, _tabs.IndexOf(tab) < _tabs.Count - 1);
            return m;
        }

        private void TabScroll_PreviewMouseWheel(object sender, MouseWheelEventArgs e)
        {
            TabScroll.ScrollToHorizontalOffset(TabScroll.HorizontalOffset - e.Delta / 2.0);
            e.Handled = true;
        }

        /// <summary>Щелчок по вкладке. В параллельном режиме вкладка, которой нет на экране, заменяет активную панель.</summary>
        private void SelectTabFromStrip(DocTab tab) => ActivateTab(tab);

        private List<DocTab> VisibleTabs()
        {
            if (_parallel) return _split.Where(t => _tabs.Contains(t)).ToList();
            return _active != null ? new List<DocTab> { _active } : new List<DocTab>();
        }

        /// <summary>Делает вкладку активной: панели инструментов, боковая панель и строка состояния переключаются на неё.</summary>
        /// <param name="addPane">В параллельном режиме: добавить новую панель (если есть место), а не заменить активную.</param>
        private void ActivateTab(DocTab tab, bool addPane = false)
        {
            if (tab == null || !_tabs.Contains(tab)) return;
            bool wasVisible = VisibleTabs().Contains(tab);
            if (_parallel && !_split.Contains(tab))
            {
                int i = _split.IndexOf(_active);
                if (addPane && _split.Count < MaxPanes) _split.Add(tab);
                else if (i >= 0) _split[i] = tab;
                else if (_split.Count < MaxPanes) _split.Add(tab);
                else _split[_split.Count - 1] = tab;
            }
            bool changed = tab != _active;
            if (changed)
            {
                _searchGen++; // текущий поиск относится к прежнему документу
                _active = tab;
            }
            // перестраиваем панели только если документа не было на экране:
            // щелчок внутри уже показанной панели не должен «пересобирать» окно
            if (!wasVisible) LayoutPanes();
            else UpdatePaneChrome();
            if (changed || !wasVisible) ApplyActiveToUi();
            try { tab.Header?.BringIntoView(); } catch { }
        }

        /// <summary>Переносит состояние активного документа в общие элементы окна.</summary>
        private void ApplyActiveToUi()
        {
            var tab = _active;
            bool has = tab?.Doc != null;
            Welcome.Visibility = has ? Visibility.Collapsed : Visibility.Visible;
            PanesGrid.Visibility = has ? Visibility.Visible : Visibility.Collapsed;
            TabStripBar.Visibility = _tabs.Count > 0 ? Visibility.Visible : Visibility.Collapsed;
            if (has)
            {
                var doc = tab.Doc;
                TitleText.Text = tab.FileName + (string.IsNullOrWhiteSpace(doc.Title) ? "" : "  —  " + doc.Title);
                Title = tab.FileName + " — DocuNova";
                FormatText.Text = doc.FormatName;
                TwoPageBtn.IsChecked = tab.Viewer.TwoPage;
                _viewer.Tool = _tool;
                SearchResults.ItemsSource = tab.HitView;
                SearchStatus.Text = tab.SearchStatus ?? "";
                SearchBox.Tag = tab.SearchKey;
            }
            else
            {
                TitleText.Text = "";
                Title = "DocuNova";
                FormatText.Text = "";
                PageBox.Text = "";
                PageCountText.Text = "/ 0";
                SearchResults.ItemsSource = null;
                SearchStatus.Text = "";
                SearchBox.Tag = null;
                RefreshRecent();
            }
            RebuildSidebar();
            UpdateSecurityBadge();
            UpdateDocButtons();
            UpdateZoomText();
            RestyleAllTabs();
            UpdateParallelUi();
            if (has)
            {
                OnCurrentPageChanged(tab.Viewer.CurrentPage);
                var v = tab.Viewer;
                Dispatcher.BeginInvoke(new Action(() => { if (_active?.Viewer == v && !IsKeyboardFocusWithinTextBox()) v.Scroll.Focus(); }), DispatcherPriority.Input);
            }
        }

        private bool IsKeyboardFocusWithinTextBox() => Keyboard.FocusedElement is TextBox || Keyboard.FocusedElement is PasswordBox;

        /// <summary>Закрывает вкладку. false — пользователь отменил закрытие.</summary>
        private bool CloseTab(DocTab tab)
        {
            if (tab == null || !_tabs.Contains(tab)) return true;
            if (!ConfirmDiscard(tab)) return false;
            int idx = _tabs.IndexOf(tab);
            bool wasActive = tab == _active;
            _tabs.Remove(tab);
            _split.Remove(tab);
            TabsPanel.Children.Remove(tab.Header);
            if (_parallel && _split.Count < 2) { _parallel = false; _split.Clear(); }
            DisposeTab(tab);

            if (wasActive || _active == null)
            {
                DocTab next = null;
                if (_parallel && _split.Count > 0) next = _split[0];
                else if (_tabs.Count > 0) next = _tabs[Math.Min(idx, _tabs.Count - 1)];
                _searchGen++;
                _active = next;
                LayoutPanes();
                ApplyActiveToUi();
            }
            else
            {
                LayoutPanes();
                RestyleAllTabs();
                UpdateParallelUi();
            }
            MemoryTrim.Schedule();
            return true;
        }

        private void DisposeTab(DocTab tab)
        {
            try
            {
                if (tab.Pane != null && tab.Pane.Parent is Panel p) p.Children.Remove(tab.Pane);
                tab.Viewer.SetDocument(null);
                tab.Viewer.ContextMenu = null;
                tab.Doc?.Dispose();
            }
            catch { }
            tab.Doc = null;
            tab.Hits = new List<SearchHit>();
            tab.HitView = null;
        }

        private void NextTab(int dir)
        {
            if (_tabs.Count < 2) return;
            int i = _active != null ? _tabs.IndexOf(_active) : 0;
            i = ((i + dir) % _tabs.Count + _tabs.Count) % _tabs.Count;
            SelectTabFromStrip(_tabs[i]);
        }

        private void UpdateTabSpacer()
        {
            // вкладки располагаются над областью документа, правее боковой панели
            TabSidebarSpacer.Width = Sidebar.Visibility == Visibility.Visible && !_fullscreen ? Math.Max(0, SidebarCol.ActualWidth + 6) : 0;
        }

        // ======================= Панели и параллельный просмотр =======================

        private void BuildPane(DocTab tab)
        {
            var title = new TextBlock { TextTrimming = TextTrimming.CharacterEllipsis, VerticalAlignment = VerticalAlignment.Center, FontSize = 12.5 };
            var close = new Button { Content = "", Width = 22, Height = 22, FontSize = 9, Padding = new Thickness(0), Focusable = false, ToolTip = "Убрать из параллельного просмотра (вкладка останется открытой)" };
            close.SetResourceReference(StyleProperty, "ToolBtn");
            close.Click += (s, e) => RemoveFromSplit(tab);
            var hdp = new DockPanel();
            DockPanel.SetDock(close, Dock.Right);
            hdp.Children.Add(close);
            hdp.Children.Add(title);
            var header = new Border { Child = hdp, Padding = new Thickness(10, 2, 4, 2), Visibility = Visibility.Collapsed };
            header.SetResourceReference(Border.BackgroundProperty, "PanelBrush");
            DockPanel.SetDock(header, Dock.Top);

            var dp = new DockPanel { LastChildFill = true };
            dp.Children.Add(header);
            dp.Children.Add(tab.Viewer);

            var pane = new Border { Child = dp, BorderThickness = new Thickness(0), CornerRadius = new CornerRadius(6), ClipToBounds = true, Margin = new Thickness(0) };
            pane.BorderBrush = Brushes.Transparent;
            // щелчок или прокрутка колесом делает панель активной (без перестройки окна)
            pane.PreviewMouseDown += (s, e) => { if (_active != tab) ActivateTab(tab); };
            pane.PreviewMouseWheel += (s, e) => { if (_active != tab && _parallel) ActivateTab(tab); };
            tab.Pane = pane;
            tab.PaneHeader = header;
            tab.PaneTitle = title;
        }

        private void UpdatePaneTitle(DocTab tab)
        {
            if (tab?.PaneTitle == null || tab.Doc == null) return;
            tab.PaneTitle.Text = $"{tab.FileName}   ·   стр. {tab.Viewer.CurrentPage + 1} из {tab.Viewer.Pages.Count}";
        }

        /// <summary>Размещает видимые документы в области просмотра; скрытые вкладки освобождают память.</summary>
        private void LayoutPanes()
        {
            var visible = VisibleTabs();
            foreach (var t in _tabs)
                if (!visible.Contains(t) && !t.Viewer.Suspended)
                {
                    t.Viewer.Suspend();
                    try { t.Doc?.TrimMemory(); } catch { }
                }

            PanesGrid.Children.Clear();
            PanesGrid.RowDefinitions.Clear();
            PanesGrid.ColumnDefinitions.Clear();
            int n = visible.Count;
            bool multi = n > 1;
            string layout = S.ParallelLayout ?? "columns";

            if (n == 1)
            {
                PanesGrid.Children.Add(visible[0].Pane);
            }
            else if (n > 1 && layout == "grid")
            {
                int cols = (int)Math.Ceiling(Math.Sqrt(n));
                int rows = (int)Math.Ceiling(n / (double)cols);
                for (int c = 0; c < cols; c++) PanesGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
                for (int r = 0; r < rows; r++) PanesGrid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
                for (int i = 0; i < n; i++)
                {
                    var pane = visible[i].Pane;
                    pane.Margin = new Thickness(2);
                    Grid.SetColumn(pane, i % cols); Grid.SetRow(pane, i / cols);
                    Grid.SetColumnSpan(pane, 1); Grid.SetRowSpan(pane, 1);
                    PanesGrid.Children.Add(pane);
                }
            }
            else if (n > 1)
            {
                bool cols = layout != "rows";
                for (int i = 0; i < n; i++)
                {
                    if (i > 0)
                    {
                        var sp = new GridSplitter
                        {
                            Background = Brushes.Transparent,
                            ResizeBehavior = GridResizeBehavior.PreviousAndNext,
                            HorizontalAlignment = HorizontalAlignment.Stretch,
                            VerticalAlignment = VerticalAlignment.Stretch,
                            ShowsPreview = false
                        };
                        sp.ResizeDirection = cols ? GridResizeDirection.Columns : GridResizeDirection.Rows;
                        if (cols)
                        {
                            PanesGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(6) });
                            sp.Width = 6; sp.Cursor = Cursors.SizeWE;
                            Grid.SetColumn(sp, PanesGrid.ColumnDefinitions.Count - 1); Grid.SetRow(sp, 0);
                        }
                        else
                        {
                            PanesGrid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(6) });
                            sp.Height = 6; sp.Cursor = Cursors.SizeNS;
                            Grid.SetRow(sp, PanesGrid.RowDefinitions.Count - 1); Grid.SetColumn(sp, 0);
                        }
                        PanesGrid.Children.Add(sp);
                    }
                    var pane = visible[i].Pane;
                    pane.Margin = new Thickness(0);
                    Grid.SetColumnSpan(pane, 1); Grid.SetRowSpan(pane, 1);
                    if (cols)
                    {
                        PanesGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star), MinWidth = 160 });
                        Grid.SetColumn(pane, PanesGrid.ColumnDefinitions.Count - 1); Grid.SetRow(pane, 0);
                    }
                    else
                    {
                        PanesGrid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star), MinHeight = 120 });
                        Grid.SetRow(pane, PanesGrid.RowDefinitions.Count - 1); Grid.SetColumn(pane, 0);
                    }
                    PanesGrid.Children.Add(pane);
                }
            }
            if (n == 1)
            {
                var pane = visible[0].Pane;
                pane.Margin = new Thickness(0);
                Grid.SetColumn(pane, 0); Grid.SetRow(pane, 0);
            }

            foreach (var t in visible)
            {
                t.PaneHeader.Visibility = multi ? Visibility.Visible : Visibility.Collapsed;
                t.Viewer.Resume();
                UpdatePaneTitle(t);
            }
            UpdatePaneChrome();
            MemoryTrim.Schedule();
        }

        /// <summary>Подсветка активной панели в параллельном просмотре.</summary>
        private void UpdatePaneChrome()
        {
            bool multi = _parallel && VisibleTabs().Count > 1;
            foreach (var t in _tabs)
            {
                if (t.Pane == null) continue;
                bool act = t == _active;
                t.Pane.BorderThickness = new Thickness(multi ? 2 : 0);
                if (multi && act) t.Pane.SetResourceReference(Border.BorderBrushProperty, "Accent1Brush");
                else if (multi) t.Pane.SetResourceReference(Border.BorderBrushProperty, "PanelBorderBrush");
                else t.Pane.BorderBrush = Brushes.Transparent;
                if (t.PaneTitle != null)
                {
                    if (act) t.PaneTitle.SetResourceReference(TextBlock.ForegroundProperty, "Accent1Brush");
                    else t.PaneTitle.SetResourceReference(TextBlock.ForegroundProperty, "SubFgBrush");
                    t.PaneTitle.FontWeight = act ? FontWeights.SemiBold : FontWeights.Normal;
                }
            }
            RestyleAllTabs();
        }

        private void UpdateParallelUi()
        {
            ParallelBtn.IsChecked = _parallel;
            LayoutBtn.Visibility = _parallel ? Visibility.Visible : Visibility.Collapsed;
            SyncBtn.Visibility = _parallel ? Visibility.Visible : Visibility.Collapsed;
            TabStripBar.Visibility = _tabs.Count > 0 && !_fullscreen ? Visibility.Visible : Visibility.Collapsed;
            UpdateTabSpacer();
        }

        private async void Parallel_Click(object sender, RoutedEventArgs e)
        {
            if (_parallel) { StopParallel(); return; }
            if (_tabs.Count < 2)
            {
                ParallelBtn.IsChecked = false;
                ShowBanner("Параллельный просмотр: выберите документы, которые нужно показать рядом (можно несколько сразу).", false);
                var files = AskFiles();
                if (files.Count == 0) return;
                await OpenFilesAsync(files);
                if (_tabs.Count < 2) { ShowBanner("Для параллельного просмотра нужно открыть хотя бы два документа.", false); return; }
            }
            StartParallel();
        }

        private void StartParallel()
        {
            if (_tabs.Count < 2) { UpdateParallelUi(); return; }
            _split.Clear();
            if (_active != null) _split.Add(_active);
            // соседние вкладки — справа от активной, затем слева
            int ai = _active != null ? _tabs.IndexOf(_active) : 0;
            foreach (var t in _tabs.Skip(ai + 1).Concat(_tabs.Take(Math.Max(0, ai))))
            {
                if (_split.Count >= 2) break;
                if (!_split.Contains(t)) _split.Add(t);
            }
            _parallel = true;
            LayoutPanes();
            UpdateParallelUi();
            RestyleAllTabs();
            StatusText.Text = "Параллельный просмотр. Ctrl+щелчок по вкладке — добавить документ, щелчок по панели — сделать её активной, F6 — следующая панель.";
        }

        private void ShowAllSideBySide()
        {
            if (_tabs.Count < 2) return;
            _split.Clear();
            if (_active != null) _split.Add(_active);
            foreach (var t in _tabs) { if (_split.Count >= MaxPanes) break; if (!_split.Contains(t)) _split.Add(t); }
            _parallel = true;
            if (_split.Count > 3 && (S.ParallelLayout ?? "columns") == "columns") S.ParallelLayout = "grid";
            LayoutPanes();
            UpdateParallelUi();
            if (_tabs.Count > MaxPanes) ShowBanner($"Одновременно можно показать до {MaxPanes} документов.", false);
        }

        private void StopParallel()
        {
            _parallel = false;
            _split.Clear();
            LayoutPanes();
            UpdateParallelUi();
            RestyleAllTabs();
        }

        private void AddToSplit(DocTab tab)
        {
            if (tab == null || _tabs.Count < 2) return;
            if (!_parallel)
            {
                _split.Clear();
                if (_active != null && _active != tab) _split.Add(_active);
                _split.Add(tab);
                if (_split.Count < 2)
                {
                    var other = _tabs.FirstOrDefault(t => t != tab);
                    if (other != null) _split.Insert(0, other);
                }
                _parallel = true;
            }
            else if (!_split.Contains(tab))
            {
                if (_split.Count >= MaxPanes) { ShowBanner($"Одновременно можно показать до {MaxPanes} документов.", false); return; }
                _split.Add(tab);
            }
            _searchGen++;
            _active = tab;
            LayoutPanes();
            ApplyActiveToUi();
        }

        private void RemoveFromSplit(DocTab tab)
        {
            if (!_parallel || !_split.Contains(tab)) return;
            _split.Remove(tab);
            if (_split.Count < 2)
            {
                var keep = _split.FirstOrDefault() ?? _active;
                _parallel = false;
                _split.Clear();
                _active = null;
                if (keep != null && _tabs.Contains(keep)) ActivateTab(keep);
                else if (_tabs.Count > 0) ActivateTab(_tabs[0]);
                UpdateParallelUi();
                return;
            }
            if (_active == tab)
            {
                _searchGen++;
                _active = _split[0];
                LayoutPanes();
                ApplyActiveToUi();
            }
            else
            {
                LayoutPanes();
                RestyleAllTabs();
            }
        }

        private void ToggleInSplit(DocTab tab)
        {
            if (_parallel && _split.Contains(tab))
            {
                if (_split.Count > 2 || tab != _active) RemoveFromSplit(tab);
                else ActivateTab(tab);
            }
            else AddToSplit(tab);
        }

        private void Layout_Click(object sender, RoutedEventArgs e)
        {
            var m = new ContextMenu();
            void Add(string code, string icon, string text)
            {
                var mi = new MenuItem
                {
                    Header = text,
                    IsCheckable = true,
                    IsChecked = (S.ParallelLayout ?? "columns") == code,
                    Icon = new TextBlock { Text = icon, FontFamily = (FontFamily)FindResource("IconFont") }
                };
                mi.Click += (s, a) => { S.ParallelLayout = code; LayoutPanes(); };
                m.Items.Add(mi);
            }
            Add("columns", "", "Рядом (слева направо)");
            Add("rows", "", "Друг под другом");
            Add("grid", "", "Сеткой");
            m.Items.Add(new Separator());
            var all = new MenuItem { Header = "Показать все открытые документы", IsEnabled = _tabs.Count > _split.Count };
            all.Click += (s, a) => ShowAllSideBySide();
            m.Items.Add(all);
            var stop = new MenuItem { Header = "Выйти из параллельного просмотра" };
            stop.Click += (s, a) => StopParallel();
            m.Items.Add(stop);
            m.PlacementTarget = sender as UIElement; m.Placement = PlacementMode.Bottom; m.IsOpen = true;
        }

        private void Sync_Click(object sender, RoutedEventArgs e)
        {
            S.SyncScroll = SyncBtn.IsChecked == true;
            StatusText.Text = S.SyncScroll ? "Синхронная прокрутка включена: остальные панели следуют за активной." : "Синхронная прокрутка выключена.";
            if (S.SyncScroll && _active != null) OnViewerScrolled(_active);
        }

        private void OnViewerScrolled(DocTab tab)
        {
            if (!_parallel || !S.SyncScroll || _syncing || tab != _active) return;
            var (page, frac) = tab.Viewer.GetPosition();
            _syncing = true;
            try
            {
                foreach (var t in VisibleTabs())
                    if (t != tab && t.Doc != null) t.Viewer.SetPosition(page, frac);
            }
            finally { _syncing = false; }
        }

        private void FocusNextPane()
        {
            var vis = VisibleTabs();
            if (vis.Count < 2) return;
            int i = vis.IndexOf(_active);
            ActivateTab(vis[(i + 1) % vis.Count]);
        }

        // ======================= Состояние окна =======================

        /// <summary>Спрашивает о несохранённых пометках во вкладке. false — отменить действие.</summary>
        private bool ConfirmDiscard(DocTab tab)
        {
            if (tab?.Doc == null || !tab.Viewer.Modified) return true;
            ActivateTab(tab);
            var r = MessageBox.Show(this, $"В документе «{tab.FileName}» есть несохранённые пометки или изменения страниц.\n\nСохранить их в новый PDF?",
                "DocuNova", MessageBoxButton.YesNoCancel, MessageBoxImage.Question);
            if (r == MessageBoxResult.Cancel) return false;
            if (r == MessageBoxResult.Yes) return SavePdf(tab, tab.Viewer.Pages);
            return true;
        }

        private void ShowLoading(string text) { LoadingText.Text = text; Loading.Visibility = Visibility.Visible; }
        private void HideLoading() => Loading.Visibility = Visibility.Collapsed;

        private void ShowError(string title, Exception ex)
        {
            string msg = ex is UnsupportedFormatException ? ex.Message : ex.Message + "\n\nФайл может быть повреждён или иметь неподдерживаемый формат.";
            MessageBox.Show(this, title + ".\n\n" + msg, "DocuNova", MessageBoxButton.OK, MessageBoxImage.Warning);
        }

        private void ShowBanner(string text, bool danger)
        {
            BannerText.Text = text;
            BannerIcon.Text = danger ? "" : "";
            Banner.Visibility = Visibility.Visible;
            _bannerTimer.Stop(); _bannerTimer.Start();
        }

        private void BannerClose_Click(object sender, RoutedEventArgs e) => Banner.Visibility = Visibility.Collapsed;

        private void RefreshRecent()
        {
            RecentList.Items.Clear();
            // сетевые пути не проверяем: недоступный сервер «подвесил» бы окно на несколько секунд
            var items = S.RememberRecent ? S.Recent.Where(p => p.StartsWith(@"\\") || File.Exists(p)).Take(8).ToList() : new List<string>();
            RecentTitle.Visibility = items.Count > 0 ? Visibility.Visible : Visibility.Collapsed;
            foreach (var p in items)
            {
                var b = new Button { HorizontalContentAlignment = HorizontalAlignment.Left, Margin = new Thickness(0, 2, 0, 2), ToolTip = p };
                b.SetResourceReference(StyleProperty, "GhostBtn");
                var sp = new StackPanel();
                sp.Children.Add(new TextBlock { Text = Path.GetFileName(p), FontWeight = FontWeights.SemiBold, TextTrimming = TextTrimming.CharacterEllipsis });
                var dir = new TextBlock { Text = Path.GetDirectoryName(p), FontSize = 11.5, TextTrimming = TextTrimming.CharacterEllipsis };
                dir.SetResourceReference(TextBlock.ForegroundProperty, "SubFgBrush");
                sp.Children.Add(dir);
                b.Content = sp;
                var path = p;
                b.Click += (s, e) => OpenFile(path);
                RecentList.Items.Add(b);
            }
        }

        private void UpdateDocButtons()
        {
            bool has = _doc != null;
            SaveBtn.IsEnabled = ExportBtn.IsEnabled = PrintBtn.IsEnabled = has;
            UndoBtn.IsEnabled = has && _viewer.CanUndo;
            RedoBtn.IsEnabled = has && _viewer.CanRedo;
            ReadSettingsBtn.IsEnabled = true;
            UpdateTabHeader(_active);
        }

        private void UpdateSecurityBadge()
        {
            if (_doc == null) { SecurityBtn.Visibility = Visibility.Collapsed; return; }
            int danger = _doc.Security.Count(f => f.Severity == Severity.Danger);
            int warn = _doc.Security.Count(f => f.Severity == Severity.Warning);
            SecurityBtn.Visibility = Visibility.Visible;
            if (danger > 0)
            {
                SecurityIcon.Text = ""; SecurityText.Text = $"Заблокировано угроз: {danger}";
                SecurityIcon.Foreground = new SolidColorBrush(Color.FromRgb(255, 70, 90));
            }
            else if (warn > 0)
            {
                SecurityIcon.Text = ""; SecurityText.Text = $"Защищено · предупреждений: {warn}";
                SecurityIcon.Foreground = new SolidColorBrush(Color.FromRgb(255, 190, 40));
            }
            else
            {
                SecurityIcon.Text = ""; SecurityText.Text = "Защищено · угроз нет";
                SecurityIcon.Foreground = new SolidColorBrush(Color.FromRgb(60, 230, 140));
            }
        }

        private void SecurityBtn_Click(object sender, RoutedEventArgs e) => ShowProperties(3);

        // ======================= Боковая панель =======================

        private void Sidebar_Click(object sender, RoutedEventArgs e) => SetSidebar(Sidebar.Visibility != Visibility.Visible);

        private void SetSidebar(bool show)
        {
            if (!show && Sidebar.Visibility == Visibility.Visible && SidebarCol.ActualWidth > 100) _sidebarWidth = SidebarCol.ActualWidth;
            Sidebar.Visibility = show ? Visibility.Visible : Visibility.Collapsed;
            SideSplitter.Visibility = Sidebar.Visibility;
            SidebarCol.Width = show ? new GridLength(Math.Max(200, _sidebarWidth)) : new GridLength(0);
            S.ShowSidebar = show;
            Dispatcher.BeginInvoke(new Action(UpdateTabSpacer), DispatcherPriority.Loaded);
        }

        private void SideTab_Checked(object sender, RoutedEventArgs e)
        {
            if (ThumbList == null || TocList == null) return;
            ThumbList.Visibility = TabThumbs.IsChecked == true ? Visibility.Visible : Visibility.Collapsed;
            bool toc = TabToc.IsChecked == true;
            TocList.Visibility = toc && TocList.Items.Count > 0 ? Visibility.Visible : Visibility.Collapsed;
            TocEmpty.Visibility = toc && TocList.Items.Count == 0 ? Visibility.Visible : Visibility.Collapsed;
            BookmarkPanel.Visibility = TabBookmarks.IsChecked == true ? Visibility.Visible : Visibility.Collapsed;
            SearchPanel.Visibility = TabSearch.IsChecked == true ? Visibility.Visible : Visibility.Collapsed;
            AnnPanel.Visibility = TabAnns.IsChecked == true ? Visibility.Visible : Visibility.Collapsed;
            if (TabSearch.IsChecked == true && sender != null) Dispatcher.BeginInvoke(new Action(() => { SearchBox.Focus(); SearchBox.SelectAll(); }), DispatcherPriority.Input);
        }

        private void RebuildSidebar()
        {
            RebuildThumbs();
            RebuildToc();
            RebuildBookmarks();
            RebuildAnnList();
        }

        private void RebuildThumbs()
        {
            foreach (var t in _thumbs) { t.Visible = false; t.Thumb = null; }
            _thumbs.Clear();
            if (_doc == null) return;
            var v = _viewer;
            for (int i = 0; i < v.Pages.Count; i++)
            {
                var r = v.Pages[i];
                var s = _doc.GetPageSize(r.Doc);
                if (r.Rotation % 180 != 0) s = new Size(s.Height, s.Width);
                double k = Math.Min(150 / s.Width, 190 / s.Height);
                _thumbs.Add(new ThumbItem { Owner = v, Ref = r, Index = i, Label = (i + 1).ToString(), BoxWidth = Math.Max(20, s.Width * k), BoxHeight = Math.Max(20, s.Height * k) });
            }
        }

        private async void ThumbItem_Loaded(object sender, RoutedEventArgs e)
        {
            if (!(sender is ListBoxItem li) || !(li.DataContext is ThumbItem item)) return;
            item.Visible = true;
            if (item.Thumb != null || item.Loading) return;
            item.Loading = true;
            try
            {
                await Task.Delay(60);
                var owner = item.Owner;
                if (!item.Visible || owner == null || owner.Document == null) return;
                var bmp = await owner.RenderThumbAsync(item.Ref, 160);
                if (bmp != null && item.Ref.Rotation != 0)
                {
                    var tb = new TransformedBitmap(bmp, new RotateTransform(item.Ref.Rotation));
                    tb.Freeze();
                    bmp = tb;
                }
                if (item.Visible && owner.Document != null) item.Thumb = DocViewer.ApplyMode(bmp, owner.PageMode);
            }
            catch { }
            finally { item.Loading = false; }
        }

        private void ThumbItem_Unloaded(object sender, RoutedEventArgs e)
        {
            if (sender is ListBoxItem li && li.DataContext is ThumbItem item)
            {
                item.Visible = false;
                item.Thumb = null; // освобождаем память
            }
        }

        private bool _syncingThumbs;
        private void ThumbList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (_syncingThumbs) return;
            if (ThumbList.SelectedItem is ThumbItem t && t.Owner == _viewer) _viewer.GoTo(t.Index);
        }

        private void RebuildToc()
        {
            var rows = new List<TocRow>();
            if (_doc != null)
            {
                // индекс страницы документа → позиция в просмотре (быстрый поиск вместо перебора)
                var map = new Dictionary<int, int>();
                for (int i = 0; i < _viewer.Pages.Count; i++)
                    if (!map.ContainsKey(_viewer.Pages[i].Doc)) map[_viewer.Pages[i].Doc] = i;
                Flatten(_doc.Toc, rows, 0, map);
            }
            TocList.ItemsSource = rows;
            SideTab_Checked(null, null);
        }

        private void Flatten(List<TocItem> items, List<TocRow> rows, int depth, Dictionary<int, int> map)
        {
            foreach (var t in items)
            {
                if (rows.Count > 5000) return;
                int view = t.PageIndex >= 0 && map.TryGetValue(t.PageIndex, out var vi) ? vi : -1;
                rows.Add(new TocRow
                {
                    Title = t.Title,
                    View = view,
                    PageLabel = view >= 0 ? (view + 1).ToString() : "",
                    Indent = new Thickness(depth * 14, 0, 0, 0),
                    Weight = depth == 0 ? FontWeights.SemiBold : FontWeights.Normal
                });
                Flatten(t.Children, rows, depth + 1, map);
            }
        }

        private void TocList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (TocList.SelectedItem is TocRow r && r.View >= 0) _viewer.GoTo(r.View);
        }

        private void RebuildBookmarks()
        {
            BookmarkList.Items.Clear();
            if (_doc == null) return;
            for (int i = 0; i < _viewer.Pages.Count; i++)
                if (_viewer.Pages[i].Bookmarked)
                {
                    var text = "";
                    try { text = _doc.GetPageText(_viewer.Pages[i].Doc); } catch { }
                    text = FlowSinkPreview(text);
                    BookmarkList.Items.Add(new BookmarkRow { Page = _viewer.Pages[i], View = i, Text = $"★ Стр. {i + 1}" + (text.Length > 0 ? " — " + text : "") });
                }
        }

        private static string FlowSinkPreview(string t)
        {
            t = (t ?? "").Replace('\n', ' ').Trim();
            return t.Length > 50 ? t.Substring(0, 50) + "…" : t;
        }

        private void BookmarkList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (BookmarkList.SelectedItem is BookmarkRow r)
            {
                int i = _viewer.Pages.IndexOf(r.Page);
                if (i >= 0) _viewer.GoTo(i);
            }
        }

        private void Bookmark_Click(object sender, RoutedEventArgs e)
        {
            if (_doc == null || _viewer.Pages.Count == 0) return;
            var p = _viewer.Pages[_viewer.CurrentPage];
            p.Bookmarked = !p.Bookmarked;
            var ti = _thumbs.FirstOrDefault(t => t.Ref == p);
            ti?.Notify(nameof(ThumbItem.BookmarkVisibility));
            RebuildBookmarks();
            StatusText.Text = p.Bookmarked ? $"Страница {_viewer.CurrentPage + 1} добавлена в закладки." : "Закладка удалена.";
        }

        private void RebuildAnnList()
        {
            AnnList.Items.Clear();
            if (_doc == null) return;
            for (int i = 0; i < _viewer.Pages.Count; i++)
                foreach (var a in _viewer.Pages[i].Anns)
                    AnnList.Items.Add(new AnnRow { Page = _viewer.Pages[i], Ann = a, View = i });
        }

        private void AnnList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (AnnList.SelectedItem is AnnRow r)
            {
                int i = _viewer.Pages.IndexOf(r.Page);
                if (i < 0) return;
                var b = r.Ann.Bounds;
                if (!b.IsEmpty) _viewer.ShowRect(i, b); else _viewer.GoTo(i);
            }
        }

        private void AnnDelete_Click(object sender, RoutedEventArgs e)
        {
            if (AnnList.SelectedItem is AnnRow r) _viewer.RemoveAnnotation(r.Page, r.Ann);
        }

        private void AnnClearPage_Click(object sender, RoutedEventArgs e)
        {
            if (_doc == null || _viewer.Pages.Count == 0) return;
            _viewer.ClearAnnotations(_viewer.Pages[_viewer.CurrentPage]);
        }

        private void OnAnnotationsChanged()
        {
            RebuildAnnList();
            UpdateDocButtons();
            if (_thumbs.Count != _viewer.Pages.Count) RebuildThumbs();
        }

        // ======================= Навигация =======================

        private void OnCurrentPageChanged(int i)
        {
            if (_doc == null) return;
            PageBox.Text = (i + 1).ToString();
            PageCountText.Text = "/ " + _viewer.Pages.Count;
            if (i >= 0 && i < _thumbs.Count)
            {
                _syncingThumbs = true;
                try
                {
                    ThumbList.SelectedIndex = i;
                    if (ThumbList.IsVisible) ThumbList.ScrollIntoView(_thumbs[i]);
                }
                finally { _syncingThumbs = false; }
            }
        }

        private void PageBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key != Key.Enter) return;
            if (_doc != null && int.TryParse(PageBox.Text.Trim(), out var n)) _viewer.GoTo(Math.Max(1, Math.Min(n, _viewer.Pages.Count)) - 1);
            _viewer.Scroll.Focus();
            e.Handled = true;
        }

        private void PrevPage_Click(object sender, RoutedEventArgs e) => _viewer.Prev();
        private void NextPage_Click(object sender, RoutedEventArgs e) => _viewer.Next();

        // ======================= Масштаб и вид =======================

        private void UpdateZoomText() => ZoomBtn.Content = Math.Round(_viewer.Zoom * 100) + " %";

        private void ZoomIn_Click(object sender, RoutedEventArgs e) => _viewer.SetZoom(NextZoom(_viewer.Zoom, true));
        private void ZoomOut_Click(object sender, RoutedEventArgs e) => _viewer.SetZoom(NextZoom(_viewer.Zoom, false));

        private static readonly double[] Steps = { 0.1, 0.25, 0.33, 0.5, 0.67, 0.75, 0.9, 1, 1.1, 1.25, 1.5, 1.75, 2, 2.5, 3, 4, 5, 6, 8 };
        private static double NextZoom(double z, bool up)
        {
            if (up) { foreach (var s in Steps) if (s > z + 0.01) return s; return 8; }
            for (int i = Steps.Length - 1; i >= 0; i--) if (Steps[i] < z - 0.01) return Steps[i];
            return 0.1;
        }

        private void ZoomBtn_Click(object sender, RoutedEventArgs e)
        {
            var m = new ContextMenu();
            foreach (var z in new[] { 0.5, 0.75, 1.0, 1.25, 1.5, 2.0, 3.0, 4.0 })
            {
                var zz = z;
                var mi = new MenuItem { Header = Math.Round(z * 100) + " %" };
                mi.Click += (s, a) => _viewer.SetZoom(zz);
                m.Items.Add(mi);
            }
            var fw = new MenuItem { Header = "По ширине" }; fw.Click += (s, a) => FitWidth_Click(null, null); m.Items.Add(fw);
            var fp = new MenuItem { Header = "Страница целиком" }; fp.Click += (s, a) => FitPage_Click(null, null); m.Items.Add(fp);
            m.PlacementTarget = ZoomBtn; m.Placement = PlacementMode.Bottom; m.IsOpen = true;
        }

        private void FitWidth_Click(object sender, RoutedEventArgs e) { _viewer.FitMode = "width"; S.FitMode = "width"; _viewer.ApplyFit(); }
        private void FitPage_Click(object sender, RoutedEventArgs e) { _viewer.FitMode = "page"; S.FitMode = "page"; _viewer.ApplyFit(); }

        private void RotateLeft_Click(object sender, RoutedEventArgs e) => Rotate(-90);
        private void RotateRight_Click(object sender, RoutedEventArgs e) => Rotate(90);
        private void Rotate(int d)
        {
            if (_doc == null) return;
            bool all = (Keyboard.Modifiers & ModifierKeys.Shift) != 0;
            _viewer.Rotate(d, all);
            RebuildThumbs();
            UpdateDocButtons();
            StatusText.Text = all ? "Все страницы повёрнуты." : $"Страница {_viewer.CurrentPage + 1} повёрнута. Shift — повернуть все.";
        }

        private void TwoPage_Click(object sender, RoutedEventArgs e)
        {
            S.TwoPage = TwoPageBtn.IsChecked == true;
            _viewer.TwoPage = S.TwoPage;
            if (_viewer.FitMode != "none") _viewer.ApplyFit();
        }

        private void PageMode_Click(object sender, RoutedEventArgs e)
        {
            var next = _viewer.PageMode == "normal" ? "night" : _viewer.PageMode == "night" ? "sepia" : "normal";
            S.PageMode = next;
            foreach (var v in AllViewers()) v.PageMode = next;
            foreach (var t in _thumbs) t.Thumb = null;
            RebuildThumbs();
            StatusText.Text = next == "night" ? "Ночной режим страниц." : next == "sepia" ? "Режим «Сепия»." : "Обычный режим страниц.";
        }

        private void FullScreen_Click(object sender, RoutedEventArgs e) => SetFullScreen(!_fullscreen);

        private void SetFullScreen(bool on)
        {
            if (on == _fullscreen) return;
            _fullscreen = on;
            var vis = on ? Visibility.Collapsed : Visibility.Visible;
            TitleBar.Visibility = vis; ToolbarBar.Visibility = vis; StatusBar.Visibility = vis;
            OptionsBar.Visibility = on ? Visibility.Collapsed : (IsAnnotationTool(_tool) ? Visibility.Visible : Visibility.Collapsed);
            Root.RowDefinitions[0].Height = on ? new GridLength(0) : new GridLength(40);
            Root.RowDefinitions[5].Height = on ? new GridLength(0) : new GridLength(32);
            if (on)
            {
                _stateBeforeFull = WindowState;
                if (Sidebar.Visibility == Visibility.Visible && SidebarCol.ActualWidth > 100) _sidebarWidth = SidebarCol.ActualWidth;
                Sidebar.Visibility = Visibility.Collapsed; SideSplitter.Visibility = Visibility.Collapsed; SidebarCol.Width = new GridLength(0);
                WindowState = WindowState.Normal; WindowState = WindowState.Maximized;
                ShowBanner("Полноэкранный режим. Выход — F11 или Esc.", false);
            }
            else
            {
                SetSidebar(S.ShowSidebar);
                WindowState = _stateBeforeFull;
            }
            UpdateParallelUi();
            UpdateMaxState();
        }

        // ======================= Инструменты =======================

        private static bool IsAnnotationTool(Tool t) => t != Tool.Hand && t != Tool.Select && t != Tool.Eraser;

        private void Tool_Checked(object sender, RoutedEventArgs e)
        {
            if (!(sender is FrameworkElement fe) || !(fe.Tag is string tag) || !Enum.TryParse<Tool>(tag, out var tool)) return;
            if (_idle == null || OptionsBar == null) return;
            _tool = tool;
            foreach (var v in AllViewers()) v.Tool = tool;
            _viewer.ClearSelection();
            var info = ToolCatalog.Get(tag);
            OptTitle.Text = info?.Title ?? "";
            OptHint.Text = info?.Description ?? "";
            bool ann = tool != Tool.Hand && tool != Tool.Select;
            OptionsBar.Visibility = ann && !_fullscreen ? Visibility.Visible : Visibility.Collapsed;
            bool colored = tool != Tool.Redact && tool != Tool.WhiteOut && tool != Tool.Eraser;
            Swatches.Visibility = colored ? Visibility.Visible : Visibility.Collapsed;
            ThicknessPanel.Visibility = tool == Tool.Pen || tool == Tool.Marker || tool == Tool.Rect || tool == Tool.Ellipse || tool == Tool.Arrow || tool == Tool.Line || tool == Tool.Underline || tool == Tool.Strike ? Visibility.Visible : Visibility.Collapsed;
            OpacityPanel.Visibility = colored && tool != Tool.Text && tool != Tool.Note ? Visibility.Visible : Visibility.Collapsed;
            FontPanel.Visibility = tool == Tool.Text || tool == Tool.Stamp ? Visibility.Visible : Visibility.Collapsed;
            StampPanel.Visibility = tool == Tool.Stamp ? Visibility.Visible : Visibility.Collapsed;
            if (tool == Tool.Highlight && _color == Colors.Black) SetColor(Color.FromRgb(255, 230, 0));
            if (_doc != null && IsAnnotationTool(tool) && _doc.IsReflowable)
                StatusText.Text = "Пометки в книгах привязаны к текущей разбивке страниц: изменение шрифта книги удалит их.";
        }

        private Annotation NewAnnotationStyle()
        {
            return new Annotation
            {
                Color = _color,
                Thickness = ThicknessSlider.Value,
                Opacity = OpacitySlider.Value,
                FontSize = FontSlider.Value,
                Text = _tool == Tool.Stamp ? (StampBox.SelectedItem as string ?? "ОДОБРЕНО") : null
            };
        }

        private void BuildSwatches()
        {
            Swatches.Children.Clear();
            foreach (var hex in Palette)
            {
                var c = ThemeColor(hex, Colors.Black);
                var b = new Button { Width = 24, Height = 24, Margin = new Thickness(2, 0, 2, 0), Cursor = Cursors.Hand, ToolTip = hex.Substring(3), Focusable = false, Tag = c };
                var tpl = new ControlTemplate(typeof(Button));
                var el = new FrameworkElementFactory(typeof(Border));
                el.SetValue(Border.CornerRadiusProperty, new CornerRadius(12));
                el.SetValue(Border.BackgroundProperty, new SolidColorBrush(c));
                el.SetValue(Border.BorderThicknessProperty, new Thickness(2));
                el.SetBinding(Border.BorderBrushProperty, new System.Windows.Data.Binding("BorderBrush") { RelativeSource = new System.Windows.Data.RelativeSource(System.Windows.Data.RelativeSourceMode.TemplatedParent) });
                tpl.VisualTree = el;
                b.Template = tpl;
                b.Click += (s, e) => SetColor((Color)((Button)s).Tag);
                Swatches.Children.Add(b);
            }
            SetColor(_color);
        }

        private void SetColor(Color c)
        {
            _color = c;
            S.PenColor = c.ToString();
            foreach (Button b in Swatches.Children)
            {
                bool sel = b.Tag is Color bc && bc == c;
                b.BorderBrush = sel ? (Brush)FindResource("AccentBrush") : new SolidColorBrush(Color.FromArgb(80, 128, 128, 128));
            }
        }

        private void CustomColor_Click(object sender, RoutedEventArgs e)
        {
            using (var dlg = new System.Windows.Forms.ColorDialog { FullOpen = true, Color = System.Drawing.Color.FromArgb(_color.R, _color.G, _color.B) })
            {
                if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                    SetColor(Color.FromRgb(dlg.Color.R, dlg.Color.G, dlg.Color.B));
            }
        }

        private void Opt_Changed(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (!_ready) return;
            S.PenThickness = ThicknessSlider.Value;
            S.AnnOpacity = OpacitySlider.Value;
            S.TextSize = FontSlider.Value;
        }

        private void Stamp_Changed(object sender, SelectionChangedEventArgs e)
        {
            if (!_ready) return;
            S.Stamp = StampBox.SelectedItem as string ?? S.Stamp;
        }

        private void Undo_Click(object sender, RoutedEventArgs e) { if (_doc == null) return; _viewer.Undo(); UpdateDocButtons(); }
        private void Redo_Click(object sender, RoutedEventArgs e) { if (_doc == null) return; _viewer.Redo(); UpdateDocButtons(); }

        private void SelectTool(Tool t)
        {
            foreach (var child in Toolbar.Children.OfType<RadioButton>())
                if (child.Tag as string == t.ToString()) { child.IsChecked = true; return; }
        }

        // ======================= Контекстное меню страницы =======================

        private ContextMenu BuildPageMenu()
        {
            var m = new ContextMenu();
            void Add(string icon, string text, Action a)
            {
                var mi = new MenuItem { Header = text, Icon = new TextBlock { Text = icon, FontFamily = (FontFamily)FindResource("IconFont") } };
                mi.Click += (s, e) => { if (_doc != null) a(); };
                m.Items.Add(mi);
            }
            Add("", "Копировать выделенный текст", CopySelection);
            Add("", "Выделить весь текст страницы", () => { SelectTool(Tool.Select); _viewer.SelectAllOnPage(); });
            Add("", "Копировать страницу как изображение", CopyPageImage);
            Add("", "Распознать текст на странице (OCR)", () => RunOcr(false));
            Add("", "Закладка на странице", () => Bookmark_Click(null, null));
            Add("", "Повернуть страницу вправо", () => Rotate(90));
            Add("", "Удалить все пометки страницы", () => AnnClearPage_Click(null, null));
            Add("", "Свойства документа", () => ShowProperties(0));
            return m;
        }

        private ContextMenu BuildThumbMenu()
        {
            var m = new ContextMenu();
            void Add(string icon, string text, Action a)
            {
                var mi = new MenuItem { Header = text, Icon = new TextBlock { Text = icon, FontFamily = (FontFamily)FindResource("IconFont") } };
                mi.Click += (s, e) => { if (_doc != null) a(); };
                m.Items.Add(mi);
            }
            Add("", "Повернуть вправо", () => Rotate(90));
            Add("", "Повернуть влево", () => Rotate(-90));
            Add("", "Переместить выше", () => { _viewer.MovePage(_viewer.CurrentPage, -1); RebuildSidebar(); UpdateDocButtons(); });
            Add("", "Переместить ниже", () => { _viewer.MovePage(_viewer.CurrentPage, 1); RebuildSidebar(); UpdateDocButtons(); });
            Add("", "Убрать страницу (в сохраняемом PDF и печати)", () =>
            {
                if (_viewer.Pages.Count <= 1) return;
                _viewer.DeletePage(_viewer.CurrentPage); RebuildSidebar(); UpdateDocButtons();
                StatusText.Text = "Страница убрана из просмотра. Исходный файл не изменён — сохраните результат в PDF.";
            });
            Add("", "Сохранить страницу как изображение…", ExportCurrentImage);
            Add("", "Напечатать эту страницу…", () => ShowPrint(true));
            return m;
        }

        protected override void OnContentRendered(EventArgs e)
        {
            base.OnContentRendered(e);
            ThumbList.ContextMenu = BuildThumbMenu();
            UpdateTabSpacer();
        }

        // ======================= Буфер обмена =======================

        private void CopySelection()
        {
            if (!string.IsNullOrEmpty(_viewer.SelectedText))
            {
                try { Clipboard.SetText(_viewer.SelectedText); StatusText.Text = "Текст скопирован в буфер обмена."; }
                catch { StatusText.Text = "Буфер обмена занят другой программой."; }
            }
            else StatusText.Text = "Сначала выделите текст инструментом «Выделение текста» (V).";
        }

        private void CopyPageImage()
        {
            if (_doc == null || _viewer.Pages.Count == 0) return;
            try
            {
                var bmp = DocViewer.RenderComposite(_doc, _viewer.Pages[_viewer.CurrentPage], 150, true, false);
                Clipboard.SetImage(bmp);
                StatusText.Text = "Изображение страницы скопировано.";
            }
            catch (Exception ex) { StatusText.Text = "Не удалось скопировать: " + ex.Message; }
        }

        // ======================= Поиск =======================

        private void Search_Click(object sender, RoutedEventArgs e)
        {
            if (Sidebar.Visibility != Visibility.Visible) SetSidebar(true);
            TabSearch.IsChecked = true;
            SearchBox.Focus(); SearchBox.SelectAll();
        }

        private void SearchBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                var tab = _active;
                if (tab != null && tab.Hits.Count > 0 && tab.SearchKey == SearchBox.Text + "|" + MatchCase.IsChecked) SearchNext_Click(null, null);
                else RunSearch();
                e.Handled = true;
            }
        }

        private void DoSearch_Click(object sender, RoutedEventArgs e) => RunSearch();

        private void SetSearchStatus(DocTab tab, string text)
        {
            tab.SearchStatus = text;
            if (tab == _active) SearchStatus.Text = text;
        }

        private async void RunSearch()
        {
            var tab = _active;
            if (tab?.Doc == null) return;
            var doc = tab.Doc;
            var viewer = tab.Viewer;
            var q = SearchBox.Text.Trim();
            int gen = ++_searchGen;
            tab.SearchGen = gen;
            tab.Hits = new List<SearchHit>();
            tab.HitIndex = -1;
            tab.HitView = new ObservableCollection<SearchHit>();
            SearchResults.ItemsSource = tab.HitView;
            viewer.SetSearchHits(null);
            if (q.Length == 0) { SetSearchStatus(tab, ""); tab.SearchKey = null; return; }
            tab.SearchKey = SearchBox.Text + "|" + MatchCase.IsChecked;
            bool mc = MatchCase.IsChecked == true;
            var byView = new Dictionary<int, List<Rect>>();
            var results = tab.HitView;
            int pages = viewer.Pages.Count;
            bool noText = true;
            for (int i = 0; i < pages; i++)
            {
                if (gen != _searchGen || tab.Doc != doc)
                {
                    if (tab.SearchGen == gen && tab.Doc == doc) SetSearchStatus(tab, $"Поиск прерван на странице {i + 1} из {pages}. Нажмите Enter, чтобы начать заново.");
                    return;
                }
                if (i % 4 == 0)
                {
                    SetSearchStatus(tab, $"Поиск… страница {i + 1} из {pages}");
                    await Dispatcher.Yield(DispatcherPriority.Background);
                    if (gen != _searchGen || tab.Doc != doc) { i--; continue; }
                }
                if (i >= viewer.Pages.Count) break;
                var docIdx = viewer.Pages[i].Doc;
                List<Rect> found;
                string text;
                try
                {
                    if (doc.CanRenderOffThread)
                    {
                        var res = await Task.Run(() => (doc.Find(docIdx, q, mc), doc.GetPageText(docIdx)));
                        found = res.Item1; text = res.Item2;
                    }
                    else { found = doc.Find(docIdx, q, mc); text = doc.GetPageText(docIdx); }
                }
                catch { continue; }
                if (gen != _searchGen || tab.Doc != doc) { i--; continue; }
                if (!string.IsNullOrEmpty(text)) noText = false;
                if (found.Count == 0) continue;
                byView[i] = found;
                var flat = text.Replace('\n', ' ');
                int pos = 0;
                foreach (var r in found)
                {
                    int at = flat.IndexOf(q, Math.Min(pos, flat.Length), mc ? StringComparison.Ordinal : StringComparison.CurrentCultureIgnoreCase);
                    string snip = flat;
                    if (at >= 0)
                    {
                        int s0 = Math.Max(0, at - 40), e0 = Math.Min(flat.Length, at + q.Length + 50);
                        snip = (s0 > 0 ? "…" : "") + flat.Substring(s0, e0 - s0) + (e0 < flat.Length ? "…" : "");
                        pos = at + q.Length;
                    }
                    else if (snip.Length > 90) snip = snip.Substring(0, 90) + "…";
                    var hit = new SearchHit { View = i, Rect = r, PageLabel = "Страница " + (i + 1), Snippet = snip };
                    tab.Hits.Add(hit);
                    if (results.Count < 1500) results.Add(hit);
                }
                viewer.SetSearchHits(byView);
            }
            if (gen != _searchGen) return;
            viewer.SetSearchHits(byView);
            SetSearchStatus(tab, tab.Hits.Count == 0
                ? (noText ? "В документе нет текстового слоя. Распознайте текст (OCR), затем повторите поиск." : "Ничего не найдено.")
                : $"Найдено: {tab.Hits.Count} на {byView.Count} стр.");
            if (tab.Hits.Count > 0 && tab == _active) { tab.HitIndex = -1; SearchNext_Click(null, null); }
        }

        private void SearchNext_Click(object sender, RoutedEventArgs e) => MoveHit(1);
        private void SearchPrev_Click(object sender, RoutedEventArgs e) => MoveHit(-1);

        private void MoveHit(int d)
        {
            var tab = _active;
            if (tab == null) return;
            if (tab.Hits.Count == 0) { if (SearchBox.Text.Trim().Length > 0) RunSearch(); return; }
            tab.HitIndex = ((tab.HitIndex + d) % tab.Hits.Count + tab.Hits.Count) % tab.Hits.Count;
            var h = tab.Hits[tab.HitIndex];
            tab.Viewer.SetActiveHit(h.View, h.Rect);
            SetSearchStatus(tab, $"Совпадение {tab.HitIndex + 1} из {tab.Hits.Count}");
        }

        private void SearchResults_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var tab = _active;
            if (tab != null && SearchResults.SelectedItem is SearchHit h)
            {
                tab.HitIndex = tab.Hits.IndexOf(h);
                tab.Viewer.SetActiveHit(h.View, h.Rect);
            }
        }

        // ======================= OCR =======================

        private void Ocr_Click(object sender, RoutedEventArgs e)
        {
            if (_doc == null) return;
            var m = new ContextMenu();
            var a = new MenuItem { Header = "Распознать текущую страницу" }; a.Click += (s, x) => RunOcr(false); m.Items.Add(a);
            var b = new MenuItem { Header = "Распознать все страницы" }; b.Click += (s, x) => RunOcr(true); m.Items.Add(b);
            var info = new MenuItem { Header = "Языки распознавания: " + OcrService.AvailableLanguages(), IsEnabled = false }; m.Items.Add(info);
            m.PlacementTarget = sender as UIElement; m.Placement = PlacementMode.Bottom; m.IsOpen = true;
        }

        private async void RunOcr(bool all)
        {
            var tab = _active;
            if (tab?.Doc == null || tab.Viewer.Pages.Count == 0) return;
            var doc = tab.Doc;
            var viewer = tab.Viewer;
            var targets = all ? viewer.Pages.ToList() : new List<PageRef> { viewer.Pages[viewer.CurrentPage] };
            int done = 0, chars = 0;
            ShowLoading("Распознавание текста…");
            try
            {
                foreach (var r in targets)
                {
                    if (tab.Doc != doc) return;
                    int v = viewer.Pages.IndexOf(r);
                    LoadingText.Text = $"Распознавание текста «{tab.FileName}»: страница {v + 1} ({done + 1} из {targets.Count})";
                    var size = doc.GetPageSize(r.Doc);
                    double scale = Math.Min(3.0, 2600 / Math.Max(size.Width, size.Height));
                    int idx = r.Doc;
                    BitmapSource bmp = doc.CanRenderOffThread ? await Task.Run(() => doc.RenderPage(idx, scale)) : doc.RenderPage(idx, scale);
                    if (tab.Doc != doc) return;
                    if (bmp == null) { done++; continue; }
                    // фактический масштаб картинки (отрисовка могла ограничить размер очень больших страниц)
                    double pxPerDip = bmp.PixelWidth / Math.Max(1.0, size.Width);
                    var list = await OcrService.RecognizeAsync(bmp, pxPerDip);
                    bmp = null;
                    doc.SetOcrChars(idx, list);
                    chars += list.Count;
                    done++;
                }
                StatusText.Text = $"Распознано символов: {chars} на {done} стр. Теперь доступны поиск, выделение и копирование.";
                _searchGen++;
                tab.Hits.Clear();
                MemoryTrim.Schedule();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Распознавание не выполнено:\n\n" + ex.Message, "DocuNova", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            finally { HideLoading(); }
        }

        // ======================= Сохранение и экспорт =======================

        private void SavePdf_Click(object sender, RoutedEventArgs e)
        {
            if (_active?.Doc == null) return;
            SavePdf(_active, _viewer.Pages);
        }

        private bool SavePdf(DocTab tab, IList<PageRef> pages)
        {
            if (tab?.Doc == null) return false;
            var dlg = new SaveFileDialog
            {
                Filter = "Документ PDF|*.pdf",
                FileName = Path.GetFileNameWithoutExtension(tab.Path ?? "Документ") + (tab.Doc.IsPdf ? " (с пометками)" : "") + ".pdf",
                Title = "Сохранить как PDF"
            };
            if (dlg.ShowDialog(this) != true) return false;
            string target;
            try { target = Path.GetFullPath(dlg.FileName); } catch { target = dlg.FileName; }
            if (_tabs.Any(t => string.Equals(t.Path, target, StringComparison.OrdinalIgnoreCase)))
            {
                MessageBox.Show(this, "Для безопасности открытые документы не перезаписываются. Выберите другое имя.", "DocuNova", MessageBoxButton.OK, MessageBoxImage.Information);
                return false;
            }
            try
            {
                Mouse.OverrideCursor = Cursors.Wait;
                PdfExport.Save(tab.Doc, pages, target, S.ExportDpi, (i, n) => StatusText.Text = $"Сохранение: страница {i} из {n}");
                if (ReferenceEquals(pages, tab.Viewer.Pages)) tab.Viewer.Modified = false;
                UpdateTabHeader(tab);
                StatusText.Text = "Сохранено: " + target;
                ShowBanner("PDF сохранён: " + Path.GetFileName(target), false);
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Не удалось сохранить PDF:\n\n" + ex.Message, "DocuNova", MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }
            finally { Mouse.OverrideCursor = null; MemoryTrim.Schedule(); }
        }

        private void Export_Click(object sender, RoutedEventArgs e)
        {
            var m = new ContextMenu();
            void Add(string icon, string text, Action a, bool needDoc = true)
            {
                var mi = new MenuItem { Header = text, Icon = new TextBlock { Text = icon, FontFamily = (FontFamily)FindResource("IconFont") }, IsEnabled = !needDoc || _doc != null };
                mi.Click += (s, x) => a();
                m.Items.Add(mi);
            }
            Add("", "Текущую страницу как изображение (PNG/JPEG/TIFF)…", ExportCurrentImage);
            Add("", "Все страницы как изображения в папку…", ExportAllImages);
            Add("", "Текст документа в TXT…", ExportText);
            Add("", "Копировать текст всего документа", CopyAllText);
            Add("", "Выбранные страницы в отдельный PDF…", ExportRange);
            Add("", "Объединить несколько PDF в один…", MergePdfs, false);
            m.PlacementTarget = sender as UIElement; m.Placement = PlacementMode.Bottom; m.IsOpen = true;
        }

        private void ExportCurrentImage()
        {
            if (_doc == null || _viewer.Pages.Count == 0) return;
            var dlg = new SaveFileDialog { Filter = "PNG|*.png|JPEG|*.jpg|TIFF|*.tif", FileName = $"{Path.GetFileNameWithoutExtension(_path)} — стр. {_viewer.CurrentPage + 1}.png" };
            if (dlg.ShowDialog(this) != true) return;
            try
            {
                var bmp = DocViewer.RenderComposite(_doc, _viewer.Pages[_viewer.CurrentPage], S.ExportDpi, true, false);
                PdfExport.SaveImage(bmp, dlg.FileName);
                StatusText.Text = "Сохранено: " + dlg.FileName;
            }
            catch (Exception ex) { MessageBox.Show(this, ex.Message, "DocuNova"); }
            finally { MemoryTrim.Schedule(); }
        }

        private async void ExportAllImages()
        {
            var tab = _active;
            if (tab?.Doc == null) return;
            var dlg = new OpenFolderDialog { Title = "Папка для изображений страниц" };
            if (dlg.ShowDialog(this) != true) return;
            var doc = tab.Doc;
            var pages = tab.Viewer.Pages.ToList();
            var name = Path.GetFileNameWithoutExtension(tab.Path);
            ShowLoading("Экспорт изображений…");
            try
            {
                for (int i = 0; i < pages.Count; i++)
                {
                    if (tab.Doc != doc) return;
                    LoadingText.Text = $"Экспорт изображений: {i + 1} из {pages.Count}";
                    await Dispatcher.Yield(DispatcherPriority.Background);
                    if (tab.Doc != doc) return;
                    var bmp = DocViewer.RenderComposite(doc, pages[i], S.ExportDpi, true, false);
                    PdfExport.SaveImage(bmp, Path.Combine(dlg.FolderName, $"{name} — {i + 1:D4}.png"));
                    // каждые несколько страниц возвращаем память, чтобы экспорт больших документов не раздувал процесс
                    if (i % 8 == 7) MemoryTrim.Collect(false);
                }
                StatusText.Text = "Изображения сохранены в " + dlg.FolderName;
            }
            catch (Exception ex) { MessageBox.Show(this, ex.Message, "DocuNova"); }
            finally { HideLoading(); MemoryTrim.Schedule(); }
        }

        private string AllText()
        {
            var sb = new StringBuilder();
            for (int i = 0; i < _viewer.Pages.Count; i++)
            {
                sb.AppendLine(_doc.GetPageText(_viewer.Pages[i].Doc));
                sb.AppendLine();
            }
            return sb.ToString();
        }

        private void ExportText()
        {
            if (_doc == null) return;
            var dlg = new SaveFileDialog { Filter = "Текст (UTF-8)|*.txt", FileName = Path.GetFileNameWithoutExtension(_path) + ".txt" };
            if (dlg.ShowDialog(this) != true) return;
            try
            {
                Mouse.OverrideCursor = Cursors.Wait;
                File.WriteAllText(dlg.FileName, AllText(), new UTF8Encoding(true));
                StatusText.Text = "Текст сохранён: " + dlg.FileName;
            }
            catch (Exception ex) { MessageBox.Show(this, ex.Message, "DocuNova"); }
            finally { Mouse.OverrideCursor = null; }
        }

        private void CopyAllText()
        {
            if (_doc == null) return;
            try
            {
                Mouse.OverrideCursor = Cursors.Wait;
                var t = AllText();
                if (string.IsNullOrWhiteSpace(t)) { StatusText.Text = "В документе нет текстового слоя (используйте OCR)."; return; }
                Clipboard.SetText(t);
                StatusText.Text = $"Скопировано символов: {t.Length:N0}";
            }
            catch (Exception ex) { StatusText.Text = ex.Message; }
            finally { Mouse.OverrideCursor = null; }
        }

        private void ExportRange()
        {
            var tab = _active;
            if (tab?.Doc == null) return;
            var range = InputDialog.Ask(this, "Страницы в отдельный PDF", $"Укажите номера страниц (1–{_viewer.Pages.Count}), например: 1-3, 5, 8-", $"{_viewer.CurrentPage + 1}");
            if (range == null) return;
            var idx = PrintService.ParseRange(range, _viewer.Pages.Count);
            if (idx.Count == 0) { MessageBox.Show(this, "Не распознан диапазон страниц.", "DocuNova"); return; }
            SavePdf(tab, idx.Select(i => _viewer.Pages[i]).ToList());
        }

        private void MergePdfs()
        {
            var open = new OpenFileDialog { Filter = "PDF|*.pdf", Multiselect = true, Title = "Выберите PDF-файлы (в нужном порядке)" };
            if (open.ShowDialog(this) != true || open.FileNames.Length == 0) return;
            var save = new SaveFileDialog { Filter = "PDF|*.pdf", FileName = "Объединённый документ.pdf" };
            if (save.ShowDialog(this) != true) return;
            string target;
            try { target = Path.GetFullPath(save.FileName); } catch { target = save.FileName; }
            if (open.FileNames.Any(f => string.Equals(Path.GetFullPath(f), target, StringComparison.OrdinalIgnoreCase)) ||
                _tabs.Any(t => string.Equals(t.Path, target, StringComparison.OrdinalIgnoreCase)))
            {
                MessageBox.Show(this, "Нельзя сохранить результат поверх одного из исходных или открытых файлов. Выберите другое имя.", "DocuNova", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            try
            {
                Mouse.OverrideCursor = Cursors.Wait;
                PdfExport.Merge(open.FileNames.OrderBy(f => f, new DocumentLoader.NaturalComparer()), target);
                StatusText.Text = "Объединено файлов: " + open.FileNames.Length;
                Mouse.OverrideCursor = null;
                if (MessageBox.Show(this, "PDF объединены. Открыть результат?", "DocuNova", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                    OpenFile(target);
            }
            catch (Exception ex) { MessageBox.Show(this, "Не удалось объединить: " + ex.Message, "DocuNova"); }
            finally { Mouse.OverrideCursor = null; MemoryTrim.Schedule(); }
        }

        // ======================= Печать, свойства, настройки, справка =======================

        private void Print_Click(object sender, RoutedEventArgs e) => ShowPrint(false);

        private void ShowPrint(bool currentOnly)
        {
            if (_doc == null) return;
            var w = new PrintWindow(_doc, _viewer.Pages, _viewer.CurrentPage, currentOnly) { Owner = this };
            w.ShowDialog();
            MemoryTrim.Schedule();
        }

        private void Properties_Click(object sender, RoutedEventArgs e) => ShowProperties(0);

        private void ShowProperties(int tab)
        {
            if (_doc == null) return;
            var w = new PropertiesWindow(_doc, _path, _viewer.Pages.Count, tab) { Owner = this };
            w.ShowDialog();
        }

        private void Settings_Click(object sender, RoutedEventArgs e) => ShowSettings(0);
        private void ReadSettings_Click(object sender, RoutedEventArgs e) => ShowSettings(1);

        private void ShowSettings(int tab)
        {
            var before = System.Text.Json.JsonSerializer.Serialize(S.Reflow);
            var w = new SettingsWindow(tab) { Owner = this };
            w.ShowDialog();
            ApplyViewSettings();
            BuildSwatches();
            UpdateSecurityBadge();
            var books = _tabs.Where(t => t.Doc != null && t.Doc.IsReflowable).ToList();
            if (books.Count > 0 && before != System.Text.Json.JsonSerializer.Serialize(S.Reflow))
            {
                if (books.Any(t => t.Viewer.HasAnnotations) &&
                    MessageBox.Show(this, "Изменение параметров чтения перестроит страницы открытых книг, и пометки в них будут удалены. Продолжить?", "DocuNova", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes)
                    return;
                ShowLoading("Перестроение страниц…");
                Dispatcher.BeginInvoke(new Action(() =>
                {
                    try
                    {
                        var rs = S.Reflow.Clone(); rs.Light = false;
                        foreach (var t in books)
                        {
                            if (t.Doc == null) continue;
                            try
                            {
                                t.Doc.Reflow(rs);
                                t.Viewer.ReloadPagesAfterReflow();
                                UpdatePaneTitle(t);
                            }
                            catch (Exception ex) { ShowError($"Не удалось перестроить страницы «{t.FileName}»", ex); }
                        }
                        RebuildSidebar();
                        if (_doc != null) OnCurrentPageChanged(_viewer.CurrentPage);
                    }
                    finally { HideLoading(); MemoryTrim.Schedule(); }
                }), DispatcherPriority.Background);
            }
            else foreach (var t in VisibleTabs()) t.Viewer.RerenderAll();
            RefreshRecent();
        }

        private void Help_Click(object sender, RoutedEventArgs e)
        {
            new HelpWindow { Owner = this }.ShowDialog();
        }

        // ======================= Клавиатура =======================

        protected override void OnPreviewKeyDown(KeyEventArgs e)
        {
            base.OnPreviewKeyDown(e);
            if (e.Handled) return;
            var mods = Keyboard.Modifiers;
            bool ctrl = (mods & ModifierKeys.Control) != 0, shift = (mods & ModifierKeys.Shift) != 0, alt = (mods & ModifierKeys.Alt) != 0;
            bool inText = IsKeyboardFocusWithinTextBox();
            var key = e.Key == Key.System ? e.SystemKey : e.Key;

            if (ctrl)
            {
                switch (key)
                {
                    case Key.Tab: NextTab(shift ? -1 : 1); e.Handled = true; return;
                    case Key.PageDown: NextTab(1); e.Handled = true; return;
                    case Key.PageUp: NextTab(-1); e.Handled = true; return;
                    case Key.Oem5: case Key.OemBackslash: Parallel_Click(null, null); e.Handled = true; return;
                    case Key.O when shift: RunOcr(false); e.Handled = true; return;
                    case Key.O: case Key.T: Open_Click(null, null); e.Handled = true; return;
                    case Key.S: SavePdf_Click(null, null); e.Handled = true; return;
                    case Key.P: Print_Click(null, null); e.Handled = true; return;
                    case Key.E: if (_doc != null) Export_Click(ExportBtn, null); e.Handled = true; return;
                    case Key.W: case Key.F4: if (_active != null) CloseTab(_active); e.Handled = true; return;
                    case Key.F: Search_Click(null, null); e.Handled = true; return;
                    case Key.B: Bookmark_Click(null, null); e.Handled = true; return;
                    case Key.Z when !inText: Undo_Click(null, null); e.Handled = true; return;
                    case Key.Y when !inText: Redo_Click(null, null); e.Handled = true; return;
                    case Key.C when !inText: CopySelection(); e.Handled = true; return;
                    case Key.A when !inText: SelectTool(Tool.Select); _viewer.SelectAllOnPage(); e.Handled = true; return;
                    case Key.OemPlus: case Key.Add: ZoomIn_Click(null, null); e.Handled = true; return;
                    case Key.OemMinus: case Key.Subtract: ZoomOut_Click(null, null); e.Handled = true; return;
                    case Key.D0: case Key.NumPad0: _viewer.SetZoom(1); e.Handled = true; return;
                    case Key.D1: FitPage_Click(null, null); e.Handled = true; return;
                    case Key.D2: FitWidth_Click(null, null); e.Handled = true; return;
                    case Key.D3: TwoPageBtn.IsChecked = !(TwoPageBtn.IsChecked == true); TwoPage_Click(null, null); e.Handled = true; return;
                    case Key.L: Rotate(-90); e.Handled = true; return;
                    case Key.R: Rotate(90); e.Handled = true; return;
                    case Key.N: PageMode_Click(null, null); e.Handled = true; return;
                    case Key.OemComma: Settings_Click(null, null); e.Handled = true; return;
                    case Key.Home when !inText: _viewer.GoTo(0); e.Handled = true; return;
                    case Key.End when !inText: _viewer.GoTo(_viewer.Pages.Count - 1); e.Handled = true; return;
                }
                return;
            }
            if (alt && key == Key.Enter) { Properties_Click(null, null); e.Handled = true; return; }

            switch (key)
            {
                case Key.F1: Help_Click(null, null); e.Handled = true; return;
                case Key.F3: if (shift) SearchPrev_Click(null, null); else SearchNext_Click(null, null); e.Handled = true; return;
                case Key.F6: FocusNextPane(); e.Handled = true; return;
                case Key.F9: Sidebar_Click(null, null); e.Handled = true; return;
                case Key.F11: SetFullScreen(!_fullscreen); e.Handled = true; return;
                case Key.Escape:
                    if (_fullscreen) { SetFullScreen(false); e.Handled = true; return; }
                    if (!inText) { HandTool.IsChecked = true; _viewer.ClearSelection(); }
                    return;
            }
            if (inText || _doc == null || alt) return;
            switch (key)
            {
                case Key.Right: if (_viewer.Scroll.ScrollableWidth < 1) { _viewer.Next(); e.Handled = true; } return;
                case Key.Left: if (_viewer.Scroll.ScrollableWidth < 1) { _viewer.Prev(); e.Handled = true; } return;
                case Key.Home: _viewer.GoTo(0); e.Handled = true; return;
                case Key.End: _viewer.GoTo(_viewer.Pages.Count - 1); e.Handled = true; return;
                case Key.Delete:
                    if (AnnList.IsKeyboardFocusWithin) { AnnDelete_Click(null, null); e.Handled = true; }
                    return;
            }
            Tool? t = null;
            switch (key)
            {
                case Key.H: t = Tool.Hand; break;
                case Key.V: t = Tool.Select; break;
                case Key.M: t = Tool.Highlight; break;
                case Key.U: t = Tool.Underline; break;
                case Key.K: t = Tool.Strike; break;
                case Key.P: t = Tool.Pen; break;
                case Key.F: t = Tool.Marker; break;
                case Key.R: t = Tool.Rect; break;
                case Key.O: t = Tool.Ellipse; break;
                case Key.A: t = Tool.Arrow; break;
                case Key.L: t = Tool.Line; break;
                case Key.T: t = Tool.Text; break;
                case Key.N: t = Tool.Note; break;
                case Key.S: t = Tool.Stamp; break;
                case Key.D: t = Tool.Redact; break;
                case Key.W: t = Tool.WhiteOut; break;
                case Key.E: t = Tool.Eraser; break;
            }
            if (t.HasValue) { SelectTool(t.Value); e.Handled = true; }
        }
    }
}
