using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Effects;
using DocuNova.Services;

namespace DocuNova.Themes
{
    /// <summary>Темы оформления: готовые пресеты и применение темы к ресурсам приложения.</summary>
    public static class ThemeManager
    {
        public static readonly List<ThemeDef> Presets = new List<ThemeDef>
        {
            new ThemeDef { Name = "Неон Киберпанк", Bg1 = "#0B0420", Bg2 = "#1A0B3D", Panel = "#160F30", Text = "#F4EEFF", SubText = "#B0A6D6", Accent1 = "#FF2BD6", Accent2 = "#00F0FF", ViewerBg = "#0E0822", Glow = 0.9 },
            new ThemeDef { Name = "Синтвейв", Bg1 = "#1B0B2E", Bg2 = "#3A0F3F", Panel = "#24102F", Text = "#FFEFF8", SubText = "#D8A9C8", Accent1 = "#FF6EC7", Accent2 = "#FFB86C", ViewerBg = "#1A0A26", Glow = 0.85 },
            new ThemeDef { Name = "Токсичный неон", Bg1 = "#03110A", Bg2 = "#0A2A1A", Panel = "#0B1E14", Text = "#EAFFF2", SubText = "#93C9A9", Accent1 = "#39FF14", Accent2 = "#00FFC6", ViewerBg = "#06160D", Glow = 0.9 },
            new ThemeDef { Name = "Северное сияние", Bg1 = "#06141F", Bg2 = "#13294A", Panel = "#0C1E30", Text = "#EAF6FF", SubText = "#9BB8D0", Accent1 = "#00FFA3", Accent2 = "#7B61FF", ViewerBg = "#081725", Glow = 0.75 },
            new ThemeDef { Name = "Лазерный лёд", Bg1 = "#020B1A", Bg2 = "#0A1F44", Panel = "#0A1730", Text = "#EAF4FF", SubText = "#93AFD6", Accent1 = "#2E9BFF", Accent2 = "#A4F4FF", ViewerBg = "#06122A", Glow = 0.8 },
            new ThemeDef { Name = "Кровавая луна", Bg1 = "#16030A", Bg2 = "#3A0A16", Panel = "#240812", Text = "#FFEDEF", SubText = "#D69AA6", Accent1 = "#FF1E56", Accent2 = "#FF9A3C", ViewerBg = "#1A050C", Glow = 0.85 },
            new ThemeDef { Name = "Закат", Bg1 = "#2A0E12", Bg2 = "#4A1F0F", Panel = "#33150F", Text = "#FFF3EA", SubText = "#E0B8A0", Accent1 = "#FF512F", Accent2 = "#F09819", ViewerBg = "#250C0C", Glow = 0.6 },
            new ThemeDef { Name = "Океан", Bg1 = "#031B2E", Bg2 = "#06395C", Panel = "#062841", Text = "#E8F7FF", SubText = "#97C3DD", Accent1 = "#00C6FF", Accent2 = "#0072FF", ViewerBg = "#04223A", Glow = 0.5 },
            new ThemeDef { Name = "Полночь", Bg1 = "#121218", Bg2 = "#1E1E2A", Panel = "#1A1A24", Text = "#ECECF4", SubText = "#9C9CB0", Accent1 = "#8A7CFF", Accent2 = "#5AC8FA", ViewerBg = "#15151D", Glow = 0.35 },
            new ThemeDef { Name = "Графит", Bg1 = "#1C1C1C", Bg2 = "#2A2A2A", Panel = "#232323", Text = "#F0F0F0", SubText = "#A8A8A8", Accent1 = "#FFFFFF", Accent2 = "#9A9A9A", ViewerBg = "#1A1A1A", Glow = 0.15 },
            new ThemeDef { Name = "Светлая", Bg1 = "#F4F6FB", Bg2 = "#E3E8F6", Panel = "#FFFFFF", Text = "#1C2033", SubText = "#5F667F", Accent1 = "#4F6BFF", Accent2 = "#B05CFF", ViewerBg = "#DDE2EF", Glow = 0.35, IsDark = false, PanelOpacity = 0.92 },
            new ThemeDef { Name = "Мятная", Bg1 = "#EFFBF6", Bg2 = "#D6F3E7", Panel = "#FFFFFF", Text = "#173328", SubText = "#557A6B", Accent1 = "#00B894", Accent2 = "#0984E3", ViewerBg = "#D2EADF", Glow = 0.3, IsDark = false, PanelOpacity = 0.92 },
            new ThemeDef { Name = "Сепия", Bg1 = "#F3E9D2", Bg2 = "#E6D5AE", Panel = "#FBF4E4", Text = "#3B2F20", SubText = "#7A6A50", Accent1 = "#A0522D", Accent2 = "#D2691E", ViewerBg = "#E2D3B0", Glow = 0.2, IsDark = false, PanelOpacity = 0.95 },
            new ThemeDef { Name = "Высокий контраст", Bg1 = "#000000", Bg2 = "#000000", Panel = "#000000", Text = "#FFFFFF", SubText = "#FFFF00", Accent1 = "#FFFF00", Accent2 = "#00FFFF", ViewerBg = "#000000", Glow = 0, Radius = 2, PanelOpacity = 1 },
        };

        public static ThemeDef Current { get; private set; } = Presets[0];

        public static ThemeDef Find(string name, ThemeDef custom)
        {
            if (custom != null && name == custom.Name) return custom;
            return Presets.FirstOrDefault(p => p.Name == name) ?? Presets[0];
        }

        public static Color C(string hex, Color fallback)
        {
            try
            {
                if (!string.IsNullOrWhiteSpace(hex) && ColorConverter.ConvertFromString(hex.Trim()) is Color c) return c;
            }
            catch { }
            return fallback;
        }

        public static Color WithA(Color c, byte a) => Color.FromArgb(a, c.R, c.G, c.B);

        private static T F<T>(T f) where T : Freezable { f.Freeze(); return f; }

        public static LinearGradientBrush Gradient(Color a, Color b, double angleDeg)
        {
            double rad = angleDeg * Math.PI / 180;
            double dx = Math.Cos(rad) * 0.5, dy = Math.Sin(rad) * 0.5;
            var br = new LinearGradientBrush
            {
                StartPoint = new Point(0.5 - dx, 0.5 - dy),
                EndPoint = new Point(0.5 + dx, 0.5 + dy)
            };
            br.GradientStops.Add(new GradientStop(a, 0));
            br.GradientStops.Add(new GradientStop(b, 1));
            return br;
        }

        public static void Apply(ThemeDef t)
        {
            Current = t;
            var res = Application.Current.Resources;
            var bg1 = C(t.Bg1, Colors.Black); var bg2 = C(t.Bg2, Colors.Black);
            var panel = C(t.Panel, Colors.Black);
            var text = C(t.Text, Colors.White); var sub = C(t.SubText, Colors.Gray);
            var a1 = C(t.Accent1, Colors.Magenta); var a2 = C(t.Accent2, Colors.Cyan);
            var viewer = C(t.ViewerBg, bg1);
            byte pa = (byte)Math.Round(255 * Math.Max(0.4, Math.Min(1, t.PanelOpacity)));

            res["BgBrush"] = F(Gradient(bg1, bg2, t.GradientAngle));
            res["PanelBrush"] = F(new SolidColorBrush(WithA(panel, pa)));
            res["PanelSolidBrush"] = F(new SolidColorBrush(panel));
            res["PanelBorderBrush"] = F(new SolidColorBrush(WithA(a1, (byte)(t.IsDark ? 0x55 : 0x40))));
            res["DividerBrush"] = F(new SolidColorBrush(WithA(text, 0x22)));
            res["FgBrush"] = F(new SolidColorBrush(text));
            res["SubFgBrush"] = F(new SolidColorBrush(sub));
            res["AccentBrush"] = F(Gradient(a1, a2, 0));
            res["AccentDiagBrush"] = F(Gradient(a1, a2, 45));
            res["Accent1Brush"] = F(new SolidColorBrush(a1));
            res["Accent2Brush"] = F(new SolidColorBrush(a2));
            res["AccentSoftBrush"] = F(Gradient(WithA(a1, 0x38), WithA(a2, 0x38), 0));
            res["HoverBrush"] = F(new SolidColorBrush(WithA(text, 0x16)));
            res["PressBrush"] = F(new SolidColorBrush(WithA(text, 0x26)));
            res["ButtonBgBrush"] = F(new SolidColorBrush(WithA(text, 0x0A)));
            res["InputBgBrush"] = F(new SolidColorBrush(t.IsDark ? Color.FromArgb(0x55, 0, 0, 0) : Color.FromArgb(0xFF, 0xFF, 0xFF, 0xFF)));
            res["ViewerBgBrush"] = F(new SolidColorBrush(viewer));
            res["OnAccentBrush"] = F(new SolidColorBrush(IsLight(a1) && IsLight(a2) ? Color.FromRgb(15, 15, 25) : Colors.White));
            res["SelectionBrush"] = F(new SolidColorBrush(WithA(a2, 0x55)));
            res["Accent1Color"] = a1;
            res["Accent2Color"] = a2;
            res["FgColor"] = text;
            res["CornerRadius"] = new CornerRadius(t.Radius);
            res["CornerRadiusSmall"] = new CornerRadius(Math.Max(0, t.Radius * 0.6));
            res["CornerRadiusLarge"] = new CornerRadius(t.Radius * 1.6);

            double glow = Math.Max(0, Math.Min(1, t.Glow));
            res["GlowEffect"] = F(new DropShadowEffect { Color = a1, BlurRadius = 6 + 18 * glow, ShadowDepth = 0, Opacity = 0.25 + 0.7 * glow });
            res["GlowEffect2"] = F(new DropShadowEffect { Color = a2, BlurRadius = 6 + 18 * glow, ShadowDepth = 0, Opacity = 0.25 + 0.7 * glow });
            res["SoftShadow"] = F(new DropShadowEffect { Color = Colors.Black, BlurRadius = 18, ShadowDepth = 3, Opacity = t.IsDark ? 0.55 : 0.18, Direction = 270 });
            res["PageShadow"] = F(new DropShadowEffect { Color = glow > 0.5 && t.IsDark ? a1 : Colors.Black, BlurRadius = 22, ShadowDepth = glow > 0.5 && t.IsDark ? 0 : 4, Opacity = t.IsDark ? 0.45 * Math.Max(0.4, glow) : 0.25, Direction = 270 });
            res["TextGlow"] = F(new DropShadowEffect { Color = a1, BlurRadius = 4 + 12 * glow, ShadowDepth = 0, Opacity = glow });
        }

        private static bool IsLight(Color c) => (0.299 * c.R + 0.587 * c.G + 0.114 * c.B) > 170;
    }
}
