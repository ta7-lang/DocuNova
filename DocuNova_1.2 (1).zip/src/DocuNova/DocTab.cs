using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Windows.Controls;
using DocuNova.Core;
using DocuNova.Viewer;

namespace DocuNova
{
    /// <summary>Открытый документ во вкладке: собственный просмотрщик, состояние поиска и элементы интерфейса.</summary>
    public sealed class DocTab
    {
        public DocViewer Viewer { get; } = new DocViewer();
        public DocumentBase Doc { get; set; }
        public string Path { get; set; }
        public string FileName => string.IsNullOrEmpty(Path) ? "Документ" : System.IO.Path.GetFileName(Path);

        // заголовок вкладки
        public Border Header;
        public TextBlock HeaderText;
        public TextBlock HeaderDot;

        // панель в области просмотра (для параллельного просмотра)
        public Border Pane;
        public Border PaneHeader;
        public TextBlock PaneTitle;

        // поиск
        public List<SearchHit> Hits = new List<SearchHit>();
        public ObservableCollection<SearchHit> HitView;
        public int HitIndex = -1;
        public string SearchKey;
        public string SearchStatus = "";
        public int SearchGen;
    }
}
