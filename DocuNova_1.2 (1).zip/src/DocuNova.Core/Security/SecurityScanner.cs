using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using DocuNova.Core.Formats;

namespace DocuNova.Core
{
    /// <summary>Анализ безопасности документа: активное содержимое, происхождение файла, подмена расширения.</summary>
    public static class SecurityScanner
    {
        /// <summary>Отказывается открывать исполняемые файлы, замаскированные под документы.</summary>
        public static void RejectExecutables(byte[] d, string path)
        {
            if (d.Length >= 2 && d[0] == 'M' && d[1] == 'Z')
                throw new UnsupportedFormatException("Это ИСПОЛНЯЕМЫЙ файл (программа), замаскированный под документ. Открытие заблокировано — файл может быть вирусом.");
            if (d.Length >= 4 && d[0] == 0x7F && d[1] == 'E' && d[2] == 'L' && d[3] == 'F')
                throw new UnsupportedFormatException("Это исполняемый файл Linux (ELF), а не документ. Открытие заблокировано.");
            var name = Path.GetFileName(path ?? "");
            if (Regex.IsMatch(name, @"\.(exe|scr|com|pif|msi|msp|lnk|hta|cpl|dll|sys|ocx|jar|appx|msix|vbe|jse|wsf|wsh)$", RegexOptions.IgnoreCase))
                throw new UnsupportedFormatException("Файлы этого типа являются программами и не открываются просмотрщиком документов.");
        }

        public static void Analyze(DocumentBase doc, byte[] data, string path)
        {
            var list = new List<SecurityFinding>();
            string code = doc.FormatCode;
            try
            {
                switch (code)
                {
                    case "pdf": ScanPdf(data, list); break;
                    case "epub": EpubReader.Scan(data, list); break;
                    case "html": TextReaders.ScanHtml(data, list); break;
                }
            }
            catch { }

            // происхождение файла (Mark of the Web)
            var zone = ReadZone(path, out var url);
            if (zone >= 3)
                list.Insert(0, new SecurityFinding(Severity.Warning, "Файл получен из Интернета" + (zone == 4 ? " (опасная зона)" : ""),
                    "Windows пометила файл как загруженный из сети" + (string.IsNullOrEmpty(url) ? "." : ": " + url) + " Документ показан в защищённом режиме — активное содержимое отключено."));

            // подмена расширения
            var ext = Path.GetExtension(path ?? "").ToLowerInvariant();
            var expected = DocumentLoader.ExtensionToCode(ext);
            if (expected != null && expected != code && !(expected == "fb2" && code == "fb2") && !(expected == "txt"))
                list.Add(new SecurityFinding(Severity.Warning, "Расширение не соответствует содержимому",
                    $"Файл назван как «{ext}», но фактически является «{doc.FormatName}». Такое бывает при подмене типа файла."));

            // уже найденные при разборе
            list.AddRange(doc.Security);
            doc.Security.Clear();
            int dangers = list.Count(f => f.Severity == Severity.Danger);
            doc.Security.Add(new SecurityFinding(Severity.Safe, "Защищённый просмотр активен",
                "Скрипты, макросы, встроенные программы, формы, сетевые запросы и автозапуск полностью отключены. Документ только отображается."));
            doc.Security.AddRange(list.OrderByDescending(f => f.Severity == Severity.Danger ? 3 : f.Severity == Severity.Warning ? 2 : 1));
            if (dangers == 0 && list.All(f => f.Severity != Severity.Warning))
                doc.Security.Add(new SecurityFinding(Severity.Safe, "Угроз не обнаружено", "Активного или подозрительного содержимого не найдено."));
        }

        public static int ReadZone(string path, out string url)
        {
            url = null;
            if (string.IsNullOrEmpty(path)) return -1;
            try
            {
                var ads = path + ":Zone.Identifier";
                if (!File.Exists(ads)) return -1;
                var text = File.ReadAllText(ads);
                var m = Regex.Match(text, @"ZoneId\s*=\s*(\d)");
                var u = Regex.Match(text, @"(HostUrl|ReferrerUrl)\s*=\s*(\S+)");
                if (u.Success) url = u.Groups[2].Value;
                return m.Success ? int.Parse(m.Groups[1].Value) : -1;
            }
            catch { return -1; }
        }

        private static void ScanPdf(byte[] d, List<SecurityFinding> list)
        {
            int js = SafeIO.Count(d, "/JavaScript") + SafeIO.Count(d, "/JS ") + SafeIO.Count(d, "/JS(") + SafeIO.Count(d, "/JS<");
            int open = SafeIO.Count(d, "/OpenAction");
            int aa = SafeIO.Count(d, "/AA");
            int launch = SafeIO.Count(d, "/Launch");
            int embedded = SafeIO.Count(d, "/EmbeddedFile");
            int rich = SafeIO.Count(d, "/RichMedia") + SafeIO.Count(d, "/Flash");
            int xfa = SafeIO.Count(d, "/XFA");
            int submit = SafeIO.Count(d, "/SubmitForm") + SafeIO.Count(d, "/ImportData");
            int remote = SafeIO.Count(d, "/GoToR") + SafeIO.Count(d, "/GoToE");
            int uri = SafeIO.Count(d, "/URI");
            int objstm = SafeIO.Count(d, "/ObjStm");
            int acro = SafeIO.Count(d, "/AcroForm");

            if (js > 0) list.Add(new SecurityFinding(Severity.Danger, "JavaScript в PDF: " + js, "Встроенный код PDF — частый вектор атак. Движок DocuNova не исполняет JavaScript."));
            if (launch > 0) list.Add(new SecurityFinding(Severity.Danger, "Действие «Запуск программы» (/Launch): " + launch, "Попытка запустить внешнюю программу. Заблокировано."));
            if (open > 0 || aa > 0) list.Add(new SecurityFinding(js > 0 ? Severity.Danger : Severity.Warning, "Автоматические действия при открытии: " + (open + aa), "Действия при открытии/просмотре страниц не выполняются."));
            if (embedded > 0) list.Add(new SecurityFinding(Severity.Warning, "Встроенные файлы: " + embedded, "Вложенные файлы не извлекаются и не запускаются."));
            if (rich > 0) list.Add(new SecurityFinding(Severity.Warning, "Мультимедиа/Flash: " + rich, "Не воспроизводится."));
            if (xfa > 0) list.Add(new SecurityFinding(Severity.Warning, "Динамические формы XFA", "Не исполняются."));
            if (submit > 0) list.Add(new SecurityFinding(Severity.Warning, "Отправка данных формы: " + submit, "Документ пытается отправлять/загружать данные. Заблокировано."));
            if (remote > 0) list.Add(new SecurityFinding(Severity.Warning, "Переходы в другие файлы: " + remote, "Внешние документы не открываются."));
            if (uri > 0) list.Add(new SecurityFinding(Severity.Info, "Веб-ссылок: " + uri, "Ссылки не открываются автоматически."));
            if (acro > 0) list.Add(new SecurityFinding(Severity.Info, "Интерактивная форма (AcroForm)", "Поля формы показаны как изображение."));
            if (objstm > 0 && js == 0) list.Add(new SecurityFinding(Severity.Info, "Сжатые потоки объектов", "Часть структуры PDF сжата — поверхностный анализ мог пропустить скрытые объекты, но выполнение любого кода всё равно невозможно."));
            int eof = SafeIO.Count(d, "%%EOF");
            if (eof > 1) list.Add(new SecurityFinding(Severity.Info, "Инкрементальные обновления: " + (eof - 1), "Документ редактировался после создания (несколько ревизий)."));
        }
    }
}
