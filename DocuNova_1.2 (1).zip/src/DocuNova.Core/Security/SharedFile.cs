using System;
using System.IO;
using Microsoft.Win32.SafeHandles;

namespace DocuNova.Core
{
    /// <summary>
    /// Файл, открытый только для чтения на всё время просмотра. Другие программы могут читать,
    /// переименовывать и удалять его, но не могут изменить содержимое, пока документ открыт.
    /// Данные читаются с диска по мере надобности — весь файл не держится в оперативной памяти.
    /// </summary>
    public sealed class SharedFile : IDisposable
    {
        private SafeFileHandle _handle;
        public long Length { get; }
        public string Path { get; }

        private SharedFile(SafeFileHandle h, long length, string path)
        {
            _handle = h;
            Length = length;
            Path = path;
        }

        /// <summary>Открывает файл с запретом записи для других программ. null — если файл сейчас кем-то изменяется.</summary>
        public static SharedFile TryOpen(string path)
        {
            SafeFileHandle h;
            try
            {
                h = File.OpenHandle(path, FileMode.Open, FileAccess.Read, FileShare.Read | FileShare.Delete, FileOptions.RandomAccess);
            }
            catch (IOException) { return null; }               // открыт другой программой на запись
            catch (UnauthorizedAccessException) { return null; }
            long len;
            try { len = RandomAccess.GetLength(h); }
            catch { h.Dispose(); return null; }
            if (len > SafeIO.MaxFileSize)
            {
                h.Dispose();
                throw new UnsupportedFormatException("Файл слишком большой (более 1,5 ГБ).");
            }
            return new SharedFile(h, len, path);
        }

        /// <summary>Читает весь файл (для определения формата и проверки безопасности).</summary>
        public byte[] ReadAll()
        {
            var buf = new byte[Length];
            int read = 0;
            while (read < buf.Length)
            {
                int n = ReadAt(read, buf.AsSpan(read));
                if (n <= 0) break;
                read += n;
            }
            if (read != buf.Length) Array.Resize(ref buf, read);
            return buf;
        }

        /// <summary>Новый независимый поток чтения (у каждого своя позиция).</summary>
        public Stream CreateStream() => new SharedFileStream(this);

        internal int ReadAt(long position, Span<byte> destination)
        {
            var h = _handle;
            if (h == null || h.IsClosed) throw new ObjectDisposedException(nameof(SharedFile));
            return RandomAccess.Read(h, destination, position);
        }

        public void Dispose()
        {
            var h = _handle;
            _handle = null;
            try { h?.Dispose(); } catch { }
        }
    }

    /// <summary>Буферизованный поток с позиционным чтением поверх <see cref="SharedFile"/>.</summary>
    internal sealed class SharedFileStream : Stream
    {
        private readonly SharedFile _file;
        private readonly byte[] _buf = new byte[32 * 1024];
        private readonly object _sync = new object();
        private long _bufStart = -1;
        private int _bufLen;
        private long _pos;
        private bool _closed;

        public SharedFileStream(SharedFile file) { _file = file; }

        public override bool CanRead => !_closed;
        public override bool CanSeek => !_closed;
        public override bool CanWrite => false;
        public override long Length => _file.Length;

        public override long Position
        {
            get => _pos;
            set { if (value < 0) throw new ArgumentOutOfRangeException(nameof(value)); _pos = value; }
        }

        public override int Read(byte[] buffer, int offset, int count) => Read(buffer.AsSpan(offset, count));

        public override int Read(Span<byte> dst)
        {
            lock (_sync)
            {
                if (_closed) throw new ObjectDisposedException(nameof(SharedFileStream));
                int total = 0;
                long len = _file.Length;
                while (dst.Length > 0 && _pos < len)
                {
                    if (_bufStart >= 0 && _pos >= _bufStart && _pos < _bufStart + _bufLen)
                    {
                        int off = (int)(_pos - _bufStart);
                        int n = Math.Min(_bufLen - off, dst.Length);
                        _buf.AsSpan(off, n).CopyTo(dst);
                        dst = dst.Slice(n);
                        _pos += n;
                        total += n;
                        continue;
                    }
                    if (dst.Length >= _buf.Length)
                    {
                        // большой блок читаем сразу в приёмник, минуя буфер
                        int n = _file.ReadAt(_pos, dst);
                        if (n <= 0) break;
                        dst = dst.Slice(n);
                        _pos += n;
                        total += n;
                        continue;
                    }
                    int r = _file.ReadAt(_pos, _buf);
                    if (r <= 0) break;
                    _bufStart = _pos;
                    _bufLen = r;
                }
                return total;
            }
        }

        public override int ReadByte()
        {
            lock (_sync)
            {
                if (_bufStart >= 0 && _pos >= _bufStart && _pos < _bufStart + _bufLen)
                {
                    int b = _buf[(int)(_pos - _bufStart)];
                    _pos++;
                    return b;
                }
            }
            Span<byte> one = stackalloc byte[1];
            return Read(one) == 1 ? one[0] : -1;
        }

        public override long Seek(long offset, SeekOrigin origin)
        {
            long p;
            switch (origin)
            {
                case SeekOrigin.Begin: p = offset; break;
                case SeekOrigin.Current: p = _pos + offset; break;
                default: p = _file.Length + offset; break;
            }
            if (p < 0) throw new IOException("Попытка перейти до начала файла.");
            _pos = p;
            return p;
        }

        public override void Flush() { }
        public override void SetLength(long value) => throw new NotSupportedException();
        public override void Write(byte[] buffer, int offset, int count) => throw new NotSupportedException();

        protected override void Dispose(bool disposing)
        {
            _closed = true;
            base.Dispose(disposing);
        }
    }
}
