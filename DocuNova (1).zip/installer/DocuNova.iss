﻿; ============================================================
;  DocuNova — установщик (Inno Setup 6)
;  Собирается автоматически в GitHub Actions.
; ============================================================
#define AppName "DocuNova"
#ifndef AppVersion
  #define AppVersion "1.0.0"
#endif
#define AppExe "DocuNova.exe"
#define ThumbClsid "{{4ade8aa0-5fdb-4a79-b9af-dcd6f72acb83}"

[Setup]
AppId={{feb27954-ea9a-4dc8-b8b1-3f13ae7ee7e4}
AppName={#AppName}
AppVersion={#AppVersion}
AppVerName={#AppName} {#AppVersion}
AppPublisher=DocuNova
VersionInfoVersion={#AppVersion}
DefaultDirName={autopf}\{#AppName}
DefaultGroupName={#AppName}
DisableProgramGroupPage=yes
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
MinVersion=10.0.17763
PrivilegesRequired=admin
OutputDir=..\dist
OutputBaseFilename=DocuNova-Setup-x64
SetupIconFile=..\src\DocuNova\Assets\app.ico
UninstallDisplayIcon={app}\{#AppExe}
UninstallDisplayName={#AppName} — просмотрщик документов
Compression=lzma2/ultra64
SolidCompression=yes
WizardStyle=modern
ChangesAssociations=yes
CloseApplications=yes
RestartApplications=no

[Languages]
Name: "russian"; MessagesFile: "compiler:Languages\Russian.isl"
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "Создать ярлык на рабочем столе"; GroupDescription: "Ярлыки:"
Name: "thumbs"; Description: "Эскизы документов в Проводнике (PDF, EPUB, FB2, MOBI, DOCX, RTF, ODT и др.)"; GroupDescription: "Интеграция с Windows:"
Name: "assoc"; Description: "Открывать PDF, EPUB, FB2, MOBI, AZW, XPS, CBZ, Markdown в DocuNova по умолчанию"; GroupDescription: "Интеграция с Windows:"
Name: "firewall"; Description: "Запретить DocuNova любой доступ в Интернет (правило брандмауэра Windows)"; GroupDescription: "Безопасность:"
Name: "clearthumbs"; Description: "Очистить старый кэш эскизов Windows (Проводник будет перезапущен)"; GroupDescription: "Интеграция с Windows:"; Flags: unchecked

[Files]
Source: "..\publish\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs
#ifdef WithRuntime
Source: "..\redist\windowsdesktop-runtime-win-x64.exe"; DestDir: "{tmp}"; Flags: deleteafterinstall; Check: NeedsRuntime
#endif

[Icons]
Name: "{autoprograms}\{#AppName}"; Filename: "{app}\{#AppExe}"; Comment: "Безопасный просмотр документов"
Name: "{autodesktop}\{#AppName}"; Filename: "{app}\{#AppExe}"; Tasks: desktopicon

[Registry]
; --- тип документа DocuNova ---
Root: HKLM; Subkey: "Software\Classes\DocuNova.Document"; ValueType: string; ValueName: ""; ValueData: "Документ (DocuNova)"; Flags: uninsdeletekey
Root: HKLM; Subkey: "Software\Classes\DocuNova.Document"; ValueType: string; ValueName: "FriendlyTypeName"; ValueData: "Документ (DocuNova)"
Root: HKLM; Subkey: "Software\Classes\DocuNova.Document\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\{#AppExe},0"
Root: HKLM; Subkey: "Software\Classes\DocuNova.Document\shell\open"; ValueType: string; ValueName: "FriendlyAppName"; ValueData: "DocuNova"
Root: HKLM; Subkey: "Software\Classes\DocuNova.Document\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\{#AppExe}"" ""%1"""
Root: HKLM; Subkey: "Software\Classes\DocuNova.Document\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{#ThumbClsid}"; Tasks: thumbs
; --- приложение ---
Root: HKLM; Subkey: "Software\Classes\Applications\{#AppExe}"; ValueType: string; ValueName: "FriendlyAppName"; ValueData: "DocuNova"; Flags: uninsdeletekey
Root: HKLM; Subkey: "Software\Classes\Applications\{#AppExe}\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\{#AppExe},0"
Root: HKLM; Subkey: "Software\Classes\Applications\{#AppExe}\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\{#AppExe}"" ""%1"""
Root: HKLM; Subkey: "Software\Microsoft\Windows\CurrentVersion\App Paths\{#AppExe}"; ValueType: string; ValueName: ""; ValueData: "{app}\{#AppExe}"; Flags: uninsdeletekey
; --- регистрация для «Приложения по умолчанию» ---
Root: HKLM; Subkey: "Software\DocuNova"; Flags: uninsdeletekey
Root: HKLM; Subkey: "Software\DocuNova\Capabilities"; ValueType: string; ValueName: "ApplicationName"; ValueData: "DocuNova"
Root: HKLM; Subkey: "Software\DocuNova\Capabilities"; ValueType: string; ValueName: "ApplicationDescription"; ValueData: "Безопасный офлайн-просмотрщик документов"
Root: HKLM; Subkey: "Software\DocuNova\Capabilities"; ValueType: string; ValueName: "ApplicationIcon"; ValueData: "{app}\{#AppExe},0"
Root: HKLM; Subkey: "Software\RegisteredApplications"; ValueType: string; ValueName: "DocuNova"; ValueData: "Software\DocuNova\Capabilities"; Flags: uninsdeletevalue
; --- провайдер эскизов: одобрение расширения оболочки ---
Root: HKLM; Subkey: "Software\Microsoft\Windows\CurrentVersion\Shell Extensions\Approved"; ValueType: string; ValueName: "{#ThumbClsid}"; ValueData: "DocuNova Thumbnail Provider"; Tasks: thumbs; Flags: uninsdeletevalue
; --- по типам файлов ---
Root: HKLM; Subkey: "Software\Classes\.pdf\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{4ade8aa0-5fdb-4a79-b9af-dcd6f72acb83}"; Tasks: thumbs; Flags: uninsdeletekey
Root: HKLM; Subkey: "Software\Classes\SystemFileAssociations\.pdf\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{4ade8aa0-5fdb-4a79-b9af-dcd6f72acb83}"; Tasks: thumbs; Flags: uninsdeletekey
Root: HKLM; Subkey: "Software\Classes\.epub\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{4ade8aa0-5fdb-4a79-b9af-dcd6f72acb83}"; Tasks: thumbs; Flags: uninsdeletekey
Root: HKLM; Subkey: "Software\Classes\SystemFileAssociations\.epub\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{4ade8aa0-5fdb-4a79-b9af-dcd6f72acb83}"; Tasks: thumbs; Flags: uninsdeletekey
Root: HKLM; Subkey: "Software\Classes\.fb2\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{4ade8aa0-5fdb-4a79-b9af-dcd6f72acb83}"; Tasks: thumbs; Flags: uninsdeletekey
Root: HKLM; Subkey: "Software\Classes\SystemFileAssociations\.fb2\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{4ade8aa0-5fdb-4a79-b9af-dcd6f72acb83}"; Tasks: thumbs; Flags: uninsdeletekey
Root: HKLM; Subkey: "Software\Classes\.fbz\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{4ade8aa0-5fdb-4a79-b9af-dcd6f72acb83}"; Tasks: thumbs; Flags: uninsdeletekey
Root: HKLM; Subkey: "Software\Classes\SystemFileAssociations\.fbz\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{4ade8aa0-5fdb-4a79-b9af-dcd6f72acb83}"; Tasks: thumbs; Flags: uninsdeletekey
Root: HKLM; Subkey: "Software\Classes\.mobi\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{4ade8aa0-5fdb-4a79-b9af-dcd6f72acb83}"; Tasks: thumbs; Flags: uninsdeletekey
Root: HKLM; Subkey: "Software\Classes\SystemFileAssociations\.mobi\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{4ade8aa0-5fdb-4a79-b9af-dcd6f72acb83}"; Tasks: thumbs; Flags: uninsdeletekey
Root: HKLM; Subkey: "Software\Classes\.azw\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{4ade8aa0-5fdb-4a79-b9af-dcd6f72acb83}"; Tasks: thumbs; Flags: uninsdeletekey
Root: HKLM; Subkey: "Software\Classes\SystemFileAssociations\.azw\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{4ade8aa0-5fdb-4a79-b9af-dcd6f72acb83}"; Tasks: thumbs; Flags: uninsdeletekey
Root: HKLM; Subkey: "Software\Classes\.azw3\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{4ade8aa0-5fdb-4a79-b9af-dcd6f72acb83}"; Tasks: thumbs; Flags: uninsdeletekey
Root: HKLM; Subkey: "Software\Classes\SystemFileAssociations\.azw3\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{4ade8aa0-5fdb-4a79-b9af-dcd6f72acb83}"; Tasks: thumbs; Flags: uninsdeletekey
Root: HKLM; Subkey: "Software\Classes\.prc\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{4ade8aa0-5fdb-4a79-b9af-dcd6f72acb83}"; Tasks: thumbs; Flags: uninsdeletekey
Root: HKLM; Subkey: "Software\Classes\SystemFileAssociations\.prc\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{4ade8aa0-5fdb-4a79-b9af-dcd6f72acb83}"; Tasks: thumbs; Flags: uninsdeletekey
Root: HKLM; Subkey: "Software\Classes\.docx\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{4ade8aa0-5fdb-4a79-b9af-dcd6f72acb83}"; Tasks: thumbs; Flags: uninsdeletekey
Root: HKLM; Subkey: "Software\Classes\SystemFileAssociations\.docx\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{4ade8aa0-5fdb-4a79-b9af-dcd6f72acb83}"; Tasks: thumbs; Flags: uninsdeletekey
Root: HKLM; Subkey: "Software\Classes\.docm\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{4ade8aa0-5fdb-4a79-b9af-dcd6f72acb83}"; Tasks: thumbs; Flags: uninsdeletekey
Root: HKLM; Subkey: "Software\Classes\SystemFileAssociations\.docm\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{4ade8aa0-5fdb-4a79-b9af-dcd6f72acb83}"; Tasks: thumbs; Flags: uninsdeletekey
Root: HKLM; Subkey: "Software\Classes\.doc\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{4ade8aa0-5fdb-4a79-b9af-dcd6f72acb83}"; Tasks: thumbs; Flags: uninsdeletekey
Root: HKLM; Subkey: "Software\Classes\SystemFileAssociations\.doc\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{4ade8aa0-5fdb-4a79-b9af-dcd6f72acb83}"; Tasks: thumbs; Flags: uninsdeletekey
Root: HKLM; Subkey: "Software\Classes\.odt\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{4ade8aa0-5fdb-4a79-b9af-dcd6f72acb83}"; Tasks: thumbs; Flags: uninsdeletekey
Root: HKLM; Subkey: "Software\Classes\SystemFileAssociations\.odt\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{4ade8aa0-5fdb-4a79-b9af-dcd6f72acb83}"; Tasks: thumbs; Flags: uninsdeletekey
Root: HKLM; Subkey: "Software\Classes\.ods\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{4ade8aa0-5fdb-4a79-b9af-dcd6f72acb83}"; Tasks: thumbs; Flags: uninsdeletekey
Root: HKLM; Subkey: "Software\Classes\SystemFileAssociations\.ods\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{4ade8aa0-5fdb-4a79-b9af-dcd6f72acb83}"; Tasks: thumbs; Flags: uninsdeletekey
Root: HKLM; Subkey: "Software\Classes\.odp\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{4ade8aa0-5fdb-4a79-b9af-dcd6f72acb83}"; Tasks: thumbs; Flags: uninsdeletekey
Root: HKLM; Subkey: "Software\Classes\SystemFileAssociations\.odp\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{4ade8aa0-5fdb-4a79-b9af-dcd6f72acb83}"; Tasks: thumbs; Flags: uninsdeletekey
Root: HKLM; Subkey: "Software\Classes\.rtf\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{4ade8aa0-5fdb-4a79-b9af-dcd6f72acb83}"; Tasks: thumbs; Flags: uninsdeletekey
Root: HKLM; Subkey: "Software\Classes\SystemFileAssociations\.rtf\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{4ade8aa0-5fdb-4a79-b9af-dcd6f72acb83}"; Tasks: thumbs; Flags: uninsdeletekey
Root: HKLM; Subkey: "Software\Classes\.xlsx\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{4ade8aa0-5fdb-4a79-b9af-dcd6f72acb83}"; Tasks: thumbs; Flags: uninsdeletekey
Root: HKLM; Subkey: "Software\Classes\SystemFileAssociations\.xlsx\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{4ade8aa0-5fdb-4a79-b9af-dcd6f72acb83}"; Tasks: thumbs; Flags: uninsdeletekey
Root: HKLM; Subkey: "Software\Classes\.pptx\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{4ade8aa0-5fdb-4a79-b9af-dcd6f72acb83}"; Tasks: thumbs; Flags: uninsdeletekey
Root: HKLM; Subkey: "Software\Classes\SystemFileAssociations\.pptx\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{4ade8aa0-5fdb-4a79-b9af-dcd6f72acb83}"; Tasks: thumbs; Flags: uninsdeletekey
Root: HKLM; Subkey: "Software\Classes\.xps\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{4ade8aa0-5fdb-4a79-b9af-dcd6f72acb83}"; Tasks: thumbs; Flags: uninsdeletekey
Root: HKLM; Subkey: "Software\Classes\SystemFileAssociations\.xps\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{4ade8aa0-5fdb-4a79-b9af-dcd6f72acb83}"; Tasks: thumbs; Flags: uninsdeletekey
Root: HKLM; Subkey: "Software\Classes\.md\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{4ade8aa0-5fdb-4a79-b9af-dcd6f72acb83}"; Tasks: thumbs; Flags: uninsdeletekey
Root: HKLM; Subkey: "Software\Classes\SystemFileAssociations\.md\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{4ade8aa0-5fdb-4a79-b9af-dcd6f72acb83}"; Tasks: thumbs; Flags: uninsdeletekey
Root: HKLM; Subkey: "Software\Classes\.cbz\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{4ade8aa0-5fdb-4a79-b9af-dcd6f72acb83}"; Tasks: thumbs; Flags: uninsdeletekey
Root: HKLM; Subkey: "Software\Classes\SystemFileAssociations\.cbz\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{4ade8aa0-5fdb-4a79-b9af-dcd6f72acb83}"; Tasks: thumbs; Flags: uninsdeletekey
Root: HKLM; Subkey: "Software\Classes\.txt\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{4ade8aa0-5fdb-4a79-b9af-dcd6f72acb83}"; Tasks: thumbs; Flags: uninsdeletekey
Root: HKLM; Subkey: "Software\Classes\SystemFileAssociations\.txt\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{4ade8aa0-5fdb-4a79-b9af-dcd6f72acb83}"; Tasks: thumbs; Flags: uninsdeletekey
Root: HKLM; Subkey: "Software\Classes\.csv\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{4ade8aa0-5fdb-4a79-b9af-dcd6f72acb83}"; Tasks: thumbs; Flags: uninsdeletekey
Root: HKLM; Subkey: "Software\Classes\SystemFileAssociations\.csv\ShellEx\{{e357fccd-a995-4576-b01f-234630154e96}"; ValueType: string; ValueName: ""; ValueData: "{{4ade8aa0-5fdb-4a79-b9af-dcd6f72acb83}"; Tasks: thumbs; Flags: uninsdeletekey
Root: HKLM; Subkey: "Software\Classes\.pdf\OpenWithProgids"; ValueType: string; ValueName: "DocuNova.Document"; ValueData: ""; Flags: uninsdeletevalue
Root: HKLM; Subkey: "Software\DocuNova\Capabilities\FileAssociations"; ValueType: string; ValueName: ".pdf"; ValueData: "DocuNova.Document"
Root: HKLM; Subkey: "Software\Classes\Applications\DocuNova.exe\SupportedTypes"; ValueType: string; ValueName: ".pdf"; ValueData: ""
Root: HKLM; Subkey: "Software\Classes\.epub\OpenWithProgids"; ValueType: string; ValueName: "DocuNova.Document"; ValueData: ""; Flags: uninsdeletevalue
Root: HKLM; Subkey: "Software\DocuNova\Capabilities\FileAssociations"; ValueType: string; ValueName: ".epub"; ValueData: "DocuNova.Document"
Root: HKLM; Subkey: "Software\Classes\Applications\DocuNova.exe\SupportedTypes"; ValueType: string; ValueName: ".epub"; ValueData: ""
Root: HKLM; Subkey: "Software\Classes\.fb2\OpenWithProgids"; ValueType: string; ValueName: "DocuNova.Document"; ValueData: ""; Flags: uninsdeletevalue
Root: HKLM; Subkey: "Software\DocuNova\Capabilities\FileAssociations"; ValueType: string; ValueName: ".fb2"; ValueData: "DocuNova.Document"
Root: HKLM; Subkey: "Software\Classes\Applications\DocuNova.exe\SupportedTypes"; ValueType: string; ValueName: ".fb2"; ValueData: ""
Root: HKLM; Subkey: "Software\Classes\.fbz\OpenWithProgids"; ValueType: string; ValueName: "DocuNova.Document"; ValueData: ""; Flags: uninsdeletevalue
Root: HKLM; Subkey: "Software\DocuNova\Capabilities\FileAssociations"; ValueType: string; ValueName: ".fbz"; ValueData: "DocuNova.Document"
Root: HKLM; Subkey: "Software\Classes\Applications\DocuNova.exe\SupportedTypes"; ValueType: string; ValueName: ".fbz"; ValueData: ""
Root: HKLM; Subkey: "Software\Classes\.mobi\OpenWithProgids"; ValueType: string; ValueName: "DocuNova.Document"; ValueData: ""; Flags: uninsdeletevalue
Root: HKLM; Subkey: "Software\DocuNova\Capabilities\FileAssociations"; ValueType: string; ValueName: ".mobi"; ValueData: "DocuNova.Document"
Root: HKLM; Subkey: "Software\Classes\Applications\DocuNova.exe\SupportedTypes"; ValueType: string; ValueName: ".mobi"; ValueData: ""
Root: HKLM; Subkey: "Software\Classes\.azw\OpenWithProgids"; ValueType: string; ValueName: "DocuNova.Document"; ValueData: ""; Flags: uninsdeletevalue
Root: HKLM; Subkey: "Software\DocuNova\Capabilities\FileAssociations"; ValueType: string; ValueName: ".azw"; ValueData: "DocuNova.Document"
Root: HKLM; Subkey: "Software\Classes\Applications\DocuNova.exe\SupportedTypes"; ValueType: string; ValueName: ".azw"; ValueData: ""
Root: HKLM; Subkey: "Software\Classes\.azw3\OpenWithProgids"; ValueType: string; ValueName: "DocuNova.Document"; ValueData: ""; Flags: uninsdeletevalue
Root: HKLM; Subkey: "Software\DocuNova\Capabilities\FileAssociations"; ValueType: string; ValueName: ".azw3"; ValueData: "DocuNova.Document"
Root: HKLM; Subkey: "Software\Classes\Applications\DocuNova.exe\SupportedTypes"; ValueType: string; ValueName: ".azw3"; ValueData: ""
Root: HKLM; Subkey: "Software\Classes\.prc\OpenWithProgids"; ValueType: string; ValueName: "DocuNova.Document"; ValueData: ""; Flags: uninsdeletevalue
Root: HKLM; Subkey: "Software\DocuNova\Capabilities\FileAssociations"; ValueType: string; ValueName: ".prc"; ValueData: "DocuNova.Document"
Root: HKLM; Subkey: "Software\Classes\Applications\DocuNova.exe\SupportedTypes"; ValueType: string; ValueName: ".prc"; ValueData: ""
Root: HKLM; Subkey: "Software\Classes\.docx\OpenWithProgids"; ValueType: string; ValueName: "DocuNova.Document"; ValueData: ""; Flags: uninsdeletevalue
Root: HKLM; Subkey: "Software\DocuNova\Capabilities\FileAssociations"; ValueType: string; ValueName: ".docx"; ValueData: "DocuNova.Document"
Root: HKLM; Subkey: "Software\Classes\Applications\DocuNova.exe\SupportedTypes"; ValueType: string; ValueName: ".docx"; ValueData: ""
Root: HKLM; Subkey: "Software\Classes\.docm\OpenWithProgids"; ValueType: string; ValueName: "DocuNova.Document"; ValueData: ""; Flags: uninsdeletevalue
Root: HKLM; Subkey: "Software\DocuNova\Capabilities\FileAssociations"; ValueType: string; ValueName: ".docm"; ValueData: "DocuNova.Document"
Root: HKLM; Subkey: "Software\Classes\Applications\DocuNova.exe\SupportedTypes"; ValueType: string; ValueName: ".docm"; ValueData: ""
Root: HKLM; Subkey: "Software\Classes\.doc\OpenWithProgids"; ValueType: string; ValueName: "DocuNova.Document"; ValueData: ""; Flags: uninsdeletevalue
Root: HKLM; Subkey: "Software\DocuNova\Capabilities\FileAssociations"; ValueType: string; ValueName: ".doc"; ValueData: "DocuNova.Document"
Root: HKLM; Subkey: "Software\Classes\Applications\DocuNova.exe\SupportedTypes"; ValueType: string; ValueName: ".doc"; ValueData: ""
Root: HKLM; Subkey: "Software\Classes\.odt\OpenWithProgids"; ValueType: string; ValueName: "DocuNova.Document"; ValueData: ""; Flags: uninsdeletevalue
Root: HKLM; Subkey: "Software\DocuNova\Capabilities\FileAssociations"; ValueType: string; ValueName: ".odt"; ValueData: "DocuNova.Document"
Root: HKLM; Subkey: "Software\Classes\Applications\DocuNova.exe\SupportedTypes"; ValueType: string; ValueName: ".odt"; ValueData: ""
Root: HKLM; Subkey: "Software\Classes\.ods\OpenWithProgids"; ValueType: string; ValueName: "DocuNova.Document"; ValueData: ""; Flags: uninsdeletevalue
Root: HKLM; Subkey: "Software\DocuNova\Capabilities\FileAssociations"; ValueType: string; ValueName: ".ods"; ValueData: "DocuNova.Document"
Root: HKLM; Subkey: "Software\Classes\Applications\DocuNova.exe\SupportedTypes"; ValueType: string; ValueName: ".ods"; ValueData: ""
Root: HKLM; Subkey: "Software\Classes\.odp\OpenWithProgids"; ValueType: string; ValueName: "DocuNova.Document"; ValueData: ""; Flags: uninsdeletevalue
Root: HKLM; Subkey: "Software\DocuNova\Capabilities\FileAssociations"; ValueType: string; ValueName: ".odp"; ValueData: "DocuNova.Document"
Root: HKLM; Subkey: "Software\Classes\Applications\DocuNova.exe\SupportedTypes"; ValueType: string; ValueName: ".odp"; ValueData: ""
Root: HKLM; Subkey: "Software\Classes\.rtf\OpenWithProgids"; ValueType: string; ValueName: "DocuNova.Document"; ValueData: ""; Flags: uninsdeletevalue
Root: HKLM; Subkey: "Software\DocuNova\Capabilities\FileAssociations"; ValueType: string; ValueName: ".rtf"; ValueData: "DocuNova.Document"
Root: HKLM; Subkey: "Software\Classes\Applications\DocuNova.exe\SupportedTypes"; ValueType: string; ValueName: ".rtf"; ValueData: ""
Root: HKLM; Subkey: "Software\Classes\.xlsx\OpenWithProgids"; ValueType: string; ValueName: "DocuNova.Document"; ValueData: ""; Flags: uninsdeletevalue
Root: HKLM; Subkey: "Software\DocuNova\Capabilities\FileAssociations"; ValueType: string; ValueName: ".xlsx"; ValueData: "DocuNova.Document"
Root: HKLM; Subkey: "Software\Classes\Applications\DocuNova.exe\SupportedTypes"; ValueType: string; ValueName: ".xlsx"; ValueData: ""
Root: HKLM; Subkey: "Software\Classes\.pptx\OpenWithProgids"; ValueType: string; ValueName: "DocuNova.Document"; ValueData: ""; Flags: uninsdeletevalue
Root: HKLM; Subkey: "Software\DocuNova\Capabilities\FileAssociations"; ValueType: string; ValueName: ".pptx"; ValueData: "DocuNova.Document"
Root: HKLM; Subkey: "Software\Classes\Applications\DocuNova.exe\SupportedTypes"; ValueType: string; ValueName: ".pptx"; ValueData: ""
Root: HKLM; Subkey: "Software\Classes\.xps\OpenWithProgids"; ValueType: string; ValueName: "DocuNova.Document"; ValueData: ""; Flags: uninsdeletevalue
Root: HKLM; Subkey: "Software\DocuNova\Capabilities\FileAssociations"; ValueType: string; ValueName: ".xps"; ValueData: "DocuNova.Document"
Root: HKLM; Subkey: "Software\Classes\Applications\DocuNova.exe\SupportedTypes"; ValueType: string; ValueName: ".xps"; ValueData: ""
Root: HKLM; Subkey: "Software\Classes\.md\OpenWithProgids"; ValueType: string; ValueName: "DocuNova.Document"; ValueData: ""; Flags: uninsdeletevalue
Root: HKLM; Subkey: "Software\DocuNova\Capabilities\FileAssociations"; ValueType: string; ValueName: ".md"; ValueData: "DocuNova.Document"
Root: HKLM; Subkey: "Software\Classes\Applications\DocuNova.exe\SupportedTypes"; ValueType: string; ValueName: ".md"; ValueData: ""
Root: HKLM; Subkey: "Software\Classes\.cbz\OpenWithProgids"; ValueType: string; ValueName: "DocuNova.Document"; ValueData: ""; Flags: uninsdeletevalue
Root: HKLM; Subkey: "Software\DocuNova\Capabilities\FileAssociations"; ValueType: string; ValueName: ".cbz"; ValueData: "DocuNova.Document"
Root: HKLM; Subkey: "Software\Classes\Applications\DocuNova.exe\SupportedTypes"; ValueType: string; ValueName: ".cbz"; ValueData: ""
Root: HKLM; Subkey: "Software\Classes\.txt\OpenWithProgids"; ValueType: string; ValueName: "DocuNova.Document"; ValueData: ""; Flags: uninsdeletevalue
Root: HKLM; Subkey: "Software\DocuNova\Capabilities\FileAssociations"; ValueType: string; ValueName: ".txt"; ValueData: "DocuNova.Document"
Root: HKLM; Subkey: "Software\Classes\Applications\DocuNova.exe\SupportedTypes"; ValueType: string; ValueName: ".txt"; ValueData: ""
Root: HKLM; Subkey: "Software\Classes\.csv\OpenWithProgids"; ValueType: string; ValueName: "DocuNova.Document"; ValueData: ""; Flags: uninsdeletevalue
Root: HKLM; Subkey: "Software\DocuNova\Capabilities\FileAssociations"; ValueType: string; ValueName: ".csv"; ValueData: "DocuNova.Document"
Root: HKLM; Subkey: "Software\Classes\Applications\DocuNova.exe\SupportedTypes"; ValueType: string; ValueName: ".csv"; ValueData: ""
Root: HKLM; Subkey: "Software\Classes\.html\OpenWithProgids"; ValueType: string; ValueName: "DocuNova.Document"; ValueData: ""; Flags: uninsdeletevalue
Root: HKLM; Subkey: "Software\DocuNova\Capabilities\FileAssociations"; ValueType: string; ValueName: ".html"; ValueData: "DocuNova.Document"
Root: HKLM; Subkey: "Software\Classes\Applications\DocuNova.exe\SupportedTypes"; ValueType: string; ValueName: ".html"; ValueData: ""
Root: HKLM; Subkey: "Software\Classes\.htm\OpenWithProgids"; ValueType: string; ValueName: "DocuNova.Document"; ValueData: ""; Flags: uninsdeletevalue
Root: HKLM; Subkey: "Software\DocuNova\Capabilities\FileAssociations"; ValueType: string; ValueName: ".htm"; ValueData: "DocuNova.Document"
Root: HKLM; Subkey: "Software\Classes\Applications\DocuNova.exe\SupportedTypes"; ValueType: string; ValueName: ".htm"; ValueData: ""
Root: HKLM; Subkey: "Software\Classes\.tif\OpenWithProgids"; ValueType: string; ValueName: "DocuNova.Document"; ValueData: ""; Flags: uninsdeletevalue
Root: HKLM; Subkey: "Software\DocuNova\Capabilities\FileAssociations"; ValueType: string; ValueName: ".tif"; ValueData: "DocuNova.Document"
Root: HKLM; Subkey: "Software\Classes\Applications\DocuNova.exe\SupportedTypes"; ValueType: string; ValueName: ".tif"; ValueData: ""
Root: HKLM; Subkey: "Software\Classes\.tiff\OpenWithProgids"; ValueType: string; ValueName: "DocuNova.Document"; ValueData: ""; Flags: uninsdeletevalue
Root: HKLM; Subkey: "Software\DocuNova\Capabilities\FileAssociations"; ValueType: string; ValueName: ".tiff"; ValueData: "DocuNova.Document"
Root: HKLM; Subkey: "Software\Classes\Applications\DocuNova.exe\SupportedTypes"; ValueType: string; ValueName: ".tiff"; ValueData: ""
Root: HKLM; Subkey: "Software\Classes\.markdown\OpenWithProgids"; ValueType: string; ValueName: "DocuNova.Document"; ValueData: ""; Flags: uninsdeletevalue
Root: HKLM; Subkey: "Software\DocuNova\Capabilities\FileAssociations"; ValueType: string; ValueName: ".markdown"; ValueData: "DocuNova.Document"
Root: HKLM; Subkey: "Software\Classes\Applications\DocuNova.exe\SupportedTypes"; ValueType: string; ValueName: ".markdown"; ValueData: ""
Root: HKLM; Subkey: "Software\Classes\.log\OpenWithProgids"; ValueType: string; ValueName: "DocuNova.Document"; ValueData: ""; Flags: uninsdeletevalue
Root: HKLM; Subkey: "Software\DocuNova\Capabilities\FileAssociations"; ValueType: string; ValueName: ".log"; ValueData: "DocuNova.Document"
Root: HKLM; Subkey: "Software\Classes\Applications\DocuNova.exe\SupportedTypes"; ValueType: string; ValueName: ".log"; ValueData: ""
Root: HKLM; Subkey: "Software\Classes\.tsv\OpenWithProgids"; ValueType: string; ValueName: "DocuNova.Document"; ValueData: ""; Flags: uninsdeletevalue
Root: HKLM; Subkey: "Software\DocuNova\Capabilities\FileAssociations"; ValueType: string; ValueName: ".tsv"; ValueData: "DocuNova.Document"
Root: HKLM; Subkey: "Software\Classes\Applications\DocuNova.exe\SupportedTypes"; ValueType: string; ValueName: ".tsv"; ValueData: ""
Root: HKLM; Subkey: "Software\Classes\.dotx\OpenWithProgids"; ValueType: string; ValueName: "DocuNova.Document"; ValueData: ""; Flags: uninsdeletevalue
Root: HKLM; Subkey: "Software\DocuNova\Capabilities\FileAssociations"; ValueType: string; ValueName: ".dotx"; ValueData: "DocuNova.Document"
Root: HKLM; Subkey: "Software\Classes\Applications\DocuNova.exe\SupportedTypes"; ValueType: string; ValueName: ".dotx"; ValueData: ""
Root: HKLM; Subkey: "Software\Classes\.ott\OpenWithProgids"; ValueType: string; ValueName: "DocuNova.Document"; ValueData: ""; Flags: uninsdeletevalue
Root: HKLM; Subkey: "Software\DocuNova\Capabilities\FileAssociations"; ValueType: string; ValueName: ".ott"; ValueData: "DocuNova.Document"
Root: HKLM; Subkey: "Software\Classes\Applications\DocuNova.exe\SupportedTypes"; ValueType: string; ValueName: ".ott"; ValueData: ""
Root: HKLM; Subkey: "Software\Classes\.xlsm\OpenWithProgids"; ValueType: string; ValueName: "DocuNova.Document"; ValueData: ""; Flags: uninsdeletevalue
Root: HKLM; Subkey: "Software\DocuNova\Capabilities\FileAssociations"; ValueType: string; ValueName: ".xlsm"; ValueData: "DocuNova.Document"
Root: HKLM; Subkey: "Software\Classes\Applications\DocuNova.exe\SupportedTypes"; ValueType: string; ValueName: ".xlsm"; ValueData: ""
Root: HKLM; Subkey: "Software\Classes\.ppsx\OpenWithProgids"; ValueType: string; ValueName: "DocuNova.Document"; ValueData: ""; Flags: uninsdeletevalue
Root: HKLM; Subkey: "Software\DocuNova\Capabilities\FileAssociations"; ValueType: string; ValueName: ".ppsx"; ValueData: "DocuNova.Document"
Root: HKLM; Subkey: "Software\Classes\Applications\DocuNova.exe\SupportedTypes"; ValueType: string; ValueName: ".ppsx"; ValueData: ""
Root: HKLM; Subkey: "Software\Classes\.pdf"; ValueType: string; ValueName: ""; ValueData: "DocuNova.Document"; Tasks: assoc; Flags: uninsdeletevalue
Root: HKLM; Subkey: "Software\Classes\.epub"; ValueType: string; ValueName: ""; ValueData: "DocuNova.Document"; Tasks: assoc; Flags: uninsdeletevalue
Root: HKLM; Subkey: "Software\Classes\.fb2"; ValueType: string; ValueName: ""; ValueData: "DocuNova.Document"; Tasks: assoc; Flags: uninsdeletevalue
Root: HKLM; Subkey: "Software\Classes\.fbz"; ValueType: string; ValueName: ""; ValueData: "DocuNova.Document"; Tasks: assoc; Flags: uninsdeletevalue
Root: HKLM; Subkey: "Software\Classes\.mobi"; ValueType: string; ValueName: ""; ValueData: "DocuNova.Document"; Tasks: assoc; Flags: uninsdeletevalue
Root: HKLM; Subkey: "Software\Classes\.azw"; ValueType: string; ValueName: ""; ValueData: "DocuNova.Document"; Tasks: assoc; Flags: uninsdeletevalue
Root: HKLM; Subkey: "Software\Classes\.azw3"; ValueType: string; ValueName: ""; ValueData: "DocuNova.Document"; Tasks: assoc; Flags: uninsdeletevalue
Root: HKLM; Subkey: "Software\Classes\.prc"; ValueType: string; ValueName: ""; ValueData: "DocuNova.Document"; Tasks: assoc; Flags: uninsdeletevalue
Root: HKLM; Subkey: "Software\Classes\.xps"; ValueType: string; ValueName: ""; ValueData: "DocuNova.Document"; Tasks: assoc; Flags: uninsdeletevalue
Root: HKLM; Subkey: "Software\Classes\.cbz"; ValueType: string; ValueName: ""; ValueData: "DocuNova.Document"; Tasks: assoc; Flags: uninsdeletevalue
Root: HKLM; Subkey: "Software\Classes\.md"; ValueType: string; ValueName: ""; ValueData: "DocuNova.Document"; Tasks: assoc; Flags: uninsdeletevalue

[Run]
#ifdef WithRuntime
Filename: "{tmp}\windowsdesktop-runtime-win-x64.exe"; Parameters: "/install /quiet /norestart"; StatusMsg: "Установка .NET Desktop Runtime 8 (офлайн)…"; Check: NeedsRuntime; Flags: waituntilterminated
#endif
Filename: "{sys}\regsvr32.exe"; Parameters: "/s ""{app}\DocuNova.Shell.comhost.dll"""; StatusMsg: "Регистрация эскизов Проводника…"; Tasks: thumbs; Flags: runhidden waituntilterminated
Filename: "{sys}\netsh.exe"; Parameters: "advfirewall firewall delete rule name=""DocuNova - no internet"""; Tasks: firewall; Flags: runhidden waituntilterminated
Filename: "{sys}\netsh.exe"; Parameters: "advfirewall firewall add rule name=""DocuNova - no internet"" dir=out action=block program=""{app}\{#AppExe}"" enable=yes"; StatusMsg: "Настройка брандмауэра…"; Tasks: firewall; Flags: runhidden waituntilterminated
Filename: "{app}\{#AppExe}"; Parameters: "/clear-thumbcache"; StatusMsg: "Очистка кэша эскизов…"; Tasks: clearthumbs; Flags: runasoriginaluser waituntilterminated
Filename: "ms-settings:defaultapps"; Description: "Открыть «Приложения по умолчанию», чтобы выбрать DocuNova для PDF и других документов"; Flags: shellexec postinstall skipifsilent unchecked
Filename: "{app}\{#AppExe}"; Description: "Запустить DocuNova"; Flags: nowait postinstall skipifsilent runasoriginaluser

[UninstallRun]
Filename: "{sys}\regsvr32.exe"; Parameters: "/u /s ""{app}\DocuNova.Shell.comhost.dll"""; RunOnceId: "UnregThumbs"; Flags: runhidden waituntilterminated
Filename: "{sys}\netsh.exe"; Parameters: "advfirewall firewall delete rule name=""DocuNova - no internet"""; RunOnceId: "DelFirewall"; Flags: runhidden waituntilterminated

[UninstallDelete]
Type: filesandordirs; Name: "{userappdata}\DocuNova"

[Code]
function NeedsRuntime: Boolean;
var
  Names: TArrayOfString;
  I: Integer;
begin
  Result := True;
  if RegGetValueNames(HKLM64, 'SOFTWARE\dotnet\Setup\InstalledVersions\x64\sharedfx\Microsoft.WindowsDesktop.App', Names) then
    for I := 0 to GetArrayLength(Names) - 1 do
      if Copy(Names[I], 1, 2) = '8.' then
      begin
        Result := False;
        Exit;
      end;
end;

#ifndef WithRuntime
procedure CurStepChanged(CurStep: TSetupStep);
begin
  if (CurStep = ssPostInstall) and NeedsRuntime then
    MsgBox('Для работы DocuNova нужен .NET Desktop Runtime 8 (x64). Скачайте его с сайта Microsoft: https://dotnet.microsoft.com/download/dotnet/8.0', mbInformation, MB_OK);
end;
#endif
