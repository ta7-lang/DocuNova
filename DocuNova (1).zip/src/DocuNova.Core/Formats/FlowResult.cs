using System.Collections.Generic;
using System.Windows;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace DocuNova.Core.Formats
{
    /// <summary>Результат разбора перетекаемого формата.</summary>
    public sealed class FlowResult
    {
        public FlowDocument Doc { get; } = new FlowDocument();
        public List<TocItem> Toc { get; } = new List<TocItem>();
        public List<InfoSection> Info { get; } = new List<InfoSection>();
        public List<SecurityFinding> Security { get; } = new List<SecurityFinding>();
        public List<string> Notices { get; } = new List<string>();
        public string Title { get; set; }
        public string Author { get; set; }
        public BitmapSource Cover { get; set; }
        public Size? PageSize { get; set; }
        public Thickness? Padding { get; set; }

        public FlowResult()
        {
            Doc.FontFamily = new FontFamily("Segoe UI");
        }

        public PaginatedDoc Build(ReflowSettings s)
        {
            var d = PaginatedDoc.FromFlowLazy(Doc);
            d.Toc.AddRange(Toc);
            d.Info.AddRange(Info);
            d.Security.AddRange(Security);
            d.Notices.AddRange(Notices);
            d.Title = Title; d.Author = Author; d.Cover = Cover;
            d.Configure(PageSize, Padding);
            d.Reflow(s);
            return d;
        }
    }
}
