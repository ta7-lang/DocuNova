using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace DocuNova.Core.Formats
{
    /// <summary>Стиль фрагмента текста.</summary>
    public struct InlineStyle
    {
        public bool Bold, Italic, Underline, Strike, Mono, Sup, Sub, SmallCaps;
        public double Size;          // множитель размера (0 = 1)
        public double AbsSize;       // абсолютный размер в DIP (0 = нет)
        public Brush Color, Highlight;
        public string Font;
    }

    /// <summary>
    /// Помощник построения FlowDocument: собирает абзацы, блоки, разрывы страниц, якоря оглавления.
    /// </summary>
    public sealed class FlowSink
    {
        private readonly Action<Block> _add;
        private readonly Stack<Func<Paragraph>> _factories = new Stack<Func<Paragraph>>();
        public Paragraph Cur { get; private set; }
        public bool PendingPageBreak { get; set; }
        private readonly List<string> _pendingAnchors = new List<string>();
        private readonly List<TocItem> _pendingToc = new List<TocItem>();
        public Dictionary<string, TextElement> Anchors { get; }
        public double MaxImageWidth { get; set; } = 560;
        public double MaxImageHeight { get; set; } = 780;
        public bool LastEndsWithSpace { get; private set; } = true;
        public int BlockCount { get; private set; }

        public FlowSink(BlockCollection target, Dictionary<string, TextElement> anchors = null)
        {
            _add = b => target.Add(b);
            Anchors = anchors ?? new Dictionary<string, TextElement>(StringComparer.OrdinalIgnoreCase);
        }

        public FlowSink(Action<Block> add, Dictionary<string, TextElement> anchors)
        {
            _add = add;
            Anchors = anchors ?? new Dictionary<string, TextElement>(StringComparer.OrdinalIgnoreCase);
        }

        /// <summary>Дочерний приёмник (ячейка таблицы, элемент списка) с общими якорями.</summary>
        public FlowSink Child(BlockCollection target)
        {
            return new FlowSink(target, Anchors) { MaxImageWidth = MaxImageWidth * 0.9, MaxImageHeight = MaxImageHeight };
        }

        public void Begin(Func<Paragraph> factory) { Flush(); _factories.Push(factory); }
        public void End() { Flush(); if (_factories.Count > 0) _factories.Pop(); }

        public void Anchor(string key)
        {
            if (string.IsNullOrEmpty(key)) return;
            if (Cur != null) { Anchors[key] = Cur; return; }
            _pendingAnchors.Add(key);
        }

        public void TocHere(TocItem item)
        {
            if (Cur != null) { item.Anchor = Cur; return; }
            _pendingToc.Add(item);
        }

        private void ApplyPending(Block b)
        {
            if (PendingPageBreak) { b.BreakPageBefore = true; PendingPageBreak = false; }
            foreach (var a in _pendingAnchors) Anchors[a] = b;
            _pendingAnchors.Clear();
            foreach (var t in _pendingToc) t.Anchor = b;
            _pendingToc.Clear();
            BlockCount++;
        }

        public void Add(Block b)
        {
            Flush();
            ApplyPending(b);
            _add(b);
            LastEndsWithSpace = true;
        }

        public Paragraph EnsurePara()
        {
            if (Cur == null)
            {
                Cur = _factories.Count > 0 ? _factories.Peek()() : new Paragraph();
                ApplyPending(Cur);
                _add(Cur);
                LastEndsWithSpace = true;
            }
            return Cur;
        }

        public void Flush() { Cur = null; LastEndsWithSpace = true; }

        public void AddInline(Inline i)
        {
            EnsurePara().Inlines.Add(i);
            LastEndsWithSpace = i is LineBreak;
        }

        /// <summary>Добавляет текст. collapse — схлопывать пробелы как в HTML.</summary>
        public void AddText(string text, InlineStyle st, bool collapse = true)
        {
            if (string.IsNullOrEmpty(text)) return;
            if (collapse)
            {
                text = CollapseWs(text);
                if (LastEndsWithSpace) text = text.TrimStart(' ');
                if (text.Length == 0) return;
            }
            var run = MakeRun(text, st);
            EnsurePara().Inlines.Add(run);
            LastEndsWithSpace = text.EndsWith(" ");
        }

        public void AddLineBreak()
        {
            EnsurePara().Inlines.Add(new LineBreak());
            LastEndsWithSpace = true;
        }

        public static string CollapseWs(string s)
        {
            var sb = new System.Text.StringBuilder(s.Length);
            bool ws = false;
            foreach (var ch in s)
            {
                if (ch == ' ' || ch == '\n' || ch == '\r' || ch == '\t' || ch == '\f')
                {
                    if (!ws) sb.Append(' ');
                    ws = true;
                }
                else { sb.Append(ch); ws = false; }
            }
            return sb.ToString();
        }

        public static Run MakeRun(string text, InlineStyle st)
        {
            var r = new Run(text);
            if (st.Bold) r.FontWeight = FontWeights.Bold;
            if (st.Italic) r.FontStyle = FontStyles.Italic;
            if (st.Underline || st.Strike)
            {
                var tdc = new TextDecorationCollection();
                if (st.Underline) foreach (var d in TextDecorations.Underline) tdc.Add(d);
                if (st.Strike) foreach (var d in TextDecorations.Strikethrough) tdc.Add(d);
                r.TextDecorations = tdc;
            }
            if (st.Mono) r.FontFamily = new FontFamily("Consolas, Courier New");
            else if (!string.IsNullOrEmpty(st.Font)) { try { r.FontFamily = new FontFamily(st.Font + ", Segoe UI"); } catch { } }
            if (st.Sup) { r.BaselineAlignment = BaselineAlignment.Superscript; }
            if (st.Sub) { r.BaselineAlignment = BaselineAlignment.Subscript; }
            if (st.SmallCaps) r.Typography.Capitals = FontCapitals.SmallCaps;
            if (st.AbsSize > 0) r.FontSize = Math.Max(4, Math.Min(st.AbsSize, 200));
            if (st.Color != null) r.Foreground = st.Color;
            if (st.Highlight != null) r.Background = st.Highlight;
            return r;
        }

        /// <summary>Применяет относительный размер к уже созданному Run после вставки (FontSize наследуется).</summary>
        public static void ApplyRelativeSize(TextElement e, double factor, double baseSize)
        {
            if (factor > 0 && Math.Abs(factor - 1) > 0.01) e.FontSize = Math.Max(4, baseSize * factor);
        }

        public UIElement MakeImage(BitmapSource bmp, double desiredW = 0, double desiredH = 0)
        {
            double w = desiredW > 0 ? desiredW : bmp.PixelWidth;
            double h = desiredH > 0 ? desiredH : bmp.PixelHeight;
            if (w < 1 || h < 1) { w = bmp.PixelWidth; h = bmp.PixelHeight; }
            double k = Math.Min(1, Math.Min(MaxImageWidth / w, MaxImageHeight / h));
            var img = new Image
            {
                Source = bmp,
                Width = Math.Max(1, w * k),
                Height = Math.Max(1, h * k),
                Stretch = Stretch.Uniform,
                HorizontalAlignment = HorizontalAlignment.Center,
                SnapsToDevicePixels = true
            };
            RenderOptions.SetBitmapScalingMode(img, BitmapScalingMode.HighQuality);
            return img;
        }

        /// <summary>Вставляет изображение блоком (крупное) или в строку (мелкое).</summary>
        public void AddImage(BitmapSource bmp, double desiredW = 0, double desiredH = 0, bool forceBlock = false)
        {
            if (bmp == null) return;
            var el = MakeImage(bmp, desiredW, desiredH);
            var fe = (FrameworkElement)el;
            if (forceBlock || fe.Width > 140 || fe.Height > 90)
            {
                Add(new BlockUIContainer(el) { Margin = new Thickness(0, 6, 0, 6) });
            }
            else
            {
                EnsurePara().Inlines.Add(new InlineUIContainer(el) { BaselineAlignment = BaselineAlignment.Center });
                LastEndsWithSpace = false;
            }
        }

        public void PageBreak() { Flush(); PendingPageBreak = true; }

        public void Rule()
        {
            Add(new Paragraph
            {
                BorderBrush = new SolidColorBrush(Color.FromRgb(190, 190, 195)),
                BorderThickness = new Thickness(0, 0, 0, 1),
                Margin = new Thickness(0, 6, 0, 10),
                FontSize = 2
            });
        }

        public static Table NewTable()
        {
            return new Table
            {
                CellSpacing = 0,
                BorderBrush = new SolidColorBrush(Color.FromRgb(170, 170, 178)),
                BorderThickness = new Thickness(0.5),
                Margin = new Thickness(0, 6, 0, 10)
            };
        }

        public static TableCell NewCell(bool header)
        {
            var c = new TableCell
            {
                BorderBrush = new SolidColorBrush(Color.FromRgb(170, 170, 178)),
                BorderThickness = new Thickness(0.5),
                Padding = new Thickness(5, 3, 5, 3)
            };
            if (header) { c.FontWeight = FontWeights.Bold; c.Background = new SolidColorBrush(Color.FromRgb(236, 238, 245)); }
            return c;
        }

        /// <summary>Устанавливает колонки таблицы по максимальному числу ячеек.</summary>
        public static void FixColumns(Table t)
        {
            int max = 1;
            foreach (var g in t.RowGroups)
                foreach (var r in g.Rows)
                {
                    int cnt = 0;
                    foreach (var c in r.Cells) cnt += Math.Max(1, c.ColumnSpan);
                    max = Math.Max(max, cnt);
                }
            max = Math.Min(max, 64);
            t.Columns.Clear();
            for (int i = 0; i < max; i++) t.Columns.Add(new TableColumn { Width = new GridLength(1, GridUnitType.Star) });
            if (max > 6) t.FontSize = Math.Max(7, 14 - max * 0.5);
        }
    }
}
