using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;

namespace DocuNova.Core.Formats
{
    /// <summary>Узел упрощённого DOM.</summary>
    public sealed class HNode
    {
        public string Name;              // null — текстовый узел
        public string Text;
        public Dictionary<string, string> Attr = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        public List<HNode> Kids = new List<HNode>();
        public HNode Parent;

        public bool IsText => Name == null;
        public string A(string name) => Attr.TryGetValue(name, out var v) ? v : null;

        public HNode Find(string name)
        {
            if (Name == name) return this;
            foreach (var k in Kids) { var f = k.Find(name); if (f != null) return f; }
            return null;
        }

        public IEnumerable<HNode> All()
        {
            yield return this;
            foreach (var k in Kids) foreach (var x in k.All()) yield return x;
        }

        public string InnerText()
        {
            var sb = new StringBuilder();
            foreach (var n in All()) if (n.IsText) sb.Append(n.Text);
            return sb.ToString();
        }
    }

    /// <summary>
    /// Терпимый к ошибкам HTML/XHTML-парсер. Скрипты, стили, формы и встраиваемые объекты
    /// отбрасываются на этапе разбора — они никогда не выполняются.
    /// </summary>
    public static class HtmlParser
    {
        private static readonly HashSet<string> Void = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        { "br", "img", "hr", "meta", "link", "input", "col", "area", "base", "wbr", "source", "embed", "param", "track", "keygen", "mbp:pagebreak", "image" };

        private static readonly HashSet<string> Dropped = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        { "script", "style", "noscript", "iframe", "frame", "frameset", "object", "embed", "applet", "template", "head", "title", "form", "button", "select", "textarea", "input", "audio", "video", "canvas", "svg:script", "math" };

        private static readonly HashSet<string> RawText = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        { "script", "style", "textarea", "title", "noscript", "xmp" };

        private static readonly HashSet<string> AutoCloseSame = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        { "p", "li", "dt", "dd", "tr", "td", "th", "option" };

        private static readonly HashSet<string> BlockBreakers = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        { "div", "h1", "h2", "h3", "h4", "h5", "h6", "ul", "ol", "table", "blockquote", "pre", "section", "article", "hr", "dl", "header", "footer", "figure", "nav", "aside", "address", "center" };

        private static readonly HashSet<string> Scopes = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        { "ul", "ol", "table", "div", "body", "blockquote", "section", "td", "th", "dl", "html" };

        public static HNode Parse(string html)
        {
            var root = new HNode { Name = "#root" };
            if (string.IsNullOrEmpty(html)) return root;
            var stack = new List<HNode> { root };
            int i = 0, n = html.Length;
            var text = new StringBuilder();
            int dropDepth = 0;

            void FlushText()
            {
                if (text.Length == 0) return;
                if (dropDepth == 0)
                {
                    var t = WebUtility.HtmlDecode(text.ToString());
                    var top = stack[stack.Count - 1];
                    top.Kids.Add(new HNode { Text = t, Parent = top });
                }
                text.Clear();
            }

            while (i < n)
            {
                char c = html[i];
                if (c != '<') { text.Append(c); i++; continue; }

                // комментарии / CDATA / doctype / инструкции
                if (string.CompareOrdinal(html, i, "<!--", 0, 4) == 0)
                {
                    int e = html.IndexOf("-->", i + 4, StringComparison.Ordinal);
                    i = e < 0 ? n : e + 3; continue;
                }
                if (string.CompareOrdinal(html, i, "<![CDATA[", 0, 9) == 0)
                {
                    int e = html.IndexOf("]]>", i + 9, StringComparison.Ordinal);
                    int end = e < 0 ? n : e;
                    text.Append(WebUtility.HtmlEncode(html.Substring(i + 9, end - i - 9)));
                    i = e < 0 ? n : e + 3; continue;
                }
                if (i + 1 < n && (html[i + 1] == '!' || html[i + 1] == '?'))
                {
                    int e = html.IndexOf('>', i + 1);
                    i = e < 0 ? n : e + 1; continue;
                }

                bool closing = i + 1 < n && html[i + 1] == '/';
                int nameStart = i + (closing ? 2 : 1);
                int j = nameStart;
                while (j < n && !char.IsWhiteSpace(html[j]) && html[j] != '>' && html[j] != '/') j++;
                if (j == nameStart || !(char.IsLetter(html[nameStart])))
                {
                    text.Append(c); i++; continue; // одиночный «<» в тексте
                }
                string name = html.Substring(nameStart, j - nameStart).ToLowerInvariant();
                // убираем префикс пространства имён, кроме mbp:
                if (name.Contains(':') && !name.StartsWith("mbp:")) name = name.Substring(name.IndexOf(':') + 1);

                // разбор атрибутов
                var attrs = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                bool selfClose = false;
                int k = j;
                while (k < n && html[k] != '>')
                {
                    if (char.IsWhiteSpace(html[k])) { k++; continue; }
                    if (html[k] == '/') { selfClose = true; k++; continue; }
                    int an = k;
                    while (k < n && !char.IsWhiteSpace(html[k]) && html[k] != '=' && html[k] != '>' && html[k] != '/') k++;
                    string aname = html.Substring(an, k - an).ToLowerInvariant();
                    if (aname.Contains(':') && !aname.StartsWith("xml")) aname = aname.Substring(aname.IndexOf(':') + 1);
                    while (k < n && char.IsWhiteSpace(html[k])) k++;
                    string aval = "";
                    if (k < n && html[k] == '=')
                    {
                        k++;
                        while (k < n && char.IsWhiteSpace(html[k])) k++;
                        if (k < n && (html[k] == '"' || html[k] == '\''))
                        {
                            char qch = html[k++];
                            int vs = k;
                            while (k < n && html[k] != qch) k++;
                            aval = html.Substring(vs, Math.Min(k, n) - vs);
                            if (k < n) k++;
                        }
                        else
                        {
                            int vs = k;
                            while (k < n && !char.IsWhiteSpace(html[k]) && html[k] != '>') k++;
                            aval = html.Substring(vs, k - vs);
                        }
                    }
                    if (aname.Length > 0 && !attrs.ContainsKey(aname)) attrs[aname] = WebUtility.HtmlDecode(aval);
                }
                i = k < n ? k + 1 : n;

                FlushText();

                if (closing)
                {
                    if (Dropped.Contains(name))
                    {
                        if (dropDepth > 0) dropDepth--;
                        continue;
                    }
                    for (int s = stack.Count - 1; s > 0; s--)
                    {
                        if (stack[s].Name == name) { stack.RemoveRange(s, stack.Count - s); break; }
                    }
                    continue;
                }

                // элементы с «сырым» текстом пропускаем целиком
                if (RawText.Contains(name) && !selfClose)
                {
                    int e = html.IndexOf("</" + name, i, StringComparison.OrdinalIgnoreCase);
                    if (e < 0) { i = n; }
                    else { int gt = html.IndexOf('>', e); i = gt < 0 ? n : gt + 1; }
                    continue;
                }

                if (name == "body") dropDepth = 0; // незакрытый <head>
                if (Dropped.Contains(name))
                {
                    if (!selfClose && !Void.Contains(name)) dropDepth++;
                    continue;
                }
                if (dropDepth > 0) continue;

                // автозакрытие
                if (name == "tr")
                {
                    for (int s = stack.Count - 1; s > 0; s--)
                    {
                        var sn = stack[s].Name;
                        if (sn == "tr") { stack.RemoveRange(s, stack.Count - s); break; }
                        if (sn == "table" || sn == "tbody" || sn == "thead" || sn == "tfoot") break;
                    }
                }
                else if (name == "td" || name == "th")
                {
                    for (int s = stack.Count - 1; s > 0; s--)
                    {
                        var sn = stack[s].Name;
                        if (sn == "td" || sn == "th") { stack.RemoveRange(s, stack.Count - s); break; }
                        if (sn == "tr" || sn == "table") break;
                    }
                }
                else if (AutoCloseSame.Contains(name))
                {
                    for (int s = stack.Count - 1; s > 0; s--)
                    {
                        if (stack[s].Name == name) { stack.RemoveRange(s, stack.Count - s); break; }
                        if (Scopes.Contains(stack[s].Name)) break;
                    }
                }
                if (BlockBreakers.Contains(name))
                {
                    for (int s = stack.Count - 1; s > 0; s--)
                    {
                        if (stack[s].Name == "p") { stack.RemoveRange(s, stack.Count - s); break; }
                        if (Scopes.Contains(stack[s].Name)) break;
                    }
                }

                var parent = stack[stack.Count - 1];
                var node = new HNode { Name = name, Attr = attrs, Parent = parent };
                parent.Kids.Add(node);
                if (!selfClose && !Void.Contains(name)) stack.Add(node);
                if (stack.Count > 400) stack.RemoveAt(stack.Count - 1); // защита от слишком глубокой вложенности
            }
            FlushText();
            return root;
        }
    }
}
