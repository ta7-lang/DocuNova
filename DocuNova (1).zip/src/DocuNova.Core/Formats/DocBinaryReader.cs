using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Documents;

namespace DocuNova.Core.Formats
{
    /// <summary>Чтение составного файла OLE2 (Compound File Binary) — только чтение, с защитой от циклов.</summary>
    public sealed class CfbReader
    {
        private readonly byte[] _d;
        private readonly int _sec, _mini;
        private readonly int[] _fat;
        private int[] _miniFat;
        private byte[] _miniStream;
        private readonly uint _cutoff;
        public sealed class Entry { public string Name; public int Type; public int Start; public long Size; }
        public List<Entry> Entries { get; } = new List<Entry>();

        public static bool IsCfb(byte[] d) => d.Length > 512 && d[0] == 0xD0 && d[1] == 0xCF && d[2] == 0x11 && d[3] == 0xE0 && d[4] == 0xA1 && d[5] == 0xB1 && d[6] == 0x1A && d[7] == 0xE1;

        private static int I32(byte[] b, int o) => o + 4 <= b.Length ? BitConverter.ToInt32(b, o) : -2;
        private static int U16(byte[] b, int o) => o + 2 <= b.Length ? BitConverter.ToUInt16(b, o) : 0;

        public CfbReader(byte[] d)
        {
            if (!IsCfb(d)) throw new UnsupportedFormatException("Не составной файл OLE.");
            _d = d;
            int shift = U16(d, 0x1E);
            if (shift != 9 && shift != 12) throw new UnsupportedFormatException("Некорректный OLE-файл.");
            _sec = 1 << shift;
            _mini = 1 << U16(d, 0x20);
            int numFat = I32(d, 0x2C);
            int firstDir = I32(d, 0x30);
            _cutoff = (uint)I32(d, 0x38);
            int firstMiniFat = I32(d, 0x3C);
            int firstDifat = I32(d, 0x44);
            int numDifat = I32(d, 0x48);

            var fatSectors = new List<int>();
            for (int i = 0; i < 109 && fatSectors.Count < numFat; i++)
            {
                int s = I32(d, 0x4C + i * 4);
                if (s < 0) break;
                fatSectors.Add(s);
            }
            int dif = firstDifat, guard = 0;
            while (dif >= 0 && guard++ < Math.Max(0, numDifat) + 2 && guard < 10000)
            {
                int off = Off(dif);
                int per = _sec / 4 - 1;
                for (int i = 0; i < per && fatSectors.Count < numFat; i++)
                {
                    int s = I32(d, off + i * 4);
                    if (s >= 0) fatSectors.Add(s);
                }
                dif = I32(d, off + per * 4);
            }
            var fat = new List<int>();
            foreach (var fs in fatSectors)
            {
                int off = Off(fs);
                for (int i = 0; i < _sec / 4; i++) fat.Add(I32(d, off + i * 4));
            }
            _fat = fat.ToArray();

            // каталог
            var dir = Chain(firstDir, _fat, _sec, false);
            for (int o = 0; o + 128 <= dir.Length; o += 128)
            {
                int nameLen = U16(dir, o + 0x40);
                string name = nameLen >= 2 && nameLen <= 64 ? Encoding.Unicode.GetString(dir, o, nameLen - 2) : "";
                Entries.Add(new Entry { Name = name, Type = dir[o + 0x42], Start = I32(dir, o + 0x74), Size = BitConverter.ToUInt32(dir, o + 0x78) });
            }
            var root = Entries.FirstOrDefault(e => e.Type == 5);
            if (root != null)
            {
                _miniStream = Chain(root.Start, _fat, _sec, false, root.Size);
                _miniFat = ToInts(Chain(firstMiniFat, _fat, _sec, false));
            }
        }

        private int Off(int sector) => (sector + 1) * _sec;

        private static int[] ToInts(byte[] b)
        {
            var r = new int[b.Length / 4];
            for (int i = 0; i < r.Length; i++) r[i] = BitConverter.ToInt32(b, i * 4);
            return r;
        }

        private byte[] Chain(int start, int[] fat, int size, bool mini, long limit = long.MaxValue)
        {
            var ms = new System.IO.MemoryStream();
            int s = start, guard = 0;
            var src = mini ? _miniStream : _d;
            while (s >= 0 && s < fat.Length + (mini ? 0 : 1) && guard++ < 2_000_000)
            {
                int off = mini ? s * size : Off(s);
                if (off < 0 || off >= src.Length) break;
                int n = Math.Min(size, src.Length - off);
                ms.Write(src, off, n);
                if (ms.Length >= limit) break;
                if (s >= fat.Length) break;
                s = fat[s];
            }
            var arr = ms.ToArray();
            if (limit != long.MaxValue && arr.Length > limit) Array.Resize(ref arr, (int)limit);
            return arr;
        }

        public bool Has(string name) => Entries.Any(e => string.Equals(e.Name, name, StringComparison.OrdinalIgnoreCase));

        public byte[] Stream(string name)
        {
            var e = Entries.FirstOrDefault(x => x.Type == 2 && string.Equals(x.Name, name, StringComparison.OrdinalIgnoreCase));
            if (e == null) return null;
            if (e.Size > SafeIO.MaxZipEntry) throw new UnsupportedFormatException("Поток слишком большой.");
            if (e.Size < _cutoff && _miniStream != null && _miniFat != null)
                return Chain(e.Start, _miniFat, _mini, true, e.Size);
            return Chain(e.Start, _fat, _sec, false, e.Size);
        }
    }

    /// <summary>Microsoft Word 97–2003 (.doc): извлечение текста. Макросы не выполняются.</summary>
    public static class DocBinaryReader
    {
        public static FlowResult Read(byte[] data, ReflowSettings s)
        {
            var cfb = new CfbReader(data);
            var wd = cfb.Stream("WordDocument");
            if (wd == null)
            {
                if (cfb.Has("Workbook") || cfb.Has("Book")) throw new UnsupportedFormatException("Это книга Excel 97–2003 (.xls). Сохраните её как .xlsx для просмотра.");
                if (cfb.Has("PowerPoint Document")) throw new UnsupportedFormatException("Это презентация PowerPoint 97–2003 (.ppt). Сохраните её как .pptx для просмотра.");
                if (cfb.Has("EncryptedPackage")) throw new UnsupportedFormatException("Документ Office зашифрован паролем — откройте его в Word и сохраните без пароля.");
                throw new UnsupportedFormatException("Составной файл не содержит документа Word.");
            }
            if (BitConverter.ToUInt16(wd, 0) != 0xA5EC) throw new UnsupportedFormatException("Некорректный документ Word.");
            int flags = BitConverter.ToUInt16(wd, 0x0A);
            if ((flags & 0x0100) != 0) throw new UnsupportedFormatException("Документ Word зашифрован паролем.");
            var table = cfb.Stream((flags & 0x0200) != 0 ? "1Table" : "0Table") ?? throw new UnsupportedFormatException("Документ Word повреждён (нет таблицы).");
            int ccpText = BitConverter.ToInt32(wd, 0x4C);
            int fcClx = BitConverter.ToInt32(wd, 0x01A2);
            int lcbClx = BitConverter.ToInt32(wd, 0x01A6);
            SafeIO.EnsureInit();
            var cp1252 = Encoding.GetEncoding(1252);
            var sb = new StringBuilder();
            if (fcClx > 0 && lcbClx > 0 && fcClx + lcbClx <= table.Length)
            {
                int pos = fcClx, end = fcClx + lcbClx;
                while (pos < end)
                {
                    byte t = table[pos];
                    if (t == 1) { int cb = BitConverter.ToUInt16(table, pos + 1); pos += 3 + cb; continue; }
                    if (t != 2) break;
                    int lcb = BitConverter.ToInt32(table, pos + 1);
                    int plc = pos + 5;
                    int n = (lcb - 4) / 12;
                    for (int i = 0; i < n && sb.Length < 50_000_000; i++)
                    {
                        int cpStart = BitConverter.ToInt32(table, plc + i * 4);
                        int cpEnd = BitConverter.ToInt32(table, plc + (i + 1) * 4);
                        int pcd = plc + (n + 1) * 4 + i * 8;
                        uint fc = BitConverter.ToUInt32(table, pcd + 2);
                        int len = cpEnd - cpStart;
                        if (len <= 0) continue;
                        bool compressed = (fc & 0x40000000) != 0;
                        if (compressed)
                        {
                            int off = (int)((fc & 0x3FFFFFFF) / 2);
                            if (off + len > wd.Length) len = Math.Max(0, wd.Length - off);
                            sb.Append(cp1252.GetString(wd, off, len));
                        }
                        else
                        {
                            int off = (int)fc;
                            if (off + len * 2 > wd.Length) len = Math.Max(0, (wd.Length - off) / 2);
                            sb.Append(Encoding.Unicode.GetString(wd, off, len * 2));
                        }
                    }
                    break;
                }
            }
            if (sb.Length == 0)
            {
                // запасной вариант: текст без таблицы кусков (старые файлы)
                int fcMin = BitConverter.ToInt32(wd, 0x18), fcMac = BitConverter.ToInt32(wd, 0x1C);
                if (fcMin > 0 && fcMac > fcMin && fcMac <= wd.Length) sb.Append(cp1252.GetString(wd, fcMin, fcMac - fcMin));
            }
            string text = sb.ToString();
            if (ccpText > 0 && ccpText < text.Length) text = text.Substring(0, ccpText);
            text = StripFields(text);

            var r = new FlowResult();
            r.PageSize = new Size(793.7, 1122.5);
            r.Padding = new Thickness(90, 76, 72, 76);
            r.Doc.FontFamily = new System.Windows.Media.FontFamily("Times New Roman, Segoe UI");
            r.Doc.FontSize = 16;
            var sink = new FlowSink(r.Doc.Blocks) { MaxImageWidth = 600 };
            var para = new StringBuilder();
            int count = 0;
            foreach (char ch in text)
            {
                switch (ch)
                {
                    case '\r':
                        AddPara(sink, para.ToString()); para.Clear(); count++;
                        break;
                    case '\v': para.Append('\n'); break;
                    case '\f': AddPara(sink, para.ToString()); para.Clear(); sink.PageBreak(); break;
                    case '\a': para.Append('\t'); break;
                    case '\u001E': para.Append('-'); break;
                    case '\u001F': case '\u0001': case '\u0008': case '\u0002': case '\u0005': break;
                    default: if (ch >= ' ' || ch == '\t') para.Append(ch); break;
                }
                if (s.Light && count > 150) break;
            }
            AddPara(sink, para.ToString());
            sink.Flush();

            var info = new InfoSection("Документ Word 97–2003");
            info.Add("Формат", "Двоичный Word (.doc), версия FIB " + BitConverter.ToUInt16(wd, 2));
            info.Add("Символов текста", ccpText);
            r.Info.Add(info);
            r.Notices.Add("Документ Word 97–2003 показан в текстовом режиме: форматирование и картинки старого формата не отображаются.");
            Scan(cfb, r.Security);
            return r;
        }

        private static void AddPara(FlowSink sink, string t)
        {
            sink.Begin(() => new Paragraph { Margin = new Thickness(0, 0, 0, 6) });
            var lines = t.Split('\n');
            for (int i = 0; i < lines.Length; i++)
            {
                if (i > 0) sink.AddLineBreak();
                if (lines[i].Length > 0) sink.AddText(lines[i].Replace("\t", "    "), new InlineStyle(), false);
            }
            sink.End();
            if (t.Length == 0) sink.Add(new Paragraph { Margin = new Thickness(0, 0, 0, 6) });
        }

        /// <summary>Удаляет коды полей: \x13 код \x14 результат \x15 → результат.</summary>
        private static string StripFields(string s)
        {
            var sb = new StringBuilder(s.Length);
            var stack = new Stack<bool>(); // true — сейчас в коде поля
            foreach (var ch in s)
            {
                if (ch == '\u0013') { stack.Push(true); continue; }
                if (ch == '\u0014') { if (stack.Count > 0) { stack.Pop(); stack.Push(false); } continue; }
                if (ch == '\u0015') { if (stack.Count > 0) stack.Pop(); continue; }
                if (stack.Count > 0 && stack.Peek()) continue;
                sb.Append(ch);
            }
            return sb.ToString();
        }

        public static void Scan(byte[] data, List<SecurityFinding> list)
        {
            try { Scan(new CfbReader(data), list); } catch { }
        }

        private static void Scan(CfbReader cfb, List<SecurityFinding> list)
        {
            if (cfb.Has("Macros") || cfb.Has("VBA") || cfb.Has("_VBA_PROJECT") || cfb.Has("_VBA_PROJECT_CUR"))
                list.Add(new SecurityFinding(Severity.Danger, "Документ содержит макросы VBA", "Макросы — частый способ распространения вирусов. В DocuNova они никогда не выполняются."));
            if (cfb.Has("ObjectPool"))
                list.Add(new SecurityFinding(Severity.Warning, "Встроенные OLE-объекты", "Объекты не открываются и не запускаются."));
        }
    }
}
