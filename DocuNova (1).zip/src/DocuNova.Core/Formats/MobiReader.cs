using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Media.Imaging;

namespace DocuNova.Core.Formats
{
    /// <summary>
    /// MOBI / AZW / AZW3 / PRC / PDB (PalmDOC). Поддерживаются сжатия PalmDOC и HUFF/CDIC.
    /// Файлы с DRM не открываются.
    /// </summary>
    public static class MobiReader
    {
        private sealed class Book
        {
            public byte[] Data;
            public List<(int start, int end)> Records = new List<(int, int)>();
            public int Compression, TextLength, TextRecords, Encryption, Encoding = 1252, FirstImage = -1, HuffOffset, HuffCount, ExtraFlags, MobiType;
            public string Name, FullName;
            public Dictionary<int, List<byte[]>> Exth = new Dictionary<int, List<byte[]>>();
            public bool IsMobi;

            public byte[] Rec(int i)
            {
                if (i < 0 || i >= Records.Count) return null;
                var (s, e) = Records[i];
                if (s < 0 || e > Data.Length || e < s) return null;
                var b = new byte[e - s];
                Buffer.BlockCopy(Data, s, b, 0, b.Length);
                return b;
            }
            public string ExthStr(int type, Encoding enc)
            {
                if (!Exth.TryGetValue(type, out var l)) return null;
                return string.Join("; ", l.Select(x => enc.GetString(x).Trim('\0', ' ')));
            }
            public int ExthInt(int type)
            {
                if (!Exth.TryGetValue(type, out var l) || l[0].Length < 4) return -1;
                return BE32(l[0], 0);
            }
        }

        private static int BE16(byte[] b, int o) => o + 2 <= b.Length ? (b[o] << 8) | b[o + 1] : 0;
        private static int BE32(byte[] b, int o) => o + 4 <= b.Length ? (b[o] << 24) | (b[o + 1] << 16) | (b[o + 2] << 8) | b[o + 3] : 0;

        public static bool IsMobi(byte[] d) => d.Length > 78 && (SafeIO.StartsWith(d, "BOOKMOBI", 60) || SafeIO.StartsWith(d, "TEXtREAd", 60));

        private static Book Parse(byte[] data)
        {
            if (!IsMobi(data)) throw new UnsupportedFormatException("Это не MOBI/PDB-файл.");
            var b = new Book { Data = data };
            b.Name = Encoding.ASCII.GetString(data, 0, 32).TrimEnd('\0');
            b.IsMobi = SafeIO.StartsWith(data, "BOOKMOBI", 60);
            int n = BE16(data, 76);
            if (n <= 0 || n > 65535 || 78 + n * 8 > data.Length) throw new UnsupportedFormatException("MOBI повреждён (таблица записей).");
            var offs = new int[n];
            for (int i = 0; i < n; i++) offs[i] = BE32(data, 78 + i * 8);
            for (int i = 0; i < n; i++)
            {
                int s = offs[i], e = i + 1 < n ? offs[i + 1] : data.Length;
                b.Records.Add((s, Math.Max(s, Math.Min(e, data.Length))));
            }
            var r0 = b.Rec(0) ?? throw new UnsupportedFormatException("MOBI повреждён.");
            b.Compression = BE16(r0, 0);
            b.TextLength = BE32(r0, 4);
            b.TextRecords = BE16(r0, 8);
            b.Encryption = BE16(r0, 12);
            if (b.IsMobi && r0.Length > 24 && SafeIO.StartsWith(r0, "MOBI", 16))
            {
                int hlen = BE32(r0, 20);
                b.MobiType = BE32(r0, 24);
                b.Encoding = BE32(r0, 28);
                int fnOff = BE32(r0, 84), fnLen = BE32(r0, 88);
                if (fnOff > 0 && fnLen > 0 && fnOff + fnLen <= r0.Length) b.FullName = Enc(b).GetString(r0, fnOff, fnLen);
                b.FirstImage = BE32(r0, 108);
                b.HuffOffset = BE32(r0, 112);
                b.HuffCount = BE32(r0, 116);
                int exthFlags = BE32(r0, 128);
                if (hlen >= 0xE4 && r0.Length >= 0xF4) b.ExtraFlags = BE16(r0, 0xF2);
                if ((exthFlags & 0x40) != 0)
                {
                    int eo = 16 + hlen;
                    if (eo + 12 <= r0.Length && SafeIO.StartsWith(r0, "EXTH", eo))
                    {
                        int count = BE32(r0, eo + 8);
                        int p = eo + 12;
                        for (int i = 0; i < count && p + 8 <= r0.Length; i++)
                        {
                            int type = BE32(r0, p), len = BE32(r0, p + 4);
                            if (len < 8 || p + len > r0.Length) break;
                            var val = new byte[len - 8];
                            Buffer.BlockCopy(r0, p + 8, val, 0, val.Length);
                            if (!b.Exth.TryGetValue(type, out var l)) b.Exth[type] = l = new List<byte[]>();
                            l.Add(val);
                            p += len;
                        }
                    }
                }
            }
            return b;
        }

        private static Encoding Enc(Book b)
        {
            SafeIO.EnsureInit();
            try { return b.Encoding == 65001 ? Encoding.UTF8 : Encoding.GetEncoding(b.Encoding == 0 ? 1252 : b.Encoding); }
            catch { return Encoding.GetEncoding(1252); }
        }

        private static int TrailingSize(byte[] rec, int size, int flags)
        {
            for (int bit = 1; bit < 16; bit++)
            {
                if ((flags & (1 << bit)) == 0) continue;
                int res = 0, shift = 0, s = size;
                while (s > 0)
                {
                    int v = rec[s - 1];
                    res |= (v & 0x7F) << shift;
                    shift += 7; s--;
                    if ((v & 0x80) != 0 || shift >= 28 || s == 0) break;
                }
                size -= res;
                if (size <= 0) return 0;
            }
            if ((flags & 1) != 0 && size > 0)
            {
                size -= (rec[size - 1] & 3) + 1;
            }
            return Math.Max(0, size);
        }

        private static byte[] PalmDoc(byte[] src, int len)
        {
            var o = new List<byte>(len * 2);
            int i = 0;
            while (i < len)
            {
                int c = src[i++];
                if (c == 0 || (c >= 9 && c <= 0x7F)) o.Add((byte)c);
                else if (c >= 1 && c <= 8) { for (int k = 0; k < c && i < len; k++) o.Add(src[i++]); }
                else if (c >= 0xC0) { o.Add(0x20); o.Add((byte)(c ^ 0x80)); }
                else
                {
                    if (i >= len) break;
                    int v = (c << 8) | src[i++];
                    int dist = (v >> 3) & 0x7FF, cnt = (v & 7) + 3;
                    if (dist == 0 || dist > o.Count) continue;
                    int from = o.Count - dist;
                    for (int k = 0; k < cnt; k++) o.Add(o[from + k]);
                }
                if (o.Count > 64 * 1024 * 4) break;
            }
            return o.ToArray();
        }

        // ----- HUFF/CDIC -----
        private sealed class Huff
        {
            private readonly (int codelen, bool term, ulong maxcode)[] _dict1 = new (int, bool, ulong)[256];
            private readonly ulong[] _min = new ulong[33], _max = new ulong[33];
            private readonly List<(byte[] data, bool done)> _dict = new List<(byte[], bool)>();
            private int _depth;

            public Huff(byte[] huff, IEnumerable<byte[]> cdics)
            {
                if (!SafeIO.StartsWith(huff, "HUFF")) throw new UnsupportedFormatException("Некорректная запись HUFF.");
                int off1 = BE32(huff, 8), off2 = BE32(huff, 12);
                for (int i = 0; i < 256; i++)
                {
                    uint v = (uint)BE32(huff, off1 + i * 4);
                    int codelen = (int)(v & 0x1F); bool term = (v & 0x80) != 0; ulong maxcode = v >> 8;
                    if (codelen == 0) codelen = 1;
                    maxcode = ((maxcode + 1) << (32 - codelen)) - 1;
                    _dict1[i] = (codelen, term, maxcode);
                }
                for (int codelen = 1; codelen <= 32; codelen++)
                {
                    ulong mincode = (uint)BE32(huff, off2 + (codelen - 1) * 8);
                    ulong maxcode = (uint)BE32(huff, off2 + (codelen - 1) * 8 + 4);
                    _min[codelen] = mincode << (32 - codelen);
                    _max[codelen] = ((maxcode + 1) << (32 - codelen)) - 1;
                }
                foreach (var cdic in cdics)
                {
                    if (cdic == null || !SafeIO.StartsWith(cdic, "CDIC")) continue;
                    int phrases = BE32(cdic, 8), bits = BE32(cdic, 12);
                    int n = Math.Min(1 << Math.Min(bits, 20), phrases - _dict.Count);
                    for (int i = 0; i < n; i++)
                    {
                        int off = BE16(cdic, 16 + i * 2);
                        int blen = BE16(cdic, 16 + off);
                        int len = blen & 0x7FFF;
                        int start = 18 + off;
                        if (start + len > cdic.Length) len = Math.Max(0, cdic.Length - start);
                        var slice = new byte[len];
                        if (len > 0) Buffer.BlockCopy(cdic, start, slice, 0, len);
                        _dict.Add((slice, (blen & 0x8000) != 0));
                    }
                }
            }

            public byte[] Unpack(byte[] data)
            {
                if (++_depth > 32) { _depth--; return Array.Empty<byte>(); }
                var ms = new MemoryStream();
                long bitsleft = data.Length * 8L;
                var buf = new byte[data.Length + 8];
                Buffer.BlockCopy(data, 0, buf, 0, data.Length);
                int pos = 0;
                ulong x = Q(buf, pos);
                int n = 32;
                while (true)
                {
                    if (n <= 0) { pos += 4; x = Q(buf, pos); n += 32; }
                    ulong code = (x >> n) & 0xFFFFFFFFUL;
                    var (codelen, term, maxcode) = _dict1[code >> 24];
                    if (!term)
                    {
                        while (codelen < 32 && code < _min[codelen]) codelen++;
                        maxcode = _max[codelen];
                    }
                    n -= codelen;
                    bitsleft -= codelen;
                    if (bitsleft < 0) break;
                    int r = (int)((maxcode - code) >> (32 - codelen));
                    if (r < 0 || r >= _dict.Count) break;
                    var (slice, done) = _dict[r];
                    if (!done)
                    {
                        _dict[r] = (Array.Empty<byte>(), true);
                        slice = Unpack(slice);
                        _dict[r] = (slice, true);
                    }
                    ms.Write(slice, 0, slice.Length);
                    if (ms.Length > 1 << 20) break;
                }
                _depth--;
                return ms.ToArray();
            }

            private static ulong Q(byte[] b, int o)
            {
                ulong v = 0;
                for (int i = 0; i < 8; i++) v = (v << 8) | (o + i < b.Length ? b[o + i] : (byte)0);
                return v;
            }
        }

        private static string ExtractText(Book b, bool light)
        {
            if (b.Encryption != 0) throw new UnsupportedFormatException("Книга защищена DRM — открыть её нельзя.");
            Huff huff = null;
            if (b.Compression == 17480)
            {
                var cd = new List<byte[]>();
                for (int i = 1; i < b.HuffCount; i++) cd.Add(b.Rec(b.HuffOffset + i));
                huff = new Huff(b.Rec(b.HuffOffset), cd);
            }
            else if (b.Compression != 1 && b.Compression != 2)
                throw new UnsupportedFormatException("Неизвестный тип сжатия MOBI: " + b.Compression);

            var all = new MemoryStream();
            int limit = light ? Math.Min(b.TextRecords, 6) : b.TextRecords;
            for (int i = 1; i <= limit; i++)
            {
                var rec = b.Rec(i);
                if (rec == null) break;
                int size = b.IsMobi ? TrailingSize(rec, rec.Length, b.ExtraFlags) : rec.Length;
                byte[] chunk;
                if (b.Compression == 2) chunk = PalmDoc(rec, size);
                else if (b.Compression == 17480) { var t = new byte[size]; Buffer.BlockCopy(rec, 0, t, 0, size); chunk = huff.Unpack(t); }
                else { chunk = new byte[size]; Buffer.BlockCopy(rec, 0, chunk, 0, size); }
                all.Write(chunk, 0, chunk.Length);
                if (all.Length > 200L * 1024 * 1024) break;
            }
            return Enc(b).GetString(all.ToArray());
        }

        private static byte[] ImageRecord(Book b, int idx1Based)
        {
            if (b.FirstImage <= 0 || idx1Based <= 0) return null;
            var rec = b.Rec(b.FirstImage + idx1Based - 1);
            return rec != null && SafeIO.LooksLikeImage(rec) ? rec : null;
        }

        public static BitmapSource ExtractCover(byte[] data, out string title, out string author)
        {
            var b = Parse(data);
            var enc = Enc(b);
            title = b.ExthStr(503, enc) ?? b.FullName ?? b.Name;
            author = b.ExthStr(100, enc);
            int off = b.ExthInt(201);
            if (off < 0) off = b.ExthInt(202);
            var img = off >= 0 ? ImageRecord(b, off + 1) : null;
            return img != null ? SafeIO.LoadImage(img, 2600) : null;
        }

        public static FlowResult Read(byte[] data, ReflowSettings s)
        {
            var b = Parse(data);
            var enc = Enc(b);
            var r = new FlowResult();
            r.Title = b.ExthStr(503, enc) ?? b.FullName ?? b.Name;
            r.Author = b.ExthStr(100, enc);
            var info = new InfoSection(b.IsMobi ? "Книга (MOBI/AZW)" : "Документ PalmDOC");
            info.Add("Название", r.Title);
            info.Add("Автор", r.Author);
            info.Add("Издательство", b.ExthStr(101, enc));
            info.Add("Описание", Clean(b.ExthStr(103, enc)));
            info.Add("ISBN", b.ExthStr(104, enc));
            info.Add("Темы", b.ExthStr(105, enc));
            info.Add("Дата публикации", b.ExthStr(106, enc));
            info.Add("Язык", b.ExthStr(524, enc));
            info.Add("Права", b.ExthStr(109, enc));
            info.Add("Сжатие", b.Compression == 2 ? "PalmDOC" : b.Compression == 17480 ? "HUFF/CDIC" : "нет");
            info.Add("Кодировка", b.Encoding == 65001 ? "UTF-8" : "Windows-" + b.Encoding);
            info.Add("Записей в файле", b.Records.Count);
            info.Add("Формат KF8 (AZW3)", b.Exth.ContainsKey(121) || b.MobiType == 248 ? "Да" : "Нет");
            r.Info.Add(info);

            int coff = b.ExthInt(201);
            if (coff >= 0) { var ci = ImageRecord(b, coff + 1); if (ci != null) r.Cover = SafeIO.LoadImage(ci, 2000); }

            var text = ExtractText(b, s.Light);
            if (!b.IsMobi || (text.IndexOf('<') < 0))
            {
                // простой текст PalmDOC
                var lines = text.Replace("\r\n", "\n").Split('\n');
                text = "<p>" + string.Join("</p><p>", lines.Select(l => System.Net.WebUtility.HtmlEncode(l))) + "</p>";
            }
            var sink = new FlowSink(r.Doc.Blocks)
            {
                MaxImageWidth = s.PageWidth - s.Margin * 2 - 10,
                MaxImageHeight = s.PageHeight - s.Margin * 2 - 30
            };
            var dom = HtmlParser.Parse(text);
            var conv = new HtmlToFlow(sink, n =>
            {
                var ri = n.A("recindex");
                if (ri != null && int.TryParse(ri, out var idx)) return ImageRecord(b, idx);
                var src = n.A("src") ?? "";
                var m = Regex.Match(src, @"kindle:embed:([0-9A-Va-v]+)");
                if (m.Success) return ImageRecord(b, FromBase32(m.Groups[1].Value));
                return null;
            })
            { BaseFontSize = s.FontSize };
            conv.Convert(dom);
            if (r.Doc.Blocks.Count == 0) throw new UnsupportedFormatException("Не удалось извлечь текст книги.");
            r.Toc.AddRange(conv.HeadingToc.Where(t => t.Level <= 1).Take(500));
            return r;
        }

        private static int FromBase32(string s)
        {
            int v = 0;
            foreach (var ch in s.ToUpperInvariant())
            {
                int d = ch >= '0' && ch <= '9' ? ch - '0' : ch - 'A' + 10;
                v = v * 32 + d;
            }
            return v;
        }

        private static string Clean(string s)
        {
            if (string.IsNullOrWhiteSpace(s)) return null;
            var t = FlowSink.CollapseWs(HtmlParser.Parse(s).InnerText()).Trim();
            return t.Length > 600 ? t.Substring(0, 600) + "…" : t;
        }
    }
}
