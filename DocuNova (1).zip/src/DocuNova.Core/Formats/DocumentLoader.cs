using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using DocuNova.Core.Formats;

namespace DocuNova.Core
{
    /// <summary>Определение формата по содержимому (а не только по расширению) и загрузка документа.</summary>
    public static class DocumentLoader
    {
        public sealed class FormatInfo
        {
            public string Code, Name;
            public string[] Ext;
            public FormatInfo(string code, string name, params string[] ext) { Code = code; Name = name; Ext = ext; }
        }

        public static readonly FormatInfo[] Formats =
        {
            new FormatInfo("pdf", "PDF", ".pdf"),
            new FormatInfo("epub", "EPUB (электронная книга)", ".epub"),
            new FormatInfo("fb2", "FictionBook (FB2)", ".fb2", ".fbz", ".fb2.zip"),
            new FormatInfo("mobi", "Kindle MOBI / AZW", ".mobi", ".azw", ".azw3", ".prc", ".pdb", ".kf8"),
            new FormatInfo("docx", "Документ Word (DOCX)", ".docx", ".docm", ".dotx", ".dotm"),
            new FormatInfo("doc", "Документ Word 97–2003 (DOC)", ".doc", ".dot"),
            new FormatInfo("odt", "OpenDocument (ODT/ODS/ODP)", ".odt", ".ott", ".ods", ".odp", ".fodt"),
            new FormatInfo("rtf", "Rich Text (RTF)", ".rtf"),
            new FormatInfo("xlsx", "Книга Excel (XLSX)", ".xlsx", ".xlsm"),
            new FormatInfo("pptx", "Презентация PowerPoint (PPTX)", ".pptx", ".ppsx", ".pptm"),
            new FormatInfo("xps", "XPS", ".xps"),
            new FormatInfo("html", "Веб-страница (HTML)", ".html", ".htm", ".xhtml", ".mht"),
            new FormatInfo("md", "Markdown", ".md", ".markdown"),
            new FormatInfo("csv", "Таблица CSV/TSV", ".csv", ".tsv"),
            new FormatInfo("cbz", "Комикс (CBZ)", ".cbz"),
            new FormatInfo("image", "Изображение / многостраничный TIFF", ".tif", ".tiff", ".jpg", ".jpeg", ".png", ".bmp", ".gif", ".webp", ".jxr", ".wdp"),
            new FormatInfo("txt", "Текст", ".txt", ".text", ".log", ".ini", ".cfg", ".conf", ".json", ".xml", ".yaml", ".yml", ".nfo", ".srt", ".vtt", ".tex", ".cs", ".js", ".ts", ".py", ".java", ".cpp", ".c", ".h", ".css", ".sql", ".bat", ".ps1", ".sh", ".reg", ".toml", ".properties"),
        };

        /// <summary>Расширения, для которых регистрируются эскизы и ассоциации (без кода и картинок).</summary>
        public static readonly string[] DocumentExtensions =
        {
            ".pdf", ".epub", ".fb2", ".fbz", ".mobi", ".azw", ".azw3", ".prc", ".docx", ".docm", ".doc", ".odt", ".ods", ".odp",
            ".rtf", ".xlsx", ".pptx", ".xps", ".md", ".cbz", ".txt", ".html", ".htm", ".csv", ".tif", ".tiff"
        };

        public static string OpenFileFilter()
        {
            var all = string.Join(";", Formats.SelectMany(f => f.Ext).Distinct().Select(e => "*" + e));
            var parts = new List<string> { "Все поддерживаемые документы|" + all };
            foreach (var f in Formats) parts.Add(f.Name + "|" + string.Join(";", f.Ext.Select(e => "*" + e)));
            parts.Add("Все файлы|*.*");
            return string.Join("|", parts);
        }

        public static string ExtensionToCode(string ext)
        {
            if (string.IsNullOrEmpty(ext)) return null;
            foreach (var f in Formats) if (f.Ext.Contains(ext.ToLowerInvariant())) return f.Code;
            return null;
        }

        public static string NameOf(string code) => Formats.FirstOrDefault(f => f.Code == code)?.Name ?? code;

        /// <summary>Определяет формат по сигнатуре содержимого.</summary>
        public static string Detect(byte[] d, string ext)
        {
            ext = (ext ?? "").ToLowerInvariant();
            if (d.Length == 0) return ExtensionToCode(ext) ?? "txt";
            int scan = Math.Min(d.Length, 1024);
            for (int i = 0; i + 4 < scan; i++)
                if (d[i] == '%' && d[i + 1] == 'P' && d[i + 2] == 'D' && d[i + 3] == 'F') return "pdf";
            if (SafeIO.StartsWith(d, "{\\rtf")) return "rtf";
            if (MobiReader.IsMobi(d)) return "mobi";
            if (SafeIO.StartsWith(d, "AT&TFORM")) return "djvu";
            if (CfbReader.IsCfb(d)) return "doc";
            if (d.Length > 4 && d[0] == 'P' && d[1] == 'K' && d[2] == 3 && d[3] == 4)
            {
                try
                {
                    using (var z = new SafeZip(d))
                    {
                        var mime = z.Exists("mimetype") ? Encoding.ASCII.GetString(z.Read("mimetype")).Trim() : "";
                        if (mime == "application/epub+zip" || z.Exists("META-INF/container.xml") && z.Names.Any(n => n.EndsWith(".opf", StringComparison.OrdinalIgnoreCase))) return "epub";
                        if (mime.StartsWith("application/vnd.oasis.opendocument")) return "odt";
                        if (z.Names.Any(n => n.StartsWith("word/", StringComparison.OrdinalIgnoreCase) && n.EndsWith("document.xml", StringComparison.OrdinalIgnoreCase))) return "docx";
                        if (z.Exists("xl/workbook.xml")) return "xlsx";
                        if (z.Exists("ppt/presentation.xml")) return "pptx";
                        if (z.Names.Any(n => n.EndsWith(".fdseq", StringComparison.OrdinalIgnoreCase) || n.EndsWith(".fdoc", StringComparison.OrdinalIgnoreCase))) return "xps";
                        if (z.Names.Any(n => n.EndsWith(".fb2", StringComparison.OrdinalIgnoreCase))) return "fb2";
                        if (z.Exists("content.xml")) return "odt";
                        if (z.Entries.Any(e => IsImageName(e.FullName))) return "cbz";
                    }
                }
                catch { }
                return "zip";
            }
            if (SafeIO.LooksLikeImage(d)) return "image";
            if (d.Length > 4 && d[0] == 'R' && d[1] == 'a' && d[2] == 'r' && d[3] == '!') return "rar";
            if (d.Length > 6 && d[0] == '7' && d[1] == 'z' && d[2] == 0xBC) return "7z";

            // текстовые форматы
            var head = SafeIO.DecodeText(d, 4096);
            var low = head.TrimStart('\uFEFF', ' ', '\r', '\n', '\t').ToLowerInvariant();
            if (low.Contains("<fictionbook")) return "fb2";
            if (ext == ".md" || ext == ".markdown") return "md";
            if (ext == ".csv" || ext == ".tsv") return "csv";
            if (low.StartsWith("<!doctype html") || low.StartsWith("<html") || ((ext == ".htm" || ext == ".html" || ext == ".xhtml" || ext == ".mht") && low.Contains("<")))
                return "html";
            if (low.Contains("<html") && (low.StartsWith("<?xml") || low.StartsWith("<!doctype"))) return "html";
            if (LooksBinary(d)) return "binary";
            return "txt";
        }

        private static bool LooksBinary(byte[] d)
        {
            int n = Math.Min(d.Length, 8192), ctrl = 0;
            if (n >= 2 && ((d[0] == 0xFF && d[1] == 0xFE) || (d[0] == 0xFE && d[1] == 0xFF))) return false;
            for (int i = 0; i < n; i++)
            {
                byte b = d[i];
                if (b == 0) return true;
                if (b < 8 || (b > 13 && b < 32 && b != 27)) ctrl++;
            }
            return ctrl > n / 20;
        }

        public static bool IsImageName(string n)
        {
            var e = Path.GetExtension(n ?? "").ToLowerInvariant();
            return e == ".jpg" || e == ".jpeg" || e == ".png" || e == ".gif" || e == ".bmp" || e == ".webp" || e == ".tif" || e == ".tiff";
        }

        /// <summary>
        /// Загружает документ. Вызывать в UI-потоке (STA): перетекаемые форматы строятся средствами WPF.
        /// </summary>
        /// <param name="file">Открытый файл: для PDF данные будут читаться с диска по мере надобности,
        /// без хранения всего файла в памяти. При успешной загрузке PDF владение файлом переходит к документу.</param>
        /// <param name="deferSecurityScan">data — только начало PDF-файла; полный анализ безопасности выполнит вызывающий код в фоне.</param>
        public static DocumentBase Load(string path, byte[] data, ReflowSettings s, string password = null, SharedFile file = null, bool deferSecurityScan = false)
        {
            SafeIO.EnsureInit();
            SecurityScanner.RejectExecutables(data, path);
            var ext = Path.GetExtension(path ?? "").ToLowerInvariant();
            if ((path ?? "").EndsWith(".fb2.zip", StringComparison.OrdinalIgnoreCase)) ext = ".fbz";
            var code = Detect(data, ext);
            DocumentBase doc;
            switch (code)
            {
                case "pdf": doc = file != null ? PdfDoc.Open(file, password, s.Light) : PdfDoc.Open(data, password, s.Light); break;
                case "epub": doc = EpubReader.Read(data, s).Build(s); break;
                case "fb2": doc = Fb2Reader.Read(data, s).Build(s); break;
                case "mobi": doc = MobiReader.Read(data, s).Build(s); break;
                case "docx": doc = DocxReader.Read(data, s).Build(s); break;
                case "doc": doc = DocBinaryReader.Read(data, s).Build(s); break;
                case "odt": doc = OdtReader.Read(data, s).Build(s); break;
                case "rtf": doc = TextReaders.Rtf(data, s).Build(s); break;
                case "xlsx": doc = XlsxReader.Read(data, s).Build(s); break;
                case "pptx": doc = PptxReader.Read(data, s).Build(s); break;
                case "html": doc = TextReaders.Html(data, s).Build(s); break;
                case "md": doc = TextReaders.Markdown(data, s).Build(s); break;
                case "csv": doc = TextReaders.Csv(data, ext, s).Build(s); break;
                case "txt": doc = TextReaders.Plain(data, ext, s).Build(s); break;
                case "xps":
                    if (string.IsNullOrEmpty(path) || !File.Exists(path)) throw new UnsupportedFormatException("XPS можно открыть только из файла.");
                    doc = PaginatedDoc.FromXps(path); break;
                case "cbz":
                {
                    using (var z = new SafeZip(data))
                    {
                        var names = z.Entries.Where(e => IsImageName(e.FullName)).Select(e => e.FullName).OrderBy(n => n, new NaturalComparer()).ToList();
                        var imgs = new List<byte[]>();
                        foreach (var n in names) { imgs.Add(z.Read(n)); if (s.Light) break; }
                        doc = ImageDoc.FromImages(imgs, s.Light);
                        doc.Info.Add(new InfoSection("Комикс / архив изображений"));
                        doc.Info[doc.Info.Count - 1].Add("Страниц-изображений", names.Count);
                    }
                    break;
                }
                case "image":
                    doc = ImageDoc.FromMultiFrame(data, s.Light); break;
                case "djvu":
                    throw new UnsupportedFormatException("Формат DjVu пока не поддерживается. Совет: сохраните документ в PDF.");
                case "rar": case "7z":
                    throw new UnsupportedFormatException("Это архив (" + code.ToUpperInvariant() + "), а не документ. Комиксы CBR/CB7 не поддерживаются — используйте CBZ.");
                case "zip":
                    throw new UnsupportedFormatException("Это ZIP-архив без распознаваемого документа внутри.");
                default:
                    throw new UnsupportedFormatException("Файл не является документом поддерживаемого формата (двоичные данные).");
            }
            doc.FilePath = path;
            // исходные байты храним только там, где они действительно нужны (PDF без открытого файла);
            // остальные форматы уже разобраны, и копия файла в памяти больше не нужна
            if (code != "pdf") doc.Bytes = null;
            else if (file == null) doc.Bytes = data;
            doc.FormatCode = code;
            doc.FormatName = NameOf(code);
            if (!s.Light && !(deferSecurityScan && code == "pdf" && file != null)) SecurityScanner.Analyze(doc, data, path);
            return doc;
        }

        /// <summary>«Естественная» сортировка имён (page2 перед page10).</summary>
        public sealed class NaturalComparer : IComparer<string>
        {
            public int Compare(string a, string b)
            {
                a = a ?? ""; b = b ?? "";
                int i = 0, j = 0;
                while (i < a.Length && j < b.Length)
                {
                    if (char.IsDigit(a[i]) && char.IsDigit(b[j]))
                    {
                        int si = i, sj = j;
                        while (i < a.Length && char.IsDigit(a[i])) i++;
                        while (j < b.Length && char.IsDigit(b[j])) j++;
                        var na = a.Substring(si, i - si).TrimStart('0'); var nb = b.Substring(sj, j - sj).TrimStart('0');
                        if (na.Length != nb.Length) return na.Length.CompareTo(nb.Length);
                        int c = string.CompareOrdinal(na, nb);
                        if (c != 0) return c;
                    }
                    else
                    {
                        int c = char.ToLowerInvariant(a[i]).CompareTo(char.ToLowerInvariant(b[j]));
                        if (c != 0) return c;
                        i++; j++;
                    }
                }
                return a.Length.CompareTo(b.Length);
            }
        }
    }
}
