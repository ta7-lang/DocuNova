using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Documents;
using System.Windows.Media;
using System.Xml.Linq;

namespace DocuNova.Core.Formats
{
    /// <summary>Excel 2007+ (XLSX/XLSM): листы показываются таблицами. Формулы не вычисляются, макросы не выполняются.</summary>
    public static class XlsxReader
    {
        public static FlowResult Read(byte[] data, ReflowSettings s)
        {
            var r = new FlowResult();
            r.PageSize = new Size(1122.5, 793.7);
            r.Padding = new Thickness(36);
            r.Doc.FontFamily = new FontFamily("Calibri, Segoe UI");
            r.Doc.FontSize = 13;
            using (var z = new SafeZip(data))
            {
                var wb = z.ReadXml("xl/workbook.xml") ?? throw new UnsupportedFormatException("XLSX повреждён: нет workbook.xml.");
                var rels = Rels(z, "xl/_rels/workbook.xml.rels", "xl");
                var shared = new List<string>();
                var sst = z.ReadXml("xl/sharedStrings.xml");
                if (sst != null)
                    foreach (var si in sst.Root.Kids("si"))
                        shared.Add(string.Concat(si.Desc("t").Select(t => t.Value)));
                var sink = new FlowSink(r.Doc.Blocks);
                int sheetNo = 0;
                foreach (var sh in wb.Desc("sheet"))
                {
                    var name = sh.Attr("name") ?? ("Лист " + (sheetNo + 1));
                    var rid = sh.Attr("id");
                    if (rid == null || !rels.TryGetValue(rid, out var path)) continue;
                    if (string.Equals(sh.Attr("state"), "hidden", StringComparison.OrdinalIgnoreCase) || string.Equals(sh.Attr("state"), "veryHidden", StringComparison.OrdinalIgnoreCase))
                    {
                        r.Security.Add(new SecurityFinding(Severity.Info, "Скрытый лист: " + name, "Скрытые листы тоже показаны — ничего не утаивается."));
                    }
                    var x = z.ReadXml(path);
                    if (x == null) continue;
                    if (sheetNo > 0) sink.PageBreak();
                    var item = new TocItem { Title = name, Level = 0 };
                    sink.TocHere(item); r.Toc.Add(item);
                    sink.Add(new Paragraph(new Run(name)) { FontSize = 20, FontWeight = FontWeights.Bold, Margin = new Thickness(0, 0, 0, 8) });
                    Sheet(x, shared, sink, s.Light);
                    sheetNo++;
                    if (s.Light) break;
                }
                if (sheetNo == 0) sink.Add(new Paragraph(new Run("Книга не содержит листов с данными.")));
                sink.Flush();
                DocxReader.ReadProps(z, r, "Книга Excel");
                r.Info[r.Info.Count - 1].Add("Листов", sheetNo);
                DocxReader.Scan(data, r.Security);
            }
            r.Notices.Add("Таблицы Excel показаны как значения: формулы не пересчитываются.");
            return r;
        }

        internal static Dictionary<string, string> Rels(SafeZip z, string relsPath, string baseDir)
        {
            var map = new Dictionary<string, string>();
            var x = z.ReadXml(relsPath);
            if (x == null) return map;
            foreach (var rel in x.Desc("Relationship"))
            {
                var id = rel.Attr("Id"); var t = rel.Attr("Target");
                if (id == null || t == null) continue;
                if (string.Equals(rel.Attr("TargetMode"), "External", StringComparison.OrdinalIgnoreCase)) continue;
                map[id] = t.StartsWith("/") ? SafeZip.Normalize(t) : SafeZip.Combine(baseDir, t);
            }
            return map;
        }

        private static int ColIndex(string cellRef)
        {
            int col = 0;
            foreach (var ch in cellRef)
            {
                if (ch >= 'A' && ch <= 'Z') col = col * 26 + (ch - 'A' + 1);
                else if (ch >= 'a' && ch <= 'z') col = col * 26 + (ch - 'a' + 1);
                else break;
            }
            return Math.Max(0, col - 1);
        }

        private static string ColName(int i)
        {
            var sb = new StringBuilder();
            i++;
            while (i > 0) { int m = (i - 1) % 26; sb.Insert(0, (char)('A' + m)); i = (i - 1) / 26; }
            return sb.ToString();
        }

        private static void Sheet(XDocument x, List<string> shared, FlowSink sink, bool light)
        {
            var rows = new List<(int row, Dictionary<int, string> cells)>();
            int maxCol = 0;
            int maxRows = light ? 40 : 2000;
            foreach (var row in x.Desc("row"))
            {
                if (rows.Count >= maxRows) break;
                var cells = new Dictionary<int, string>();
                int idx = 0;
                foreach (var c in row.Kids("c"))
                {
                    var rf = c.Attr("r");
                    int col = rf != null ? ColIndex(rf) : idx;
                    idx = col + 1;
                    if (col > 60) continue;
                    string t = c.Attr("t");
                    string v = c.Kid("v")?.Value;
                    string val;
                    if (t == "s" && int.TryParse(v, out var si) && si >= 0 && si < shared.Count) val = shared[si];
                    else if (t == "inlineStr") val = string.Concat(c.Desc("t").Select(e => e.Value));
                    else if (t == "b") val = v == "1" ? "ИСТИНА" : "ЛОЖЬ";
                    else if (t == "e") val = v;
                    else if (v != null && double.TryParse(v, NumberStyles.Float, CultureInfo.InvariantCulture, out var d)) val = d.ToString("G15", CultureInfo.CurrentCulture);
                    else val = v;
                    if (!string.IsNullOrEmpty(val)) { cells[col] = val; maxCol = Math.Max(maxCol, col); }
                }
                int rn = int.TryParse(row.Attr("r"), out var rr) ? rr : rows.Count + 1;
                if (cells.Count > 0) rows.Add((rn, cells));
            }
            if (rows.Count == 0) { sink.Add(new Paragraph(new Run("(пустой лист)")) { Foreground = Brushes.Gray }); return; }
            var t2 = FlowSink.NewTable();
            var g = new TableRowGroup(); t2.RowGroups.Add(g);
            var head = new TableRow(); g.Rows.Add(head);
            var corner = FlowSink.NewCell(true); corner.Blocks.Add(new Paragraph()); head.Cells.Add(corner);
            for (int cI = 0; cI <= maxCol; cI++) { var hc = FlowSink.NewCell(true); hc.Blocks.Add(new Paragraph(new Run(ColName(cI))) { TextAlignment = TextAlignment.Center }); head.Cells.Add(hc); }
            foreach (var (rn, cells) in rows)
            {
                var tr = new TableRow(); g.Rows.Add(tr);
                var nc = FlowSink.NewCell(true); nc.Blocks.Add(new Paragraph(new Run(rn.ToString()))); tr.Cells.Add(nc);
                for (int cI = 0; cI <= maxCol; cI++)
                {
                    var cell = FlowSink.NewCell(false);
                    cells.TryGetValue(cI, out var val);
                    var p = new Paragraph(new Run(val ?? "")) { Margin = new Thickness(0) };
                    if (val != null && double.TryParse(val, NumberStyles.Float, CultureInfo.CurrentCulture, out _)) p.TextAlignment = TextAlignment.Right;
                    cell.Blocks.Add(p);
                    tr.Cells.Add(cell);
                }
            }
            FlowSink.FixColumns(t2);
            t2.Columns[0].Width = new GridLength(0.5, GridUnitType.Star);
            sink.Add(t2);
        }
    }

    /// <summary>PowerPoint 2007+ (PPTX/PPSX): текст и изображения слайдов. Макросы и действия не выполняются.</summary>
    public static class PptxReader
    {
        public static FlowResult Read(byte[] data, ReflowSettings s)
        {
            var r = new FlowResult();
            r.Doc.FontFamily = new FontFamily("Segoe UI, Calibri");
            r.Doc.FontSize = 18;
            using (var z = new SafeZip(data))
            {
                var pres = z.ReadXml("ppt/presentation.xml") ?? throw new UnsupportedFormatException("PPTX повреждён: нет presentation.xml.");
                var sz = pres.DescFirst("sldSz");
                double w = 0, h = 0;
                if (sz != null) { double.TryParse(sz.Attr("cx"), out w); double.TryParse(sz.Attr("cy"), out h); }
                w /= 9525; h /= 9525;
                r.PageSize = w > 200 && h > 200 && w < 5000 && h < 5000 ? new Size(w, h) : new Size(960, 540);
                r.Padding = new Thickness(r.PageSize.Value.Width * 0.06, r.PageSize.Value.Height * 0.07, r.PageSize.Value.Width * 0.06, r.PageSize.Value.Height * 0.05);
                var rels = XlsxReader.Rels(z, "ppt/_rels/presentation.xml.rels", "ppt");
                var sink = new FlowSink(r.Doc.Blocks)
                {
                    MaxImageWidth = r.PageSize.Value.Width * 0.85,
                    MaxImageHeight = r.PageSize.Value.Height * 0.55
                };
                int no = 0;
                foreach (var sid in pres.Desc("sldId"))
                {
                    var rid = sid.Attr("id");
                    if (!(rid != null && rels.TryGetValue(rid, out var path))) continue;
                    var slide = z.ReadXml(path);
                    if (slide == null) continue;
                    no++;
                    if (no > 1) sink.PageBreak();
                    var srels = XlsxReader.Rels(z, SafeZip.DirOf(path) + "/_rels/" + path.Substring(path.LastIndexOf('/') + 1) + ".rels", SafeZip.DirOf(path));
                    Slide(slide, z, srels, sink, r, no);
                    if (s.Light) break;
                }
                if (no == 0) sink.Add(new Paragraph(new Run("Презентация не содержит слайдов.")));
                sink.Flush();
                DocxReader.ReadProps(z, r, "Презентация PowerPoint");
                r.Info[r.Info.Count - 1].Add("Слайдов", no);
                DocxReader.Scan(data, r.Security);
            }
            r.Notices.Add("Презентация показана в режиме «текст и изображения слайдов»: анимации и точное расположение фигур не воспроизводятся.");
            return r;
        }

        private static void Slide(XDocument slide, SafeZip z, Dictionary<string, string> rels, FlowSink sink, FlowResult r, int no)
        {
            var tree = slide.DescFirst("spTree");
            if (tree == null) return;
            bool titleDone = false;
            var slideItem = new TocItem { Title = $"Слайд {no}", Level = 0 };
            sink.TocHere(slideItem); r.Toc.Add(slideItem);
            foreach (var el in tree.Descendants().Where(e => e.Name.LocalName == "sp" || e.Name.LocalName == "pic"))
            {
                if (el.Name.LocalName == "pic")
                {
                    var emb = el.DescFirst("blip")?.Attr("embed");
                    if (emb != null && rels.TryGetValue(emb, out var ip))
                    {
                        var bmp = SafeIO.LoadImage(z.Read(ip), 2400);
                        if (bmp != null) sink.AddImage(bmp, 0, 0, true);
                    }
                    continue;
                }
                var ph = el.DescFirst("ph")?.Attr("type");
                bool isTitle = ph == "title" || ph == "ctrTitle";
                var body = el.Kid("txBody");
                if (body == null) continue;
                foreach (var p in body.Kids("p"))
                {
                    var text = string.Concat(p.Desc("t").Select(t => t.Value));
                    if (string.IsNullOrWhiteSpace(text)) continue;
                    if (isTitle && !titleDone)
                    {
                        slideItem.Title = $"Слайд {no}: " + (text.Length > 90 ? text.Substring(0, 87) + "…" : text);
                        sink.Add(new Paragraph(new Run(text)) { FontSize = 34, FontWeight = FontWeights.Bold, Margin = new Thickness(0, 0, 0, 16), Foreground = new SolidColorBrush(Color.FromRgb(30, 40, 80)) });
                        titleDone = true;
                        continue;
                    }
                    int lvl = int.TryParse(p.Kid("pPr")?.Attr("lvl"), out var l) ? l : 0;
                    bool bullet = !isTitle && ph != "ctrTitle" && ph != "subTitle";
                    var para = new Paragraph { Margin = new Thickness(lvl * 28, 2, 0, 6), FontSize = Math.Max(12, 22 - lvl * 2) };
                    if (bullet) para.Inlines.Add(new Run("• ") { Foreground = new SolidColorBrush(Color.FromRgb(90, 100, 200)) });
                    foreach (var run in p.Kids("r"))
                    {
                        var rpr = run.Kid("rPr");
                        var rr = new Run(run.Kid("t")?.Value ?? "");
                        if (rpr?.Attr("b") == "1") rr.FontWeight = FontWeights.Bold;
                        if (rpr?.Attr("i") == "1") rr.FontStyle = FontStyles.Italic;
                        para.Inlines.Add(rr);
                    }
                    sink.Add(para);
                }
            }
        }
    }
}
