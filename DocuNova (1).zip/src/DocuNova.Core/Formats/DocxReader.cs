using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Documents;
using System.Windows.Media;
using System.Xml.Linq;

namespace DocuNova.Core.Formats
{
    /// <summary>Microsoft Word 2007+ (DOCX, DOCM, DOTX). Макросы никогда не выполняются.</summary>
    public static class DocxReader
    {
        private sealed class StyleInfo
        {
            public string Name, BasedOn;
            public int Outline = -1;
            public bool? Bold, Italic;
            public double Size;
            public TextAlignment? Align;
        }

        private sealed class Ctx
        {
            public SafeZip Z;
            public Dictionary<string, (string target, bool external)> Rels = new Dictionary<string, (string, bool)>();
            public Dictionary<string, StyleInfo> Styles = new Dictionary<string, StyleInfo>();
            public Dictionary<string, string> AbstractOf = new Dictionary<string, string>();
            public Dictionary<string, (string fmt, string text)> Levels = new Dictionary<string, (string, string)>();
            public Dictionary<string, int[]> Counters = new Dictionary<string, int[]>();
            public double DefaultSize = 14.67;
            public FlowResult R;
            public bool Light;
            public bool PendingBreak;
            public int Paras;
            public int Images;
            public bool Dde;
        }

        private const double Twip = 1.0 / 15.0; // twip → DIP

        public static FlowResult Read(byte[] data, ReflowSettings s)
        {
            var r = new FlowResult();
            using (var z = new SafeZip(data))
            {
                var mainPath = "word/document.xml";
                var ct = z.ReadXml("[Content_Types].xml");
                var over = ct?.Desc("Override").FirstOrDefault(o => (o.Attr("ContentType") ?? "").Contains("wordprocessingml.document.main") || (o.Attr("ContentType") ?? "").Contains("wordprocessingml.template.main") || (o.Attr("ContentType") ?? "").Contains("macroEnabled.main"));
                if (over != null) mainPath = SafeZip.Normalize(over.Attr("PartName"));
                var doc = z.ReadXml(mainPath) ?? throw new UnsupportedFormatException("DOCX повреждён: не найден основной документ.");
                var c = new Ctx { Z = z, R = r, Light = s.Light };
                var dir = SafeZip.DirOf(mainPath);
                var relsPath = (dir.Length > 0 ? dir + "/" : "") + "_rels/" + mainPath.Substring(mainPath.LastIndexOf('/') + 1) + ".rels";
                var rels = z.ReadXml(relsPath);
                if (rels != null)
                    foreach (var rel in rels.Desc("Relationship"))
                    {
                        var id = rel.Attr("Id"); var target = rel.Attr("Target") ?? "";
                        bool ext = string.Equals(rel.Attr("TargetMode"), "External", StringComparison.OrdinalIgnoreCase);
                        if (id == null) continue;
                        c.Rels[id] = (ext ? target : (target.StartsWith("/") ? SafeZip.Normalize(target) : SafeZip.Combine(dir, target)), ext);
                    }
                LoadStyles(c, z.ReadXml(SafeZip.Combine(dir, "styles.xml")));
                LoadNumbering(c, z.ReadXml(SafeZip.Combine(dir, "numbering.xml")));

                // параметры страницы
                var body = doc.DescFirst("body") ?? throw new UnsupportedFormatException("DOCX: пустой документ.");
                var sect = body.Elements().LastOrDefault(e => e.Name.LocalName == "sectPr") ?? doc.Desc("sectPr").LastOrDefault();
                var pgSz = sect.Kid("pgSz"); var pgMar = sect.Kid("pgMar");
                double pw = Num(pgSz?.Attr("w")) * Twip, ph = Num(pgSz?.Attr("h")) * Twip;
                if (pw > 200 && ph > 200 && pw < 6000 && ph < 6000) r.PageSize = new Size(pw, ph);
                else r.PageSize = new Size(793.7, 1122.5); // A4
                if (pgMar != null)
                {
                    double ml = Clamp(Num(pgMar.Attr("left")) * Twip, 10, 200), mt = Clamp(Num(pgMar.Attr("top")) * Twip, 10, 200);
                    double mr = Clamp(Num(pgMar.Attr("right")) * Twip, 10, 200), mb = Clamp(Num(pgMar.Attr("bottom")) * Twip, 10, 200);
                    r.Padding = new Thickness(ml, mt, mr, mb);
                }
                else r.Padding = new Thickness(96, 76, 72, 76);

                r.Doc.FontSize = c.DefaultSize;
                r.Doc.FontFamily = new FontFamily("Calibri, Segoe UI, Arial");
                r.Doc.TextAlignment = TextAlignment.Left;

                var sink = new FlowSink(r.Doc.Blocks)
                {
                    MaxImageWidth = r.PageSize.Value.Width - r.Padding.Value.Left - r.Padding.Value.Right - 4,
                    MaxImageHeight = r.PageSize.Value.Height - r.Padding.Value.Top - r.Padding.Value.Bottom - 20
                };
                Body(body, sink, c);
                sink.Flush();

                ReadProps(z, r, "Документ Word");
                ScanInternal(z, r.Security, c.Dde);
            }
            return r;
        }

        private static double Clamp(double v, double min, double max) => Math.Max(min, Math.Min(max, v));

        private static double Num(string s) => double.TryParse(s, NumberStyles.Float, CultureInfo.InvariantCulture, out var d) ? d : 0;

        private static void LoadStyles(Ctx c, XDocument st)
        {
            if (st == null) return;
            var defSz = st.DescFirst("docDefaults")?.DescFirst("rPrDefault")?.DescFirst("sz")?.Attr("val");
            if (defSz != null && Num(defSz) > 0) c.DefaultSize = Num(defSz) / 2 * 96 / 72;
            foreach (var e in st.Desc("style"))
            {
                var id = e.Attr("styleId");
                if (id == null) continue;
                var si = new StyleInfo { Name = e.Kid("name")?.Attr("val") ?? id, BasedOn = e.Kid("basedOn")?.Attr("val") };
                var ppr = e.Kid("pPr"); var rpr = e.Kid("rPr");
                var ol = ppr.Kid("outlineLvl")?.Attr("val");
                if (ol != null) si.Outline = (int)Num(ol);
                si.Align = Jc(ppr.Kid("jc")?.Attr("val"));
                if (rpr != null)
                {
                    if (rpr.Kid("b") != null) si.Bold = OnOff(rpr.Kid("b"));
                    if (rpr.Kid("i") != null) si.Italic = OnOff(rpr.Kid("i"));
                    var sz = rpr.Kid("sz")?.Attr("val"); if (sz != null) si.Size = Num(sz) / 2 * 96 / 72;
                }
                c.Styles[id] = si;
            }
        }

        private static void LoadNumbering(Ctx c, XDocument nd)
        {
            if (nd == null) return;
            foreach (var num in nd.Desc("num"))
            {
                var id = num.Attr("numId"); var abs = num.Kid("abstractNumId")?.Attr("val");
                if (id != null && abs != null) c.AbstractOf[id] = abs;
            }
            foreach (var an in nd.Desc("abstractNum"))
            {
                var aid = an.Attr("abstractNumId");
                foreach (var lvl in an.Kids("lvl"))
                {
                    var il = lvl.Attr("ilvl") ?? "0";
                    c.Levels[aid + ":" + il] = (lvl.Kid("numFmt")?.Attr("val") ?? "decimal", lvl.Kid("lvlText")?.Attr("val") ?? "%1.");
                }
            }
        }

        private static StyleInfo Resolve(Ctx c, string id, out int outline, out bool? bold, out bool? italic, out double size, out TextAlignment? align, out string name)
        {
            outline = -1; bold = null; italic = null; size = 0; align = null; name = null;
            StyleInfo first = null;
            int guard = 0;
            while (id != null && c.Styles.TryGetValue(id, out var si) && guard++ < 12)
            {
                if (first == null) first = si;
                if (name == null) name = si.Name;
                if (outline < 0 && si.Outline >= 0) outline = si.Outline;
                if (bold == null) bold = si.Bold;
                if (italic == null) italic = si.Italic;
                if (size <= 0 && si.Size > 0) size = si.Size;
                if (align == null) align = si.Align;
                id = si.BasedOn;
            }
            return first;
        }

        private static bool OnOff(XElement e)
        {
            if (e == null) return false;
            var v = e.Attr("val");
            return v == null || !(v == "0" || v == "false" || v == "off" || v == "none");
        }

        private static TextAlignment? Jc(string v)
        {
            switch (v)
            {
                case "center": return TextAlignment.Center;
                case "right": case "end": return TextAlignment.Right;
                case "both": case "distribute": return TextAlignment.Justify;
                case "left": case "start": return TextAlignment.Left;
                default: return null;
            }
        }

        private static void Body(XElement container, FlowSink sink, Ctx c)
        {
            foreach (var e in container.Elements())
            {
                if (c.Light && c.Paras > 120) return;
                switch (e.Name.LocalName)
                {
                    case "p": Para(e, sink, c); break;
                    case "tbl": TableEl(e, sink, c); break;
                    case "sdt": var sc = e.Kid("sdtContent"); if (sc != null) Body(sc, sink, c); break;
                    case "customXml": Body(e, sink, c); break;
                    case "altChunk":
                        c.R.Security.Add(new SecurityFinding(Severity.Warning, "Встроенный внешний фрагмент (altChunk)", "Фрагмент другого формата внутри документа не отображается."));
                        break;
                }
            }
        }

        private static void Para(XElement p, FlowSink sink, Ctx c)
        {
            c.Paras++;
            var ppr = p.Kid("pPr");
            var styleId = ppr.Kid("pStyle")?.Attr("val");
            Resolve(c, styleId, out int outline, out bool? sBold, out bool? sItalic, out double sSize, out TextAlignment? sAlign, out string sName);
            var ol = ppr.Kid("outlineLvl")?.Attr("val");
            if (ol != null) outline = (int)Num(ol);
            string lname = (sName ?? "").ToLowerInvariant();
            bool isTitle = lname == "title" || lname == "заголовок";
            if (outline < 0)
            {
                var m = Regex.Match(lname, @"^(heading|заголовок)\s*(\d)");
                if (m.Success) outline = int.Parse(m.Groups[2].Value) - 1;
            }
            bool heading = (outline >= 0 && outline <= 5) || isTitle;
            var align = Jc(ppr.Kid("jc")?.Attr("val")) ?? sAlign;

            double indL = 0, first = 0, before = 0, after = 6;
            var ind = ppr.Kid("ind");
            if (ind != null)
            {
                indL = Num(ind.Attr("left") ?? ind.Attr("start")) * Twip;
                first = Num(ind.Attr("firstLine")) * Twip;
                if (ind.Attr("hanging") != null) first = -Num(ind.Attr("hanging")) * Twip;
            }
            var sp = ppr.Kid("spacing");
            if (sp != null)
            {
                if (sp.Attr("before") != null) before = Num(sp.Attr("before")) * Twip;
                if (sp.Attr("after") != null) after = Num(sp.Attr("after")) * Twip;
            }
            double lineMul = 0;
            if (sp?.Attr("line") != null && (sp.Attr("lineRule") == null || sp.Attr("lineRule") == "auto")) lineMul = Num(sp.Attr("line")) / 240.0;

            // нумерация
            string prefix = null;
            var numPr = ppr.Kid("numPr");
            var numId = numPr?.Kid("numId")?.Attr("val");
            if (numId != null && numId != "0")
            {
                int ilvl = (int)Num(numPr.Kid("ilvl")?.Attr("val") ?? "0");
                ilvl = Math.Max(0, Math.Min(8, ilvl));
                prefix = NumberPrefix(c, numId, ilvl);
                if (ind == null) { indL = 24 * (ilvl + 1); first = -18; }
            }

            double size = sSize > 0 ? sSize : c.DefaultSize;
            if (heading && sSize <= 0) size = c.DefaultSize * (isTitle ? 2 : Math.Max(1.05, 1.6 - outline * 0.15));
            bool pbb = OnOff(ppr.Kid("pageBreakBefore")) && ppr.Kid("pageBreakBefore") != null;
            if (c.PendingBreak) { pbb = true; c.PendingBreak = false; }

            var shd = ppr.Kid("shd")?.Attr("fill");
            Brush bg = null;
            if (shd != null && shd != "auto" && Regex.IsMatch(shd, "^[0-9A-Fa-f]{6}$")) bg = HtmlToFlow.ParseColor("#" + shd);

            Paragraph Factory()
            {
                var para = new Paragraph
                {
                    Margin = new Thickness(Math.Max(0, indL), before, 0, after),
                    TextIndent = first,
                    TextAlignment = align ?? TextAlignment.Left,
                };
                if (size > 0) para.FontSize = size;
                if (lineMul > 0.5 && lineMul < 4) para.LineHeight = size * 1.17 * lineMul;
                if (heading) { para.FontWeight = FontWeights.Bold; para.KeepWithNext = true; }
                if (sBold == true) para.FontWeight = FontWeights.Bold;
                if (sItalic == true) para.FontStyle = FontStyles.Italic;
                if (heading && !isTitle && outline <= 1) para.Foreground = new SolidColorBrush(Color.FromRgb(31, 56, 100));
                if (bg != null) para.Background = bg;
                return para;
            }

            if (pbb) sink.PageBreak();
            if (heading)
            {
                var text = FlowSink.CollapseWs(string.Concat(p.Desc("t").Select(t => t.Value))).Trim();
                if (text.Length > 0 && outline <= 2)
                {
                    var item = new TocItem { Title = text.Length > 120 ? text.Substring(0, 117) + "…" : text, Level = Math.Max(0, outline) };
                    sink.TocHere(item);
                    c.R.Toc.Add(item);
                }
            }
            int before0 = sink.BlockCount;
            sink.Begin(Factory);
            if (prefix != null) sink.AddText(prefix + " ", new InlineStyle(), false);
            Content(p, sink, c, new InlineStyle());
            sink.End();
            if (sink.BlockCount == before0) sink.Add(Factory());
        }

        private static string NumberPrefix(Ctx c, string numId, int ilvl)
        {
            if (!c.AbstractOf.TryGetValue(numId, out var abs)) abs = numId;
            c.Levels.TryGetValue(abs + ":" + ilvl, out var lv);
            var fmt = lv.fmt ?? "decimal";
            if (fmt == "bullet") return ilvl % 3 == 0 ? "•" : ilvl % 3 == 1 ? "◦" : "▪";
            if (fmt == "none") return null;
            if (!c.Counters.TryGetValue(numId, out var cnt)) c.Counters[numId] = cnt = new int[9];
            cnt[ilvl]++;
            for (int k = ilvl + 1; k < 9; k++) cnt[k] = 0;
            string text = lv.text ?? "%1.";
            for (int k = 0; k <= ilvl; k++)
            {
                string lf = k == ilvl ? fmt : (c.Levels.TryGetValue(abs + ":" + k, out var l2) ? l2.fmt : "decimal");
                text = text.Replace("%" + (k + 1), Format(Math.Max(1, cnt[k]), lf));
            }
            return text;
        }

        private static string Format(int n, string fmt)
        {
            switch (fmt)
            {
                case "lowerLetter": return ((char)('a' + (n - 1) % 26)).ToString();
                case "upperLetter": return ((char)('A' + (n - 1) % 26)).ToString();
                case "lowerRoman": return Roman(n).ToLowerInvariant();
                case "upperRoman": return Roman(n);
                case "russianLower": return ((char)('а' + (n - 1) % 32)).ToString();
                case "russianUpper": return ((char)('А' + (n - 1) % 32)).ToString();
                default: return n.ToString();
            }
        }

        public static string Roman(int n)
        {
            if (n <= 0 || n > 3999) return n.ToString();
            string[] th = { "", "M", "MM", "MMM" }, h = { "", "C", "CC", "CCC", "CD", "D", "DC", "DCC", "DCCC", "CM" },
                     t = { "", "X", "XX", "XXX", "XL", "L", "LX", "LXX", "LXXX", "XC" }, o = { "", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX" };
            return th[n / 1000] + h[n % 1000 / 100] + t[n % 100 / 10] + o[n % 10];
        }

        private static void Content(XElement parent, FlowSink sink, Ctx c, InlineStyle st)
        {
            foreach (var e in parent.Elements())
            {
                switch (e.Name.LocalName)
                {
                    case "r": RunEl(e, sink, c, st); break;
                    case "hyperlink":
                        var hs = st; hs.Underline = true; hs.Color = new SolidColorBrush(Color.FromRgb(5, 99, 193));
                        Content(e, sink, c, hs); break;
                    case "ins": case "smartTag": case "fldSimple": case "customXml": case "bdo": case "dir": case "moveTo":
                        Content(e, sink, c, st); break;
                    case "sdt": var sc = e.Kid("sdtContent"); if (sc != null) Content(sc, sink, c, st); break;
                    case "oMath": case "oMathPara":
                        var ms = st; ms.Italic = true; ms.Font = "Cambria Math";
                        sink.AddText(string.Concat(e.Desc("t").Select(t => t.Value)), ms, false); break;
                }
            }
        }

        private static void RunEl(XElement r, FlowSink sink, Ctx c, InlineStyle st)
        {
            var rpr = r.Kid("rPr");
            if (rpr != null)
            {
                if (rpr.Kid("vanish") != null && OnOff(rpr.Kid("vanish"))) return;
                if (rpr.Kid("b") != null) st.Bold = OnOff(rpr.Kid("b"));
                if (rpr.Kid("i") != null) st.Italic = OnOff(rpr.Kid("i"));
                var u = rpr.Kid("u")?.Attr("val"); if (u != null && u != "none") st.Underline = true;
                if (rpr.Kid("strike") != null && OnOff(rpr.Kid("strike"))) st.Strike = true;
                if (rpr.Kid("dstrike") != null && OnOff(rpr.Kid("dstrike"))) st.Strike = true;
                var sz = rpr.Kid("sz")?.Attr("val"); if (sz != null && Num(sz) > 0) st.AbsSize = Num(sz) / 2 * 96 / 72;
                var col = rpr.Kid("color")?.Attr("val");
                if (col != null && col != "auto" && Regex.IsMatch(col, "^[0-9A-Fa-f]{6}$")) st.Color = HtmlToFlow.ParseColor("#" + col);
                var hl = rpr.Kid("highlight")?.Attr("val");
                if (hl != null && hl != "none") st.Highlight = HighlightBrush(hl);
                var va = rpr.Kid("vertAlign")?.Attr("val");
                if (va == "superscript") st.Sup = true; else if (va == "subscript") st.Sub = true;
                var font = rpr.Kid("rFonts")?.Attr("ascii") ?? rpr.Kid("rFonts")?.Attr("hAnsi");
                if (!string.IsNullOrEmpty(font)) st.Font = font;
                if (rpr.Kid("smallCaps") != null && OnOff(rpr.Kid("smallCaps"))) st.SmallCaps = true;
            }
            foreach (var e in r.Elements())
            {
                switch (e.Name.LocalName)
                {
                    case "t": sink.AddText(e.Value, st, false); break;
                    case "tab": sink.AddText("    ", st, false); break;
                    case "br":
                        if (e.Attr("type") == "page") { c.PendingBreak = true; }
                        else sink.AddLineBreak();
                        break;
                    case "cr": sink.AddLineBreak(); break;
                    case "noBreakHyphen": sink.AddText("‑", st, false); break;
                    case "sym":
                        var ch = e.Attr("char");
                        if (ch != null && int.TryParse(ch, NumberStyles.HexNumber, CultureInfo.InvariantCulture, out var code))
                        {
                            if (code >= 0xF000) code -= 0xF000;
                            var ss = st; ss.Font = e.Attr("font");
                            sink.AddText(((char)code).ToString(), ss, false);
                        }
                        break;
                    case "instrText":
                        var instr = e.Value ?? "";
                        if (Regex.IsMatch(instr, @"\bDDE(AUTO)?\b", RegexOptions.IgnoreCase)) c.Dde = true;
                        break;
                    case "drawing":
                        Drawing(e, sink, c);
                        break;
                    case "pict": case "object":
                        var imd = e.DescFirst("imagedata");
                        var rid = imd?.Attr("id");
                        if (rid != null) AddImage(rid, 0, 0, sink, c);
                        break;
                }
            }
        }

        private static Brush HighlightBrush(string name)
        {
            switch (name)
            {
                case "yellow": return new SolidColorBrush(Color.FromRgb(255, 255, 0));
                case "green": return new SolidColorBrush(Color.FromRgb(0, 255, 0));
                case "cyan": return new SolidColorBrush(Color.FromRgb(0, 255, 255));
                case "magenta": return new SolidColorBrush(Color.FromRgb(255, 0, 255));
                case "blue": return new SolidColorBrush(Color.FromRgb(120, 160, 255));
                case "red": return new SolidColorBrush(Color.FromRgb(255, 120, 120));
                case "lightGray": return new SolidColorBrush(Color.FromRgb(211, 211, 211));
                case "darkGray": return new SolidColorBrush(Color.FromRgb(169, 169, 169));
                default: return new SolidColorBrush(Color.FromRgb(255, 240, 120));
            }
        }

        private static void Drawing(XElement d, FlowSink sink, Ctx c)
        {
            var blip = d.DescFirst("blip");
            var rid = blip?.Attr("embed") ?? blip?.Attr("link");
            if (rid == null) return;
            var ext = d.DescFirst("extent");
            double w = Num(ext?.Attr("cx")) / 9525.0, h = Num(ext?.Attr("cy")) / 9525.0;
            AddImage(rid, w, h, sink, c);
        }

        private static void AddImage(string rid, double w, double h, FlowSink sink, Ctx c)
        {
            if (c.Images++ > 2000) return;
            if (!c.Rels.TryGetValue(rid, out var rel) || rel.external) return; // внешние картинки не загружаются
            var bytes = c.Z.Read(rel.target);
            var bmp = SafeIO.LoadImage(bytes, 2400);
            if (bmp != null) sink.AddImage(bmp, w, h);
        }

        private static void TableEl(XElement tbl, FlowSink sink, Ctx c)
        {
            var t = FlowSink.NewTable();
            var g = new TableRowGroup(); t.RowGroups.Add(g);
            var grid = tbl.Kid("tblGrid")?.Kids("gridCol").Select(x => Num(x.Attr("w"))).ToList() ?? new List<double>();
            var rows = tbl.Elements().SelectMany(e => e.Name.LocalName == "tr" ? new[] { e } : e.Name.LocalName == "sdt" ? (e.Kid("sdtContent")?.Kids("tr") ?? Enumerable.Empty<XElement>()).ToArray() : Array.Empty<XElement>());
            int n = 0;
            foreach (var tr in rows)
            {
                if (++n > 3000) break;
                var row = new TableRow(); g.Rows.Add(row);
                foreach (var tc in tr.Elements().Where(x => x.Name.LocalName == "tc" || x.Name.LocalName == "sdt"))
                {
                    var cellEl = tc.Name.LocalName == "sdt" ? tc.Kid("sdtContent")?.Kid("tc") : tc;
                    if (cellEl == null) continue;
                    var cell = FlowSink.NewCell(false);
                    var tcPr = cellEl.Kid("tcPr");
                    var span = tcPr.Kid("gridSpan")?.Attr("val");
                    if (span != null && (int)Num(span) > 1) cell.ColumnSpan = Math.Min(64, (int)Num(span));
                    var fill = tcPr.Kid("shd")?.Attr("fill");
                    if (fill != null && Regex.IsMatch(fill, "^[0-9A-Fa-f]{6}$")) cell.Background = HtmlToFlow.ParseColor("#" + fill);
                    row.Cells.Add(cell);
                    var cs = sink.Child(cell.Blocks);
                    Body(cellEl, cs, c);
                    cs.Flush();
                    if (cell.Blocks.Count == 0) cell.Blocks.Add(new Paragraph());
                    foreach (var b in cell.Blocks) if (b is Paragraph pp) { pp.Margin = new Thickness(pp.Margin.Left, 0, 0, 2); pp.TextIndent = Math.Max(0, pp.TextIndent); }
                }
                if (row.Cells.Count == 0) { var ec = FlowSink.NewCell(false); ec.Blocks.Add(new Paragraph()); row.Cells.Add(ec); }
            }
            if (n == 0) return;
            FlowSink.FixColumns(t);
            if (grid.Count == t.Columns.Count && grid.All(x => x > 0))
                for (int i = 0; i < grid.Count; i++) t.Columns[i].Width = new GridLength(grid[i], GridUnitType.Star);
            sink.Add(t);
        }

        // ---------- метаданные и безопасность (общие для OOXML) ----------

        public static void ReadProps(SafeZip z, FlowResult r, string title)
        {
            var info = new InfoSection(title);
            var core = z.ReadXml("docProps/core.xml");
            if (core != null)
            {
                r.Title = core.DescFirst("title").Val();
                r.Author = core.DescFirst("creator").Val();
                info.Add("Заголовок", r.Title);
                info.Add("Автор", r.Author);
                info.Add("Тема", core.DescFirst("subject").Val());
                info.Add("Ключевые слова", core.DescFirst("keywords").Val());
                info.Add("Описание", core.DescFirst("description").Val());
                info.Add("Категория", core.DescFirst("category").Val());
                info.Add("Последним изменил", core.DescFirst("lastModifiedBy").Val());
                info.Add("Редакция", core.DescFirst("revision").Val());
                info.Add("Создан", IsoDate(core.DescFirst("created").Val()));
                info.Add("Изменён", IsoDate(core.DescFirst("modified").Val()));
                info.Add("Напечатан", IsoDate(core.DescFirst("lastPrinted").Val()));
            }
            var app = z.ReadXml("docProps/app.xml");
            if (app != null)
            {
                info.Add("Приложение", app.DescFirst("Application").Val() + " " + app.DescFirst("AppVersion").Val());
                info.Add("Организация", app.DescFirst("Company").Val());
                info.Add("Шаблон", app.DescFirst("Template").Val());
                info.Add("Страниц (по данным файла)", app.DescFirst("Pages").Val());
                info.Add("Слов (по данным файла)", app.DescFirst("Words").Val());
                info.Add("Символов (по данным файла)", app.DescFirst("Characters").Val());
                info.Add("Слайдов", app.DescFirst("Slides").Val());
                var tt = app.DescFirst("TotalTime").Val();
                if (tt != null && tt != "0") info.Add("Время правки, мин", tt);
            }
            r.Info.Add(info);
        }

        public static string IsoDate(string s)
        {
            if (string.IsNullOrWhiteSpace(s)) return null;
            return DateTime.TryParse(s, CultureInfo.InvariantCulture, DateTimeStyles.AdjustToUniversal, out var d) ? d.ToLocalTime().ToString("dd.MM.yyyy HH:mm") : s;
        }

        public static void Scan(byte[] data, List<SecurityFinding> list)
        {
            try { using (var z = new SafeZip(data)) ScanInternal(z, list, false); } catch { }
        }

        private static void ScanInternal(SafeZip z, List<SecurityFinding> list, bool dde)
        {
            if (z.Names.Any(n => n.EndsWith("vbaProject.bin", StringComparison.OrdinalIgnoreCase)))
                list.Add(new SecurityFinding(Severity.Danger, "Документ содержит макросы VBA", "Макросы — частый способ распространения вирусов. В DocuNova они НИКОГДА не выполняются; документ безопасно показан как текст."));
            if (z.Names.Any(n => n.IndexOf("activeX", StringComparison.OrdinalIgnoreCase) >= 0))
                list.Add(new SecurityFinding(Severity.Danger, "Элементы ActiveX", "Заблокированы и не запускаются."));
            int ole = z.Names.Count(n => n.IndexOf("embeddings/", StringComparison.OrdinalIgnoreCase) >= 0);
            if (ole > 0) list.Add(new SecurityFinding(Severity.Warning, "Встроенные OLE-объекты: " + ole, "Встроенные файлы и объекты не открываются и не запускаются."));
            int external = 0; bool template = false;
            foreach (var n in z.Names.Where(n => n.EndsWith(".rels", StringComparison.OrdinalIgnoreCase)).Take(300))
            {
                var x = z.ReadXml(n);
                if (x == null) continue;
                foreach (var rel in x.Desc("Relationship"))
                {
                    if (!string.Equals(rel.Attr("TargetMode"), "External", StringComparison.OrdinalIgnoreCase)) continue;
                    var type = rel.Attr("Type") ?? "";
                    if (type.EndsWith("/attachedTemplate") || type.EndsWith("/frame") || type.EndsWith("/oleObject")) template = true;
                    else external++;
                }
            }
            if (template) list.Add(new SecurityFinding(Severity.Danger, "Внешний шаблон / удалённый объект", "Документ пытается загрузить шаблон или объект из сети (известная техника атак). Загрузка ЗАБЛОКИРОВАНА."));
            if (external > 0) list.Add(new SecurityFinding(Severity.Info, "Внешние ссылки: " + external, "Ссылки на внешние ресурсы не открываются автоматически, картинки из сети не загружаются."));
            if (dde) list.Add(new SecurityFinding(Severity.Danger, "Поле DDE (запуск команд)", "Обнаружено поле DDE — им пытаются запускать программы. В DocuNova поля не выполняются."));
        }
    }
}
