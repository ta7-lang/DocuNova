using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Documents;
using System.Windows.Media.Imaging;
using System.Xml.Linq;

namespace DocuNova.Core.Formats
{
    /// <summary>EPUB 2/3. Скрипты EPUB3 и внешние ресурсы игнорируются.</summary>
    public static class EpubReader
    {
        private sealed class Item { public string Id, Href, Path, Media, Props; }

        private sealed class Package
        {
            public string OpfPath, OpfDir;
            public XDocument Opf;
            public Dictionary<string, Item> Manifest = new Dictionary<string, Item>();
            public List<Item> Spine = new List<Item>();
            public string TocId;
        }

        private static Package OpenPackage(SafeZip z)
        {
            var p = new Package();
            var container = z.ReadXml("META-INF/container.xml");
            p.OpfPath = container?.DescFirst("rootfile")?.Attr("full-path");
            if (p.OpfPath == null) p.OpfPath = z.Names.FirstOrDefault(n => n.EndsWith(".opf", StringComparison.OrdinalIgnoreCase));
            if (p.OpfPath == null) throw new UnsupportedFormatException("EPUB повреждён: не найден файл пакета OPF.");
            p.OpfPath = SafeZip.Normalize(p.OpfPath);
            p.OpfDir = SafeZip.DirOf(p.OpfPath);
            p.Opf = z.ReadXml(p.OpfPath) ?? throw new UnsupportedFormatException("EPUB повреждён: OPF не читается.");
            foreach (var it in p.Opf.Desc("item"))
            {
                var id = it.Attr("id"); var href = it.Attr("href");
                if (id == null || href == null) continue;
                p.Manifest[id] = new Item { Id = id, Href = href, Path = SafeZip.Combine(p.OpfDir, href), Media = it.Attr("media-type") ?? "", Props = it.Attr("properties") ?? "" };
            }
            var spine = p.Opf.DescFirst("spine");
            p.TocId = spine?.Attr("toc");
            if (spine != null)
                foreach (var r in spine.Kids("itemref"))
                {
                    var idref = r.Attr("idref");
                    if (idref != null && p.Manifest.TryGetValue(idref, out var item)) p.Spine.Add(item);
                }
            if (p.Spine.Count == 0)
                p.Spine.AddRange(p.Manifest.Values.Where(i => i.Media.Contains("html")));
            return p;
        }

        private static Item FindCover(Package p)
        {
            var c = p.Manifest.Values.FirstOrDefault(i => i.Props.Split(' ').Contains("cover-image"));
            if (c != null) return c;
            var metaCover = p.Opf.Desc("meta").FirstOrDefault(m => m.Attr("name") == "cover")?.Attr("content");
            if (metaCover != null && p.Manifest.TryGetValue(metaCover, out var mc) && mc.Media.StartsWith("image")) return mc;
            if (metaCover != null) { var byHref = p.Manifest.Values.FirstOrDefault(i => i.Href == metaCover); if (byHref != null) return byHref; }
            return p.Manifest.Values.FirstOrDefault(i => i.Media.StartsWith("image") && i.Id.IndexOf("cover", StringComparison.OrdinalIgnoreCase) >= 0)
                ?? p.Manifest.Values.FirstOrDefault(i => i.Media.StartsWith("image") && i.Href.IndexOf("cover", StringComparison.OrdinalIgnoreCase) >= 0);
        }

        public static BitmapSource ExtractCover(byte[] data, out string title, out string author)
        {
            using (var z = new SafeZip(data))
            {
                var p = OpenPackage(z);
                title = p.Opf.DescFirst("title").Val();
                author = p.Opf.DescFirst("creator").Val();
                var c = FindCover(p);
                return c != null ? SafeIO.LoadImage(z.Read(c.Path), 2600) : null;
            }
        }

        public static FlowResult Read(byte[] data, ReflowSettings s)
        {
            var r = new FlowResult();
            using (var z = new SafeZip(data))
            {
                if (z.Exists("META-INF/encryption.xml"))
                {
                    var enc = z.ReadXml("META-INF/encryption.xml");
                    bool fontsOnly = enc != null && enc.Desc("CipherReference").All(cr => Regex.IsMatch(cr.Attr("URI") ?? "", @"\.(ttf|otf|woff2?)$", RegexOptions.IgnoreCase));
                    if (!fontsOnly) throw new UnsupportedFormatException("Книга защищена DRM (шифрование содержимого) — открыть её нельзя.");
                }
                var p = OpenPackage(z);

                // метаданные
                var md = p.Opf.DescFirst("metadata");
                r.Title = md.DescFirst("title").Val();
                var creators = md?.Desc("creator").Select(c => c.Val()).Where(x => !string.IsNullOrEmpty(x)).ToList() ?? new List<string>();
                r.Author = string.Join(", ", creators);
                var info = new InfoSection("Книга (EPUB)");
                info.Add("Название", r.Title);
                info.Add("Автор(ы)", r.Author);
                info.Add("Издательство", md.DescFirst("publisher").Val());
                info.Add("Язык", md.DescFirst("language").Val());
                info.Add("Дата", md.DescFirst("date").Val());
                info.Add("Идентификатор", md.DescFirst("identifier").Val());
                info.Add("Темы", string.Join(", ", md?.Desc("subject").Select(x => x.Val()) ?? Enumerable.Empty<string>()));
                info.Add("Права", md.DescFirst("rights").Val());
                info.Add("Участники", string.Join(", ", md?.Desc("contributor").Select(x => x.Val()) ?? Enumerable.Empty<string>()));
                var series = p.Opf.Desc("meta").FirstOrDefault(m => m.Attr("name") == "calibre:series")?.Attr("content");
                info.Add("Серия", series);
                var descr = md.DescFirst("description")?.Value;
                if (!string.IsNullOrWhiteSpace(descr))
                {
                    var plain = HtmlParser.Parse(descr).InnerText();
                    plain = FlowSink.CollapseWs(plain).Trim();
                    info.Add("Описание", plain.Length > 600 ? plain.Substring(0, 600) + "…" : plain);
                }
                info.Add("Версия EPUB", p.Opf.Root?.Attr("version"));
                info.Add("Глав (файлов в порядке чтения)", p.Spine.Count);
                info.Add("Изображений в книге", p.Manifest.Values.Count(i => i.Media.StartsWith("image")));
                r.Info.Add(info);

                var cover = FindCover(p);
                if (cover != null) r.Cover = SafeIO.LoadImage(z.Read(cover.Path), 2000);

                // безопасность
                int scripts = p.Manifest.Values.Count(i => i.Media.Contains("javascript") || i.Props.Contains("scripted"));
                if (scripts > 0) r.Security.Add(new SecurityFinding(Severity.Warning, "Книга содержит скрипты (" + scripts + ")", "Скрипты EPUB3 полностью заблокированы и не выполняются."));
                int remote = p.Manifest.Values.Count(i => i.Props.Contains("remote-resources") || i.Href.StartsWith("http", StringComparison.OrdinalIgnoreCase));
                if (remote > 0) r.Security.Add(new SecurityFinding(Severity.Warning, "Внешние ресурсы (" + remote + ")", "Загрузка из интернета запрещена — внешние ресурсы не запрашиваются."));

                // содержимое
                var sink = new FlowSink(r.Doc.Blocks)
                {
                    MaxImageWidth = s.PageWidth - s.Margin * 2 - 10,
                    MaxImageHeight = s.PageHeight - s.Margin * 2 - 30
                };
                var chapterStart = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                var headingToc = new List<TocItem>();
                int chapter = 0;
                foreach (var item in p.Spine)
                {
                    if (!item.Media.Contains("html") && !item.Media.Contains("xml")) continue;
                    if (s.Light && chapter >= 2) break;
                    string html;
                    try { html = z.ReadText(item.Path); } catch { continue; }
                    if (html == null) continue;
                    if (chapter > 0) sink.PageBreak();
                    sink.Anchor(item.Path);
                    var dom = HtmlParser.Parse(html);
                    var dir = SafeZip.DirOf(item.Path);
                    var conv = new HtmlToFlow(sink, n =>
                    {
                        var src = n.A("src") ?? n.A("href");
                        return src == null ? null : z.Read(SafeZip.Combine(dir, src));
                    })
                    { AnchorPrefix = item.Path, BaseFontSize = s.FontSize };
                    conv.Convert(dom);
                    headingToc.AddRange(conv.HeadingToc);
                    chapter++;
                }
                if (chapter == 0) throw new UnsupportedFormatException("В книге нет читаемых глав.");

                // оглавление
                var navToc = ReadNav(z, p) ?? ReadNcx(z, p);
                if (navToc != null && navToc.Count > 0)
                {
                    BindToc(navToc, sink.Anchors);
                    r.Toc.AddRange(navToc);
                }
                else r.Toc.AddRange(headingToc.Where(t => t.Level == 0).Take(500));
            }
            return r;
        }

        private static void BindToc(List<TocItem> items, Dictionary<string, TextElement> anchors)
        {
            foreach (var t in items)
            {
                if (t.Anchor is string key)
                {
                    if (anchors.TryGetValue(key, out var el)) t.Anchor = el;
                    else
                    {
                        int h = key.IndexOf('#');
                        if (h > 0 && anchors.TryGetValue(key.Substring(0, h), out el)) t.Anchor = el;
                        else t.Anchor = null;
                    }
                }
                BindToc(t.Children, anchors);
            }
        }

        private static string AnchorKey(string baseDir, string href)
        {
            if (string.IsNullOrEmpty(href)) return null;
            int h = href.IndexOf('#');
            string path = SafeZip.Combine(baseDir, h >= 0 ? href.Substring(0, h) : href);
            return h >= 0 ? path + href.Substring(h) : path;
        }

        private static List<TocItem> ReadNav(SafeZip z, Package p)
        {
            var nav = p.Manifest.Values.FirstOrDefault(i => i.Props.Split(' ').Contains("nav"));
            if (nav == null) return null;
            var html = z.ReadText(nav.Path);
            if (html == null) return null;
            var dom = HtmlParser.Parse(html);
            var navEl = dom.All().FirstOrDefault(n => n.Name == "nav" && ((n.A("type") ?? "").Contains("toc"))) ?? dom.Find("nav");
            var ol = navEl?.Find("ol");
            if (ol == null) return null;
            var dir = SafeZip.DirOf(nav.Path);
            var res = new List<TocItem>();
            NavList(ol, dir, res, 0);
            return res;
        }

        private static void NavList(HNode ol, string dir, List<TocItem> target, int level)
        {
            if (level > 6) return;
            foreach (var li in ol.Kids.Where(k => k.Name == "li"))
            {
                var a = li.Kids.FirstOrDefault(k => k.Name == "a" || k.Name == "span") ?? li.Find("a");
                if (a == null) continue;
                var item = new TocItem { Title = FlowSink.CollapseWs(a.InnerText()).Trim(), Level = level, Anchor = AnchorKey(dir, a.A("href")) };
                if (string.IsNullOrEmpty(item.Title)) item.Title = "—";
                target.Add(item);
                var sub = li.Kids.FirstOrDefault(k => k.Name == "ol");
                if (sub != null) NavList(sub, dir, item.Children, level + 1);
            }
        }

        private static List<TocItem> ReadNcx(SafeZip z, Package p)
        {
            Item ncx = null;
            if (p.TocId != null) p.Manifest.TryGetValue(p.TocId, out ncx);
            if (ncx == null) ncx = p.Manifest.Values.FirstOrDefault(i => i.Media.Contains("ncx"));
            if (ncx == null) return null;
            var x = z.ReadXml(ncx.Path);
            var map = x?.DescFirst("navMap");
            if (map == null) return null;
            var dir = SafeZip.DirOf(ncx.Path);
            var res = new List<TocItem>();
            NcxPoints(map, dir, res, 0);
            return res;
        }

        private static void NcxPoints(XElement parent, string dir, List<TocItem> target, int level)
        {
            if (level > 6) return;
            foreach (var np in parent.Kids("navPoint"))
            {
                var item = new TocItem
                {
                    Title = FlowSink.CollapseWs(np.Kid("navLabel")?.Kid("text")?.Value ?? "—").Trim(),
                    Level = level,
                    Anchor = AnchorKey(dir, np.Kid("content")?.Attr("src"))
                };
                target.Add(item);
                NcxPoints(np, dir, item.Children, level + 1);
            }
        }

        public static void Scan(byte[] data, List<SecurityFinding> list)
        {
            try
            {
                using (var z = new SafeZip(data))
                {
                    int scripts = 0, handlers = 0, forms = 0;
                    foreach (var n in z.Names.Where(n => Regex.IsMatch(n, @"\.(x?html?|xml)$", RegexOptions.IgnoreCase)).Take(400))
                    {
                        var t = z.ReadText(n) ?? "";
                        scripts += Regex.Matches(t, @"<script", RegexOptions.IgnoreCase).Count;
                        handlers += Regex.Matches(t, @"\son[a-z]+\s*=", RegexOptions.IgnoreCase).Count;
                        forms += Regex.Matches(t, @"<(form|iframe|object|embed)\b", RegexOptions.IgnoreCase).Count;
                    }
                    if (scripts + handlers > 0) list.Add(new SecurityFinding(Severity.Warning, $"JavaScript в книге: {scripts} блок(ов), {handlers} обработчик(ов)", "Заблокировано: при отображении все скрипты удаляются."));
                    if (forms > 0) list.Add(new SecurityFinding(Severity.Warning, "Встраиваемые объекты/формы: " + forms, "Заблокировано: iframe, object, embed и формы не отображаются."));
                }
            }
            catch { }
        }
    }
}
