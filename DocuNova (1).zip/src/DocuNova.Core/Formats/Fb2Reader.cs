using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Xml.Linq;

namespace DocuNova.Core.Formats
{
    /// <summary>FictionBook 2 (FB2, FB2.ZIP, FBZ).</summary>
    public static class Fb2Reader
    {
        public static byte[] Unwrap(byte[] data)
        {
            if (data.Length > 4 && data[0] == 'P' && data[1] == 'K')
            {
                using (var z = new SafeZip(data))
                {
                    var name = z.Names.FirstOrDefault(n => n.EndsWith(".fb2", StringComparison.OrdinalIgnoreCase));
                    if (name == null) throw new UnsupportedFormatException("В архиве нет файла .fb2");
                    return z.Read(name);
                }
            }
            return data;
        }

        public static FlowResult Read(byte[] raw, ReflowSettings s)
        {
            var data = Unwrap(raw);
            var xd = SafeIO.LoadXml(data);
            var root = xd.Root;
            if (root == null || root.Name.LocalName != "FictionBook") throw new UnsupportedFormatException("Это не FB2-документ.");
            var r = new FlowResult();
            var binaries = new Dictionary<string, byte[]>(StringComparer.OrdinalIgnoreCase);
            foreach (var b in root.Kids("binary"))
            {
                var id = b.Attr("id");
                if (id == null) continue;
                try { binaries[id] = Convert.FromBase64String(b.Value); } catch { }
            }

            var desc = root.Kid("description");
            var ti = desc.Kid("title-info");
            var pi = desc.Kid("publish-info");
            var di = desc.Kid("document-info");

            string title = ti.Kid("book-title").Val();
            var authors = ti?.Kids("author").Select(PersonName).Where(x => !string.IsNullOrWhiteSpace(x)).ToList() ?? new List<string>();
            r.Title = title; r.Author = string.Join(", ", authors);

            var meta = new InfoSection("Книга (FB2)");
            meta.Add("Название", title);
            meta.Add("Автор(ы)", r.Author);
            meta.Add("Жанры", string.Join(", ", ti?.Kids("genre").Select(g => g.Val()) ?? Enumerable.Empty<string>()));
            meta.Add("Язык", ti.Kid("lang").Val());
            meta.Add("Исходный язык", ti.Kid("src-lang").Val());
            var seq = ti.Kid("sequence");
            if (seq != null) meta.Add("Серия", seq.Attr("name") + (seq.Attr("number") != null ? " № " + seq.Attr("number") : ""));
            meta.Add("Дата", ti.Kid("date").Val());
            meta.Add("Ключевые слова", ti.Kid("keywords").Val());
            meta.Add("Переводчик", string.Join(", ", ti?.Kids("translator").Select(PersonName) ?? Enumerable.Empty<string>()));
            meta.Add("Аннотация", Short(ti.Kid("annotation")?.Value, 600));
            r.Info.Add(meta);
            if (pi != null)
            {
                var pub = new InfoSection("Издание");
                pub.Add("Название издания", pi.Kid("book-name").Val());
                pub.Add("Издательство", pi.Kid("publisher").Val());
                pub.Add("Город", pi.Kid("city").Val());
                pub.Add("Год", pi.Kid("year").Val());
                pub.Add("ISBN", pi.Kid("isbn").Val());
                r.Info.Add(pub);
            }
            if (di != null)
            {
                var doc = new InfoSection("Электронная версия");
                doc.Add("Автор файла", string.Join(", ", di.Kids("author").Select(PersonName)));
                doc.Add("Программа", di.Kid("program-used").Val());
                doc.Add("Дата файла", di.Kid("date").Val());
                doc.Add("Версия", di.Kid("version").Val());
                doc.Add("ID", di.Kid("id").Val());
                r.Info.Add(doc);
            }

            // обложка
            var coverImg = ti.Kid("coverpage")?.Kid("image");
            var coverId = coverImg?.Attr("href")?.TrimStart('#');
            if (coverId != null && binaries.TryGetValue(coverId, out var cb)) r.Cover = SafeIO.LoadImage(cb, 2000);

            var ctx = new Ctx { Binaries = binaries, Base = s.FontSize, Result = r, Light = s.Light };
            var sink = new FlowSink(r.Doc.Blocks)
            {
                MaxImageWidth = s.PageWidth - s.Margin * 2 - 10,
                MaxImageHeight = s.PageHeight - s.Margin * 2 - 30
            };

            // титульная страница
            if (r.Cover != null)
            {
                sink.AddImage(r.Cover, 0, 0, true);
                sink.PageBreak();
            }
            if (!string.IsNullOrEmpty(title))
            {
                sink.Add(new Paragraph(new Run(title)) { FontSize = s.FontSize * 1.9, FontWeight = FontWeights.Bold, TextAlignment = TextAlignment.Center, Margin = new Thickness(0, 120, 0, 18) });
                if (authors.Count > 0)
                    sink.Add(new Paragraph(new Run(string.Join(", ", authors))) { FontSize = s.FontSize * 1.2, FontStyle = FontStyles.Italic, TextAlignment = TextAlignment.Center });
                var ann = ti.Kid("annotation");
                if (ann != null)
                {
                    sink.Add(new Paragraph { Margin = new Thickness(0, 30, 0, 0) });
                    foreach (var e in ann.Elements()) Element(e, sink, ctx, new InlineStyle { Italic = true }, 0);
                }
                sink.PageBreak();
            }

            bool firstBody = true;
            foreach (var body in root.Kids("body"))
            {
                var bname = body.Attr("name");
                if (!firstBody) sink.PageBreak();
                if (bname == "notes" || bname == "comments")
                {
                    var item = new TocItem { Title = bname == "notes" ? "Примечания" : "Комментарии", Level = 0 };
                    sink.TocHere(item); r.Toc.Add(item);
                    sink.Add(new Paragraph(new Run(item.Title)) { FontSize = s.FontSize * 1.5, FontWeight = FontWeights.Bold, Margin = new Thickness(0, 0, 0, 14) });
                }
                firstBody = false;
                foreach (var e in body.Elements())
                {
                    if (e.Name.LocalName == "section") SectionEl(e, sink, ctx, 1, r.Toc);
                    else Element(e, sink, ctx, new InlineStyle(), 0);
                }
                if (ctx.Light && sink.BlockCount > 60) break;
            }
            sink.Flush();

            // безопасность: FB2 не может содержать исполняемый код
            int ext = xd.Descendants().Count(e => e.Name.LocalName == "a" && (e.Attr("href") ?? "").StartsWith("http", StringComparison.OrdinalIgnoreCase));
            if (ext > 0) r.Security.Add(new SecurityFinding(Severity.Info, "Внешние ссылки: " + ext, "Ссылки показываются как текст и не открываются автоматически."));
            return r;
        }

        /// <summary>Быстрое извлечение обложки для эскиза.</summary>
        public static BitmapSource ExtractCover(byte[] raw, out string title, out string author)
        {
            title = null; author = null;
            var xd = SafeIO.LoadXml(Unwrap(raw));
            var root = xd.Root;
            var ti = root?.Kid("description")?.Kid("title-info");
            title = ti.Kid("book-title").Val();
            author = string.Join(", ", ti?.Kids("author").Select(PersonName) ?? Enumerable.Empty<string>());
            var id = ti?.Kid("coverpage")?.Kid("image")?.Attr("href")?.TrimStart('#');
            if (id == null) return null;
            var bin = root.Kids("binary").FirstOrDefault(b => b.Attr("id") == id);
            if (bin == null) return null;
            try { return SafeIO.LoadImage(Convert.FromBase64String(bin.Value), 2600); } catch { return null; }
        }

        private sealed class Ctx
        {
            public Dictionary<string, byte[]> Binaries;
            public double Base;
            public FlowResult Result;
            public bool Light;
        }

        private static string PersonName(XElement a)
        {
            if (a == null) return null;
            var parts = new[] { a.Kid("first-name").Val(), a.Kid("middle-name").Val(), a.Kid("last-name").Val() }.Where(x => !string.IsNullOrWhiteSpace(x));
            var n = string.Join(" ", parts);
            return string.IsNullOrWhiteSpace(n) ? a.Kid("nickname").Val() : n;
        }

        private static string Short(string s, int max)
        {
            if (string.IsNullOrWhiteSpace(s)) return null;
            s = FlowSink.CollapseWs(s).Trim();
            return s.Length > max ? s.Substring(0, max) + "…" : s;
        }

        private static void SectionEl(XElement sec, FlowSink sink, Ctx ctx, int depth, List<TocItem> toc)
        {
            var id = sec.Attr("id");
            if (depth == 1 && sink.BlockCount > 0) sink.PageBreak();
            if (id != null) sink.Anchor("#" + id);
            var titleEl = sec.Kid("title");
            List<TocItem> childToc = toc;
            if (titleEl != null)
            {
                var text = FlowSink.CollapseWs(string.Join(" ", titleEl.Elements().Select(e => e.Value))).Trim();
                if (text.Length > 0 && depth <= 4)
                {
                    var item = new TocItem { Title = text.Length > 120 ? text.Substring(0, 117) + "…" : text, Level = depth - 1 };
                    sink.TocHere(item);
                    toc.Add(item);
                    childToc = item.Children;
                }
            }
            foreach (var e in sec.Elements())
            {
                if (e.Name.LocalName == "section") SectionEl(e, sink, ctx, depth + 1, childToc);
                else if (e.Name.LocalName == "title") TitleEl(e, sink, ctx, depth);
                else Element(e, sink, ctx, new InlineStyle(), depth);
            }
        }

        private static void TitleEl(XElement t, FlowSink sink, Ctx ctx, int depth)
        {
            double size = ctx.Base * Math.Max(1.1, 1.7 - depth * 0.15);
            foreach (var p in t.Elements())
            {
                if (p.Name.LocalName == "empty-line") { sink.Add(new Paragraph()); continue; }
                sink.Begin(() => new Paragraph
                {
                    FontSize = size, FontWeight = FontWeights.Bold, TextAlignment = TextAlignment.Center,
                    Margin = new Thickness(0, size * 0.6, 0, size * 0.5), KeepWithNext = true, TextIndent = 0, LineHeight = size * 1.3
                });
                Inlines(p, sink, ctx, new InlineStyle());
                sink.End();
            }
        }

        private static void Element(XElement e, FlowSink sink, Ctx ctx, InlineStyle st, int depth)
        {
            var b = ctx.Base;
            switch (e.Name.LocalName)
            {
                case "p":
                    var pid = e.Attr("id"); if (pid != null) sink.Anchor("#" + pid);
                    sink.Begin(() => new Paragraph { TextIndent = b * 1.4, Margin = new Thickness(0, 0, 0, b * 0.25) });
                    Inlines(e, sink, ctx, st);
                    sink.End();
                    break;
                case "empty-line":
                    sink.Add(new Paragraph { Margin = new Thickness(0, 0, 0, b * 0.6) });
                    break;
                case "subtitle":
                    sink.Begin(() => new Paragraph { TextAlignment = TextAlignment.Center, FontWeight = FontWeights.Bold, Margin = new Thickness(0, b * 0.6, 0, b * 0.4), KeepWithNext = true });
                    Inlines(e, sink, ctx, st);
                    sink.End();
                    break;
                case "title":
                    TitleEl(e, sink, ctx, depth + 1);
                    break;
                case "epigraph":
                {
                    var sec = new Section { Margin = new Thickness(b * 8, b * 0.5, 0, b), FontStyle = FontStyles.Italic, FontSize = b * 0.92 };
                    sink.Add(sec);
                    var c = sink.Child(sec.Blocks);
                    foreach (var k in e.Elements())
                    {
                        if (k.Name.LocalName == "text-author") { c.Add(new Paragraph(new Run(k.Value.Trim())) { TextAlignment = TextAlignment.Right, FontWeight = FontWeights.SemiBold }); continue; }
                        Element(k, c, ctx, st, depth);
                    }
                    c.Flush();
                    break;
                }
                case "cite":
                case "annotation":
                {
                    var sec = new Section { Margin = new Thickness(b * 2, b * 0.4, b, b * 0.6), Padding = new Thickness(b * 0.7, 0, 0, 0), BorderBrush = new SolidColorBrush(Color.FromRgb(190, 190, 205)), BorderThickness = new Thickness(2, 0, 0, 0) };
                    sink.Add(sec);
                    var c = sink.Child(sec.Blocks);
                    foreach (var k in e.Elements())
                    {
                        if (k.Name.LocalName == "text-author") { c.Add(new Paragraph(new Run(k.Value.Trim())) { TextAlignment = TextAlignment.Right, FontStyle = FontStyles.Italic }); continue; }
                        Element(k, c, ctx, st, depth);
                    }
                    c.Flush();
                    break;
                }
                case "poem":
                {
                    var sec = new Section { Margin = new Thickness(b * 3, b * 0.5, 0, b * 0.5) };
                    sink.Add(sec);
                    var c = sink.Child(sec.Blocks);
                    foreach (var k in e.Elements())
                    {
                        switch (k.Name.LocalName)
                        {
                            case "title": TitleEl(k, c, ctx, depth + 2); break;
                            case "epigraph": Element(k, c, ctx, st, depth); break;
                            case "stanza":
                                foreach (var v in k.Elements())
                                {
                                    if (v.Name.LocalName == "v")
                                    {
                                        c.Begin(() => new Paragraph { Margin = new Thickness(0), TextAlignment = TextAlignment.Left, TextIndent = 0 });
                                        Inlines(v, c, ctx, st);
                                        c.End();
                                    }
                                    else if (v.Name.LocalName == "title" || v.Name.LocalName == "subtitle") Element(v, c, ctx, st, depth);
                                }
                                c.Add(new Paragraph { Margin = new Thickness(0, 0, 0, b * 0.5) });
                                break;
                            case "text-author": c.Add(new Paragraph(new Run(k.Value.Trim())) { TextAlignment = TextAlignment.Right, FontStyle = FontStyles.Italic }); break;
                            case "date": c.Add(new Paragraph(new Run(k.Value.Trim())) { TextAlignment = TextAlignment.Right }); break;
                        }
                    }
                    c.Flush();
                    break;
                }
                case "text-author":
                    sink.Add(new Paragraph(new Run(e.Value.Trim())) { TextAlignment = TextAlignment.Right, FontStyle = FontStyles.Italic });
                    break;
                case "image":
                {
                    var id = e.Attr("href")?.TrimStart('#');
                    if (id != null && ctx.Binaries.TryGetValue(id, out var data))
                    {
                        var bmp = SafeIO.LoadImage(data, 2400);
                        if (bmp != null) sink.AddImage(bmp, 0, 0, true);
                    }
                    break;
                }
                case "table":
                {
                    var t = FlowSink.NewTable();
                    var g = new TableRowGroup(); t.RowGroups.Add(g);
                    foreach (var tr in e.Kids("tr"))
                    {
                        var row = new TableRow(); g.Rows.Add(row);
                        foreach (var td in tr.Elements())
                        {
                            var cell = FlowSink.NewCell(td.Name.LocalName == "th");
                            if (int.TryParse(td.Attr("colspan"), out var cs) && cs > 1) cell.ColumnSpan = Math.Min(64, cs);
                            if (int.TryParse(td.Attr("rowspan"), out var rs) && rs > 1) cell.RowSpan = Math.Min(1000, rs);
                            row.Cells.Add(cell);
                            var c = sink.Child(cell.Blocks);
                            c.Begin(() => new Paragraph { Margin = new Thickness(0), TextIndent = 0 });
                            Inlines(td, c, ctx, st);
                            c.End();
                            if (cell.Blocks.Count == 0) cell.Blocks.Add(new Paragraph());
                        }
                    }
                    FlowSink.FixColumns(t);
                    sink.Add(t);
                    break;
                }
                case "section":
                    SectionEl(e, sink, ctx, depth + 1, new List<TocItem>());
                    break;
                default:
                    // неизвестные блоки — как абзац
                    if (e.HasElements) foreach (var k in e.Elements()) Element(k, sink, ctx, st, depth);
                    else if (!string.IsNullOrWhiteSpace(e.Value))
                    {
                        sink.Begin(() => new Paragraph());
                        sink.AddText(e.Value, st);
                        sink.End();
                    }
                    break;
            }
        }

        private static void Inlines(XElement e, FlowSink sink, Ctx ctx, InlineStyle st)
        {
            foreach (var node in e.Nodes())
            {
                if (node is XText t) { sink.AddText(t.Value, st); continue; }
                if (!(node is XElement x)) continue;
                var s2 = st;
                switch (x.Name.LocalName)
                {
                    case "strong": s2.Bold = true; break;
                    case "emphasis": s2.Italic = true; break;
                    case "strikethrough": s2.Strike = true; break;
                    case "sup": s2.Sup = true; s2.AbsSize = ctx.Base * 0.7; break;
                    case "sub": s2.Sub = true; s2.AbsSize = ctx.Base * 0.7; break;
                    case "code": s2.Mono = true; break;
                    case "style": break;
                    case "a":
                        var href = x.Attr("href") ?? "";
                        if (href.StartsWith("#") || x.Attr("type") == "note") { s2.Sup = true; s2.AbsSize = ctx.Base * 0.72; s2.Color = new SolidColorBrush(Color.FromRgb(40, 90, 200)); }
                        else { s2.Underline = true; s2.Color = new SolidColorBrush(Color.FromRgb(40, 90, 200)); }
                        break;
                    case "image":
                        var id = x.Attr("href")?.TrimStart('#');
                        if (id != null && ctx.Binaries.TryGetValue(id, out var data))
                        {
                            var bmp = SafeIO.LoadImage(data, 1600);
                            if (bmp != null) sink.AddImage(bmp);
                        }
                        continue;
                }
                Inlines(x, sink, ctx, s2);
            }
        }
    }
}
