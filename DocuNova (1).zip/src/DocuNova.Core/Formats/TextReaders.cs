using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Documents;
using System.Windows.Media;

namespace DocuNova.Core.Formats
{
    /// <summary>Простые текстовые форматы: TXT, LOG, код, Markdown, CSV/TSV, RTF, HTML.</summary>
    public static class TextReaders
    {
        public static readonly HashSet<string> CodeExt = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        { ".log", ".ini", ".cfg", ".conf", ".json", ".xml", ".yaml", ".yml", ".cs", ".js", ".ts", ".py", ".java", ".cpp", ".c", ".h", ".css", ".sql", ".bat", ".ps1", ".sh", ".reg", ".toml", ".properties", ".nfo", ".srt", ".vtt", ".tex" };

        public static FlowResult Plain(byte[] data, string ext, ReflowSettings s)
        {
            var r = new FlowResult();
            int max = s.Light ? 24 * 1024 : 8 * 1024 * 1024;
            var text = SafeIO.DecodeText(data, max);
            if (!s.Light && data.Length > max) r.Notices.Add("Файл очень большой: показаны первые 8 МБ текста.");
            bool code = CodeExt.Contains(ext ?? "");
            if (code)
            {
                r.Doc.FontFamily = new FontFamily("Consolas, Courier New");
                r.PageSize = new Size(793.7, 1122.5);
                r.Padding = new Thickness(48, 48, 40, 48);
                r.Doc.FontSize = 13;
                r.Doc.TextAlignment = TextAlignment.Left;
            }
            var lines = text.Replace("\r\n", "\n").Replace('\r', '\n').Split('\n');
            var sink = new FlowSink(r.Doc.Blocks);
            if (code)
            {
                // по 40 строк в абзаце — быстрая разбивка на страницы
                var sb = new List<string>();
                foreach (var l in lines)
                {
                    sb.Add(l);
                    if (sb.Count >= 40) { CodeBlock(sink, sb); sb.Clear(); }
                }
                if (sb.Count > 0) CodeBlock(sink, sb);
            }
            else
            {
                var para = new StringBuilder();
                foreach (var raw in lines)
                {
                    var l = raw.TrimEnd();
                    if (l.Length == 0)
                    {
                        if (para.Length > 0) { TextPara(sink, para.ToString()); para.Clear(); }
                        continue;
                    }
                    // строка с отступом — новый абзац (книжный TXT)
                    if (para.Length > 0 && (raw.StartsWith("  ") || raw.StartsWith("\t"))) { TextPara(sink, para.ToString()); para.Clear(); }
                    if (para.Length > 0) para.Append('\n');
                    para.Append(l.TrimStart());
                    if (para.Length > 20000) { TextPara(sink, para.ToString()); para.Clear(); }
                }
                if (para.Length > 0) TextPara(sink, para.ToString());
            }
            if (r.Doc.Blocks.Count == 0) r.Doc.Blocks.Add(new Paragraph(new Run("(пустой файл)")) { Foreground = Brushes.Gray });
            var info = new InfoSection("Текст");
            info.Add("Строк", lines.Length);
            info.Add("Символов", text.Length);
            info.Add("Кодировка", GuessEncodingName(data));
            r.Info.Add(info);
            return r;
        }

        private static void CodeBlock(FlowSink sink, List<string> lines)
        {
            var p = new Paragraph { Margin = new Thickness(0), TextAlignment = TextAlignment.Left };
            for (int i = 0; i < lines.Count; i++)
            {
                if (i > 0) p.Inlines.Add(new LineBreak());
                p.Inlines.Add(new Run(lines[i].Replace("\t", "    ")));
            }
            sink.Add(p);
        }

        private static void TextPara(FlowSink sink, string t)
        {
            var p = new Paragraph { Margin = new Thickness(0, 0, 0, 8) };
            var parts = t.Split('\n');
            for (int i = 0; i < parts.Length; i++)
            {
                if (i > 0) p.Inlines.Add(new LineBreak());
                p.Inlines.Add(new Run(parts[i]));
            }
            sink.Add(p);
        }

        public static string GuessEncodingName(byte[] b)
        {
            if (b.Length >= 3 && b[0] == 0xEF && b[1] == 0xBB && b[2] == 0xBF) return "UTF-8 (BOM)";
            if (b.Length >= 2 && b[0] == 0xFF && b[1] == 0xFE) return "UTF-16 LE";
            if (b.Length >= 2 && b[0] == 0xFE && b[1] == 0xFF) return "UTF-16 BE";
            try { new UTF8Encoding(false, true).GetString(b, 0, Math.Min(b.Length, 1 << 20)); return "UTF-8"; }
            catch { return "Windows-1251 (предположительно)"; }
        }

        // ---------- Markdown ----------
        public static FlowResult Markdown(byte[] data, ReflowSettings s)
        {
            var r = new FlowResult();
            var text = SafeIO.DecodeText(data, s.Light ? 24 * 1024 : 8 * 1024 * 1024);
            var lines = text.Replace("\r\n", "\n").Split('\n');
            var sink = new FlowSink(r.Doc.Blocks);
            double b = s.FontSize;
            int i = 0;
            var para = new StringBuilder();
            void FlushPara()
            {
                if (para.Length == 0) return;
                sink.Begin(() => new Paragraph { Margin = new Thickness(0, 0, 0, b * 0.6) });
                MdInline(sink, para.ToString(), new InlineStyle());
                sink.End();
                para.Clear();
            }
            while (i < lines.Length)
            {
                var line = lines[i];
                var trimmed = line.Trim();
                if (trimmed.StartsWith("```") || trimmed.StartsWith("~~~"))
                {
                    FlushPara();
                    var fence = trimmed.Substring(0, 3);
                    var code = new List<string>();
                    i++;
                    while (i < lines.Length && !lines[i].Trim().StartsWith(fence)) code.Add(lines[i++]);
                    i++;
                    var p = new Paragraph { FontFamily = new FontFamily("Consolas"), FontSize = b * 0.82, Background = new SolidColorBrush(Color.FromRgb(244, 245, 248)), Padding = new Thickness(10), TextAlignment = TextAlignment.Left };
                    for (int k = 0; k < code.Count; k++) { if (k > 0) p.Inlines.Add(new LineBreak()); p.Inlines.Add(new Run(code[k].Replace("\t", "    "))); }
                    sink.Add(p);
                    continue;
                }
                var hm = Regex.Match(line, @"^(#{1,6})\s+(.*?)\s*#*\s*$");
                if (hm.Success)
                {
                    FlushPara();
                    int lvl = hm.Groups[1].Value.Length;
                    double size = b * new[] { 0, 1.9, 1.55, 1.3, 1.15, 1.05, 1.0 }[lvl];
                    var title = hm.Groups[2].Value;
                    if (lvl <= 3) { var item = new TocItem { Title = Regex.Replace(title, @"[*_`]", ""), Level = lvl - 1 }; sink.TocHere(item); r.Toc.Add(item); }
                    sink.Begin(() => new Paragraph { FontSize = size, FontWeight = FontWeights.Bold, Margin = new Thickness(0, size * 0.7, 0, size * 0.35), KeepWithNext = true, TextAlignment = TextAlignment.Left });
                    MdInline(sink, title, new InlineStyle());
                    sink.End();
                    if (lvl <= 2) sink.Rule();
                    i++; continue;
                }
                if (Regex.IsMatch(trimmed, @"^(\*\s*){3,}$|^(-\s*){3,}$|^(_\s*){3,}$")) { FlushPara(); sink.Rule(); i++; continue; }
                var lm = Regex.Match(line, @"^(\s*)([-*+]|\d+[.)])\s+(.*)$");
                if (lm.Success)
                {
                    FlushPara();
                    int indent = lm.Groups[1].Value.Replace("\t", "    ").Length / 2;
                    string marker = char.IsDigit(lm.Groups[2].Value[0]) ? lm.Groups[2].Value : "•";
                    var content = lm.Groups[3].Value;
                    var task = Regex.Match(content, @"^\[( |x|X)\]\s+(.*)$");
                    if (task.Success) { marker = task.Groups[1].Value == " " ? "☐" : "☑"; content = task.Groups[2].Value; }
                    sink.Begin(() => new Paragraph { Margin = new Thickness(18 + indent * 20, 0, 0, 3), TextIndent = -14, TextAlignment = TextAlignment.Left });
                    sink.AddText(marker + " ", new InlineStyle(), false);
                    MdInline(sink, content, new InlineStyle());
                    sink.End();
                    i++; continue;
                }
                if (trimmed.StartsWith(">"))
                {
                    FlushPara();
                    var quote = new StringBuilder();
                    while (i < lines.Length && lines[i].Trim().StartsWith(">")) { quote.AppendLine(lines[i].Trim().TrimStart('>').Trim()); i++; }
                    var sec = new Section { Margin = new Thickness(16, 4, 0, 8), Padding = new Thickness(12, 2, 0, 2), BorderBrush = new SolidColorBrush(Color.FromRgb(150, 160, 220)), BorderThickness = new Thickness(3, 0, 0, 0), Foreground = new SolidColorBrush(Color.FromRgb(70, 70, 90)) };
                    sink.Add(sec);
                    var c = sink.Child(sec.Blocks);
                    c.Begin(() => new Paragraph());
                    MdInline(c, quote.ToString().Trim(), new InlineStyle { Italic = true });
                    c.End();
                    continue;
                }
                if (trimmed.StartsWith("|") && i + 1 < lines.Length && Regex.IsMatch(lines[i + 1].Trim(), @"^\|?\s*:?-+:?\s*(\|\s*:?-+:?\s*)*\|?$"))
                {
                    FlushPara();
                    var rows = new List<string[]>();
                    rows.Add(SplitRow(trimmed));
                    i += 2;
                    while (i < lines.Length && lines[i].Trim().StartsWith("|")) rows.Add(SplitRow(lines[i++].Trim()));
                    var t = FlowSink.NewTable();
                    var g = new TableRowGroup(); t.RowGroups.Add(g);
                    for (int ri = 0; ri < rows.Count; ri++)
                    {
                        var tr = new TableRow(); g.Rows.Add(tr);
                        foreach (var cellText in rows[ri])
                        {
                            var cell = FlowSink.NewCell(ri == 0);
                            tr.Cells.Add(cell);
                            var cs = sink.Child(cell.Blocks);
                            cs.Begin(() => new Paragraph { Margin = new Thickness(0), TextAlignment = TextAlignment.Left });
                            MdInline(cs, cellText, new InlineStyle());
                            cs.End();
                            if (cell.Blocks.Count == 0) cell.Blocks.Add(new Paragraph());
                        }
                    }
                    FlowSink.FixColumns(t);
                    sink.Add(t);
                    continue;
                }
                if (trimmed.Length == 0) { FlushPara(); i++; continue; }
                if (para.Length > 0) para.Append(line.EndsWith("  ") ? "\n" : " ");
                para.Append(trimmed);
                i++;
            }
            FlushPara();
            sink.Flush();
            r.Info.Add(new InfoSection("Markdown"));
            r.Info[0].Add("Строк", lines.Length);
            r.Info[0].Add("Заголовков", r.Toc.Count);
            return r;
        }

        private static string[] SplitRow(string row)
        {
            row = row.Trim();
            if (row.StartsWith("|")) row = row.Substring(1);
            if (row.EndsWith("|")) row = row.Substring(0, row.Length - 1);
            return row.Split('|').Select(c => c.Trim()).ToArray();
        }

        private static readonly Regex MdToken = new Regex(@"(`[^`]+`)|(\*\*[^*]+\*\*)|(__[^_]+__)|(\*[^*\s][^*]*\*)|(_[^_\s][^_]*_)|(~~[^~]+~~)|(!?\[[^\]]*\]\([^)]*\))", RegexOptions.Compiled);

        private static void MdInline(FlowSink sink, string text, InlineStyle st)
        {
            int pos = 0;
            foreach (Match m in MdToken.Matches(text))
            {
                if (m.Index > pos) AddWithBreaks(sink, text.Substring(pos, m.Index - pos), st);
                var v = m.Value;
                var s2 = st;
                if (v.StartsWith("`")) { s2.Mono = true; s2.Highlight = new SolidColorBrush(Color.FromRgb(238, 240, 246)); sink.AddText(v.Trim('`'), s2, false); }
                else if (v.StartsWith("**") || v.StartsWith("__")) { s2.Bold = true; MdInline(sink, v.Substring(2, v.Length - 4), s2); }
                else if (v.StartsWith("~~")) { s2.Strike = true; MdInline(sink, v.Substring(2, v.Length - 4), s2); }
                else if (v.StartsWith("*") || v.StartsWith("_")) { s2.Italic = true; MdInline(sink, v.Substring(1, v.Length - 2), s2); }
                else if (v.StartsWith("!["))
                {
                    var alt = Regex.Match(v, @"!\[([^\]]*)\]").Groups[1].Value;
                    s2.Italic = true; s2.Color = Brushes.Gray;
                    sink.AddText("[изображение: " + alt + "]", s2, false);
                }
                else if (v.StartsWith("["))
                {
                    var label = Regex.Match(v, @"\[([^\]]*)\]").Groups[1].Value;
                    s2.Underline = true; s2.Color = new SolidColorBrush(Color.FromRgb(30, 90, 200));
                    MdInline(sink, label, s2);
                }
                pos = m.Index + m.Length;
            }
            if (pos < text.Length) AddWithBreaks(sink, text.Substring(pos), st);
        }

        private static void AddWithBreaks(FlowSink sink, string t, InlineStyle st)
        {
            var parts = t.Split('\n');
            for (int i = 0; i < parts.Length; i++)
            {
                if (i > 0) sink.AddLineBreak();
                sink.AddText(parts[i], st, false);
            }
        }

        // ---------- CSV / TSV ----------
        public static FlowResult Csv(byte[] data, string ext, ReflowSettings s)
        {
            var r = new FlowResult();
            r.PageSize = new Size(1122.5, 793.7);
            r.Padding = new Thickness(36);
            r.Doc.FontSize = 13;
            r.Doc.FontFamily = new FontFamily("Segoe UI");
            var text = SafeIO.DecodeText(data, s.Light ? 16 * 1024 : 50 * 1024 * 1024);
            var lines = text.Replace("\r\n", "\n").Split('\n').Where(l => l.Length > 0).ToList();
            char sep = ext == ".tsv" ? '\t' : DetectSep(lines.Take(20));
            var t = FlowSink.NewTable();
            var g = new TableRowGroup(); t.RowGroups.Add(g);
            int maxRows = s.Light ? 30 : 3000;
            for (int i = 0; i < lines.Count && i < maxRows; i++)
            {
                var tr = new TableRow(); g.Rows.Add(tr);
                foreach (var cell in ParseCsvLine(lines[i], sep).Take(60))
                {
                    var c = FlowSink.NewCell(i == 0);
                    c.Blocks.Add(new Paragraph(new Run(cell)) { Margin = new Thickness(0) });
                    tr.Cells.Add(c);
                }
            }
            if (g.Rows.Count == 0) { r.Doc.Blocks.Add(new Paragraph(new Run("(пустой файл)"))); return r; }
            FlowSink.FixColumns(t);
            r.Doc.Blocks.Add(t);
            if (lines.Count > maxRows) r.Notices.Add($"Показаны первые {maxRows} строк из {lines.Count}.");
            var info = new InfoSection("Таблица CSV");
            info.Add("Строк", lines.Count);
            info.Add("Разделитель", sep == '\t' ? "табуляция" : sep.ToString());
            info.Add("Кодировка", GuessEncodingName(data));
            r.Info.Add(info);
            // защита от CSV-инъекций: формулы показываются как текст и не вычисляются
            if (lines.Take(3000).Any(l => Regex.IsMatch(l, @"(^|[,;\t])\s*[=+@-][A-Za-z]")))
                r.Security.Add(new SecurityFinding(Severity.Info, "В ячейках есть формулы", "Формулы (возможная CSV-инъекция) показаны как обычный текст и не вычисляются."));
            return r;
        }

        private static char DetectSep(IEnumerable<string> lines)
        {
            var cands = new[] { ';', ',', '\t', '|' };
            return cands.OrderByDescending(c => lines.Sum(l => l.Count(ch => ch == c))).First();
        }

        public static List<string> ParseCsvLine(string line, char sep)
        {
            var res = new List<string>();
            var sb = new StringBuilder();
            bool q = false;
            for (int i = 0; i < line.Length; i++)
            {
                char c = line[i];
                if (q)
                {
                    if (c == '"') { if (i + 1 < line.Length && line[i + 1] == '"') { sb.Append('"'); i++; } else q = false; }
                    else sb.Append(c);
                }
                else if (c == '"') q = true;
                else if (c == sep) { res.Add(sb.ToString()); sb.Clear(); }
                else sb.Append(c);
            }
            res.Add(sb.ToString());
            return res;
        }

        // ---------- RTF ----------
        public static FlowResult Rtf(byte[] data, ReflowSettings s)
        {
            var r = new FlowResult();
            r.PageSize = new Size(793.7, 1122.5);
            r.Padding = new Thickness(90, 76, 72, 76);
            r.Doc.FontFamily = new FontFamily("Times New Roman, Segoe UI");
            r.Doc.FontSize = 16;
            // Защита: удаляем из RTF встроенные OLE-объекты и поля автоматического обновления до разбора
            var clean = SanitizeRtf(data, r.Security);
            var range = new TextRange(r.Doc.ContentStart, r.Doc.ContentEnd);
            using (var ms = new MemoryStream(clean, false))
                range.Load(ms, DataFormats.Rtf);
            if (s.Light)
            {
                while (r.Doc.Blocks.Count > 80) r.Doc.Blocks.Remove(r.Doc.Blocks.LastBlock);
            }
            // заголовки по крупному жирному шрифту → оглавление
            foreach (var b in r.Doc.Blocks.OfType<Paragraph>().Take(5000))
            {
                var txt = new TextRange(b.ContentStart, b.ContentEnd).Text.Trim();
                if (txt.Length > 0 && txt.Length < 120 && b.FontWeight == FontWeights.Bold && b.FontSize > 18)
                    r.Toc.Add(new TocItem { Title = txt, Level = 0, Anchor = b });
            }
            var info = new InfoSection("Документ RTF");
            var head = Encoding.ASCII.GetString(data, 0, Math.Min(data.Length, 200000));
            info.Add("Заголовок", RtfInfo(head, "title"));
            info.Add("Автор", RtfInfo(head, "author"));
            info.Add("Тема", RtfInfo(head, "subject"));
            info.Add("Ключевые слова", RtfInfo(head, "keywords"));
            info.Add("Оператор", RtfInfo(head, "operator"));
            info.Add("Генератор", Regex.Match(head, @"\{\\\*\\generator ([^;}]*)").Groups[1].Value);
            r.Info.Add(info);
            r.Title = RtfInfo(head, "title"); r.Author = RtfInfo(head, "author");
            return r;
        }

        private static string RtfInfo(string head, string key)
        {
            var m = Regex.Match(head, @"\{\\" + key + @"\s+([^}]*)\}");
            return m.Success ? m.Groups[1].Value.Trim() : null;
        }

        /// <summary>
        /// Удаляет опасные группы RTF: \object (OLE, в т.ч. эксплойты вида CVE-2017-0199/11882),
        /// \objdata, \*\template (внешний шаблон), а также поля с DDE и сетевыми INCLUDE.
        /// </summary>
        public static byte[] SanitizeRtf(byte[] data, List<SecurityFinding> findings)
        {
            var s = Encoding.GetEncoding(28591).GetString(data); // 1:1 байты
            int removed = 0;
            bool dde = false, template = false;
            string[] dangerous = { "\\object", "\\*\\objdata", "\\objdata", "\\*\\template", "\\*\\datastore", "\\*\\objclass", "\\*\\oleclsid", "\\*\\blipuid" };
            var sb = new StringBuilder(s.Length);
            int i = 0;
            while (i < s.Length)
            {
                if (s[i] == '{')
                {
                    int j = i + 1;
                    while (j < s.Length && (s[j] == ' ' || s[j] == '\r' || s[j] == '\n')) j++;
                    string hit = null;
                    foreach (var d in dangerous)
                        if (string.CompareOrdinal(s, j, d, 0, d.Length) == 0 && (j + d.Length >= s.Length || !char.IsLetter(s[j + d.Length]))) { hit = d; break; }
                    if (hit != null && hit != "\\*\\blipuid")
                    {
                        if (hit.Contains("template")) template = true;
                        int depth = 0, k = i;
                        for (; k < s.Length; k++)
                        {
                            if (s[k] == '\\') { k++; continue; }
                            if (s[k] == '{') depth++;
                            else if (s[k] == '}') { depth--; if (depth == 0) break; }
                        }
                        removed++;
                        i = k + 1;
                        continue;
                    }
                }
                sb.Append(s[i]);
                i++;
            }
            var result = sb.ToString();
            if (Regex.IsMatch(result, @"\\fldinst[^}]*\bDDE(AUTO)?\b", RegexOptions.IgnoreCase))
            {
                dde = true;
                result = Regex.Replace(result, @"(\\fldinst[^}]*?)\bDDE(AUTO)?\b", "$1XDDE", RegexOptions.IgnoreCase);
            }
            result = Regex.Replace(result, @"(INCLUDE(PICTURE|TEXT))\s+(\\\\)?""?(https?|file|\\\\)", "BLOCKED_$1 ", RegexOptions.IgnoreCase);
            if (removed > 0) findings.Add(new SecurityFinding(Severity.Danger, "Встроенные OLE-объекты удалены: " + removed, "Объекты в RTF часто используются для эксплойтов. Они вырезаны до разбора документа."));
            if (template) findings.Add(new SecurityFinding(Severity.Danger, "Ссылка на внешний шаблон", "Загрузка внешнего шаблона заблокирована."));
            if (dde) findings.Add(new SecurityFinding(Severity.Danger, "Поле DDE (запуск команд)", "Поле обезврежено и не выполняется."));
            return Encoding.GetEncoding(28591).GetBytes(result);
        }

        // ---------- HTML ----------
        public static FlowResult Html(byte[] data, ReflowSettings s)
        {
            var r = new FlowResult();
            var html = DecodeHtml(data, s.Light ? 64 * 1024 : 16 * 1024 * 1024);
            var dom = HtmlParser.Parse(html);
            var sink = new FlowSink(r.Doc.Blocks)
            {
                MaxImageWidth = s.PageWidth - s.Margin * 2 - 10,
                MaxImageHeight = s.PageHeight - s.Margin * 2 - 30
            };
            var conv = new HtmlToFlow(sink, n => null) { BaseFontSize = s.FontSize };
            conv.Convert(dom);
            r.Toc.AddRange(conv.HeadingToc.Where(t => t.Level <= 1).Take(500));
            var title = Regex.Match(html, @"<title[^>]*>(.*?)</title>", RegexOptions.IgnoreCase | RegexOptions.Singleline);
            r.Title = title.Success ? System.Net.WebUtility.HtmlDecode(title.Groups[1].Value).Trim() : null;
            var info = new InfoSection("Веб-страница (HTML)");
            info.Add("Заголовок", r.Title);
            foreach (Match m in Regex.Matches(html, @"<meta\s+[^>]*name\s*=\s*[""']?(description|author|keywords|generator)[""']?[^>]*content\s*=\s*[""']([^""']*)", RegexOptions.IgnoreCase))
                info.Add(m.Groups[1].Value.ToLowerInvariant() == "description" ? "Описание" : m.Groups[1].Value.ToLowerInvariant() == "author" ? "Автор" : m.Groups[1].Value.ToLowerInvariant() == "keywords" ? "Ключевые слова" : "Генератор", System.Net.WebUtility.HtmlDecode(m.Groups[2].Value));
            r.Info.Add(info);
            if (r.Doc.Blocks.Count == 0) r.Doc.Blocks.Add(new Paragraph(new Run("(страница не содержит текста)")) { Foreground = Brushes.Gray });
            r.Notices.Add("Веб-страница показана в безопасном режиме: скрипты удалены, внешние картинки и ресурсы не загружаются.");
            return r;
        }

        public static string DecodeHtml(byte[] data, int max)
        {
            // учитываем <meta charset>
            var head = Encoding.ASCII.GetString(data, 0, Math.Min(data.Length, 4096));
            var m = Regex.Match(head, @"charset\s*=\s*[""']?([\w-]+)", RegexOptions.IgnoreCase);
            if (m.Success && !(data.Length >= 3 && data[0] == 0xEF && data[1] == 0xBB))
            {
                try
                {
                    SafeIO.EnsureInit();
                    var enc = Encoding.GetEncoding(m.Groups[1].Value);
                    return enc.GetString(data, 0, Math.Min(data.Length, max));
                }
                catch { }
            }
            return SafeIO.DecodeText(data, max);
        }

        public static void ScanHtml(byte[] data, List<SecurityFinding> list)
        {
            var t = Encoding.UTF8.GetString(data, 0, Math.Min(data.Length, 30 * 1024 * 1024));
            int scripts = Regex.Matches(t, @"<script\b", RegexOptions.IgnoreCase).Count;
            int handlers = Regex.Matches(t, @"\son[a-z]{3,20}\s*=", RegexOptions.IgnoreCase).Count;
            int frames = Regex.Matches(t, @"<(iframe|frame|object|embed|applet)\b", RegexOptions.IgnoreCase).Count;
            int forms = Regex.Matches(t, @"<form\b", RegexOptions.IgnoreCase).Count;
            int jsLinks = Regex.Matches(t, @"(href|src)\s*=\s*[""']?\s*(javascript|vbscript):", RegexOptions.IgnoreCase).Count;
            int remote = Regex.Matches(t, @"(src|href)\s*=\s*[""']?https?://", RegexOptions.IgnoreCase).Count;
            if (scripts + handlers + jsLinks > 0) list.Add(new SecurityFinding(Severity.Danger, $"Скрипты: {scripts} блок(ов), {handlers} обработчик(ов), {jsLinks} JS-ссылок", "Все скрипты удалены при разборе и никогда не выполняются."));
            if (frames > 0) list.Add(new SecurityFinding(Severity.Warning, "Встраиваемые объекты (iframe/object/embed): " + frames, "Не отображаются и не загружаются."));
            if (forms > 0) list.Add(new SecurityFinding(Severity.Warning, "Формы ввода: " + forms, "Формы (в т.ч. фишинговые) не отображаются и ничего не отправляют."));
            if (remote > 0) list.Add(new SecurityFinding(Severity.Info, "Ссылок на внешние ресурсы: " + remote, "Ничего не загружается из интернета — исключены «маячки» слежения."));
        }
    }
}
