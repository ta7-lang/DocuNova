using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace DocuNova.Core.Formats
{
    /// <summary>
    /// Преобразование упрощённого DOM (HTML/XHTML) в блоки FlowDocument.
    /// Внешние ресурсы (http/https/file) никогда не загружаются.
    /// </summary>
    public sealed class HtmlToFlow
    {
        private readonly FlowSink _root;
        private readonly Func<HNode, byte[]> _resolveImage;
        public string AnchorPrefix { get; set; } = "";
        public List<TocItem> HeadingToc { get; } = new List<TocItem>();
        public bool CollectHeadings { get; set; } = true;
        public double BaseFontSize { get; set; } = 17;
        private int _images;
        public int MaxImages { get; set; } = 3000;

        public HtmlToFlow(FlowSink sink, Func<HNode, byte[]> resolveImage)
        {
            _root = sink;
            _resolveImage = resolveImage;
        }

        public void Convert(HNode root)
        {
            var body = root.Find("body") ?? root;
            Children(body, _root, new InlineStyle(), false);
            _root.Flush();
        }

        private void Children(HNode n, FlowSink sink, InlineStyle st, bool pre)
        {
            foreach (var k in n.Kids) Node(k, sink, st, pre);
        }

        private static readonly Regex Ws = new Regex(@"\s+", RegexOptions.Compiled);

        private void Node(HNode n, FlowSink sink, InlineStyle st, bool pre)
        {
            if (n.IsText)
            {
                if (pre)
                {
                    var lines = n.Text.Replace("\r\n", "\n").Split('\n');
                    for (int i = 0; i < lines.Length; i++)
                    {
                        if (i > 0) sink.AddLineBreak();
                        if (lines[i].Length > 0) sink.AddText(lines[i].Replace("\t", "    "), st, false);
                    }
                }
                else sink.AddText(n.Text, st);
                return;
            }

            string id = n.A("id") ?? (n.Name == "a" ? n.A("name") : null);
            if (!string.IsNullOrEmpty(id)) sink.Anchor(AnchorPrefix + "#" + id);

            st = ApplyCss(n, st);
            if (IsHidden(n)) return;

            switch (n.Name)
            {
                case "br": sink.AddLineBreak(); return;
                case "mbp:pagebreak": sink.PageBreak(); return;
                case "hr": sink.Rule(); return;
                case "img":
                case "image":
                    if (_images++ < MaxImages)
                    {
                        var bytes = SafeResolve(n);
                        var bmp = bytes != null ? SafeIO.LoadImage(bytes, 2400) : null;
                        if (bmp != null)
                        {
                            double w = ParseLen(n.A("width")), h = ParseLen(n.A("height"));
                            sink.AddImage(bmp, w, h, n.Name == "image" || n.Parent?.Name == "svg");
                        }
                        else
                        {
                            var alt = n.A("alt");
                            if (!string.IsNullOrWhiteSpace(alt)) sink.AddText("[" + alt + "]", new InlineStyle { Italic = true, Color = Brushes.Gray });
                        }
                    }
                    return;

                case "b": case "strong": st.Bold = true; break;
                case "i": case "em": case "cite": case "dfn": case "var": st.Italic = true; break;
                case "u": case "ins": st.Underline = true; break;
                case "s": case "strike": case "del": st.Strike = true; break;
                case "code": case "tt": case "kbd": case "samp": st.Mono = true; break;
                case "sup": st.Sup = true; st.Size = 0.8; break;
                case "sub": st.Sub = true; st.Size = 0.8; break;
                case "small": st.AbsSize = BaseFontSize * 0.85; break;
                case "big": st.AbsSize = BaseFontSize * 1.2; break;
                case "mark": st.Highlight = new SolidColorBrush(Color.FromRgb(255, 240, 120)); break;
                case "a":
                    if (n.A("href") != null) { st.Color = new SolidColorBrush(Color.FromRgb(30, 90, 200)); st.Underline = true; }
                    break;
                case "font":
                    var fc = ParseColor(n.A("color")); if (fc != null) st.Color = fc;
                    if (!string.IsNullOrEmpty(n.A("face"))) st.Font = n.A("face").Split(',')[0].Trim();
                    break;
                case "q":
                    sink.AddText("«", st); Children(n, sink, st, pre); sink.AddText("»", st); return;
            }

            if (IsBlock(n.Name)) { BlockEl(n, sink, st, pre); return; }
            if (n.Name == "sup" || n.Name == "sub")
            {
                // уменьшенный шрифт
                st.AbsSize = BaseFontSize * 0.75;
            }
            Children(n, sink, st, pre);
        }

        private static bool IsHidden(HNode n)
        {
            var style = n.A("style");
            if (style != null && Regex.IsMatch(style, @"display\s*:\s*none", RegexOptions.IgnoreCase)) return true;
            return n.Attr.ContainsKey("hidden");
        }

        private static readonly HashSet<string> Blocks = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        {
            "p","div","h1","h2","h3","h4","h5","h6","blockquote","pre","ul","ol","li","table","section","article","header","footer",
            "center","figure","figcaption","dl","dt","dd","nav","aside","main","address","body","html","caption","tr","td","th","thead","tbody","tfoot","svg","listing"
        };

        private static bool IsBlock(string name) => Blocks.Contains(name);

        private void BlockEl(HNode n, FlowSink sink, InlineStyle st, bool pre)
        {
            var align = Align(n);
            switch (n.Name)
            {
                case "h1": case "h2": case "h3": case "h4": case "h5": case "h6":
                {
                    int level = n.Name[1] - '0';
                    double[] k = { 0, 1.75, 1.45, 1.25, 1.1, 1.0, 0.95 };
                    double size = BaseFontSize * k[level];
                    var item = CollectHeadings && level <= 3 ? new TocItem { Title = Ws.Replace(n.InnerText(), " ").Trim(), Level = level - 1 } : null;
                    if (item != null && item.Title.Length > 0)
                    {
                        if (item.Title.Length > 120) item.Title = item.Title.Substring(0, 117) + "…";
                        sink.TocHere(item);
                        HeadingToc.Add(item);
                    }
                    sink.Begin(() => new Paragraph
                    {
                        FontSize = size,
                        FontWeight = FontWeights.Bold,
                        Margin = new Thickness(0, size * 0.9, 0, size * 0.45),
                        KeepWithNext = true,
                        TextAlignment = align ?? TextAlignment.Left,
                        LineHeight = size * 1.25
                    });
                    Children(n, sink, st, pre);
                    sink.End();
                    return;
                }
                case "pre": case "listing":
                    sink.Begin(() => new Paragraph
                    {
                        FontFamily = new FontFamily("Consolas, Courier New"),
                        FontSize = BaseFontSize * 0.82,
                        Background = new SolidColorBrush(Color.FromRgb(244, 245, 248)),
                        Padding = new Thickness(8),
                        TextAlignment = TextAlignment.Left,
                        Margin = new Thickness(0, 4, 0, 8)
                    });
                    Children(n, sink, st, true);
                    sink.End();
                    return;

                case "blockquote":
                {
                    var sec = new Section
                    {
                        Margin = new Thickness(24, 6, 12, 6),
                        Padding = new Thickness(12, 2, 0, 2),
                        BorderBrush = new SolidColorBrush(Color.FromRgb(180, 180, 200)),
                        BorderThickness = new Thickness(3, 0, 0, 0),
                        FontStyle = FontStyles.Italic
                    };
                    sink.Add(sec);
                    var child = sink.Child(sec.Blocks);
                    Children(n, child, st, pre);
                    child.Flush();
                    return;
                }
                case "ul": case "ol":
                {
                    var list = new List
                    {
                        MarkerStyle = n.Name == "ol" ? TextMarkerStyle.Decimal : TextMarkerStyle.Disc,
                        Margin = new Thickness(0, 4, 0, 6),
                        Padding = new Thickness(22, 0, 0, 0)
                    };
                    if (n.Name == "ol" && int.TryParse(n.A("start"), out var start) && start > 0) list.StartIndex = start;
                    var type = n.A("type");
                    if (type == "a") list.MarkerStyle = TextMarkerStyle.LowerLatin;
                    else if (type == "A") list.MarkerStyle = TextMarkerStyle.UpperLatin;
                    else if (type == "i") list.MarkerStyle = TextMarkerStyle.LowerRoman;
                    else if (type == "I") list.MarkerStyle = TextMarkerStyle.UpperRoman;
                    sink.Add(list);
                    ListItem cur = null;
                    FlowSink curSink = null;
                    foreach (var k in n.Kids)
                    {
                        if (k.Name == "li")
                        {
                            cur = new ListItem();
                            list.ListItems.Add(cur);
                            var s2 = sink.Child(cur.Blocks);
                            Children(k, s2, st, pre);
                            s2.Flush();
                            curSink = null;
                        }
                        else if (k.IsText && string.IsNullOrWhiteSpace(k.Text)) continue;
                        else
                        {
                            if (curSink == null)
                            {
                                if (cur == null) { cur = new ListItem(); list.ListItems.Add(cur); }
                                curSink = sink.Child(cur.Blocks);
                            }
                            Node(k, curSink, st, pre);
                        }
                    }
                    if (list.ListItems.Count == 0) list.ListItems.Add(new ListItem(new Paragraph()));
                    return;
                }
                case "dl":
                    Children(n, sink, st, pre);
                    return;
                case "dt":
                    sink.Begin(() => new Paragraph { FontWeight = FontWeights.Bold, Margin = new Thickness(0, 6, 0, 0) });
                    Children(n, sink, st, pre);
                    sink.End();
                    return;
                case "dd":
                    sink.Begin(() => new Paragraph { Margin = new Thickness(24, 0, 0, 4) });
                    Children(n, sink, st, pre);
                    sink.End();
                    return;
                case "table":
                    TableEl(n, sink, st);
                    return;
                case "tr": case "td": case "th": case "thead": case "tbody": case "tfoot": case "caption":
                    // вне таблицы — как обычный блок
                    sink.Begin(() => new Paragraph());
                    Children(n, sink, st, pre);
                    sink.End();
                    return;
                case "li":
                    sink.Begin(() => new Paragraph { Margin = new Thickness(18, 0, 0, 2) });
                    sink.AddText("• ", st);
                    Children(n, sink, st, pre);
                    sink.End();
                    return;
                case "figcaption":
                    sink.Begin(() => new Paragraph { TextAlignment = TextAlignment.Center, FontStyle = FontStyles.Italic, FontSize = BaseFontSize * 0.88 });
                    Children(n, sink, st, pre);
                    sink.End();
                    return;
                case "center":
                    align = TextAlignment.Center;
                    break;
            }

            // Обычные блоки: p, div, section и т.д.
            bool isP = n.Name == "p";
            var cls = (n.A("class") ?? "").ToLowerInvariant();
            sink.Begin(() =>
            {
                var p = new Paragraph { Margin = isP ? new Thickness(0, 0, 0, BaseFontSize * 0.45) : new Thickness(0, 0, 0, 2) };
                if (align.HasValue) p.TextAlignment = align.Value;
                if (isP && !align.HasValue && !cls.Contains("noindent")) p.TextIndent = BaseFontSize * 1.3;
                var indent = CssValue(n.A("style"), "text-indent");
                if (indent != null) { var v = ParseLen(indent); if (v >= 0) p.TextIndent = v; }
                return p;
            });
            Children(n, sink, st, pre);
            sink.End();
        }

        private void TableEl(HNode n, FlowSink sink, InlineStyle st)
        {
            var t = FlowSink.NewTable();
            var group = new TableRowGroup();
            t.RowGroups.Add(group);
            int rows = 0;
            foreach (var tr in n.All().Where(x => x.Name == "tr"))
            {
                // пропускаем строки вложенных таблиц
                var owner = tr.Parent;
                while (owner != null && owner.Name != "table") owner = owner.Parent;
                if (owner != n) continue;
                if (++rows > 5000) break;
                var row = new TableRow();
                group.Rows.Add(row);
                foreach (var td in tr.Kids.Where(x => x.Name == "td" || x.Name == "th"))
                {
                    var cell = FlowSink.NewCell(td.Name == "th");
                    if (int.TryParse(td.A("colspan"), out var cs) && cs > 1) cell.ColumnSpan = Math.Min(cs, 64);
                    if (int.TryParse(td.A("rowspan"), out var rs) && rs > 1) cell.RowSpan = Math.Min(rs, 1000);
                    row.Cells.Add(cell);
                    var s2 = sink.Child(cell.Blocks);
                    s2.Begin(() => new Paragraph { Margin = new Thickness(0), TextIndent = 0, TextAlignment = TextAlignment.Left });
                    Children(td, s2, st, false);
                    s2.End();
                    if (cell.Blocks.Count == 0) cell.Blocks.Add(new Paragraph());
                }
                if (row.Cells.Count == 0) { var c = FlowSink.NewCell(false); c.Blocks.Add(new Paragraph()); row.Cells.Add(c); }
            }
            if (rows == 0) return;
            FlowSink.FixColumns(t);
            sink.Add(t);
        }

        private byte[] SafeResolve(HNode n)
        {
            try
            {
                var src = n.A("src") ?? n.A("href") ?? n.A("xlink:href");
                if (src != null && src.StartsWith("data:", StringComparison.OrdinalIgnoreCase))
                {
                    int comma = src.IndexOf(',');
                    if (comma > 0 && src.Substring(0, comma).IndexOf("base64", StringComparison.OrdinalIgnoreCase) >= 0)
                        return System.Convert.FromBase64String(src.Substring(comma + 1));
                    return null;
                }
                if (src != null && (src.StartsWith("http:", StringComparison.OrdinalIgnoreCase) || src.StartsWith("https:", StringComparison.OrdinalIgnoreCase)
                    || src.StartsWith("file:", StringComparison.OrdinalIgnoreCase) || src.StartsWith("\\\\") || src.StartsWith("ftp:", StringComparison.OrdinalIgnoreCase)))
                    return null; // внешние ресурсы заблокированы
                return _resolveImage?.Invoke(n);
            }
            catch { return null; }
        }

        // ---------- CSS (минимально) ----------

        private InlineStyle ApplyCss(HNode n, InlineStyle st)
        {
            var style = n.A("style");
            if (string.IsNullOrEmpty(style)) return st;
            var fw = CssValue(style, "font-weight");
            if (fw != null) st.Bold = fw.Contains("bold") || (int.TryParse(fw, out var w) && w >= 600);
            var fs = CssValue(style, "font-style");
            if (fs != null) st.Italic = fs.Contains("italic") || fs.Contains("oblique");
            var td = CssValue(style, "text-decoration");
            if (td != null) { if (td.Contains("underline")) st.Underline = true; if (td.Contains("line-through")) st.Strike = true; }
            var col = ParseColor(CssValue(style, "color"));
            if (col != null && !IsNearWhite(col)) st.Color = col;
            var size = CssValue(style, "font-size");
            if (size != null)
            {
                if (size.EndsWith("em") && double.TryParse(size.Replace("em", "").Replace("r", ""), NumberStyles.Float, CultureInfo.InvariantCulture, out var em)) st.AbsSize = BaseFontSize * Math.Max(0.5, Math.Min(em, 3));
                else if (size.EndsWith("%") && double.TryParse(size.TrimEnd('%'), NumberStyles.Float, CultureInfo.InvariantCulture, out var pc)) st.AbsSize = BaseFontSize * Math.Max(0.5, Math.Min(pc / 100, 3));
            }
            var fv = CssValue(style, "font-variant");
            if (fv != null && fv.Contains("small-caps")) st.SmallCaps = true;
            return st;
        }

        private static bool IsNearWhite(Brush b) => b is SolidColorBrush s && s.Color.R > 235 && s.Color.G > 235 && s.Color.B > 235;

        private static TextAlignment? Align(HNode n)
        {
            var a = n.A("align") ?? CssValue(n.A("style"), "text-align");
            if (a == null) return null;
            a = a.ToLowerInvariant();
            if (a.Contains("center")) return TextAlignment.Center;
            if (a.Contains("right")) return TextAlignment.Right;
            if (a.Contains("justify")) return TextAlignment.Justify;
            if (a.Contains("left")) return TextAlignment.Left;
            return null;
        }

        public static string CssValue(string style, string prop)
        {
            if (string.IsNullOrEmpty(style)) return null;
            foreach (var part in style.Split(';'))
            {
                int c = part.IndexOf(':');
                if (c <= 0) continue;
                if (part.Substring(0, c).Trim().Equals(prop, StringComparison.OrdinalIgnoreCase))
                    return part.Substring(c + 1).Trim().ToLowerInvariant().Replace("!important", "").Trim();
            }
            return null;
        }

        public static double ParseLen(string v)
        {
            if (string.IsNullOrWhiteSpace(v)) return 0;
            v = v.Trim().ToLowerInvariant();
            double mul = 1;
            if (v.EndsWith("px")) v = v.Substring(0, v.Length - 2);
            else if (v.EndsWith("pt")) { v = v.Substring(0, v.Length - 2); mul = 96.0 / 72; }
            else if (v.EndsWith("em")) { v = v.Substring(0, v.Length - 2); mul = 16; }
            else if (v.EndsWith("%")) return 0;
            return double.TryParse(v, NumberStyles.Float, CultureInfo.InvariantCulture, out var d) ? d * mul : 0;
        }

        public static Brush ParseColor(string c)
        {
            if (string.IsNullOrWhiteSpace(c)) return null;
            try
            {
                c = c.Trim();
                if (c.StartsWith("rgb", StringComparison.OrdinalIgnoreCase))
                {
                    var nums = Regex.Matches(c, @"\d+").Cast<Match>().Select(m => int.Parse(m.Value)).ToArray();
                    if (nums.Length >= 3) return Frozen(Color.FromRgb((byte)Math.Min(255, nums[0]), (byte)Math.Min(255, nums[1]), (byte)Math.Min(255, nums[2])));
                    return null;
                }
                if (!c.StartsWith("#") && Regex.IsMatch(c, "^[0-9a-fA-F]{6}$")) c = "#" + c;
                var obj = ColorConverter.ConvertFromString(c);
                if (obj is Color col) return Frozen(col);
            }
            catch { }
            return null;
        }

        private static Brush Frozen(Color c) { var b = new SolidColorBrush(c); b.Freeze(); return b; }
    }
}
