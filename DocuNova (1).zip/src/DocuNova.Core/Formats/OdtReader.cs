using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Xml.Linq;

namespace DocuNova.Core.Formats
{
    /// <summary>OpenDocument: ODT, ODS, ODP, OTT. Макросы Basic не выполняются.</summary>
    public static class OdtReader
    {
        private sealed class OStyle { public bool? Bold, Italic, Underline, Strike; public double Size; public Brush Color, Bg; public TextAlignment? Align; public string Parent; public double MarginLeft; }

        private sealed class Ctx
        {
            public SafeZip Z;
            public Dictionary<string, OStyle> Styles = new Dictionary<string, OStyle>();
            public FlowResult R;
            public double Base = 16;
            public bool Light;
            public int Count;
            public int Images;
        }

        public static FlowResult Read(byte[] data, ReflowSettings s)
        {
            var r = new FlowResult();
            using (var z = new SafeZip(data))
            {
                var content = z.ReadXml("content.xml") ?? throw new UnsupportedFormatException("OpenDocument повреждён: нет content.xml.");
                var c = new Ctx { Z = z, R = r, Light = s.Light };
                var stylesDoc = z.ReadXml("styles.xml");
                if (stylesDoc != null) LoadStyles(c, stylesDoc);
                LoadStyles(c, content);

                // страница из styles.xml
                var pl = stylesDoc?.DescFirst("page-layout-properties");
                double pw = Len(pl?.Attr("page-width")), ph = Len(pl?.Attr("page-height"));
                var bodyEl = content.DescFirst("body");
                bool presentation = bodyEl?.Kid("presentation") != null;
                bool spreadsheet = bodyEl?.Kid("spreadsheet") != null;
                if (pw > 200 && ph > 200 && pw < 6000 && ph < 6000) r.PageSize = new Size(pw, ph);
                else r.PageSize = presentation ? new Size(1056, 594) : new Size(793.7, 1122.5);
                double ml = Len(pl?.Attr("margin-left")), mt = Len(pl?.Attr("margin-top")), mr = Len(pl?.Attr("margin-right")), mb = Len(pl?.Attr("margin-bottom"));
                r.Padding = (ml + mt + mr + mb) > 0 && !presentation
                    ? new Thickness(Math.Max(20, ml), Math.Max(20, mt), Math.Max(20, mr), Math.Max(20, mb))
                    : new Thickness(48, 40, 48, 40);
                if (spreadsheet) { r.PageSize = new Size(1122.5, 793.7); r.Padding = new Thickness(36); }

                var defSize = stylesDoc?.Desc("default-style").Select(d => d.Kid("text-properties")?.Attr("font-size")).FirstOrDefault(x => x != null);
                if (defSize != null && Len(defSize) > 0) c.Base = Len(defSize);
                r.Doc.FontSize = c.Base;
                r.Doc.FontFamily = new FontFamily("Liberation Serif, Times New Roman, Segoe UI");
                r.Doc.TextAlignment = TextAlignment.Left;

                var sink = new FlowSink(r.Doc.Blocks)
                {
                    MaxImageWidth = r.PageSize.Value.Width - r.Padding.Value.Left - r.Padding.Value.Right - 4,
                    MaxImageHeight = r.PageSize.Value.Height - r.Padding.Value.Top - r.Padding.Value.Bottom - 20
                };
                if (bodyEl != null) Blocks(bodyEl, sink, c, 0);
                sink.Flush();

                // метаданные
                var meta = z.ReadXml("meta.xml");
                var info = new InfoSection(presentation ? "Презентация OpenDocument" : spreadsheet ? "Таблица OpenDocument" : "Документ OpenDocument");
                if (meta != null)
                {
                    r.Title = meta.DescFirst("title").Val();
                    r.Author = meta.DescFirst("initial-creator").Val() ?? meta.DescFirst("creator").Val();
                    info.Add("Заголовок", r.Title);
                    info.Add("Автор", meta.DescFirst("initial-creator").Val());
                    info.Add("Последним изменил", meta.DescFirst("creator").Val());
                    info.Add("Тема", meta.DescFirst("subject").Val());
                    info.Add("Описание", meta.DescFirst("description").Val());
                    info.Add("Ключевые слова", string.Join(", ", meta.Desc("keyword").Select(k => k.Val())));
                    info.Add("Создан", DocxReader.IsoDate(meta.DescFirst("creation-date").Val()));
                    info.Add("Изменён", DocxReader.IsoDate(meta.DescFirst("date").Val()));
                    info.Add("Программа", meta.DescFirst("generator").Val());
                    info.Add("Редакций", meta.DescFirst("editing-cycles").Val());
                    var stat = meta.DescFirst("document-statistic");
                    if (stat != null)
                    {
                        info.Add("Страниц (по данным файла)", stat.Attr("page-count"));
                        info.Add("Слов (по данным файла)", stat.Attr("word-count"));
                        info.Add("Символов (по данным файла)", stat.Attr("character-count"));
                        info.Add("Таблиц", stat.Attr("table-count"));
                        info.Add("Изображений", stat.Attr("image-count"));
                    }
                }
                r.Info.Add(info);
                Scan(z, r.Security);
            }
            return r;
        }

        public static BitmapSource ExtractThumbnail(byte[] data)
        {
            using (var z = new SafeZip(data)) return SafeIO.LoadImage(z.Read("Thumbnails/thumbnail.png"));
        }

        public static void Scan(byte[] data, List<SecurityFinding> list)
        {
            try { using (var z = new SafeZip(data)) Scan(z, list); } catch { }
        }

        private static void Scan(SafeZip z, List<SecurityFinding> list)
        {
            if (z.Names.Any(n => n.StartsWith("Basic/", StringComparison.OrdinalIgnoreCase) && n.EndsWith(".xml") && !n.EndsWith("script-lc.xml")) || z.Names.Any(n => n.StartsWith("Scripts/", StringComparison.OrdinalIgnoreCase)))
                list.Add(new SecurityFinding(Severity.Danger, "Документ содержит макросы", "Макросы LibreOffice/OpenOffice никогда не выполняются в DocuNova."));
            var content = z.Read("content.xml");
            if (content != null && SafeIO.IndexOf(content, "event-listener") >= 0)
                list.Add(new SecurityFinding(Severity.Warning, "Обработчики событий", "Автоматические действия документа (события) отключены."));
            if (z.Names.Any(n => n.StartsWith("Object ", StringComparison.OrdinalIgnoreCase) || n.StartsWith("ObjectReplacements/", StringComparison.OrdinalIgnoreCase)))
                list.Add(new SecurityFinding(Severity.Info, "Встроенные объекты", "Показываются только их изображения-заменители; объекты не запускаются."));
        }

        private static double Len(string v)
        {
            if (string.IsNullOrWhiteSpace(v)) return 0;
            v = v.Trim();
            double mul;
            string num;
            if (v.EndsWith("cm")) { mul = 96 / 2.54; num = v.Substring(0, v.Length - 2); }
            else if (v.EndsWith("mm")) { mul = 96 / 25.4; num = v.Substring(0, v.Length - 2); }
            else if (v.EndsWith("in")) { mul = 96; num = v.Substring(0, v.Length - 2); }
            else if (v.EndsWith("pt")) { mul = 96.0 / 72; num = v.Substring(0, v.Length - 2); }
            else if (v.EndsWith("px")) { mul = 1; num = v.Substring(0, v.Length - 2); }
            else if (v.EndsWith("%")) return 0;
            else { mul = 1; num = v; }
            return double.TryParse(num, NumberStyles.Float, CultureInfo.InvariantCulture, out var d) ? d * mul : 0;
        }

        private static void LoadStyles(Ctx c, XDocument d)
        {
            foreach (var st in d.Desc("style"))
            {
                var name = st.Attr("name");
                if (name == null) continue;
                var os = new OStyle { Parent = st.Attr("parent-style-name") };
                var tp = st.Kid("text-properties");
                if (tp != null)
                {
                    var fw = tp.Attr("font-weight"); if (fw != null) os.Bold = fw == "bold" || (int.TryParse(fw, out var w) && w >= 600);
                    var fs = tp.Attr("font-style"); if (fs != null) os.Italic = fs == "italic" || fs == "oblique";
                    var ul = tp.Attr("text-underline-style"); if (ul != null) os.Underline = ul != "none";
                    var lt = tp.Attr("text-line-through-style"); if (lt != null) os.Strike = lt != "none";
                    var sz = tp.Attr("font-size"); if (sz != null && !sz.EndsWith("%")) os.Size = Len(sz);
                    var col = tp.Attr("color"); if (col != null) os.Color = HtmlToFlow.ParseColor(col);
                    var bg = tp.Attr("background-color"); if (bg != null && bg != "transparent") os.Bg = HtmlToFlow.ParseColor(bg);
                }
                var pp = st.Kid("paragraph-properties");
                if (pp != null)
                {
                    switch (pp.Attr("text-align"))
                    {
                        case "center": os.Align = TextAlignment.Center; break;
                        case "end": case "right": os.Align = TextAlignment.Right; break;
                        case "justify": os.Align = TextAlignment.Justify; break;
                        case "start": case "left": os.Align = TextAlignment.Left; break;
                    }
                    os.MarginLeft = Len(pp.Attr("margin-left"));
                }
                c.Styles[name] = os;
            }
        }

        private static OStyle Get(Ctx c, string name)
        {
            var res = new OStyle();
            int guard = 0;
            while (name != null && c.Styles.TryGetValue(name, out var s) && guard++ < 10)
            {
                res.Bold = res.Bold ?? s.Bold; res.Italic = res.Italic ?? s.Italic;
                res.Underline = res.Underline ?? s.Underline; res.Strike = res.Strike ?? s.Strike;
                if (res.Size <= 0) res.Size = s.Size;
                res.Color = res.Color ?? s.Color; res.Bg = res.Bg ?? s.Bg;
                res.Align = res.Align ?? s.Align;
                if (res.MarginLeft <= 0) res.MarginLeft = s.MarginLeft;
                name = s.Parent;
            }
            return res;
        }

        private static InlineStyle Apply(InlineStyle st, OStyle o)
        {
            if (o.Bold.HasValue) st.Bold = o.Bold.Value;
            if (o.Italic.HasValue) st.Italic = o.Italic.Value;
            if (o.Underline == true) st.Underline = true;
            if (o.Strike == true) st.Strike = true;
            if (o.Size > 0) st.AbsSize = o.Size;
            if (o.Color != null) st.Color = o.Color;
            if (o.Bg != null) st.Highlight = o.Bg;
            return st;
        }

        private static void Blocks(XElement parent, FlowSink sink, Ctx c, int depth)
        {
            if (depth > 60) return;
            foreach (var e in parent.Elements())
            {
                if (c.Light && c.Count > 120) return;
                switch (e.Name.LocalName)
                {
                    case "h":
                    case "p":
                        Para(e, sink, c, e.Name.LocalName == "h");
                        break;
                    case "list":
                        ListEl(e, sink, c, 0);
                        break;
                    case "table":
                        TableEl(e, sink, c);
                        break;
                    case "page":  // слайд ODP
                        if (sink.BlockCount > 0) sink.PageBreak();
                        var pname = e.Attr("name");
                        if (pname != null) { var item = new TocItem { Title = pname, Level = 0 }; sink.TocHere(item); c.R.Toc.Add(item); }
                        Blocks(e, sink, c, depth + 1);
                        break;
                    case "frame":
                        var img = e.Kid("image");
                        if (img != null) ImageEl(img, e, sink, c);
                        else Blocks(e, sink, c, depth + 1);
                        break;
                    case "image":
                        ImageEl(e, e.Parent, sink, c);
                        break;
                    case "text-box": case "section": case "text": case "presentation": case "spreadsheet": case "drawing": case "g": case "custom-shape": case "rect": case "ellipse": case "index-body": case "table-of-content": case "alphabetical-index":
                        Blocks(e, sink, c, depth + 1);
                        break;
                    case "notes": case "forms": case "sequence-decls": case "variable-decls": case "user-field-decls": case "tracked-changes": case "index-title-template":
                        break;
                }
            }
        }

        private static void Para(XElement p, FlowSink sink, Ctx c, bool heading)
        {
            c.Count++;
            var os = Get(c, p.Attr("style-name"));
            int level = heading ? Math.Max(1, (int)Len(p.Attr("outline-level") ?? "1")) : 0;
            double size = os.Size > 0 ? os.Size : (heading ? c.Base * Math.Max(1.1, 1.7 - level * 0.15) : 0);
            if (heading)
            {
                var text = FlowSink.CollapseWs(p.Value).Trim();
                if (text.Length > 0 && level <= 3)
                {
                    var item = new TocItem { Title = text.Length > 120 ? text.Substring(0, 117) + "…" : text, Level = level - 1 };
                    sink.TocHere(item); c.R.Toc.Add(item);
                }
            }
            int before = sink.BlockCount;
            Paragraph F()
            {
                var para = new Paragraph { Margin = new Thickness(os.MarginLeft, heading ? 10 : 0, 0, heading ? 6 : 4), TextAlignment = os.Align ?? TextAlignment.Left };
                if (size > 0) para.FontSize = size;
                if (heading) { para.FontWeight = FontWeights.Bold; para.KeepWithNext = true; }
                return para;
            }
            sink.Begin(F);
            Inlines(p, sink, c, Apply(new InlineStyle(), os));
            sink.End();
            if (sink.BlockCount == before) sink.Add(F());
        }

        private static void Inlines(XElement e, FlowSink sink, Ctx c, InlineStyle st)
        {
            foreach (var node in e.Nodes())
            {
                if (node is XText t) { sink.AddText(t.Value, st, true); continue; }
                if (!(node is XElement x)) continue;
                switch (x.Name.LocalName)
                {
                    case "span": Inlines(x, sink, c, Apply(st, Get(c, x.Attr("style-name")))); break;
                    case "a": var ls = st; ls.Underline = true; ls.Color = new SolidColorBrush(Color.FromRgb(5, 99, 193)); Inlines(x, sink, c, ls); break;
                    case "s": int n = 1; int.TryParse(x.Attr("c"), out n); sink.AddText(new string(' ', Math.Max(1, Math.Min(n, 200))), st, false); break;
                    case "tab": sink.AddText("    ", st, false); break;
                    case "line-break": sink.AddLineBreak(); break;
                    case "frame":
                        var img = x.Kid("image");
                        if (img != null) ImageEl(img, x, sink, c);
                        break;
                    case "note": case "annotation": case "bookmark": case "bookmark-start": case "bookmark-end": case "soft-page-break": case "change-start": case "change-end": break;
                    default: Inlines(x, sink, c, st); break;
                }
            }
        }

        private static void ImageEl(XElement img, XElement frame, FlowSink sink, Ctx c)
        {
            if (c.Images++ > 2000) return;
            var href = img.Attr("href");
            if (string.IsNullOrEmpty(href) || href.Contains("://")) return; // внешние ресурсы не загружаются
            var bmp = SafeIO.LoadImage(c.Z.Read(href), 2400);
            if (bmp == null) return;
            double w = Len(frame?.Attr("width")), h = Len(frame?.Attr("height"));
            sink.AddImage(bmp, w, h);
        }

        private static void ListEl(XElement list, FlowSink sink, Ctx c, int level)
        {
            if (level > 10) return;
            foreach (var li in list.Elements().Where(x => x.Name.LocalName == "list-item" || x.Name.LocalName == "list-header"))
            {
                foreach (var e in li.Elements())
                {
                    switch (e.Name.LocalName)
                    {
                        case "p": case "h":
                            c.Count++;
                            var os = Get(c, e.Attr("style-name"));
                            sink.Begin(() => new Paragraph { Margin = new Thickness(22 * (level + 1), 0, 0, 2), TextIndent = -14 });
                            sink.AddText(level % 2 == 0 ? "• " : "◦ ", new InlineStyle(), false);
                            Inlines(e, sink, c, Apply(new InlineStyle(), os));
                            sink.End();
                            break;
                        case "list": ListEl(e, sink, c, level + 1); break;
                        default: Blocks(new XElement("wrap", e), sink, c, 1); break;
                    }
                }
            }
        }

        private static void TableEl(XElement tbl, FlowSink sink, Ctx c)
        {
            var t = FlowSink.NewTable();
            var g = new TableRowGroup(); t.RowGroups.Add(g);
            int rows = 0;
            var tname = tbl.Attr("name");
            foreach (var tr in tbl.Descendants().Where(x => x.Name.LocalName == "table-row"))
            {
                // только строки этой таблицы
                var owner = tr.Ancestors().FirstOrDefault(a => a.Name.LocalName == "table");
                if (owner != tbl) continue;
                int rep = Math.Min(int.TryParse(tr.Attr("number-rows-repeated"), out var rr) ? rr : 1, 50);
                var cells = new List<XElement>();
                foreach (var cell in tr.Elements().Where(x => x.Name.LocalName == "table-cell" || x.Name.LocalName == "covered-table-cell"))
                {
                    int crep = Math.Min(int.TryParse(cell.Attr("number-columns-repeated"), out var cr) ? cr : 1, 60);
                    for (int i = 0; i < crep; i++) cells.Add(cell);
                }
                // убираем хвост пустых ячеек
                while (cells.Count > 1 && !cells[cells.Count - 1].HasElements) cells.RemoveAt(cells.Count - 1);
                if (cells.Count == 1 && !cells[0].HasElements && rep > 1) continue;
                for (int k = 0; k < rep; k++)
                {
                    if (++rows > 3000) break;
                    var row = new TableRow(); g.Rows.Add(row);
                    foreach (var cell in cells)
                    {
                        var tc = FlowSink.NewCell(false);
                        if (int.TryParse(cell.Attr("number-columns-spanned"), out var span) && span > 1) tc.ColumnSpan = Math.Min(64, span);
                        row.Cells.Add(tc);
                        var cs = sink.Child(tc.Blocks);
                        Blocks(cell, cs, c, 1);
                        cs.Flush();
                        if (tc.Blocks.Count == 0) tc.Blocks.Add(new Paragraph());
                    }
                }
                if (rows > 3000) break;
            }
            // убираем пустые строки в конце
            while (g.Rows.Count > 1 && g.Rows[g.Rows.Count - 1].Cells.All(cl => cl.Blocks.All(b => b is Paragraph pp && pp.Inlines.Count == 0))) g.Rows.RemoveAt(g.Rows.Count - 1);
            if (g.Rows.Count == 0) return;
            if (!string.IsNullOrEmpty(tname) && sink.BlockCount >= 0 && c.R.Doc.Blocks.Count >= 0 && IsSheet(tbl))
            {
                if (sink.BlockCount > 0) sink.PageBreak();
                var item = new TocItem { Title = tname, Level = 0 };
                sink.TocHere(item); c.R.Toc.Add(item);
                sink.Add(new Paragraph(new Run(tname)) { FontWeight = FontWeights.Bold, FontSize = c.Base * 1.3, Margin = new Thickness(0, 0, 0, 8) });
            }
            FlowSink.FixColumns(t);
            sink.Add(t);
        }

        private static bool IsSheet(XElement tbl) => tbl.Parent?.Name.LocalName == "spreadsheet";
    }
}
