using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace DocuNova.Core
{
    /// <summary>Документ из изображений: комиксы CBZ, многостраничный TIFF, одиночные картинки.</summary>
    public sealed class ImageDoc : DocumentBase
    {
        private readonly List<Func<BitmapSource>> _loaders = new List<Func<BitmapSource>>();
        private readonly List<Size> _sizes = new List<Size>();
        private const double MaxDipSide = 1100;
        private const int MaxPixelSide = 4000;

        public override int PageCount => _loaders.Count;
        public override bool CanRenderOffThread => true;

        private ImageDoc() { Kind = DocKind.Images; }

        public static ImageDoc FromImages(IList<byte[]> images, bool light)
        {
            var d = new ImageDoc();
            foreach (var img in images)
            {
                if (img == null) continue;
                Size px;
                try
                {
                    using (var ms = new MemoryStream(img, false))
                    {
                        var dec = BitmapDecoder.Create(ms, BitmapCreateOptions.DelayCreation | BitmapCreateOptions.IgnoreColorProfile, BitmapCacheOption.None);
                        px = new Size(dec.Frames[0].PixelWidth, dec.Frames[0].PixelHeight);
                    }
                }
                catch { continue; }
                if (px.Width < 1 || px.Height < 1) continue;
                var data = img;
                d._sizes.Add(Normalize(px));
                d._loaders.Add(() => SafeIO.LoadImage(data, 6000));
                if (light) break;
            }
            if (d._loaders.Count == 0) throw new UnsupportedFormatException("Не найдено ни одного изображения.");
            return d;
        }

        /// <summary>Многостраничный TIFF (факсы, сканы) и другие многокадровые изображения.</summary>
        public static ImageDoc FromMultiFrame(byte[] data, bool light)
        {
            var d = new ImageDoc();
            // Кадры не декодируются заранее: многостраничный TIFF на сотни страниц не занимает память целиком
            var dec = BitmapDecoder.Create(new MemoryStream(data, false), BitmapCreateOptions.DelayCreation | BitmapCreateOptions.IgnoreColorProfile, BitmapCacheOption.None);
            int total = dec.Frames.Count;
            int n = light ? Math.Min(1, total) : Math.Min(total, 5000);
            for (int i = 0; i < n; i++)
            {
                var f = dec.Frames[i];
                double dpiX = f.DpiX > 1 ? f.DpiX : 96, dpiY = f.DpiY > 1 ? f.DpiY : 96;
                var px = new Size(f.PixelWidth * 96.0 / dpiX, f.PixelHeight * 96.0 / dpiY);
                d._sizes.Add(Normalize(px));
                int idx = i;
                d._loaders.Add(() => LoadFrame(data, idx));
            }
            if (n == 0) throw new UnsupportedFormatException("Изображение не содержит кадров.");
            d.Info.Add(new InfoSection("Изображение") { });
            d.Info[0].Add("Кадров (страниц)", total);
            d.Info[0].Add("Размер первого кадра", $"{dec.Frames[0].PixelWidth}×{dec.Frames[0].PixelHeight} пикс.");
            d.Info[0].Add("Разрешение", $"{dec.Frames[0].DpiX:0}×{dec.Frames[0].DpiY:0} DPI");
            return d;
        }

        /// <summary>Декодирует один кадр с ограничением размера (защита от «бомб» распаковки и лишней памяти).</summary>
        private static BitmapSource LoadFrame(byte[] data, int index)
        {
            using (var ms = new MemoryStream(data, false))
            {
                var dec = BitmapDecoder.Create(ms, BitmapCreateOptions.IgnoreColorProfile, BitmapCacheOption.None);
                if (index >= dec.Frames.Count) return null;
                BitmapSource f = dec.Frames[index];
                int side = Math.Max(f.PixelWidth, f.PixelHeight);
                if (side > MaxPixelSide)
                {
                    double k = (double)MaxPixelSide / side;
                    f = new TransformedBitmap(f, new ScaleTransform(k, k));
                }
                // копия пикселей, пока поток открыт; дальше декодер не нужен
                return BitmapUtil.Prepare(f, "normal", false, true);
            }
        }

        private static Size Normalize(Size s)
        {
            double k = Math.Max(s.Width, s.Height) > MaxDipSide ? MaxDipSide / Math.Max(s.Width, s.Height) : 1;
            return new Size(Math.Max(1, s.Width * k), Math.Max(1, s.Height * k));
        }

        public override Size GetPageSize(int index) => _sizes[Math.Max(0, Math.Min(index, _sizes.Count - 1))];

        public override BitmapSource RenderPage(int index, double scale)
        {
            var src = _loaders[index]();
            if (src == null) return null;
            var size = GetPageSize(index);
            int targetW = Math.Max(1, (int)Math.Round(size.Width * scale));
            int targetH = Math.Max(1, (int)Math.Round(size.Height * scale));
            // на экране не меньше родного размера — показываем оригинальные пиксели как есть
            if (targetW >= src.PixelWidth || targetH >= src.PixelHeight) return src;
            // уменьшение — точно до размера на экране (пиксель в пиксель), качественным фильтром;
            // материализуем копию, чтобы не держать в памяти полноразмерный оригинал
            double kx = (double)targetW / src.PixelWidth, ky = (double)targetH / src.PixelHeight;
            return BitmapUtil.Prepare(new TransformedBitmap(src, new ScaleTransform(kx, ky)), "normal", false, true);
        }
    }
}
