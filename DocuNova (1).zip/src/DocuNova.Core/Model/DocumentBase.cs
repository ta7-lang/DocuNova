using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Media.Imaging;

namespace DocuNova.Core
{
    /// <summary>Тип раскладки документа.</summary>
    public enum DocKind
    {
        /// <summary>Фиксированная вёрстка (PDF, XPS).</summary>
        Fixed,
        /// <summary>Перетекаемый текст, разбитый на страницы (книги, текстовые документы).</summary>
        Reflow,
        /// <summary>Набор изображений (комиксы, TIFF, картинки).</summary>
        Images
    }

    public sealed class TocItem
    {
        public string Title { get; set; }
        public int PageIndex { get; set; }
        public int Level { get; set; }
        public List<TocItem> Children { get; } = new List<TocItem>();
        internal object Anchor { get; set; }
        public override string ToString() => Title;
    }

    /// <summary>Символ на странице с его рамкой в координатах страницы (DIP, 1/96 дюйма).</summary>
    public struct PageChar
    {
        public char C;
        public Rect Box;
        public PageChar(char c, Rect box) { C = c; Box = box; }
    }

    public sealed class InfoSection
    {
        public string Title { get; set; }
        public List<KeyValuePair<string, string>> Items { get; } = new List<KeyValuePair<string, string>>();
        public InfoSection(string title) { Title = title; }
        public void Add(string key, string value)
        {
            if (!string.IsNullOrWhiteSpace(value))
                Items.Add(new KeyValuePair<string, string>(key, value.Trim()));
        }
        public void Add(string key, long value) => Add(key, value.ToString("N0"));
    }

    public enum Severity { Info, Warning, Danger, Safe }

    public sealed class SecurityFinding
    {
        public Severity Severity { get; set; }
        public string Title { get; set; }
        public string Detail { get; set; }
        public SecurityFinding(Severity s, string title, string detail) { Severity = s; Title = title; Detail = detail; }
    }

    public sealed class PasswordRequiredException : Exception
    {
        public bool WrongPassword { get; }
        public PasswordRequiredException(bool wrong) : base(wrong ? "Неверный пароль." : "Документ защищён паролем.") { WrongPassword = wrong; }
    }

    public sealed class UnsupportedFormatException : Exception
    {
        public UnsupportedFormatException(string message) : base(message) { }
    }

    /// <summary>Базовый класс открытого документа.</summary>
    public abstract class DocumentBase : IDisposable
    {
        public string FilePath { get; internal set; }
        public string FormatName { get; internal set; }
        public string FormatCode { get; internal set; }
        public DocKind Kind { get; protected set; }
        public byte[] Bytes { get; internal set; }
        public string Title { get; set; }
        public string Author { get; set; }
        public BitmapSource Cover { get; set; }
        public List<TocItem> Toc { get; } = new List<TocItem>();
        public List<InfoSection> Info { get; } = new List<InfoSection>();
        public List<SecurityFinding> Security { get; } = new List<SecurityFinding>();
        public List<string> Notices { get; } = new List<string>();

        /// <summary>Распознанный (OCR) текст по страницам — дополняет страницы без текстового слоя.</summary>
        private readonly Dictionary<int, List<PageChar>> _ocr = new Dictionary<int, List<PageChar>>();

        public abstract int PageCount { get; }

        /// <summary>Размер страницы в DIP (1/96 дюйма).</summary>
        public abstract Size GetPageSize(int index);

        /// <summary>Отрисовка страницы. scale = 1 соответствует 96 DPI.</summary>
        public abstract BitmapSource RenderPage(int index, double scale);

        /// <summary>Умеет ли документ рисовать только часть страницы (для чёткого крупного масштаба без огромных картинок).</summary>
        public virtual bool CanRenderRegion => false;

        /// <summary>Отрисовка фрагмента страницы region (DIP страницы) в масштабе scale.</summary>
        public virtual BitmapSource RenderRegion(int index, double scale, Rect region) => null;

        /// <summary>
        /// Отрисовка страницы сразу в «сырые» пиксели с режимом (ночь/сепия) и поворотом — для экрана.
        /// Документы с собственным быстрым путём (PDF) переопределяют этот метод и обходятся без лишних копий.
        /// </summary>
        public virtual PagePixels RenderPagePixels(int index, double scale, string mode, int rotation) =>
            PagePixels.From(RenderPage(index, scale), mode, rotation, Kind != DocKind.Images);

        /// <summary>То же для фрагмента страницы region (DIP страницы).</summary>
        public virtual PagePixels RenderRegionPixels(int index, double scale, Rect region, string mode, int rotation) =>
            PagePixels.From(RenderRegion(index, scale, region), mode, rotation, Kind != DocKind.Images);

        /// <summary>
        /// Отрисовка для экрана с возможностью прервать работу: cancelled проверяется во время отрисовки,
        /// и если страница больше не нужна (прокрутили дальше, сменили масштаб), возвращается null.
        /// </summary>
        public virtual PagePixels RenderPagePixels(int index, double scale, string mode, int rotation, Func<bool> cancelled) =>
            RenderPagePixels(index, scale, mode, rotation);

        /// <summary>То же для фрагмента страницы.</summary>
        public virtual PagePixels RenderRegionPixels(int index, double scale, Rect region, string mode, int rotation, Func<bool> cancelled) =>
            RenderRegionPixels(index, scale, region, mode, rotation);

        /// <summary>Сколько страниц документа имеет смысл рисовать одновременно.</summary>
        public virtual int RenderConcurrency => CanRenderOffThread ? (Environment.ProcessorCount >= 4 ? 3 : 2) : 1;

        /// <summary>
        /// Есть ли данные, которые не нужны для показа первой страницы (оглавление, метаданные, размеры дальних страниц)
        /// и догружаются в фоне уже после того, как документ появился на экране.
        /// </summary>
        public virtual bool HasPendingLoad => false;

        /// <summary>Фоновая догрузка (вызывается не в UI-потоке). Результат копится внутри документа.</summary>
        public virtual void CompleteLoading() { }

        /// <summary>
        /// Переносит догруженные данные в общедоступные списки (Toc, Info, Notices). Вызывать в UI-потоке.
        /// Возвращает true, если изменились размеры каких-либо страниц.
        /// </summary>
        public virtual bool ApplyCompletedLoading() => false;

        /// <summary>Можно ли рисовать страницы из фонового потока.</summary>
        public virtual bool CanRenderOffThread => false;

        public virtual bool IsPdf => false;

        /// <summary>Поддерживает ли документ перестраивание страниц (размер шрифта и т.п.).</summary>
        public virtual bool IsReflowable => false;

        /// <summary>Символы страницы, если есть текстовый слой.</summary>
        public IReadOnlyList<PageChar> GetPageChars(int index)
        {
            if (_ocr.TryGetValue(index, out var o)) return o;
            try { return GetPageCharsCore(index) ?? (IReadOnlyList<PageChar>)Array.Empty<PageChar>(); }
            catch { return Array.Empty<PageChar>(); }
        }

        protected virtual IReadOnlyList<PageChar> GetPageCharsCore(int index) => Array.Empty<PageChar>();

        public void SetOcrChars(int index, List<PageChar> chars) { _ocr[index] = chars; }
        public bool HasOcr(int index) => _ocr.ContainsKey(index);

        public string GetPageText(int index) => CharsToText(GetPageChars(index));

        /// <summary>Собирает текст из символов, восстанавливая пробелы и переводы строк.</summary>
        public static string CharsToText(IReadOnlyList<PageChar> chars)
        {
            var sb = new StringBuilder();
            if (chars == null || chars.Count == 0) return "";
            PageChar prev = chars[0];
            sb.Append(prev.C);
            for (int i = 1; i < chars.Count; i++)
            {
                var c = chars[i];
                double h = Math.Max(1, Math.Min(prev.Box.Height, c.Box.Height));
                double prevMid = prev.Box.Top + prev.Box.Height / 2;
                bool sameLine = Math.Abs((c.Box.Top + c.Box.Height / 2) - prevMid) < h * 0.6;
                if (!sameLine)
                {
                    if (prev.C != '\n') sb.Append('\n');
                }
                else
                {
                    double gap = c.Box.Left - prev.Box.Right;
                    if (gap > h * 0.25 && prev.C != ' ' && c.C != ' ') sb.Append(' ');
                }
                sb.Append(c.C);
                prev = c;
            }
            return sb.ToString();
        }

        /// <summary>Поиск текста на странице: возвращает рамки найденных фрагментов (по строкам).</summary>
        public List<Rect> Find(int index, string query, bool matchCase)
        {
            var result = new List<Rect>();
            if (string.IsNullOrEmpty(query)) return result;
            var chars = GetPageChars(index);
            if (chars.Count == 0) return result;

            // Строим строку с картой индексов символов (пробелы-разделители помечаются -1)
            var sb = new StringBuilder();
            var map = new List<int>();
            for (int i = 0; i < chars.Count; i++)
            {
                if (i > 0)
                {
                    var p = chars[i - 1]; var c = chars[i];
                    double h = Math.Max(1, Math.Min(p.Box.Height, c.Box.Height));
                    bool sameLine = Math.Abs((c.Box.Top + c.Box.Height / 2) - (p.Box.Top + p.Box.Height / 2)) < h * 0.6;
                    if ((!sameLine || c.Box.Left - p.Box.Right > h * 0.25) && p.C != ' ' && c.C != ' ')
                    { sb.Append(' '); map.Add(-1); }
                }
                sb.Append(chars[i].C); map.Add(i);
            }
            string text = sb.ToString();
            string q = System.Text.RegularExpressions.Regex.Replace(query.Trim(), @"\s+", " ");
            var cmp = matchCase ? StringComparison.Ordinal : StringComparison.CurrentCultureIgnoreCase;
            int pos = 0;
            while (pos < text.Length)
            {
                int f = text.IndexOf(q, pos, cmp);
                if (f < 0) break;
                Rect line = Rect.Empty;
                for (int k = f; k < f + q.Length && k < map.Count; k++)
                {
                    int ci = map[k];
                    if (ci < 0) continue;
                    var b = chars[ci].Box;
                    if (!line.IsEmpty && Math.Abs(b.Top - line.Top) > Math.Max(b.Height, line.Height) * 0.6)
                    { result.Add(line); line = Rect.Empty; }
                    line = line.IsEmpty ? b : Rect.Union(line, b);
                }
                if (!line.IsEmpty) result.Add(line);
                pos = f + Math.Max(1, q.Length);
            }
            return result;
        }

        /// <summary>Символы внутри прямоугольника выделения.</summary>
        public List<PageChar> CharsInRect(int index, Rect r)
        {
            var chars = GetPageChars(index);
            var list = new List<PageChar>();
            foreach (var c in chars)
            {
                var b = c.Box;
                var center = new Point(b.Left + b.Width / 2, b.Top + b.Height / 2);
                if (r.Contains(center)) list.Add(c);
            }
            return list;
        }

        /// <summary>Группирует символы в прямоугольники по строкам (для выделения маркером).</summary>
        public static List<Rect> LineRects(List<PageChar> chars)
        {
            var res = new List<Rect>();
            Rect line = Rect.Empty;
            foreach (var c in chars)
            {
                var b = c.Box;
                if (b.Width <= 0 || b.Height <= 0) continue;
                if (!line.IsEmpty && Math.Abs((b.Top + b.Height / 2) - (line.Top + line.Height / 2)) > Math.Max(b.Height, line.Height) * 0.6)
                { res.Add(line); line = Rect.Empty; }
                line = line.IsEmpty ? b : Rect.Union(line, b);
            }
            if (!line.IsEmpty) res.Add(line);
            return res;
        }

        /// <summary>Перестроить страницы (для перетекаемых документов).</summary>
        public virtual void Reflow(ReflowSettings settings) { }

        /// <summary>Поток для повторного чтения исходного файла (null — недоступно).</summary>
        public virtual System.IO.Stream OpenSource() => Bytes != null ? new System.IO.MemoryStream(Bytes, false) : null;

        /// <summary>Освобождает кэши, которые можно восстановить (вызывается для скрытых вкладок и при сворачивании).</summary>
        public virtual void TrimMemory() { }

        /// <summary>Дополнительные сведения для окна свойств (собираются только по запросу).</summary>
        public virtual void LoadDetails() { }

        public virtual void Dispose()
        {
            Bytes = null;
            _ocr.Clear();
            Cover = null;
        }

        public int CountWords(int maxPages = int.MaxValue)
        {
            int words = 0;
            int n = Math.Min(PageCount, maxPages);
            for (int i = 0; i < n; i++)
            {
                var t = GetPageText(i);
                words += t.Split(new[] { ' ', '\n', '\t', '\r' }, StringSplitOptions.RemoveEmptyEntries).Length;
            }
            return words;
        }
    }

    /// <summary>Параметры отображения перетекаемых документов (книг).</summary>
    public sealed class ReflowSettings
    {
        public string FontFamily { get; set; } = "Georgia";
        public double FontSize { get; set; } = 17;
        public double LineHeight { get; set; } = 1.45;
        public double PageWidth { get; set; } = 680;
        public double PageHeight { get; set; } = 940;
        public double Margin { get; set; } = 56;
        public bool Justify { get; set; } = true;
        public bool Hyphenation { get; set; } = true;
        /// <summary>Облегчённый режим (для эскизов): грузится только начало документа.</summary>
        public bool Light { get; set; }

        public ReflowSettings Clone() => (ReflowSettings)MemberwiseClone();
    }
}
