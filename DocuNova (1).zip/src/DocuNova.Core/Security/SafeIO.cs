using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Windows.Media.Imaging;
using System.Xml;
using System.Xml.Linq;

namespace DocuNova.Core
{
    /// <summary>
    /// Безопасный ввод-вывод: ограничения на размер, защита от zip-бомб, XXE,
    /// «бомб» распаковки изображений. Ничего не распаковывается на диск.
    /// </summary>
    public static class SafeIO
    {
        public const long MaxFileSize = 1536L * 1024 * 1024;      // 1.5 ГБ
        public const long MaxZipEntry = 160L * 1024 * 1024;       // 160 МБ на элемент архива
        public const long MaxZipTotal = 1024L * 1024 * 1024;      // 1 ГБ суммарно
        public const int MaxZipEntries = 50000;
        public const int MaxImageSide = 4096;

        static SafeIO()
        {
            try { Encoding.RegisterProvider(CodePagesEncodingProvider.Instance); } catch { }
        }

        public static void EnsureInit() { }

        public static byte[] ReadFile(string path)
        {
            var fi = new FileInfo(path);
            if (!fi.Exists) throw new FileNotFoundException("Файл не найден.", path);
            if (fi.Length > MaxFileSize) throw new UnsupportedFormatException("Файл слишком большой (более 1,5 ГБ).");
            using (var fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete, 1 << 16, FileOptions.SequentialScan))
            {
                var buf = new byte[fs.Length];
                int read = 0;
                while (read < buf.Length)
                {
                    int n = fs.Read(buf, read, buf.Length - read);
                    if (n <= 0) break;
                    read += n;
                }
                if (read != buf.Length) Array.Resize(ref buf, read);
                return buf;
            }
        }

        public static XmlReaderSettings XmlSettings() => new XmlReaderSettings
        {
            DtdProcessing = DtdProcessing.Ignore,       // никаких DTD → нет XXE
            XmlResolver = null,                         // никаких внешних ресурсов
            MaxCharactersFromEntities = 4096,
            MaxCharactersInDocument = 400L * 1024 * 1024,
            IgnoreComments = true,
            IgnoreProcessingInstructions = true,
            CheckCharacters = false,
        };

        public static XDocument LoadXml(byte[] data)
        {
            using (var ms = new MemoryStream(data, false))
            using (var xr = XmlReader.Create(ms, XmlSettings()))
                return XDocument.Load(xr, LoadOptions.PreserveWhitespace);
        }

        public static XDocument LoadXml(string text)
        {
            using (var sr = new StringReader(text))
            using (var xr = XmlReader.Create(sr, XmlSettings()))
                return XDocument.Load(xr, LoadOptions.PreserveWhitespace);
        }

        /// <summary>Безопасная загрузка картинки с ограничением размеров (защита от «бомб» распаковки).</summary>
        public static BitmapSource LoadImage(byte[] data, int maxSide = MaxImageSide)
        {
            if (data == null || data.Length < 8) return null;
            try
            {
                int pw, ph;
                using (var ms = new MemoryStream(data, false))
                {
                    var dec = BitmapDecoder.Create(ms, BitmapCreateOptions.DelayCreation | BitmapCreateOptions.IgnoreColorProfile, BitmapCacheOption.None);
                    if (dec.Frames.Count == 0) return null;
                    pw = dec.Frames[0].PixelWidth; ph = dec.Frames[0].PixelHeight;
                }
                if (pw <= 0 || ph <= 0) return null;
                var bi = new BitmapImage();
                bi.BeginInit();
                bi.CacheOption = BitmapCacheOption.OnLoad;
                bi.CreateOptions = BitmapCreateOptions.IgnoreColorProfile | BitmapCreateOptions.IgnoreImageCache;
                bi.StreamSource = new MemoryStream(data, false);
                if (pw > maxSide || ph > maxSide)
                {
                    if (pw >= ph) bi.DecodePixelWidth = maxSide; else bi.DecodePixelHeight = maxSide;
                }
                bi.EndInit();
                bi.Freeze();
                return bi;
            }
            catch { return null; }
        }

        public static bool LooksLikeImage(byte[] d)
        {
            if (d == null || d.Length < 12) return false;
            if (d[0] == 0xFF && d[1] == 0xD8) return true;                       // JPEG
            if (d[0] == 0x89 && d[1] == 0x50 && d[2] == 0x4E && d[3] == 0x47) return true; // PNG
            if (d[0] == 'G' && d[1] == 'I' && d[2] == 'F') return true;
            if (d[0] == 'B' && d[1] == 'M') return true;
            if ((d[0] == 'I' && d[1] == 'I' && d[2] == 42) || (d[0] == 'M' && d[1] == 'M' && d[3] == 42)) return true;
            if (d[0] == 'R' && d[1] == 'I' && d[2] == 'F' && d[3] == 'F' && d[8] == 'W' && d[9] == 'E' && d[10] == 'B' && d[11] == 'P') return true;
            return false;
        }

        /// <summary>Декодирование текста с определением кодировки (BOM, UTF-8, UTF-16, Windows-1251).</summary>
        public static string DecodeText(byte[] b, int maxBytes = int.MaxValue)
        {
            EnsureInit();
            int len = Math.Min(b.Length, maxBytes);
            if (len >= 3 && b[0] == 0xEF && b[1] == 0xBB && b[2] == 0xBF) return Encoding.UTF8.GetString(b, 3, len - 3);
            if (len >= 2 && b[0] == 0xFF && b[1] == 0xFE) return Encoding.Unicode.GetString(b, 2, (len - 2) & ~1);
            if (len >= 2 && b[0] == 0xFE && b[1] == 0xFF) return Encoding.BigEndianUnicode.GetString(b, 2, (len - 2) & ~1);
            // UTF-16 без BOM: много нулевых байтов
            int zeros = 0, sample = Math.Min(len, 4096);
            for (int i = 1; i < sample; i += 2) if (b[i] == 0) zeros++;
            if (sample > 16 && zeros > sample / 4) return Encoding.Unicode.GetString(b, 0, len & ~1);
            try
            {
                var strict = new UTF8Encoding(false, true);
                int cut = len;
                // не режем посреди многобайтового символа
                if (cut < b.Length) while (cut > 0 && (b[cut] & 0xC0) == 0x80) cut--;
                return strict.GetString(b, 0, cut);
            }
            catch (DecoderFallbackException)
            {
                try { return Encoding.GetEncoding(1251).GetString(b, 0, len); }
                catch { return Encoding.Latin1.GetString(b, 0, len); }
            }
        }

        public static int IndexOf(byte[] data, string ascii, int start = 0)
        {
            var pat = Encoding.ASCII.GetBytes(ascii);
            if (start >= data.Length) return -1;
            int i = data.AsSpan(start).IndexOf(pat);
            return i < 0 ? -1 : i + start;
        }

        public static int Count(byte[] data, string ascii, int max = 100000)
        {
            var pat = Encoding.ASCII.GetBytes(ascii);
            int count = 0, pos = 0;
            var span = data.AsSpan();
            while (pos < data.Length && count < max)
            {
                int i = span.Slice(pos).IndexOf(pat);
                if (i < 0) break;
                count++;
                pos += i + pat.Length;
            }
            return count;
        }

        public static bool StartsWith(byte[] d, string ascii, int offset = 0)
        {
            if (d.Length < offset + ascii.Length) return false;
            for (int i = 0; i < ascii.Length; i++) if (d[offset + i] != (byte)ascii[i]) return false;
            return true;
        }
    }

    /// <summary>ZIP-архив, открытый только для чтения в памяти с лимитами.</summary>
    public sealed class SafeZip : IDisposable
    {
        private readonly ZipArchive _zip;
        private readonly Dictionary<string, ZipArchiveEntry> _map = new Dictionary<string, ZipArchiveEntry>(StringComparer.OrdinalIgnoreCase);
        private long _total;

        public SafeZip(byte[] data)
        {
            _zip = new ZipArchive(new MemoryStream(data, false), ZipArchiveMode.Read, false);
            if (_zip.Entries.Count > SafeIO.MaxZipEntries) throw new UnsupportedFormatException("Архив содержит слишком много файлов.");
            foreach (var e in _zip.Entries)
            {
                var key = Normalize(e.FullName);
                if (!_map.ContainsKey(key)) _map[key] = e;
            }
        }

        public IEnumerable<string> Names => _map.Keys;
        public IEnumerable<ZipArchiveEntry> Entries => _map.Values;

        public static string Normalize(string p)
        {
            if (p == null) return "";
            p = p.Replace('\\', '/');
            try { p = Uri.UnescapeDataString(p); } catch { }
            while (p.StartsWith("/")) p = p.Substring(1);
            return p;
        }

        /// <summary>Объединяет базовую папку и относительный путь, разрешая «..» и «.».</summary>
        public static string Combine(string baseDir, string rel)
        {
            if (string.IsNullOrEmpty(rel)) return baseDir ?? "";
            int hash = rel.IndexOf('#'); if (hash >= 0) rel = rel.Substring(0, hash);
            int q = rel.IndexOf('?'); if (q >= 0) rel = rel.Substring(0, q);
            rel = Normalize(rel);
            var parts = new List<string>();
            if (!string.IsNullOrEmpty(baseDir)) parts.AddRange(baseDir.Replace('\\', '/').Split(new[] { '/' }, StringSplitOptions.RemoveEmptyEntries));
            foreach (var seg in rel.Split('/'))
            {
                if (seg == "" || seg == ".") continue;
                if (seg == "..") { if (parts.Count > 0) parts.RemoveAt(parts.Count - 1); continue; }
                parts.Add(seg);
            }
            return string.Join("/", parts);
        }

        public static string DirOf(string path)
        {
            path = Normalize(path);
            int i = path.LastIndexOf('/');
            return i < 0 ? "" : path.Substring(0, i);
        }

        public bool Exists(string path) => _map.ContainsKey(Normalize(path));

        public byte[] Read(string path)
        {
            if (path == null) return null;
            if (!_map.TryGetValue(Normalize(path), out var e)) return null;
            return Read(e);
        }

        public byte[] Read(ZipArchiveEntry e)
        {
            if (e.Length > SafeIO.MaxZipEntry) throw new UnsupportedFormatException("Элемент архива слишком большой: " + e.FullName);
            using (var s = e.Open())
            using (var ms = new MemoryStream((int)Math.Max(0, Math.Min(e.Length, SafeIO.MaxZipEntry))))
            {
                var buf = new byte[81920];
                int n; long got = 0;
                while ((n = s.Read(buf, 0, buf.Length)) > 0)
                {
                    got += n;
                    if (got > SafeIO.MaxZipEntry) throw new UnsupportedFormatException("Подозрение на zip-бомбу: " + e.FullName);
                    ms.Write(buf, 0, n);
                }
                _total += got;
                if (_total > SafeIO.MaxZipTotal) throw new UnsupportedFormatException("Подозрение на zip-бомбу: распаковано слишком много данных.");
                return ms.ToArray();
            }
        }

        public string ReadText(string path)
        {
            var b = Read(path);
            return b == null ? null : SafeIO.DecodeText(b);
        }

        public XDocument ReadXml(string path)
        {
            var b = Read(path);
            if (b == null) return null;
            try { return SafeIO.LoadXml(b); } catch { return null; }
        }

        public void Dispose() { _zip.Dispose(); }
    }

    internal static class XExt
    {
        public static IEnumerable<XElement> Kids(this XElement e, string local) => e.Elements().Where(x => x.Name.LocalName == local);
        public static XElement Kid(this XElement e, string local) => e?.Elements().FirstOrDefault(x => x.Name.LocalName == local);
        public static IEnumerable<XElement> Desc(this XContainer e, string local) => e.Descendants().Where(x => x.Name.LocalName == local);
        public static XElement DescFirst(this XContainer e, string local) => e?.Descendants().FirstOrDefault(x => x.Name.LocalName == local);
        public static string Attr(this XElement e, string local)
        {
            if (e == null) return null;
            foreach (var a in e.Attributes()) if (a.Name.LocalName == local) return a.Value;
            return null;
        }
        public static string Val(this XElement e) => e?.Value?.Trim();
    }
}
