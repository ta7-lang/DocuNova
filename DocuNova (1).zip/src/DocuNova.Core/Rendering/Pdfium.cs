using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;

namespace DocuNova.Core
{
    /// <summary>
    /// Качество показа текста на экране. Задаётся из настроек программы.
    /// </summary>
    public static class RenderQuality
    {
        /// <summary>Субпиксельное сглаживание текста (ClearType) — самый чёткий текст на ЖК-мониторах.</summary>
        public static volatile bool LcdText = true;
        /// <summary>Усиление контраста тонких шрифтов: 0 — выключено, 1 — слабое, 2 — среднее, 3 — сильное.</summary>
        public static volatile int TextContrast = 1;
    }

    /// <summary>Результат отрисовки PDFium.</summary>
    internal enum PdfiumStatus { Ok, Cancelled, Failed }

    /// <summary>
    /// Документ, открытый движком PDFium (тот же, что в браузере Chrome; сборка без JavaScript и XFA).
    /// Страница рисуется прямо в итоговый массив пикселей — без кодирования в промежуточный формат,
    /// с субпиксельным сглаживанием текста и с возможностью прервать устаревшую отрисовку.
    /// PDFium не допускает одновременной работы из нескольких потоков, поэтому все обращения идут под общей блокировкой.
    /// </summary>
    internal sealed class PdfiumDocument : IDisposable
    {
        private static readonly object Gate = new object();
        private static volatile int _state; // 0 — не проверялся, 1 — работает, -1 — недоступен

        private const int FPDF_ANNOT = 0x01;
        private const int FPDF_LCD_TEXT = 0x02;
        private const int FPDFBitmap_BGRx = 3;
        private const int FPDF_RENDER_TOBECONTINUED = 1;
        private const int FPDF_RENDER_DONE = 2;
        private const int MaxCachedPages = 8;

        private IntPtr _doc;
        private IntPtr _access;
        private GetBlockFn _getBlock;
        private Stream _stream;
        private byte[] _chunk = new byte[64 * 1024];
        private readonly Dictionary<int, IntPtr> _pages = new Dictionary<int, IntPtr>();
        private readonly LinkedList<int> _lru = new LinkedList<int>();

        /// <summary>Есть ли в системе работоспособный PDFium (библиотека рядом с программой).</summary>
        public static bool Available
        {
            get
            {
                if (_state != 0) return _state > 0;
                lock (Gate)
                {
                    if (_state != 0) return _state > 0;
                    try
                    {
                        Native.FPDF_InitLibrary();
                        _state = 1;
                    }
                    catch { _state = -1; }
                    return _state > 0;
                }
            }
        }

        private PdfiumDocument() { }

        /// <summary>Открывает документ из потока (поток переходит во владение документа). null — не удалось.</summary>
        public static PdfiumDocument Open(Stream stream, string password)
        {
            if (stream == null) return null;
            if (!Available || !stream.CanSeek || stream.Length <= 0 || stream.Length > uint.MaxValue)
            {
                try { stream.Dispose(); } catch { }
                return null;
            }
            var d = new PdfiumDocument { _stream = stream };
            lock (Gate)
            {
                try
                {
                    d._getBlock = d.GetBlock;
                    var fa = new PdfFileAccess
                    {
                        FileLen = (uint)stream.Length,
                        GetBlock = Marshal.GetFunctionPointerForDelegate(d._getBlock),
                        Param = IntPtr.Zero
                    };
                    d._access = Marshal.AllocHGlobal(Marshal.SizeOf<PdfFileAccess>());
                    Marshal.StructureToPtr(fa, d._access, false);
                    d._doc = Native.FPDF_LoadCustomDocument(d._access, Pwd(password, Encoding.UTF8));
                    if (d._doc == IntPtr.Zero && !string.IsNullOrEmpty(password))
                        d._doc = Native.FPDF_LoadCustomDocument(d._access, Pwd(password, Encoding.Latin1));
                }
                catch { d._doc = IntPtr.Zero; }
                if (d._doc == IntPtr.Zero)
                {
                    d.ReleaseCore();
                    return null;
                }
            }
            return d;
        }

        private static byte[] Pwd(string password, Encoding enc)
        {
            if (string.IsNullOrEmpty(password)) return null;
            var b = enc.GetBytes(password);
            var z = new byte[b.Length + 1];
            Buffer.BlockCopy(b, 0, z, 0, b.Length);
            return z;
        }

        /// <summary>Чтение блока файла по запросу PDFium (вызывается внутри общей блокировки).</summary>
        private int GetBlock(IntPtr param, uint position, IntPtr buffer, uint size)
        {
            try
            {
                var s = _stream;
                if (s == null) return 0;
                if ((long)position + size > s.Length) return 0;
                s.Position = position;
                long done = 0;
                while (done < size)
                {
                    int want = (int)Math.Min(_chunk.Length, size - done);
                    int got = s.Read(_chunk, 0, want);
                    if (got <= 0) return 0;
                    Marshal.Copy(_chunk, 0, IntPtr.Add(buffer, (int)done), got);
                    done += got;
                }
                return 1;
            }
            catch { return 0; }
        }

        public int PageCount
        {
            get
            {
                lock (Gate)
                {
                    try { return _doc == IntPtr.Zero ? 0 : Native.FPDF_GetPageCount(_doc); }
                    catch { return 0; }
                }
            }
        }

        private IntPtr GetPage(int index)
        {
            if (_pages.TryGetValue(index, out var p))
            {
                _lru.Remove(index);
                _lru.AddFirst(index);
                return p;
            }
            p = Native.FPDF_LoadPage(_doc, index);
            if (p == IntPtr.Zero) return p;
            _pages[index] = p;
            _lru.AddFirst(index);
            while (_lru.Count > MaxCachedPages)
            {
                int old = _lru.Last.Value;
                _lru.RemoveLast();
                if (_pages.TryGetValue(old, out var op))
                {
                    _pages.Remove(old);
                    try { Native.FPDF_ClosePage(op); } catch { }
                }
            }
            return p;
        }

        /// <summary>
        /// Рисует страницу в растр width × height (BGRx, без выравнивания строк). Страница целиком занимает на этом
        /// растре прямоугольник (startX, startY, sizeX, sizeY) — так рисуется и вся страница, и любой её фрагмент
        /// с одинаковой геометрией. rotate — 0..3 (поворот по часовой стрелке на 90°).
        /// cancelled — проверяется во время отрисовки; если вернул true, работа прерывается.
        /// </summary>
        public PdfiumStatus Render(int index, int width, int height, int startX, int startY, int sizeX, int sizeY,
            int rotate, bool lcd, Func<bool> cancelled, out byte[] pixels)
        {
            pixels = null;
            if (width < 1 || height < 1 || sizeX < 1 || sizeY < 1) return PdfiumStatus.Failed;
            long bytes = (long)width * height * 4;
            if (bytes > int.MaxValue) return PdfiumStatus.Failed;
            if (cancelled != null && Safe(cancelled)) return PdfiumStatus.Cancelled;

            lock (Gate)
            {
                if (_doc == IntPtr.Zero) return PdfiumStatus.Failed;
                if (cancelled != null && Safe(cancelled)) return PdfiumStatus.Cancelled;
                var data = new byte[bytes];
                var pin = GCHandle.Alloc(data, GCHandleType.Pinned);
                IntPtr bmp = IntPtr.Zero;
                try
                {
                    var page = GetPage(index);
                    if (page == IntPtr.Zero) return PdfiumStatus.Failed;
                    bmp = Native.FPDFBitmap_CreateEx(width, height, FPDFBitmap_BGRx, pin.AddrOfPinnedObject(), width * 4);
                    if (bmp == IntPtr.Zero) return PdfiumStatus.Failed;
                    Native.FPDFBitmap_FillRect(bmp, 0, 0, width, height, 0xFFFFFFFFu);
                    int flags = FPDF_ANNOT | (lcd ? FPDF_LCD_TEXT : 0);
                    if (cancelled == null)
                    {
                        Native.FPDF_RenderPageBitmap(bmp, page, startX, startY, sizeX, sizeY, rotate & 3, flags);
                    }
                    else
                    {
                        bool stop = false;
                        PauseFn check = self =>
                        {
                            if (!stop && Safe(cancelled)) stop = true;
                            return stop ? 1 : 0;
                        };
                        var pause = new Pause { Version = 1, NeedToPauseNow = Marshal.GetFunctionPointerForDelegate(check), User = IntPtr.Zero };
                        int st;
                        try
                        {
                            st = Native.FPDF_RenderPageBitmap_Start(bmp, page, startX, startY, sizeX, sizeY, rotate & 3, flags, ref pause);
                            while (st == FPDF_RENDER_TOBECONTINUED && !stop)
                                st = Native.FPDF_RenderPage_Continue(page, ref pause);
                        }
                        finally
                        {
                            Native.FPDF_RenderPage_Close(page);
                            GC.KeepAlive(check);
                        }
                        if (stop) return PdfiumStatus.Cancelled;
                        if (st != FPDF_RENDER_DONE) return PdfiumStatus.Failed;
                    }
                }
                catch { return PdfiumStatus.Failed; }
                finally
                {
                    if (bmp != IntPtr.Zero) { try { Native.FPDFBitmap_Destroy(bmp); } catch { } }
                    pin.Free();
                }
                pixels = data;
                return PdfiumStatus.Ok;
            }
        }

        private static bool Safe(Func<bool> f)
        {
            try { return f(); } catch { return false; }
        }

        /// <summary>Освобождает разобранные страницы (сворачивание, переключение вкладок).</summary>
        public void Trim()
        {
            lock (Gate) ClosePages();
        }

        private void ClosePages()
        {
            foreach (var p in _pages.Values)
            {
                try { Native.FPDF_ClosePage(p); } catch { }
            }
            _pages.Clear();
            _lru.Clear();
        }

        private void ReleaseCore()
        {
            ClosePages();
            if (_doc != IntPtr.Zero)
            {
                try { Native.FPDF_CloseDocument(_doc); } catch { }
                _doc = IntPtr.Zero;
            }
            if (_access != IntPtr.Zero)
            {
                Marshal.FreeHGlobal(_access);
                _access = IntPtr.Zero;
            }
            try { _stream?.Dispose(); } catch { }
            _stream = null;
            _getBlock = null;
            _chunk = null;
        }

        public void Dispose()
        {
            lock (Gate) ReleaseCore();
        }

        // ================== интерфейс библиотеки ==================

        [StructLayout(LayoutKind.Sequential)]
        private struct PdfFileAccess
        {
            public uint FileLen;          // unsigned long (в Windows — 32 бита)
            public IntPtr GetBlock;
            public IntPtr Param;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct Pause
        {
            public int Version;
            public IntPtr NeedToPauseNow;
            public IntPtr User;
        }

        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        private delegate int GetBlockFn(IntPtr param, uint position, IntPtr buffer, uint size);

        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        private delegate int PauseFn(IntPtr self);

        private static class Native
        {
            private const string Lib = "pdfium";

            [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)]
            public static extern void FPDF_InitLibrary();

            [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)]
            public static extern IntPtr FPDF_LoadCustomDocument(IntPtr fileAccess, byte[] password);

            [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)]
            public static extern void FPDF_CloseDocument(IntPtr document);

            [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)]
            public static extern int FPDF_GetPageCount(IntPtr document);

            [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)]
            public static extern IntPtr FPDF_LoadPage(IntPtr document, int index);

            [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)]
            public static extern void FPDF_ClosePage(IntPtr page);

            [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)]
            public static extern IntPtr FPDFBitmap_CreateEx(int width, int height, int format, IntPtr firstScan, int stride);

            [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)]
            public static extern void FPDFBitmap_Destroy(IntPtr bitmap);

            [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)]
            public static extern int FPDFBitmap_FillRect(IntPtr bitmap, int left, int top, int width, int height, uint color);

            [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)]
            public static extern void FPDF_RenderPageBitmap(IntPtr bitmap, IntPtr page, int startX, int startY, int sizeX, int sizeY, int rotate, int flags);

            [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)]
            public static extern int FPDF_RenderPageBitmap_Start(IntPtr bitmap, IntPtr page, int startX, int startY, int sizeX, int sizeY, int rotate, int flags, ref Pause pause);

            [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)]
            public static extern int FPDF_RenderPage_Continue(IntPtr page, ref Pause pause);

            [DllImport(Lib, CallingConvention = CallingConvention.Cdecl)]
            public static extern void FPDF_RenderPage_Close(IntPtr page);
        }
    }
}
