using System;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace DocuNova.Core
{
    /// <summary>
    /// Подготовка изображений страниц к показу с минимальным расходом памяти.
    /// WPF рисует без преобразования только форматы Bgr32 и Pbgra32: картинку в любом другом формате
    /// он молча копирует ещё раз при отрисовке. Поэтому страница сразу приводится к «родному» формату
    /// и хранится в единственном экземпляре в неуправляемой памяти (без больших массивов в куче .NET).
    /// </summary>
    public static class BitmapUtil
    {
        private static bool IsNative(PixelFormat f) => f == PixelFormats.Bgr32 || f == PixelFormats.Pbgra32;

        private static bool HasAlpha(PixelFormat f) =>
            f == PixelFormats.Bgra32 || f == PixelFormats.Pbgra32 || f == PixelFormats.Prgba64 || f == PixelFormats.Rgba64 ||
            f == PixelFormats.Rgba128Float || f == PixelFormats.Prgba128Float ||
            f == PixelFormats.Indexed1 || f == PixelFormats.Indexed2 || f == PixelFormats.Indexed4 || f == PixelFormats.Indexed8;

        /// <summary>Ленивые обёртки держат ссылку на исходную (часто огромную) картинку — их нужно «материализовать».</summary>
        private static bool IsLazy(BitmapSource s) =>
            s is TransformedBitmap || s is FormatConvertedBitmap || s is CroppedBitmap || s is ColorConvertedBitmap;

        /// <summary>
        /// Возвращает замороженную картинку в родном для WPF формате с применённым режимом страницы
        /// (см. <see cref="PageTint"/>). opaque = true — страница заведомо непрозрачна (PDF): альфа-канал отбрасывается.
        /// </summary>
        public static BitmapSource Prepare(BitmapSource src, string mode, bool opaque = false, bool materialize = false)
        {
            if (src == null) return null;
            bool tint = PageTint.Applies(mode);
            var fmt = src.Format;
            var target = !opaque && HasAlpha(fmt) ? PixelFormats.Pbgra32 : PixelFormats.Bgr32;
            if (!tint && !materialize && !IsLazy(src) && (fmt == target || (!opaque && IsNative(fmt))))
            {
                if (!src.IsFrozen && src.CanFreeze) src.Freeze();
                // картинка, созданная в фоновом потоке, доступна интерфейсу только «замороженной»;
                // если заморозить нельзя — делаем замороженную копию ниже
                if (src.IsFrozen) return src;
            }
            BitmapSource conv = fmt == target ? src : new FormatConvertedBitmap(src, target, null, 0);
            var wb = new WriteableBitmap(conv); // копия пикселей сразу в неуправляемый буфер
            if (tint) Tint(wb, mode);
            wb.Freeze();
            return wb;
        }

        private static unsafe void Tint(WriteableBitmap wb, string mode)
        {
            int w = wb.PixelWidth, h = wb.PixelHeight, stride = wb.BackBufferStride;
            wb.Lock();
            try
            {
                byte* basePtr = (byte*)wb.BackBuffer;
                for (int y = 0; y < h; y++) PageTint.Apply(basePtr + (long)y * stride, w, mode);
                wb.AddDirtyRect(new Int32Rect(0, 0, w, h));
            }
            finally { wb.Unlock(); }
        }
    }
}
