using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media.Imaging;
using WinImg = global::Windows.Graphics.Imaging;
using WinOcr = global::Windows.Media.Ocr;
using WinStreams = global::Windows.Storage.Streams;

namespace DocuNova.Core
{
    /// <summary>
    /// Распознавание текста встроенным в Windows 10/11 движком OCR — полностью офлайн.
    /// </summary>
    public static class OcrService
    {
        public static string AvailableLanguages()
        {
            try { return string.Join(", ", WinOcr.OcrEngine.AvailableRecognizerLanguages.Select(l => l.DisplayName)); }
            catch { return "—"; }
        }

        private static WinOcr.OcrEngine CreateEngine()
        {
            var e = WinOcr.OcrEngine.TryCreateFromUserProfileLanguages();
            if (e != null) return e;
            foreach (var tag in new[] { "ru", "uk", "en-US", "en" })
            {
                try
                {
                    var lang = new global::Windows.Globalization.Language(tag);
                    if (WinOcr.OcrEngine.IsLanguageSupported(lang)) return WinOcr.OcrEngine.TryCreateFromLanguage(lang);
                }
                catch { }
            }
            var any = WinOcr.OcrEngine.AvailableRecognizerLanguages.FirstOrDefault();
            return any != null ? WinOcr.OcrEngine.TryCreateFromLanguage(any) : null;
        }

        /// <summary>Распознаёт текст на изображении страницы. pxPerDip — пикселей изображения на 1 DIP страницы.</summary>
        public static async Task<List<PageChar>> RecognizeAsync(BitmapSource bmp, double pxPerDip)
        {
            var engine = CreateEngine() ?? throw new InvalidOperationException("В Windows не установлен ни один язык распознавания текста (Параметры → Время и язык → Язык → добавьте язык с компонентом «Оптическое распознавание»).");
            uint max = WinOcr.OcrEngine.MaxImageDimension;
            double k = 1;
            if (bmp.PixelWidth > max || bmp.PixelHeight > max)
            {
                k = (double)max / Math.Max(bmp.PixelWidth, bmp.PixelHeight) * 0.98;
                var tb = new TransformedBitmap(bmp, new System.Windows.Media.ScaleTransform(k, k));
                tb.Freeze();
                bmp = tb;
            }
            byte[] png;
            var enc = new PngBitmapEncoder();
            enc.Frames.Add(BitmapFrame.Create(bmp));
            using (var ms = new MemoryStream()) { enc.Save(ms); png = ms.ToArray(); }

            using (var ras = new WinStreams.InMemoryRandomAccessStream())
            {
                using (var w = new WinStreams.DataWriter(ras.GetOutputStreamAt(0)))
                {
                    w.WriteBytes(png);
                    await w.StoreAsync();
                    await w.FlushAsync();
                    w.DetachStream();
                }
                ras.Seek(0);
                var dec = await WinImg.BitmapDecoder.CreateAsync(ras);
                using (var sb = await dec.GetSoftwareBitmapAsync(WinImg.BitmapPixelFormat.Bgra8, WinImg.BitmapAlphaMode.Premultiplied))
                {
                    var result = await engine.RecognizeAsync(sb);
                    var list = new List<PageChar>();
                    double toDip = 1.0 / (pxPerDip * k);
                    foreach (var line in result.Lines)
                    {
                        bool firstWord = true;
                        PageChar last = default;
                        foreach (var word in line.Words)
                        {
                            var br = word.BoundingRect;
                            double x = br.X * toDip, y = br.Y * toDip, ww = br.Width * toDip, hh = br.Height * toDip;
                            var text = word.Text ?? "";
                            if (text.Length == 0) continue;
                            if (!firstWord)
                            {
                                double gx = last.Box.Right;
                                list.Add(new PageChar(' ', new Rect(gx, y, Math.Max(0.5, x - gx), hh)));
                            }
                            double cw = ww / text.Length;
                            for (int i = 0; i < text.Length; i++)
                            {
                                last = new PageChar(text[i], new Rect(x + cw * i, y, Math.Max(0.5, cw), hh));
                                list.Add(last);
                            }
                            firstWord = false;
                        }
                    }
                    return list;
                }
            }
        }
    }
}
