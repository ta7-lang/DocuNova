using System;
using System.Collections.Generic;

namespace DocuNova.Core
{
    /// <summary>
    /// Цветовые режимы страниц: обычный, ночной, сепия, тёплая ночь, оттенки серого, высокий контраст, мягкий зелёный.
    /// Применяются к уже отрисованным пикселям BGRA (4 байта на пиксель), альфа-канал не меняется.
    /// Для режимов с независимыми каналами используются таблицы подстановки — один проход без умножений.
    /// </summary>
    public static class PageTint
    {
        /// <summary>Код режима и его название для меню и настроек (в порядке переключения Ctrl+N).</summary>
        public static readonly IReadOnlyList<(string Code, string Name, string Hint)> Modes = new[]
        {
            ("normal", "Обычный", "Страницы в исходных цветах."),
            ("night", "Ночной", "Инверсия: светлый текст на тёмном фоне — бережёт глаза в темноте."),
            ("warmnight", "Тёплая ночь", "Тёмно-коричневый фон и бежевый текст: мягче обычного ночного режима, меньше синего света."),
            ("sepia", "Сепия", "Тёплый оттенок старой бумаги."),
            ("green", "Мягкий зелёный", "Светло-зелёный «бумажный» фон, который многим комфортнее белого при долгом чтении."),
            ("gray", "Оттенки серого", "Убирает цвет: удобно для сканов с цветными пятнами и для проверки чёрно-белой печати."),
            ("contrast", "Высокий контраст", "Бледный текст становится чёрным, сероватый фон — белым. Помогает со слабыми сканами и копиями."),
        };

        public static bool Applies(string mode) =>
            mode == "night" || mode == "sepia" || mode == "warmnight" || mode == "green" || mode == "gray" || mode == "contrast";

        public static string NameOf(string mode)
        {
            foreach (var m in Modes) if (m.Code == mode) return m.Name;
            return Modes[0].Name;
        }

        /// <summary>Следующий режим по кругу (Ctrl+N).</summary>
        public static string Next(string mode)
        {
            for (int i = 0; i < Modes.Count; i++)
                if (Modes[i].Code == mode) return Modes[(i + 1) % Modes.Count].Code;
            return Modes[0].Code;
        }

        private static readonly Dictionary<string, byte[][]> _luts = new Dictionary<string, byte[][]>();
        private static readonly object _lock = new object();

        /// <summary>Таблицы подстановки B, G, R для режима (null — режим не сводится к таблицам).</summary>
        private static byte[][] Lut(string mode)
        {
            if (mode == "gray") return null;
            lock (_lock)
            {
                if (_luts.TryGetValue(mode, out var t)) return t;
                var b = new byte[256]; var g = new byte[256]; var r = new byte[256];
                for (int v = 0; v < 256; v++)
                {
                    switch (mode)
                    {
                        case "night":
                            b[v] = (byte)(28 + ((255 - v) * 205 >> 8));
                            g[v] = (byte)(28 + ((255 - v) * 205 >> 8));
                            r[v] = (byte)(30 + ((255 - v) * 205 >> 8));
                            break;
                        case "warmnight":
                            b[v] = Clamp(20 + ((255 - v) * 160 >> 8));
                            g[v] = Clamp(26 + ((255 - v) * 195 >> 8));
                            r[v] = Clamp(32 + ((255 - v) * 220 >> 8));
                            break;
                        case "sepia":
                            b[v] = (byte)(v * 205 >> 8);
                            g[v] = (byte)(v * 238 >> 8);
                            r[v] = (byte)(v * 253 >> 8);
                            break;
                        case "green":
                            b[v] = (byte)(v * 206 >> 8);
                            g[v] = (byte)(v * 237 >> 8);
                            r[v] = (byte)(v * 205 >> 8);
                            break;
                        case "contrast":
                        {
                            // растяжение 48…208 → 0…255 с лёгкой S-кривой: бледный текст темнее, серый фон белее
                            double x = Math.Max(0, Math.Min(1, (v - 48) / 160.0));
                            x = x * x * (3 - 2 * x);
                            byte c = Clamp((int)Math.Round(x * 255));
                            b[v] = g[v] = r[v] = c;
                            break;
                        }
                        default:
                            b[v] = g[v] = r[v] = (byte)v;
                            break;
                    }
                }
                t = new[] { b, g, r };
                _luts[mode] = t;
                return t;
            }
        }

        private static byte Clamp(int v) => (byte)(v < 0 ? 0 : v > 255 ? 255 : v);

        /// <summary>Применяет режим к массиву пикселей BGRA.</summary>
        public static unsafe void Apply(byte[] data, string mode)
        {
            if (data == null || data.Length < 4 || !Applies(mode)) return;
            fixed (byte* p = data) Apply(p, data.Length / 4, mode);
        }

        /// <summary>Применяет режим к непрерывному участку пикселей BGRA (например, к одной строке картинки).</summary>
        public static unsafe void Apply(byte* p, long pixels, string mode)
        {
            if (p == null || pixels <= 0 || !Applies(mode)) return;
            byte* end = p + pixels * 4;
            var lut = Lut(mode);
            if (lut == null)
            {
                // оттенки серого: яркость по Rec.601 в целых числах
                for (; p < end; p += 4)
                {
                    byte y = (byte)((p[0] * 29 + p[1] * 150 + p[2] * 77) >> 8);
                    p[0] = y; p[1] = y; p[2] = y;
                }
                return;
            }
            byte[] lb = lut[0], lg = lut[1], lr = lut[2];
            for (; p < end; p += 4)
            {
                p[0] = lb[p[0]];
                p[1] = lg[p[1]];
                p[2] = lr[p[2]];
            }
        }
    }
}
