using System;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using DocuNova.Core.Formats;

namespace DocuNova.Core
{
    /// <summary>
    /// Построение эскиза документа заданного размера. Вызывать в STA-потоке.
    /// Используется и расширением Проводника, и самим приложением. Ничего не пишет на диск.
    /// </summary>
    public static class ThumbnailRenderer
    {
        public static BitmapSource Render(byte[] data, string extHint, int size)
        {
            size = Math.Max(16, Math.Min(size, 2560));
            SafeIO.EnsureInit();
            if (data.Length >= 2 && data[0] == 'M' && data[1] == 'Z') return null; // не документ
            string code = DocumentLoader.Detect(data, extHint);
            BitmapSource page = null;
            string title = null, author = null;
            try
            {
                switch (code)
                {
                    case "pdf":
                        using (var pdf = PdfDoc.Open(data, null, true))
                        {
                            var sz = pdf.GetPageSize(0);
                            page = pdf.RenderPage(0, size / Math.Max(sz.Width, sz.Height));
                        }
                        break;
                    case "epub": page = EpubReader.ExtractCover(data, out title, out author); break;
                    case "fb2": page = Fb2Reader.ExtractCover(data, out title, out author); break;
                    case "mobi": page = MobiReader.ExtractCover(data, out title, out author); break;
                    case "image":
                    {
                        page = SafeIO.LoadImage(data, Math.Max(size * 2, 256));
                        break;
                    }
                    case "cbz":
                        using (var z = new SafeZip(data))
                        {
                            var first = z.Entries.Where(e => DocumentLoader.IsImageName(e.FullName)).Select(e => e.FullName).OrderBy(n => n, new DocumentLoader.NaturalComparer()).FirstOrDefault();
                            if (first != null) page = SafeIO.LoadImage(z.Read(first), Math.Max(size * 2, 256));
                        }
                        break;
                }
            }
            catch { page = null; }

            if (page == null && code != "pdf")
            {
                // отрисовка первой страницы облегчённой загрузкой
                try
                {
                    var rs = new ReflowSettings { Light = true, FontSize = 15, PageWidth = 600, PageHeight = 820, Margin = 44 };
                    if (code == "epub" || code == "fb2" || code == "mobi")
                    {
                        // для книги без обложки — красивая карточка с названием
                        if (!string.IsNullOrWhiteSpace(title)) return Card(title, author, code, size);
                    }
                    using (var doc = DocumentLoader.Load("thumbnail" + (extHint ?? ""), data, rs))
                    {
                        if (doc.Cover != null) page = doc.Cover;
                        else
                        {
                            var sz = doc.GetPageSize(0);
                            page = doc.RenderPage(0, size / Math.Max(sz.Width, sz.Height));
                        }
                    }
                }
                catch { page = null; }
            }
            if (page == null) return null;
            if (page.PixelWidth < 2 || page.PixelHeight < 2) return null;
            return VisualTools.FitTo(page, size, true);
        }

        /// <summary>Карточка книги: градиент, название и автор (если нет обложки).</summary>
        public static BitmapSource Card(string title, string author, string code, int size)
        {
            double w = 600, h = 860;
            var dv = new DrawingVisual();
            using (var dc = dv.RenderOpen())
            {
                var bg = new LinearGradientBrush(Color.FromRgb(36, 18, 84), Color.FromRgb(10, 60, 110), 60);
                dc.DrawRectangle(bg, null, new Rect(0, 0, w, h));
                var glow = new LinearGradientBrush(Color.FromRgb(255, 43, 214), Color.FromRgb(0, 240, 255), 0);
                dc.DrawRectangle(glow, null, new Rect(40, 120, w - 80, 8));
                dc.DrawRectangle(glow, null, new Rect(40, h - 140, w - 80, 8));
                var tf = new Typeface(new FontFamily("Segoe UI"), FontStyles.Normal, FontWeights.Bold, FontStretches.Normal);
                var ft = new FormattedText(title ?? "", CultureInfo.CurrentUICulture, FlowDirection.LeftToRight, tf, 54, Brushes.White, 1.0)
                { MaxTextWidth = w - 100, MaxTextHeight = 420, TextAlignment = TextAlignment.Center, Trimming = TextTrimming.WordEllipsis };
                dc.DrawText(ft, new Point(50, 170));
                if (!string.IsNullOrWhiteSpace(author))
                {
                    var fa = new FormattedText(author, CultureInfo.CurrentUICulture, FlowDirection.LeftToRight, new Typeface("Segoe UI"), 34, new SolidColorBrush(Color.FromRgb(180, 230, 255)), 1.0)
                    { MaxTextWidth = w - 100, MaxTextHeight = 120, TextAlignment = TextAlignment.Center, Trimming = TextTrimming.WordEllipsis };
                    dc.DrawText(fa, new Point(50, h - 290));
                }
                var fc = new FormattedText(code.ToUpperInvariant(), CultureInfo.InvariantCulture, FlowDirection.LeftToRight, tf, 40, new SolidColorBrush(Color.FromRgb(255, 120, 230)), 1.0)
                { MaxTextWidth = w - 100, TextAlignment = TextAlignment.Center };
                dc.DrawText(fc, new Point(50, h - 110));
            }
            var rtb = new RenderTargetBitmap((int)w, (int)h, 96, 96, PixelFormats.Pbgra32);
            rtb.Render(dv);
            rtb.Freeze();
            return VisualTools.FitTo(rtb, size, false);
        }
    }
}
