using System;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;
using System.Threading;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using DocuNova.Core;

namespace DocuNova.Shell
{
    [ComImport, Guid("b824b49d-22ac-4161-ac8a-9916e8fa3f7f"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    public interface IInitializeWithStream
    {
        void Initialize(IStream pstream, uint grfMode);
    }

    [ComImport, Guid("e357fccd-a995-4576-b01f-234630154e96"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    public interface IThumbnailProvider
    {
        void GetThumbnail(uint cx, out IntPtr phbmp, out uint pdwAlpha);
    }

    /// <summary>
    /// Провайдер эскизов Проводника Windows для документов.
    /// Работает в изолированном процессе Windows (dllhost), получает файл только как поток для чтения,
    /// ничего не пишет на диск и не кэширует — кэшем эскизов управляет сама Windows.
    /// </summary>
    [ComVisible(true)]
    [Guid(ThumbnailProvider.ClsidString)]
    [ClassInterface(ClassInterfaceType.None)]
    [ProgId("DocuNova.ThumbnailProvider")]
    public sealed class ThumbnailProvider : IInitializeWithStream, IThumbnailProvider
    {
        public const string ClsidString = "4ade8aa0-5fdb-4a79-b9af-dcd6f72acb83";
        private const long MaxBytes = 400L * 1024 * 1024;
        private const uint WTSAT_RGB = 1;
        private byte[] _data;

        public void Initialize(IStream pstream, uint grfMode)
        {
            if (_data != null) return;
            try { _data = ReadAll(pstream); }
            finally
            {
                try { Marshal.ReleaseComObject(pstream); } catch { }
            }
        }

        private static byte[] ReadAll(IStream s)
        {
            long size = 0;
            try
            {
                s.Stat(out STATSTG st, 1 /* STATFLAG_NONAME */);
                size = st.cbSize;
            }
            catch { }
            if (size > MaxBytes) throw new COMException("Файл слишком большой для эскиза", unchecked((int)0x80004005));
            var ms = new System.IO.MemoryStream(size > 0 ? (int)size : 1 << 16);
            var buf = new byte[1 << 16];
            IntPtr pRead = Marshal.AllocCoTaskMem(4);
            try
            {
                while (true)
                {
                    Marshal.WriteInt32(pRead, 0);
                    s.Read(buf, buf.Length, pRead);
                    int n = Marshal.ReadInt32(pRead);
                    if (n <= 0) break;
                    ms.Write(buf, 0, n);
                    if (ms.Length > MaxBytes) throw new COMException("Файл слишком большой для эскиза", unchecked((int)0x80004005));
                }
            }
            finally { Marshal.FreeCoTaskMem(pRead); }
            return ms.ToArray();
        }

        public void GetThumbnail(uint cx, out IntPtr phbmp, out uint pdwAlpha)
        {
            phbmp = IntPtr.Zero;
            pdwAlpha = WTSAT_RGB;
            var data = _data ?? throw new COMException("Не инициализирован", unchecked((int)0x8000FFFF));
            int width = 0, height = 0;
            byte[] pixels = null;
            Exception error = null;

            // WPF требует STA-поток: отрисовываем в отдельном потоке с ограничением по времени
            var t = new Thread(() =>
            {
                try
                {
                    var bmp = ThumbnailRenderer.Render(data, null, (int)Math.Max(16, Math.Min(cx, 2560)));
                    if (bmp != null)
                    {
                        var conv = new FormatConvertedBitmap(bmp, PixelFormats.Bgra32, null, 0);
                        width = conv.PixelWidth; height = conv.PixelHeight;
                        pixels = new byte[width * height * 4];
                        conv.CopyPixels(pixels, width * 4, 0);
                    }
                }
                catch (Exception ex) { error = ex; }
                finally
                {
                    try { Dispatcher.CurrentDispatcher.InvokeShutdown(); } catch { }
                }
            });
            t.SetApartmentState(ApartmentState.STA);
            t.IsBackground = true;
            t.Start();
            if (!t.Join(TimeSpan.FromSeconds(30)))
                throw new COMException("Превышено время построения эскиза", unchecked((int)0x800705B4));
            _data = null; // освобождаем память сразу
            if (pixels == null)
                throw new COMException(error?.Message ?? "Эскиз недоступен", unchecked((int)0x80004005));

            // делаем все пиксели непрозрачными: прозрачные области (PNG, обложки) накладываются на белый фон,
            // а не становятся чёрными
            for (int i = 0; i < pixels.Length; i += 4)
            {
                int al = pixels[i + 3];
                if (al == 255) continue;
                int inv = 255 - al;
                pixels[i] = (byte)((pixels[i] * al + 255 * inv) / 255);
                pixels[i + 1] = (byte)((pixels[i + 1] * al + 255 * inv) / 255);
                pixels[i + 2] = (byte)((pixels[i + 2] * al + 255 * inv) / 255);
                pixels[i + 3] = 255;
            }

            var bi = new BITMAPINFO
            {
                biSize = Marshal.SizeOf<BITMAPINFO>(),
                biWidth = width,
                biHeight = -height, // сверху вниз
                biPlanes = 1,
                biBitCount = 32,
                biCompression = 0
            };
            IntPtr hbmp = CreateDIBSection(IntPtr.Zero, ref bi, 0, out IntPtr bits, IntPtr.Zero, 0);
            if (hbmp == IntPtr.Zero || bits == IntPtr.Zero) throw new COMException("CreateDIBSection", unchecked((int)0x8007000E));
            Marshal.Copy(pixels, 0, bits, pixels.Length);
            phbmp = hbmp;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct BITMAPINFO
        {
            public int biSize;
            public int biWidth;
            public int biHeight;
            public short biPlanes;
            public short biBitCount;
            public int biCompression;
            public int biSizeImage;
            public int biXPelsPerMeter;
            public int biYPelsPerMeter;
            public int biClrUsed;
            public int biClrImportant;
            public int bmiColors;
        }

        [DllImport("gdi32.dll", SetLastError = true)]
        private static extern IntPtr CreateDIBSection(IntPtr hdc, ref BITMAPINFO pbmi, uint usage, out IntPtr ppvBits, IntPtr hSection, uint offset);
    }
}
