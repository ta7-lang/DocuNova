using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using DocuNova.Core;
using DocuNova.Services;
using DocuNova.Viewer;
using DocuNova.Views;
using Microsoft.Win32;

namespace DocuNova
{
    public partial class MainWindow : Window
    {
        // ---------- вкладки и панели ----------
        private readonly List<DocTab> _tabs = new List<DocTab>();
        private readonly List<DocTab> _split = new List<DocTab>();   // документы в параллельном просмотре
        private DocTab _active;
        private bool _parallel;
        private bool _syncing;
        private const int MaxPanes = 6;
        private readonly SemaphoreSlim _openLock = new SemaphoreSlim(1, 1);

        /// <summary>Пустой просмотрщик, когда нет открытых документов (никогда не показывается).</summary>
        private readonly DocViewer _idle = new DocViewer();
        private DocViewer _viewer => _active?.Viewer ?? _idle;
        private DocumentBase _doc => _active?.Doc;
        private string _path => _active?.Path;

        private Tool _tool = Tool.Hand;
        private bool _ready;
        private bool _fullscreen;
        private WindowState _stateBeforeFull;
        private WindowState _stateBeforeMin = WindowState.Normal;
        private Color _color;
        private double _sidebarWidth = 290;
        private readonly ObservableCollection<ThumbItem> _thumbs = new ObservableCollection<ThumbItem>();
        private int _searchGen;
        private readonly DispatcherTimer _bannerTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(14) };

        // ---------- ряд вкладок ----------
        private const double TabScrollStep = 180;
        /// <summary>Недавно закрытые вкладки (Ctrl+Shift+T открывает последнюю снова — на том же месте).</summary>
        private readonly List<SessionTab> _closedTabs = new List<SessionTab>();
        private DocTab _tabDrag;
        private Point _tabDragStart;
        private bool _tabDragging;

        // ---------- чтение ----------
        private bool _ruler;
        private const string StampToday = "Сегодняшняя дата";
        private const string StampAddCustom = "＋ Свой штамп…";
        private const string StampClearCustom = "✕ Удалить свои штампы";
        private bool _stampUpdating;

        private static readonly string[] Palette = { "#FFFF2BD6", "#FF00F0FF", "#FFFFE600", "#FF39FF14", "#FFFF7A00", "#FFFF1E3C", "#FF7B61FF", "#FF2E9BFF", "#FF000000", "#FFFFFFFF" };
        private static readonly string[] Stamps = { "ОДОБРЕНО", "ПРОВЕРЕНО", "ЧЕРНОВИК", "КОПИЯ", "КОНФИДЕНЦИАЛЬНО", "ОТКЛОНЕНО", "СРОЧНО", "ОПЛАЧЕНО", "ПОЛУЧЕНО", "УТВЕРЖДАЮ" };

        private AppSettings S => App.Settings;

        public MainWindow()
        {
            InitializeComponent();
            _idle.NewAnnotation = NewAnnotationStyle;

            ThumbList.ItemsSource = _thumbs;
            _bannerTimer.Tick += (s, e) => { _bannerTimer.Stop(); Banner.Visibility = Visibility.Collapsed; };

            // параметры пометок
            _color = ThemeColor(S.PenColor, Color.FromRgb(255, 43, 214));
            ThicknessSlider.Value = S.PenThickness;
            OpacitySlider.Value = S.AnnOpacity;
            FontSlider.Value = S.TextSize;
            RebuildStampList();
            BuildSwatches();

            // параметры вида
            _sidebarWidth = Math.Max(200, Math.Min(600, S.SidebarWidth > 0 ? S.SidebarWidth : 290));
            SidebarCol.Width = new GridLength(_sidebarWidth);
            ApplyViewSettings();
            TwoPageBtn.IsChecked = S.TwoPage;
            SyncBtn.IsChecked = S.SyncScroll;
            if (!S.ShowSidebar) SetSidebar(false);
            Width = Math.Max(MinWidth, S.WindowWidth);
            Height = Math.Max(MinHeight, S.WindowHeight);
            if (S.WindowMaximized) WindowState = WindowState.Maximized;

            Drop += OnDrop;
            // боковые кнопки мыши «назад / вперёд» — по истории переходов в документе
            PreviewMouseDown += (s, e) =>
            {
                if (e.ChangedButton == MouseButton.XButton1) { GoBack(); e.Handled = true; }
                else if (e.ChangedButton == MouseButton.XButton2) { GoForward(); e.Handled = true; }
            };
            DragOver += (s, e) => { e.Effects = e.Data.GetDataPresent(DataFormats.FileDrop) ? DragDropEffects.Copy : DragDropEffects.None; e.Handled = true; };
            StateChanged += OnStateChanged;
            Closing += OnClosing;
            Loaded += (s, e) => { UpdateMaxState(); RefreshRecent(); };
            Sidebar.SizeChanged += (s, e) => UpdateTabSpacer();
            UpdateDocButtons();
            UpdateParallelUi();
            _ready = true;
        }

        private static Color ThemeColor(string s, Color fallback) => Themes.ThemeManager.C(s, fallback);

        private IEnumerable<DocViewer> AllViewers() => _tabs.Select(t => t.Viewer).Concat(new[] { _idle });

        private void ApplyViewSettings()
        {
            foreach (var v in AllViewers()) ApplyViewSettings(v, false);
        }

        /// <summary>Включено ли в Windows сглаживание шрифтов ClearType.</summary>
        private static bool SystemClearType()
        {
            try { return System.Windows.Forms.SystemInformation.IsFontSmoothingEnabled && System.Windows.Forms.SystemInformation.FontSmoothingType == 2; }
            catch { return true; }
        }

        private void ApplyViewSettings(DocViewer v, bool isNew)
        {
            var smoothing = S.TextSmoothing ?? "auto";
            DocuNova.Core.RenderQuality.LcdText = smoothing == "cleartype" || (smoothing != "grayscale" && SystemClearType());
            DocuNova.Core.RenderQuality.TextContrast = Math.Max(0, Math.Min(3, S.TextContrast));
            v.SmoothScrolling = S.SmoothScroll;
            v.Gap = S.PageGap;
            v.Shadows = S.PageShadows;
            v.PageMode = S.PageMode ?? "normal";
            v.CoverPage = S.CoverPage;
            v.WheelStep = S.WheelStep;
            v.AutoScrollSpeed = S.AutoScrollSpeed;
            v.RulerHeight = S.RulerHeight;
            v.RulerShade = S.RulerShade;
            v.ReadingRuler = _ruler;
            if (OverlayLayer.ShowAnnotations != S.ShowAnnotations) { OverlayLayer.ShowAnnotations = S.ShowAnnotations; v.RefreshOverlays(); }
            if (isNew || v == _idle)
            {
                v.FitMode = S.FitMode ?? "width";
                v.TwoPage = S.TwoPage;
            }
            v.Tool = _tool;
        }

        // ======================= Окно =======================

        private void Min_Click(object sender, RoutedEventArgs e) => WindowState = WindowState.Minimized;
        private void Max_Click(object sender, RoutedEventArgs e) => WindowState = WindowState == WindowState.Maximized ? WindowState.Normal : WindowState.Maximized;
        private void Close_Click(object sender, RoutedEventArgs e) => Close();

        private void UpdateMaxState()
        {
            bool max = WindowState == WindowState.Maximized;
            Root.Margin = max && !_fullscreen ? new Thickness(7) : new Thickness(0);
            MaxBtn.Content = max ? "" : "";
        }

        private void OnStateChanged(object sender, EventArgs e)
        {
            UpdateMaxState();
            if (WindowState == WindowState.Minimized)
            {
                // свёрнутое окно не держит в памяти изображения страниц и вспомогательные кэши
                foreach (var t in VisibleTabs()) t.Viewer.Suspend();
                foreach (var t in _tabs) { try { t.Doc?.TrimMemory(); } catch { } }
                foreach (var th in _thumbs) th.Thumb = null;
                Dispatcher.BeginInvoke(new Action(() => MemoryTrim.Collect(true)), DispatcherPriority.Background);
            }
            else
            {
                _stateBeforeMin = WindowState;
                bool wasSuspended = false;
                foreach (var t in VisibleTabs()) { if (t.Viewer.Suspended) wasSuspended = true; t.Viewer.Resume(); }
                if (wasSuspended) RebuildThumbs(); // эскизы были освобождены при сворачивании
            }
        }

        private void OnClosing(object sender, CancelEventArgs e)
        {
            foreach (var t in _tabs.ToList())
            {
                if (t.Doc != null && t.Viewer.Modified && !ConfirmDiscard(t)) { e.Cancel = true; return; }
            }
            // открытые редакторы PDF: сохранение в процессе или несохранённые изменения — спрашиваем до закрытия
            foreach (var ed in OwnedWindows.OfType<PdfEditorWindow>().ToList())
            {
                if (!ed.ConfirmClose()) { e.Cancel = true; ed.Activate(); return; }
            }
            SaveSession();
            S.WindowMaximized = WindowState == WindowState.Maximized;
            if (WindowState == WindowState.Normal) { S.WindowWidth = ActualWidth; S.WindowHeight = ActualHeight; }
            if (Sidebar.Visibility == Visibility.Visible && SidebarCol.ActualWidth > 100) S.SidebarWidth = SidebarCol.ActualWidth;
            else S.SidebarWidth = _sidebarWidth;
            S.Save();
            foreach (var t in _tabs.ToList()) DisposeTab(t);
            _tabs.Clear();
            _split.Clear();
            _active = null;
        }

        private void OnDrop(object sender, DragEventArgs e)
        {
            if (e.Data.GetData(DataFormats.FileDrop) is string[] files && files.Length > 0) OpenFiles(files);
        }

        /// <summary>Вывести окно на передний план (документ открыт из Проводника при запущенной программе).</summary>
        private void BringToFront()
        {
            try
            {
                if (WindowState == WindowState.Minimized) WindowState = _stateBeforeMin == WindowState.Maximized ? WindowState.Maximized : WindowState.Normal;
                Show();
                Activate();
                Topmost = true;
                Topmost = false;
                Focus();
            }
            catch { }
        }

        /// <summary>Файлы, переданные повторным запуском программы (двойной щелчок в Проводнике).</summary>
        public void ReceiveFiles(string[] paths)
        {
            BringToFront();
            var files = (paths ?? new string[0]).Where(p =>
            {
                try { return Path.IsPathFullyQualified(p) && File.Exists(p); } catch { return false; }
            }).ToList();
            if (files.Count > 0) OpenFiles(files);
        }

        // ======================= Открытие =======================

        private void Open_Click(object sender, RoutedEventArgs e)
        {
            var files = AskFiles();
            if (files.Count > 0) OpenFiles(files);
        }

        private List<string> AskFiles()
        {
            var dlg = new OpenFileDialog
            {
                Filter = DocumentLoader.OpenFileFilter(),
                Title = "Открыть документы (можно выбрать несколько — откроются во вкладках)",
                CheckFileExists = true,
                Multiselect = true,
                DereferenceLinks = false // ярлык не подменяет файл
            };
            return dlg.ShowDialog(this) == true ? dlg.FileNames.ToList() : new List<string>();
        }

        /// <summary>Открывает файлы по очереди, каждый — в своей вкладке.</summary>
        public async void OpenFiles(IEnumerable<string> files)
        {
            try { await OpenFilesAsync(files); } catch { }
        }

        private async Task OpenFilesAsync(IEnumerable<string> files)
        {
            foreach (var f in (files ?? Enumerable.Empty<string>()).Distinct(StringComparer.OrdinalIgnoreCase).Take(50).ToList())
                await OpenFileAsync(f);
        }

        public async void OpenFile(string path)
        {
            try { await OpenFileAsync(path); } catch { }
        }

        public Task OpenFileAsync(string path) => OpenFileAsync(path, null, false);

        /// <summary>
        /// Открывает документ во вкладке.
        /// </summary>
        /// <param name="state">Место чтения и вид, к которым нужно вернуться (null — из памяти мест чтения, если она включена).</param>
        /// <param name="quiet">Восстановление сеанса: без диалогов и сообщений об ошибках, вкладка не активируется.</param>
        /// <returns>Вкладка документа или null, если документ не открыт.</returns>
        private async Task<DocTab> OpenFileAsync(string path, SessionTab state, bool quiet)
        {
            if (string.IsNullOrEmpty(path)) return null;
            try { path = Path.GetFullPath(path); } catch { }
            await _openLock.WaitAsync();
            try
            {
                // уже открыт — просто переходим на его вкладку
                var existing = _tabs.FirstOrDefault(t => string.Equals(t.Path, path, StringComparison.OrdinalIgnoreCase));
                if (existing != null) { if (!quiet) ActivateTab(existing); return existing; }
                return await OpenCoreAsync(path, state, quiet);
            }
            finally { _openLock.Release(); }
        }

        private async Task<DocTab> OpenCoreAsync(string path, SessionTab state, bool quiet)
        {
            if (!File.Exists(path))
            {
                if (!quiet) MessageBox.Show(this, "Файл не найден:\n" + path, "DocuNova", MessageBoxButton.OK, MessageBoxImage.Warning);
                return null;
            }

            ShowLoading("Открытие «" + Path.GetFileName(path) + "»…");
            SharedFile file = null;
            byte[] data;
            bool headOnly = false;
            try
            {
                (file, data, headOnly) = await Task.Run(() =>
                {
                    // файл остаётся открытым только для чтения: для PDF данные читаются с диска по мере надобности
                    var f = SharedFile.TryOpen(path);
                    try
                    {
                        if (f == null) return ((SharedFile)null, SafeIO.ReadFile(path), false);
                        // PDF узнаётся по началу файла: весь файл для показа не нужен (полная проверка — в фоне)
                        var head = f.ReadHead(64 * 1024);
                        if (head.Length < f.Length && DocumentLoader.Detect(head, Path.GetExtension(path)) == "pdf")
                            return (f, head, true);
                        return (f, f.ReadAll(), false);
                    }
                    catch { f?.Dispose(); throw; }
                });
            }
            catch (Exception ex) { HideLoading(); if (!quiet) ShowError("Не удалось прочитать файл", ex); return null; }

            var rs = S.Reflow.Clone();
            rs.Light = false;
            string password = null;
            DocumentBase doc = null;
            bool isPdf = DocumentLoader.Detect(data, Path.GetExtension(path)) == "pdf";
            bool fileOwnedByDoc = false;
            try
            {
                while (true)
                {
                    try
                    {
                        if (isPdf)
                        {
                            var d = data; var f = file; var pw = password; bool defer = headOnly;
                            doc = await Task.Run(() => DocumentLoader.Load(path, d, rs, pw, f, defer));
                        }
                        else
                        {
                            await Dispatcher.Yield(DispatcherPriority.Background);
                            doc = DocumentLoader.Load(path, data, rs, password);
                        }
                        break;
                    }
                    catch (PasswordRequiredException ex)
                    {
                        HideLoading();
                        // при восстановлении сеанса пароль не спрашиваем: документ можно открыть позже вручную
                        if (quiet) return null;
                        password = PasswordDialog.Ask(this, Path.GetFileName(path), ex.WrongPassword);
                        if (password == null) return null;
                        ShowLoading("Расшифровка…");
                    }
                    catch (Exception ex)
                    {
                        HideLoading();
                        if (!quiet) ShowError("Документ не удалось открыть", ex);
                        return null;
                    }
                }
                fileOwnedByDoc = isPdf && file != null;
            }
            finally
            {
                if (!fileOwnedByDoc) file?.Dispose();
                data = null; // копия файла больше не нужна — память освобождается
            }

            var tab = CreateTab(doc, path);
            // в параллельном режиме новый документ занимает новую панель (или заменяет активную, если места нет);
            // при восстановлении сеанса вкладки создаются скрытыми — активная выбирается в конце
            if (!quiet) ActivateTab(tab, addPane: true);
            else ApplyActiveToUi();
            // возвращаемся к месту, где документ читали в прошлый раз
            ApplyState(tab, state ?? S.FindPlace(path));
            HideLoading();
            if (!quiet) { S.AddRecent(path); S.Save(); }
            MemoryTrim.Schedule();

            var warn = doc.Security.Where(f => f.Severity == Severity.Danger || f.Severity == Severity.Warning).ToList();
            bool securityBanner = warn.Count > 0 && S.WarnInternetFiles;
            if (securityBanner)
            {
                var top = warn.First();
                ShowBanner($"«{tab.FileName}»: обнаружено и заблокировано: {top.Title}" + (warn.Count > 1 ? $" (и ещё {warn.Count - 1})" : "") + ". Документ показан в защищённом режиме. Подробности — кнопка щита внизу.", true);
            }
            else if (doc.Notices.Count > 0 && !quiet) ShowBanner(doc.Notices[0], false);

            // оглавление, метаданные, текстовый слой и размеры дальних страниц — в фоне, после показа первой страницы
            if (doc.HasPendingLoad) tab.Loading = FinishLoadingAsync(tab, !securityBanner && doc.Notices.Count == 0);
            // полный анализ безопасности большого PDF — тоже в фоне (активное содержимое и так никогда не выполняется)
            if (headOnly && fileOwnedByDoc) _ = ScanSecurityAsync(tab, path, file);
            return tab;
        }

        // ======================= Сеанс и место чтения =======================

        /// <summary>Место чтения и вид вкладки (страница указывается по номеру в файле — переставленные страницы не мешают).</summary>
        private SessionTab CaptureState(DocTab tab)
        {
            if (tab?.Doc == null || string.IsNullOrEmpty(tab.Path)) return null;
            try
            {
                var v = tab.Viewer;
                var (view, offset) = v.CurrentPlace();
                int page = view >= 0 && view < v.Pages.Count ? v.Pages[view].Doc : Math.Max(0, view);
                var marks = v.Pages.Where(p => p.Bookmarked).Select(p => p.Doc).Distinct().OrderBy(i => i).ToList();
                return new SessionTab
                {
                    Path = tab.Path,
                    Page = page,
                    Offset = double.IsNaN(offset) ? 0 : Math.Round(offset, 4),
                    Zoom = Math.Round(v.Zoom, 4),
                    Fit = v.FitMode ?? "width",
                    TwoPage = v.TwoPage,
                    Bookmarks = marks.Count > 0 ? marks : null
                };
            }
            catch { return null; }
        }

        /// <summary>Возвращает вкладку к сохранённому месту чтения, восстанавливает масштаб, разворот и закладки.</summary>
        private void ApplyState(DocTab tab, SessionTab st)
        {
            if (tab?.Doc == null || st == null) return;
            try
            {
                var v = tab.Viewer;
                if (st.Bookmarks != null && st.Bookmarks.Count > 0)
                {
                    var set = new HashSet<int>(st.Bookmarks);
                    foreach (var p in v.Pages) if (set.Contains(p.Doc)) p.Bookmarked = true;
                }
                int view = v.Pages.FindIndex(p => p.Doc == st.Page);
                if (view < 0) view = Math.Max(0, Math.Min(v.Pages.Count - 1, st.Page));
                // книги перестраиваются под шрифт: если число страниц изменилось, место приблизительное
                v.RestoreState(view, st.Offset, st.Zoom, st.Fit, st.TwoPage);
                if (tab == _active)
                {
                    TwoPageBtn.IsChecked = v.TwoPage;
                    RebuildSidebar();
                    UpdateZoomText();
                }
            }
            catch { }
        }

        /// <summary>Запоминает открытые вкладки и место чтения каждой — при следующем запуске они откроются снова.</summary>
        private void SaveSession()
        {
            S.Session.Clear();
            S.SessionSplit.Clear();
            S.SessionActive = 0;
            var saved = new List<DocTab>();
            foreach (var t in _tabs)
            {
                var st = CaptureState(t);
                if (st == null) continue;
                S.RememberPlace(st);
                if (!S.RestoreSession) continue;
                S.Session.Add(st);
                saved.Add(t);
            }
            if (!S.RestoreSession) return;
            S.SessionActive = Math.Max(0, saved.IndexOf(_active));
            if (_parallel)
                foreach (var t in _split)
                {
                    int i = saved.IndexOf(t);
                    if (i >= 0 && !S.SessionSplit.Contains(i)) S.SessionSplit.Add(i);
                }
            if (S.SessionSplit.Count < 2) S.SessionSplit.Clear();
        }

        /// <summary>
        /// Запуск программы: восстановление вкладок прошлого сеанса, затем документы из командной строки
        /// (двойной щелчок по файлу в Проводнике) — они открываются последними и становятся активными.
        /// </summary>
        public async void StartUp(List<string> files, bool restoreSession)
        {
            try
            {
                if (restoreSession && S.RestoreSession && S.Session.Count > 0) await RestoreSessionAsync();
                if (files != null && files.Count > 0) await OpenFilesAsync(files);
            }
            catch { }
        }

        private async Task RestoreSessionAsync()
        {
            var items = S.Session.Where(t => t != null && !string.IsNullOrWhiteSpace(t.Path)).ToList();
            int active = S.SessionActive;
            var split = S.SessionSplit.ToList();
            var opened = new List<DocTab>();
            int missing = 0, failed = 0, n = 0;
            foreach (var st in items)
            {
                n++;
                DocTab tab = null;
                bool exists;
                try { exists = File.Exists(st.Path); } catch { exists = false; }
                if (!exists) missing++;
                else
                {
                    ShowLoading($"Восстановление вкладок: {n} из {items.Count}…");
                    try { tab = await OpenFileAsync(st.Path, st, true); } catch { tab = null; }
                    if (tab == null) failed++;
                }
                opened.Add(tab);
            }
            HideLoading();

            var splitTabs = split.Where(i => i >= 0 && i < opened.Count).Select(i => opened[i]).Where(t => t != null && _tabs.Contains(t)).Distinct().Take(MaxPanes).ToList();
            var act = active >= 0 && active < opened.Count ? opened[active] : null;
            if (act == null || !_tabs.Contains(act)) act = opened.FirstOrDefault(t => t != null && _tabs.Contains(t));
            if (splitTabs.Count >= 2)
            {
                _split.Clear();
                _split.AddRange(splitTabs);
                _parallel = true;
                if (act == null || !_split.Contains(act)) act = _split[0];
                _searchGen++;
                _active = act;
                LayoutPanes();
                ApplyActiveToUi();
                EnsureTabVisible(act);
            }
            else if (act != null) ActivateTab(act);

            if (missing + failed > 0)
            {
                var parts = new List<string>();
                if (missing > 0) parts.Add($"не найдено файлов: {missing}");
                if (failed > 0) parts.Add($"не удалось открыть: {failed} (например, защищённые паролем — откройте их вручную)");
                ShowBanner("Вкладки прошлого сеанса восстановлены не полностью: " + string.Join("; ", parts) + ".", false);
            }
            else if (opened.Count > 0) StatusText.Text = $"Восстановлены вкладки прошлого сеанса: {opened.Count}.";
        }

        private async Task ScanSecurityAsync(DocTab tab, string path, SharedFile file)
        {
            var doc = tab.Doc;
            List<SecurityFinding> found;
            try
            {
                string code = doc.FormatCode, name = doc.FormatName;
                found = await Task.Run(() => SecurityScanner.Collect(code, name, file.ReadAll(), path));
            }
            catch
            {
                // файл закрыт (вкладку закрыли) или не читается — показываем хотя бы базовое состояние защиты
                found = new List<SecurityFinding>();
            }
            if (tab.Doc != doc || !_tabs.Contains(tab)) return;
            SecurityScanner.Apply(doc, found);
            MemoryTrim.Schedule();
            if (tab == _active) UpdateSecurityBadge();
            var warn = doc.Security.Where(f => f.Severity == Severity.Danger || f.Severity == Severity.Warning).ToList();
            if (warn.Count > 0 && S.WarnInternetFiles)
            {
                var top = warn.First();
                ShowBanner($"«{tab.FileName}»: обнаружено и заблокировано: {top.Title}" + (warn.Count > 1 ? $" (и ещё {warn.Count - 1})" : "") + ". Документ показан в защищённом режиме. Подробности — кнопка щита внизу.", true);
            }
        }

        /// <summary>
        /// Фоновая догрузка документа. Начинается, когда первая страница уже на экране (или через 1,5 с,
        /// если вкладка открыта в фоне), чтобы не отнимать время у отрисовки.
        /// </summary>
        private async Task FinishLoadingAsync(DocTab tab, bool mayShowNotice)
        {
            var doc = tab.Doc;
            if (doc == null) return;
            var shown = new TaskCompletionSource<bool>();
            Action onShown = () => shown.TrySetResult(true);
            tab.Viewer.PageRendered += onShown;
            try { await Task.WhenAny(shown.Task, Task.Delay(1500)); }
            finally { tab.Viewer.PageRendered -= onShown; }

            try { await Task.Run(() => doc.CompleteLoading()); } catch { }
            if (tab.Doc != doc || !_tabs.Contains(tab)) return;
            int notices = doc.Notices.Count;
            bool sizesChanged;
            try { sizesChanged = doc.ApplyCompletedLoading(); } catch { return; }
            if (sizesChanged) tab.Viewer.OnPageSizesChanged();
            if (tab == _active)
            {
                TitleText.Text = tab.FileName + (string.IsNullOrWhiteSpace(doc.Title) ? "" : "  —  " + doc.Title);
                RebuildToc();
            }
            UpdatePaneTitle(tab);
            if (mayShowNotice && doc.Notices.Count > notices) ShowBanner(doc.Notices[notices], false);
        }

        /// <summary>Окна свойств и печати ждут фоновую догрузку (метаданные, точные размеры всех страниц).</summary>
        private async Task WaitLoadingAsync()
        {
            var t = _active?.Loading;
            if (t == null || t.IsCompleted) return;
            Mouse.OverrideCursor = Cursors.Wait;
            try { await t; } catch { }
            finally { Mouse.OverrideCursor = null; }
        }

        // ======================= Вкладки =======================

        private DocTab CreateTab(DocumentBase doc, string path)
        {
            var tab = new DocTab { Doc = doc, Path = path };
            var v = tab.Viewer;
            ApplyViewSettings(v, true);
            v.NewAnnotation = NewAnnotationStyle;
            v.AskText = (title, initial) => InputDialog.Ask(this, title, "Введите текст. Ctrl+Enter — готово.", initial, true);
            v.ContextMenu = BuildPageMenu();
            v.CurrentPageChanged += i => { if (tab == _active) OnCurrentPageChanged(i); UpdatePaneTitle(tab); };
            v.ZoomChanged += () => { if (tab == _active) UpdateZoomText(); };
            v.AnnotationsChanged += () => { UpdateTabHeader(tab); if (tab == _active) OnAnnotationsChanged(); };
            v.StatusMessage += m => StatusText.Text = m;
            v.Scrolled += () => OnViewerScrolled(tab);
            v.PageSizesUpdated += () => { if (tab == _active) RebuildThumbs(); };
            v.HistoryChanged += () => { if (tab == _active) UpdateNavButtons(); };
            v.AutoScrollChanged += () => { if (tab == _active) UpdateAutoScrollUi(); };

            BuildTabHeader(tab);
            BuildPane(tab);
            _tabs.Add(tab);
            TabsPanel.Children.Add(tab.Header);
            // пока панель не на экране, страницы не рисуются; LayoutPanes покажет её и подгонит масштаб
            v.Suspend();
            v.SetDocument(doc);
            UpdateTabHeader(tab);
            UpdatePaneTitle(tab);
            return tab;
        }

        private void BuildTabHeader(DocTab tab)
        {
            var text = new TextBlock { Text = tab.FileName, MaxWidth = TabTextWidth(), TextTrimming = TextTrimming.CharacterEllipsis, VerticalAlignment = VerticalAlignment.Center, FontSize = 12.5 };
            var dot = new TextBlock { Text = "●", FontSize = 9, Margin = new Thickness(0, 0, 6, 0), VerticalAlignment = VerticalAlignment.Center, Visibility = Visibility.Collapsed, ToolTip = "Есть несохранённые пометки или изменения страниц" };
            dot.SetResourceReference(TextBlock.ForegroundProperty, "Accent2Brush");
            var close = new Button { Content = "", Width = 20, Height = 20, FontSize = 9, Margin = new Thickness(8, 0, 0, 0), Padding = new Thickness(0), Focusable = false, ToolTip = "Закрыть вкладку (Ctrl+W, средняя кнопка мыши)" };
            close.SetResourceReference(StyleProperty, "ToolBtn");
            close.Click += (s, e) => CloseTab(tab);
            var dp = new DockPanel { LastChildFill = true };
            DockPanel.SetDock(close, Dock.Right);
            dp.Children.Add(close);
            var icon = new TextBlock { Text = "", FontSize = 12, Margin = new Thickness(0, 0, 6, 0), VerticalAlignment = VerticalAlignment.Center };
            icon.SetResourceReference(TextBlock.FontFamilyProperty, "IconFont");
            DockPanel.SetDock(icon, Dock.Left);
            DockPanel.SetDock(dot, Dock.Left);
            dp.Children.Add(icon);
            dp.Children.Add(dot);
            dp.Children.Add(text);
            var header = new Border
            {
                Child = dp,
                Padding = new Thickness(10, 5, 4, 5),
                Margin = new Thickness(0, 0, 3, 0),
                BorderThickness = new Thickness(1, 1, 1, 2),
                CornerRadius = new CornerRadius(7, 7, 0, 0),
                Cursor = Cursors.Hand,
                ToolTip = tab.Path + "\n\nCtrl+щелчок — показать рядом (параллельный просмотр)\nПеретащите вкладку, чтобы изменить порядок",
                SnapsToDevicePixels = true
            };
            header.MouseLeftButtonDown += (s, e) =>
            {
                if (e.OriginalSource is DependencyObject src && IsInside<Button>(src, header)) return; // кнопка «закрыть»
                if ((Keyboard.Modifiers & ModifierKeys.Control) != 0) ToggleInSplit(tab);
                else
                {
                    SelectTabFromStrip(tab);
                    // перетаскивание вкладки меняет порядок вкладок
                    _tabDrag = tab;
                    _tabDragStart = e.GetPosition(TabStripBar); // в координатах ряда: автопрокрутка к вкладке не считается перетаскиванием
                    _tabDragging = false;
                }
                e.Handled = true;
            };
            header.MouseMove += (s, e) => OnTabDragMove(tab, e);
            header.MouseLeftButtonUp += (s, e) => { if (_tabDrag == tab) { EndTabDrag(); e.Handled = true; } };
            header.LostMouseCapture += (s, e) => { if (_tabDrag == tab && _tabDragging) EndTabDrag(); };
            header.MouseDown += (s, e) =>
            {
                if (e.ChangedButton == MouseButton.Middle) { CloseTab(tab); e.Handled = true; }
            };
            header.MouseEnter += (s, e) => StyleTabHeader(tab, true);
            header.MouseLeave += (s, e) => StyleTabHeader(tab, false);
            header.ContextMenuOpening += (s, e) => header.ContextMenu = BuildTabMenu(tab);
            header.ContextMenu = new ContextMenu();
            tab.Header = header;
            tab.HeaderText = text;
            tab.HeaderDot = dot;
            StyleTabHeader(tab, false);
        }

        private void StyleTabHeader(DocTab tab, bool hover)
        {
            if (tab.Header == null) return;
            bool active = tab == _active;
            bool shown = _parallel && _split.Contains(tab);
            var h = tab.Header;
            if (active)
            {
                h.SetResourceReference(Border.BackgroundProperty, "PanelSolidBrush");
                h.SetResourceReference(Border.BorderBrushProperty, "Accent1Brush");
                tab.HeaderText.SetResourceReference(TextBlock.ForegroundProperty, "Accent1Brush");
                tab.HeaderText.FontWeight = FontWeights.SemiBold;
            }
            else
            {
                h.SetResourceReference(Border.BackgroundProperty, hover ? "HoverBrush" : "ButtonBgBrush");
                if (shown) h.SetResourceReference(Border.BorderBrushProperty, "Accent2Brush");
                else h.SetResourceReference(Border.BorderBrushProperty, "PanelBorderBrush");
                tab.HeaderText.SetResourceReference(TextBlock.ForegroundProperty, hover ? "FgBrush" : "SubFgBrush");
                tab.HeaderText.FontWeight = FontWeights.Normal;
            }
        }

        private void UpdateTabHeader(DocTab tab)
        {
            if (tab?.HeaderDot == null) return;
            tab.HeaderDot.Visibility = tab.Doc != null && tab.Viewer.Modified ? Visibility.Visible : Visibility.Collapsed;
        }

        private void RestyleAllTabs()
        {
            foreach (var t in _tabs) StyleTabHeader(t, t.Header != null && t.Header.IsMouseOver);
        }

        private ContextMenu BuildTabMenu(DocTab tab)
        {
            var m = new ContextMenu();
            void Add(string icon, string text, Action a, bool enabled = true)
            {
                var mi = new MenuItem { Header = text, IsEnabled = enabled, Icon = new TextBlock { Text = icon, FontFamily = (FontFamily)FindResource("IconFont") } };
                mi.Click += (s, e) => a();
                m.Items.Add(mi);
            }
            bool inSplit = _parallel && _split.Contains(tab);
            if (!inSplit)
                Add("", "Показать рядом (параллельный просмотр)", () => AddToSplit(tab), _tabs.Count > 1 && (!_parallel || _split.Count < MaxPanes));
            else
                Add("", "Убрать из параллельного просмотра", () => RemoveFromSplit(tab));
            Add("", "Показать рядом все вкладки", ShowAllSideBySide, _tabs.Count > 1);
            m.Items.Add(new Separator());
            Add("", "Копировать путь к файлу", () =>
            {
                try { Clipboard.SetText(tab.Path ?? ""); StatusText.Text = "Путь скопирован."; } catch { }
            });
            Add("", "Показать в папке", () => ShellIntegration.ShowInExplorer(tab.Path));
            m.Items.Add(new Separator());
            Add("\uE74A", "Переместить в начало", () => MoveTabTo(tab, 0), _tabs.IndexOf(tab) > 0);
            Add("\uE74B", "Переместить в конец", () => MoveTabTo(tab, _tabs.Count - 1), _tabs.IndexOf(tab) < _tabs.Count - 1);
            Add("\uE8CB", "Упорядочить вкладки по имени", SortTabsByName, _tabs.Count > 1);
            m.Items.Add(new Separator());
            Add("", "Закрыть", () => CloseTab(tab));
            Add("", "Закрыть другие вкладки", () => { foreach (var t in _tabs.Where(x => x != tab).ToList()) if (!CloseTab(t)) break; }, _tabs.Count > 1);
            Add("", "Закрыть вкладки справа", () =>
            {
                int i = _tabs.IndexOf(tab);
                foreach (var t in _tabs.Skip(i + 1).ToList()) if (!CloseTab(t)) break;
            }, _tabs.IndexOf(tab) < _tabs.Count - 1);
            Add("\uE711", "Закрыть вкладки слева", () =>
            {
                int i = _tabs.IndexOf(tab);
                foreach (var t in _tabs.Take(i).ToList()) if (!CloseTab(t)) break;
            }, _tabs.IndexOf(tab) > 0);
            Add("\uE711", "Закрыть все вкладки", CloseAllTabs);
            m.Items.Add(new Separator());
            Add("\uE7A7", "Восстановить закрытую вкладку", ReopenClosedTab, _closedTabs.Count > 0);
            return m;
        }

        private void TabScroll_PreviewMouseWheel(object sender, MouseWheelEventArgs e)
        {
            // вертикальное колесо листает ряд вкладок по горизонтали
            ScrollTabsBy(-e.Delta * 0.75);
            e.Handled = true;
        }

        private double TabTextWidth() => Math.Max(60, Math.Min(400, S.CompactTabs ? Math.Min(130, S.TabMaxWidth) : S.TabMaxWidth));

        /// <summary>Применяет ширину заголовков вкладок из настроек.</summary>
        private void ApplyTabWidth()
        {
            double w = TabTextWidth();
            foreach (var t in _tabs) if (t.HeaderText != null) t.HeaderText.MaxWidth = w;
            UpdateTabScrollButtons();
        }

        private void ScrollTabsBy(double dx)
        {
            double to = Math.Max(0, Math.Min(TabScroll.ScrollableWidth, TabScroll.HorizontalOffset + dx));
            TabScroll.ScrollToHorizontalOffset(to);
        }

        private void TabLeft_Click(object sender, RoutedEventArgs e)
        {
            if ((Keyboard.Modifiers & ModifierKeys.Shift) != 0) TabScroll.ScrollToLeftEnd();
            else ScrollTabsBy(-TabScrollStep);
        }

        private void TabRight_Click(object sender, RoutedEventArgs e)
        {
            if ((Keyboard.Modifiers & ModifierKeys.Shift) != 0) TabScroll.ScrollToRightEnd();
            else ScrollTabsBy(TabScrollStep);
        }

        private void TabScroll_ScrollChanged(object sender, ScrollChangedEventArgs e) => UpdateTabScrollButtons();

        /// <summary>Кнопки ‹ › и затухание краёв видны, только когда вкладки не помещаются в ряд.</summary>
        private void UpdateTabScrollButtons()
        {
            if (TabScroll == null || TabLeftBtn == null) return;
            bool overflow = TabScroll.ScrollableWidth > 0.5;
            bool canLeft = overflow && TabScroll.HorizontalOffset > 0.5;
            bool canRight = overflow && TabScroll.HorizontalOffset < TabScroll.ScrollableWidth - 0.5;
            var vis = overflow ? Visibility.Visible : Visibility.Collapsed;
            if (TabLeftBtn.Visibility != vis) TabLeftBtn.Visibility = vis;
            if (TabRightBtn.Visibility != vis) TabRightBtn.Visibility = vis;
            TabLeftBtn.IsEnabled = canLeft;
            TabRightBtn.IsEnabled = canRight;
            TabFadeLeft.Visibility = canLeft ? Visibility.Visible : Visibility.Collapsed;
            TabFadeRight.Visibility = canRight ? Visibility.Visible : Visibility.Collapsed;
            int hidden = overflow ? CountHiddenTabs() : 0;
            TabListBtn.ToolTip = "Все вкладки — список с быстрым переходом (Ctrl+Shift+Пробел)" +
                                 (hidden > 0 ? $"\nЗа краями ряда: {hidden}" : "") + $"\nОткрыто вкладок: {_tabs.Count}";
        }

        /// <summary>Сколько вкладок не видно целиком (ушли за левый или правый край ряда).</summary>
        private int CountHiddenTabs()
        {
            int n = 0;
            double off = TabScroll.HorizontalOffset, vw = TabScroll.ViewportWidth;
            foreach (var t in _tabs)
            {
                if (t.Header == null || !t.Header.IsVisible) continue;
                try
                {
                    var p = t.Header.TransformToAncestor(TabsPanel).Transform(new Point(0, 0));
                    if (p.X < off - 1 || p.X + t.Header.ActualWidth > off + vw + 1) n++;
                }
                catch { }
            }
            return n;
        }

        /// <summary>Прокручивает ряд так, чтобы вкладка была видна целиком (с небольшим запасом по краям).</summary>
        private void EnsureTabVisible(DocTab tab)
        {
            if (tab?.Header == null) return;
            Dispatcher.BeginInvoke(new Action(() =>
            {
                if (tab.Header == null || !TabsPanel.Children.Contains(tab.Header) || !TabStripBar.IsVisible) { UpdateTabScrollButtons(); return; }
                try
                {
                    TabScroll.UpdateLayout();
                    var p = tab.Header.TransformToAncestor(TabsPanel).Transform(new Point(0, 0));
                    double left = p.X, right = p.X + tab.Header.ActualWidth;
                    double off = TabScroll.HorizontalOffset, vw = TabScroll.ViewportWidth;
                    const double pad = 28;
                    if (left - pad < off) TabScroll.ScrollToHorizontalOffset(Math.Max(0, left - pad));
                    else if (right + pad > off + vw) TabScroll.ScrollToHorizontalOffset(Math.Min(TabScroll.ScrollableWidth, right + pad - vw));
                }
                catch { }
                UpdateTabScrollButtons();
            }), DispatcherPriority.Loaded);
        }

        private static bool IsInside<T>(DependencyObject d, DependencyObject stop) where T : DependencyObject
        {
            while (d != null && d != stop)
            {
                if (d is T) return true;
                d = d is Visual || d is System.Windows.Media.Media3D.Visual3D ? VisualTreeHelper.GetParent(d) : LogicalTreeHelper.GetParent(d);
            }
            return false;
        }

        // ---------- перетаскивание вкладок ----------

        private void OnTabDragMove(DocTab tab, MouseEventArgs e)
        {
            if (_tabDrag != tab) return;
            if (e.LeftButton != MouseButtonState.Pressed) { EndTabDrag(); return; }
            var pos = e.GetPosition(TabsPanel);
            if (!_tabDragging)
            {
                if (Math.Abs(e.GetPosition(TabStripBar).X - _tabDragStart.X) < 8 || _tabs.Count < 2) return;
                _tabDragging = true;
                tab.Header.CaptureMouse();
                tab.Header.Opacity = 0.7;
                tab.Header.Cursor = Cursors.SizeWE;
            }
            // у края ряда — прокручиваем, чтобы вкладку можно было унести за пределы видимой части
            double x = e.GetPosition(TabScroll).X;
            if (x < 24) ScrollTabsBy(-14);
            else if (x > TabScroll.ViewportWidth - 24) ScrollTabsBy(14);

            int cur = TabsPanel.Children.IndexOf(tab.Header);
            if (cur < 0) return;
            int target = 0;
            for (int i = 0; i < TabsPanel.Children.Count; i++)
            {
                if (i == cur || !(TabsPanel.Children[i] is FrameworkElement fe)) continue;
                double mid;
                try { mid = fe.TransformToAncestor(TabsPanel).Transform(new Point(fe.ActualWidth / 2, 0)).X; } catch { continue; }
                if (pos.X > mid) target++;
            }
            if (target != cur) MoveTabHeader(tab, target);
        }

        private void EndTabDrag()
        {
            var tab = _tabDrag;
            _tabDrag = null;
            if (tab?.Header == null) { _tabDragging = false; return; }
            bool was = _tabDragging;
            _tabDragging = false;
            tab.Header.Opacity = 1;
            tab.Header.Cursor = Cursors.Hand;
            if (tab.Header.IsMouseCaptured) tab.Header.ReleaseMouseCapture();
            if (was) EnsureTabVisible(tab);
        }

        /// <summary>
        /// Переставляет заголовок вкладки. Перетаскиваемый элемент не вынимается из дерева (иначе потерялся бы захват мыши) —
        /// вместо этого соседние заголовки переносятся на другую сторону.
        /// </summary>
        private void MoveTabHeader(DocTab tab, int target)
        {
            var kids = TabsPanel.Children;
            int cur = kids.IndexOf(tab.Header);
            if (cur < 0) return;
            target = Math.Max(0, Math.Min(kids.Count - 1, target));
            while (cur > target)
            {
                var n = kids[cur - 1];
                kids.RemoveAt(cur - 1);
                kids.Insert(cur, n);
                cur--;
            }
            while (cur < target)
            {
                var n = kids[cur + 1];
                kids.RemoveAt(cur + 1);
                kids.Insert(cur, n);
                cur++;
            }
            SyncTabOrder();
        }

        /// <summary>Порядок вкладок в списке — как на экране (для Ctrl+Tab, сеанса и меню).</summary>
        private void SyncTabOrder()
        {
            var order = new Dictionary<DocTab, int>();
            foreach (var t in _tabs) order[t] = t.Header != null ? TabsPanel.Children.IndexOf(t.Header) : int.MaxValue;
            var sorted = _tabs.OrderBy(t => order[t]).ToList();
            _tabs.Clear();
            _tabs.AddRange(sorted);
        }

        private void MoveTabTo(DocTab tab, int index)
        {
            if (tab?.Header == null) return;
            MoveTabHeader(tab, index);
            EnsureTabVisible(tab);
        }

        private void SortTabsByName()
        {
            var sorted = _tabs.OrderBy(t => t.FileName, StringComparer.CurrentCultureIgnoreCase).ToList();
            TabsPanel.Children.Clear();
            foreach (var t in sorted) if (t.Header != null) TabsPanel.Children.Add(t.Header);
            _tabs.Clear();
            _tabs.AddRange(sorted);
            EnsureTabVisible(_active);
            StatusText.Text = "Вкладки упорядочены по имени файла.";
        }

        // ---------- список вкладок ----------

        private void TabList_Click(object sender, RoutedEventArgs e) => ShowTabList();

        private void ShowTabList()
        {
            var m = new ContextMenu { MaxHeight = Math.Max(240, ActualHeight - 160) };
            var iconFont = (FontFamily)FindResource("IconFont");
            if (_tabs.Count == 0) m.Items.Add(new MenuItem { Header = "Нет открытых вкладок", IsEnabled = false });
            int n = 0;
            foreach (var t in _tabs)
            {
                var tab = t;
                n++;
                string mark = tab.Doc != null && tab.Viewer.Modified ? "  ●" : "";
                bool shown = _parallel && _split.Contains(tab);
                var mi = new MenuItem
                {
                    Header = new TextBlock { Text = tab.FileName + mark, MaxWidth = 460, TextTrimming = TextTrimming.CharacterEllipsis, FontWeight = tab == _active ? FontWeights.SemiBold : FontWeights.Normal },
                    ToolTip = tab.Path,
                    InputGestureText = n <= 9 ? "Alt+" + n : "",
                    Icon = new TextBlock { Text = tab == _active ? "" : shown ? "" : "", FontFamily = iconFont }
                };
                mi.Click += (s, x) => ActivateTab(tab);
                m.Items.Add(mi);
            }
            m.Items.Add(new Separator());
            var reopen = new MenuItem { Header = "Восстановить закрытую вкладку", InputGestureText = "Ctrl+Shift+T", IsEnabled = _closedTabs.Count > 0, Icon = new TextBlock { Text = "", FontFamily = iconFont } };
            reopen.Click += (s, x) => ReopenClosedTab();
            m.Items.Add(reopen);
            var sort = new MenuItem { Header = "Упорядочить по имени", IsEnabled = _tabs.Count > 1, Icon = new TextBlock { Text = "", FontFamily = iconFont } };
            sort.Click += (s, x) => SortTabsByName();
            m.Items.Add(sort);
            var closeAll = new MenuItem { Header = "Закрыть все вкладки", IsEnabled = _tabs.Count > 0, Icon = new TextBlock { Text = "", FontFamily = iconFont } };
            closeAll.Click += (s, x) => CloseAllTabs();
            m.Items.Add(closeAll);
            bool strip = TabListBtn.IsVisible;
            m.PlacementTarget = strip ? (UIElement)TabListBtn : this;
            m.Placement = strip ? PlacementMode.Bottom : PlacementMode.Center;
            m.IsOpen = true;
        }

        private void CloseAllTabs()
        {
            foreach (var t in _tabs.ToList()) if (!CloseTab(t)) break;
        }

        /// <summary>Ctrl+Shift+T: снова открыть последнюю закрытую вкладку на том же месте.</summary>
        private async void ReopenClosedTab()
        {
            while (_closedTabs.Count > 0)
            {
                var st = _closedTabs[_closedTabs.Count - 1];
                _closedTabs.RemoveAt(_closedTabs.Count - 1);
                if (!File.Exists(st.Path)) continue;
                try { await OpenFileAsync(st.Path, st, false); } catch { }
                return;
            }
            StatusText.Text = "Нет недавно закрытых вкладок.";
        }

        /// <summary>Alt+1…Alt+8 — вкладка по номеру, Alt+9 — последняя.</summary>
        private void SelectTabByNumber(int n)
        {
            if (_tabs.Count == 0) return;
            int i = n >= 9 ? _tabs.Count - 1 : n - 1;
            if (i >= 0 && i < _tabs.Count) ActivateTab(_tabs[i]);
        }

        /// <summary>Щелчок по вкладке. В параллельном режиме вкладка, которой нет на экране, заменяет активную панель.</summary>
        private void SelectTabFromStrip(DocTab tab) => ActivateTab(tab);

        private List<DocTab> VisibleTabs()
        {
            if (_parallel) return _split.Where(t => _tabs.Contains(t)).ToList();
            return _active != null ? new List<DocTab> { _active } : new List<DocTab>();
        }

        /// <summary>Делает вкладку активной: панели инструментов, боковая панель и строка состояния переключаются на неё.</summary>
        /// <param name="addPane">В параллельном режиме: добавить новую панель (если есть место), а не заменить активную.</param>
        private void ActivateTab(DocTab tab, bool addPane = false)
        {
            if (tab == null || !_tabs.Contains(tab)) return;
            bool wasVisible = VisibleTabs().Contains(tab);
            if (_parallel && !_split.Contains(tab))
            {
                int i = _split.IndexOf(_active);
                if (addPane && _split.Count < MaxPanes) _split.Add(tab);
                else if (i >= 0) _split[i] = tab;
                else if (_split.Count < MaxPanes) _split.Add(tab);
                else _split[_split.Count - 1] = tab;
            }
            bool changed = tab != _active;
            if (changed)
            {
                _searchGen++; // текущий поиск относится к прежнему документу
                _active = tab;
            }
            // перестраиваем панели только если документа не было на экране:
            // щелчок внутри уже показанной панели не должен «пересобирать» окно
            if (!wasVisible) LayoutPanes();
            else UpdatePaneChrome();
            if (changed || !wasVisible) ApplyActiveToUi();
            EnsureTabVisible(tab);
        }

        /// <summary>Переносит состояние активного документа в общие элементы окна.</summary>
        private void ApplyActiveToUi()
        {
            var tab = _active;
            bool has = tab?.Doc != null;
            Welcome.Visibility = has ? Visibility.Collapsed : Visibility.Visible;
            PanesGrid.Visibility = has ? Visibility.Visible : Visibility.Collapsed;
            TabStripBar.Visibility = _tabs.Count > 0 ? Visibility.Visible : Visibility.Collapsed;
            if (has)
            {
                var doc = tab.Doc;
                TitleText.Text = tab.FileName + (string.IsNullOrWhiteSpace(doc.Title) ? "" : "  —  " + doc.Title);
                Title = tab.FileName + " — DocuNova";
                FormatText.Text = doc.FormatName;
                TwoPageBtn.IsChecked = tab.Viewer.TwoPage;
                _viewer.Tool = _tool;
                SearchResults.ItemsSource = tab.HitView;
                SearchStatus.Text = tab.SearchStatus ?? "";
                SearchBox.Tag = tab.SearchKey;
            }
            else
            {
                TitleText.Text = "";
                Title = "DocuNova";
                FormatText.Text = "";
                PageBox.Text = "";
                PageCountText.Text = "/ 0";
                SearchResults.ItemsSource = null;
                SearchStatus.Text = "";
                SearchBox.Tag = null;
                RefreshRecent();
            }
            RebuildSidebar();
            UpdateSecurityBadge();
            UpdateDocButtons();
            UpdateZoomText();
            RestyleAllTabs();
            UpdateParallelUi();
            UpdateNavButtons();
            UpdateAutoScrollUi();
            if (has)
            {
                OnCurrentPageChanged(tab.Viewer.CurrentPage);
                var v = tab.Viewer;
                Dispatcher.BeginInvoke(new Action(() => { if (_active?.Viewer == v && !IsKeyboardFocusWithinTextBox()) v.Scroll.Focus(); }), DispatcherPriority.Input);
            }
        }

        private bool IsKeyboardFocusWithinTextBox() => Keyboard.FocusedElement is TextBox || Keyboard.FocusedElement is PasswordBox;

        /// <summary>Закрывает вкладку. false — пользователь отменил закрытие.</summary>
        private bool CloseTab(DocTab tab)
        {
            if (tab == null || !_tabs.Contains(tab)) return true;
            if (!ConfirmDiscard(tab)) return false;
            if (_tabDrag == tab) EndTabDrag();
            var place = CaptureState(tab);
            if (place != null)
            {
                S.RememberPlace(place);
                _closedTabs.RemoveAll(c => string.Equals(c.Path, place.Path, StringComparison.OrdinalIgnoreCase));
                _closedTabs.Add(place);
                if (_closedTabs.Count > 25) _closedTabs.RemoveAt(0);
            }
            int idx = _tabs.IndexOf(tab);
            bool wasActive = tab == _active;
            _tabs.Remove(tab);
            _split.Remove(tab);
            TabsPanel.Children.Remove(tab.Header);
            if (_parallel && _split.Count < 2) { _parallel = false; _split.Clear(); }
            DisposeTab(tab);

            if (wasActive || _active == null)
            {
                DocTab next = null;
                if (_parallel && _split.Count > 0) next = _split[0];
                else if (_tabs.Count > 0) next = _tabs[Math.Min(idx, _tabs.Count - 1)];
                _searchGen++;
                _active = next;
                LayoutPanes();
                ApplyActiveToUi();
            }
            else
            {
                LayoutPanes();
                RestyleAllTabs();
                UpdateParallelUi();
            }
            MemoryTrim.Schedule();
            return true;
        }

        private void DisposeTab(DocTab tab)
        {
            try
            {
                if (tab.Pane != null && tab.Pane.Parent is Panel p) p.Children.Remove(tab.Pane);
                tab.Viewer.SetDocument(null);
                tab.Viewer.ContextMenu = null;
                tab.Doc?.Dispose();
            }
            catch { }
            tab.Doc = null;
            tab.Hits = new List<SearchHit>();
            tab.HitView = null;
        }

        private void NextTab(int dir)
        {
            if (_tabs.Count < 2) return;
            int i = _active != null ? _tabs.IndexOf(_active) : 0;
            i = ((i + dir) % _tabs.Count + _tabs.Count) % _tabs.Count;
            SelectTabFromStrip(_tabs[i]);
        }

        private void UpdateTabSpacer()
        {
            // вкладки располагаются над областью документа, правее боковой панели
            TabSidebarSpacer.Width = Sidebar.Visibility == Visibility.Visible && !_fullscreen ? Math.Max(0, SidebarCol.ActualWidth + 6) : 0;
        }

        // ======================= Панели и параллельный просмотр =======================

        private void BuildPane(DocTab tab)
        {
            var title = new TextBlock { TextTrimming = TextTrimming.CharacterEllipsis, VerticalAlignment = VerticalAlignment.Center, FontSize = 12.5 };
            var close = new Button { Content = "", Width = 22, Height = 22, FontSize = 9, Padding = new Thickness(0), Focusable = false, ToolTip = "Убрать из параллельного просмотра (вкладка останется открытой)" };
            close.SetResourceReference(StyleProperty, "ToolBtn");
            close.Click += (s, e) => RemoveFromSplit(tab);
            var hdp = new DockPanel();
            DockPanel.SetDock(close, Dock.Right);
            hdp.Children.Add(close);
            hdp.Children.Add(title);
            var header = new Border { Child = hdp, Padding = new Thickness(10, 2, 4, 2), Visibility = Visibility.Collapsed };
            header.SetResourceReference(Border.BackgroundProperty, "PanelBrush");
            DockPanel.SetDock(header, Dock.Top);

            var dp = new DockPanel { LastChildFill = true };
            dp.Children.Add(header);
            dp.Children.Add(tab.Viewer);

            var pane = new Border { Child = dp, BorderThickness = new Thickness(0), CornerRadius = new CornerRadius(6), ClipToBounds = true, Margin = new Thickness(0) };
            pane.BorderBrush = Brushes.Transparent;
            // щелчок или прокрутка колесом делает панель активной (без перестройки окна)
            pane.PreviewMouseDown += (s, e) => { if (_active != tab) ActivateTab(tab); };
            pane.PreviewMouseWheel += (s, e) => { if (_active != tab && _parallel) ActivateTab(tab); };
            tab.Pane = pane;
            tab.PaneHeader = header;
            tab.PaneTitle = title;
        }

        private void UpdatePaneTitle(DocTab tab)
        {
            if (tab?.PaneTitle == null || tab.Doc == null) return;
            tab.PaneTitle.Text = $"{tab.FileName}   ·   стр. {tab.Viewer.CurrentPage + 1} из {tab.Viewer.Pages.Count}";
        }

        /// <summary>Размещает видимые документы в области просмотра; скрытые вкладки освобождают память.</summary>
        private void LayoutPanes()
        {
            var visible = VisibleTabs();
            foreach (var t in _tabs)
                if (!visible.Contains(t) && !t.Viewer.Suspended)
                {
                    t.Viewer.Suspend();
                    try { t.Doc?.TrimMemory(); } catch { }
                }

            PanesGrid.Children.Clear();
            PanesGrid.RowDefinitions.Clear();
            PanesGrid.ColumnDefinitions.Clear();
            int n = visible.Count;
            bool multi = n > 1;
            string layout = S.ParallelLayout ?? "columns";

            if (n == 1)
            {
                PanesGrid.Children.Add(visible[0].Pane);
            }
            else if (n > 1 && layout == "grid")
            {
                int cols = (int)Math.Ceiling(Math.Sqrt(n));
                int rows = (int)Math.Ceiling(n / (double)cols);
                for (int c = 0; c < cols; c++) PanesGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
                for (int r = 0; r < rows; r++) PanesGrid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
                for (int i = 0; i < n; i++)
                {
                    var pane = visible[i].Pane;
                    pane.Margin = new Thickness(2);
                    Grid.SetColumn(pane, i % cols); Grid.SetRow(pane, i / cols);
                    Grid.SetColumnSpan(pane, 1); Grid.SetRowSpan(pane, 1);
                    PanesGrid.Children.Add(pane);
                }
            }
            else if (n > 1)
            {
                bool cols = layout != "rows";
                for (int i = 0; i < n; i++)
                {
                    if (i > 0)
                    {
                        var sp = new GridSplitter
                        {
                            Background = Brushes.Transparent,
                            ResizeBehavior = GridResizeBehavior.PreviousAndNext,
                            HorizontalAlignment = HorizontalAlignment.Stretch,
                            VerticalAlignment = VerticalAlignment.Stretch,
                            ShowsPreview = false
                        };
                        sp.ResizeDirection = cols ? GridResizeDirection.Columns : GridResizeDirection.Rows;
                        if (cols)
                        {
                            PanesGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(6) });
                            sp.Width = 6; sp.Cursor = Cursors.SizeWE;
                            Grid.SetColumn(sp, PanesGrid.ColumnDefinitions.Count - 1); Grid.SetRow(sp, 0);
                        }
                        else
                        {
                            PanesGrid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(6) });
                            sp.Height = 6; sp.Cursor = Cursors.SizeNS;
                            Grid.SetRow(sp, PanesGrid.RowDefinitions.Count - 1); Grid.SetColumn(sp, 0);
                        }
                        PanesGrid.Children.Add(sp);
                    }
                    var pane = visible[i].Pane;
                    pane.Margin = new Thickness(0);
                    Grid.SetColumnSpan(pane, 1); Grid.SetRowSpan(pane, 1);
                    if (cols)
                    {
                        PanesGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star), MinWidth = 160 });
                        Grid.SetColumn(pane, PanesGrid.ColumnDefinitions.Count - 1); Grid.SetRow(pane, 0);
                    }
                    else
                    {
                        PanesGrid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star), MinHeight = 120 });
                        Grid.SetRow(pane, PanesGrid.RowDefinitions.Count - 1); Grid.SetColumn(pane, 0);
                    }
                    PanesGrid.Children.Add(pane);
                }
            }
            if (n == 1)
            {
                var pane = visible[0].Pane;
                pane.Margin = new Thickness(0);
                Grid.SetColumn(pane, 0); Grid.SetRow(pane, 0);
            }

            foreach (var t in visible)
            {
                t.PaneHeader.Visibility = multi ? Visibility.Visible : Visibility.Collapsed;
                t.Viewer.Resume();
                UpdatePaneTitle(t);
            }
            UpdatePaneChrome();
            MemoryTrim.Schedule();
        }

        /// <summary>Подсветка активной панели в параллельном просмотре.</summary>
        private void UpdatePaneChrome()
        {
            bool multi = _parallel && VisibleTabs().Count > 1;
            foreach (var t in _tabs)
            {
                if (t.Pane == null) continue;
                bool act = t == _active;
                t.Pane.BorderThickness = new Thickness(multi ? 2 : 0);
                if (multi && act) t.Pane.SetResourceReference(Border.BorderBrushProperty, "Accent1Brush");
                else if (multi) t.Pane.SetResourceReference(Border.BorderBrushProperty, "PanelBorderBrush");
                else t.Pane.BorderBrush = Brushes.Transparent;
                if (t.PaneTitle != null)
                {
                    if (act) t.PaneTitle.SetResourceReference(TextBlock.ForegroundProperty, "Accent1Brush");
                    else t.PaneTitle.SetResourceReference(TextBlock.ForegroundProperty, "SubFgBrush");
                    t.PaneTitle.FontWeight = act ? FontWeights.SemiBold : FontWeights.Normal;
                }
            }
            RestyleAllTabs();
        }

        private void UpdateParallelUi()
        {
            ParallelBtn.IsChecked = _parallel;
            LayoutBtn.Visibility = _parallel ? Visibility.Visible : Visibility.Collapsed;
            SyncBtn.Visibility = _parallel ? Visibility.Visible : Visibility.Collapsed;
            TabStripBar.Visibility = _tabs.Count > 0 && !_fullscreen ? Visibility.Visible : Visibility.Collapsed;
            UpdateTabSpacer();
        }

        private async void Parallel_Click(object sender, RoutedEventArgs e)
        {
            if (_parallel) { StopParallel(); return; }
            if (_tabs.Count < 2)
            {
                ParallelBtn.IsChecked = false;
                ShowBanner("Параллельный просмотр: выберите документы, которые нужно показать рядом (можно несколько сразу).", false);
                var files = AskFiles();
                if (files.Count == 0) return;
                await OpenFilesAsync(files);
                if (_tabs.Count < 2) { ShowBanner("Для параллельного просмотра нужно открыть хотя бы два документа.", false); return; }
            }
            StartParallel();
        }

        private void StartParallel()
        {
            if (_tabs.Count < 2) { UpdateParallelUi(); return; }
            _split.Clear();
            if (_active != null) _split.Add(_active);
            // соседние вкладки — справа от активной, затем слева
            int ai = _active != null ? _tabs.IndexOf(_active) : 0;
            foreach (var t in _tabs.Skip(ai + 1).Concat(_tabs.Take(Math.Max(0, ai))))
            {
                if (_split.Count >= 2) break;
                if (!_split.Contains(t)) _split.Add(t);
            }
            _parallel = true;
            LayoutPanes();
            UpdateParallelUi();
            RestyleAllTabs();
            StatusText.Text = "Параллельный просмотр. Ctrl+щелчок по вкладке — добавить документ, щелчок по панели — сделать её активной, F6 — следующая панель.";
        }

        private void ShowAllSideBySide()
        {
            if (_tabs.Count < 2) return;
            _split.Clear();
            if (_active != null) _split.Add(_active);
            foreach (var t in _tabs) { if (_split.Count >= MaxPanes) break; if (!_split.Contains(t)) _split.Add(t); }
            _parallel = true;
            if (_split.Count > 3 && (S.ParallelLayout ?? "columns") == "columns") S.ParallelLayout = "grid";
            LayoutPanes();
            UpdateParallelUi();
            if (_tabs.Count > MaxPanes) ShowBanner($"Одновременно можно показать до {MaxPanes} документов.", false);
        }

        private void StopParallel()
        {
            _parallel = false;
            _split.Clear();
            LayoutPanes();
            UpdateParallelUi();
            RestyleAllTabs();
        }

        private void AddToSplit(DocTab tab)
        {
            if (tab == null || _tabs.Count < 2) return;
            if (!_parallel)
            {
                _split.Clear();
                if (_active != null && _active != tab) _split.Add(_active);
                _split.Add(tab);
                if (_split.Count < 2)
                {
                    var other = _tabs.FirstOrDefault(t => t != tab);
                    if (other != null) _split.Insert(0, other);
                }
                _parallel = true;
            }
            else if (!_split.Contains(tab))
            {
                if (_split.Count >= MaxPanes) { ShowBanner($"Одновременно можно показать до {MaxPanes} документов.", false); return; }
                _split.Add(tab);
            }
            _searchGen++;
            _active = tab;
            LayoutPanes();
            ApplyActiveToUi();
        }

        private void RemoveFromSplit(DocTab tab)
        {
            if (!_parallel || !_split.Contains(tab)) return;
            _split.Remove(tab);
            if (_split.Count < 2)
            {
                var keep = _split.FirstOrDefault() ?? _active;
                _parallel = false;
                _split.Clear();
                _active = null;
                if (keep != null && _tabs.Contains(keep)) ActivateTab(keep);
                else if (_tabs.Count > 0) ActivateTab(_tabs[0]);
                UpdateParallelUi();
                return;
            }
            if (_active == tab)
            {
                _searchGen++;
                _active = _split[0];
                LayoutPanes();
                ApplyActiveToUi();
            }
            else
            {
                LayoutPanes();
                RestyleAllTabs();
            }
        }

        private void ToggleInSplit(DocTab tab)
        {
            if (_parallel && _split.Contains(tab))
            {
                if (_split.Count > 2 || tab != _active) RemoveFromSplit(tab);
                else ActivateTab(tab);
            }
            else AddToSplit(tab);
        }

        private void Layout_Click(object sender, RoutedEventArgs e)
        {
            var m = new ContextMenu();
            void Add(string code, string icon, string text)
            {
                var mi = new MenuItem
                {
                    Header = text,
                    IsCheckable = true,
                    IsChecked = (S.ParallelLayout ?? "columns") == code,
                    Icon = new TextBlock { Text = icon, FontFamily = (FontFamily)FindResource("IconFont") }
                };
                mi.Click += (s, a) => { S.ParallelLayout = code; LayoutPanes(); };
                m.Items.Add(mi);
            }
            Add("columns", "", "Рядом (слева направо)");
            Add("rows", "", "Друг под другом");
            Add("grid", "", "Сеткой");
            m.Items.Add(new Separator());
            var all = new MenuItem { Header = "Показать все открытые документы", IsEnabled = _tabs.Count > _split.Count };
            all.Click += (s, a) => ShowAllSideBySide();
            m.Items.Add(all);
            var stop = new MenuItem { Header = "Выйти из параллельного просмотра" };
            stop.Click += (s, a) => StopParallel();
            m.Items.Add(stop);
            m.PlacementTarget = sender as UIElement; m.Placement = PlacementMode.Bottom; m.IsOpen = true;
        }

        private void Sync_Click(object sender, RoutedEventArgs e)
        {
            S.SyncScroll = SyncBtn.IsChecked == true;
            StatusText.Text = S.SyncScroll ? "Синхронная прокрутка включена: остальные панели следуют за активной." : "Синхронная прокрутка выключена.";
            if (S.SyncScroll && _active != null) OnViewerScrolled(_active);
        }

        private void OnViewerScrolled(DocTab tab)
        {
            if (!_parallel || !S.SyncScroll || _syncing || tab != _active) return;
            var (page, frac) = tab.Viewer.GetPosition();
            _syncing = true;
            try
            {
                foreach (var t in VisibleTabs())
                    if (t != tab && t.Doc != null) t.Viewer.SetPosition(page, frac);
            }
            finally { _syncing = false; }
        }

        private void FocusNextPane()
        {
            var vis = VisibleTabs();
            if (vis.Count < 2) return;
            int i = vis.IndexOf(_active);
            ActivateTab(vis[(i + 1) % vis.Count]);
        }

        // ======================= Состояние окна =======================

        /// <summary>Спрашивает о несохранённых пометках во вкладке. false — отменить действие.</summary>
        private bool ConfirmDiscard(DocTab tab)
        {
            if (tab?.Doc == null || !tab.Viewer.Modified) return true;
            ActivateTab(tab);
            var r = MessageBox.Show(this, $"В документе «{tab.FileName}» есть несохранённые пометки или изменения страниц.\n\nСохранить их в новый PDF?",
                "DocuNova", MessageBoxButton.YesNoCancel, MessageBoxImage.Question);
            if (r == MessageBoxResult.Cancel) return false;
            if (r == MessageBoxResult.Yes) return SavePdf(tab, tab.Viewer.Pages);
            return true;
        }

        private void ShowLoading(string text) { LoadingText.Text = text; Loading.Visibility = Visibility.Visible; }
        private void HideLoading() => Loading.Visibility = Visibility.Collapsed;

        private void ShowError(string title, Exception ex)
        {
            string msg = ex is UnsupportedFormatException ? ex.Message : ex.Message + "\n\nФайл может быть повреждён или иметь неподдерживаемый формат.";
            MessageBox.Show(this, title + ".\n\n" + msg, "DocuNova", MessageBoxButton.OK, MessageBoxImage.Warning);
        }

        private void ShowBanner(string text, bool danger)
        {
            BannerText.Text = text;
            BannerIcon.Text = danger ? "" : "";
            Banner.Visibility = Visibility.Visible;
            _bannerTimer.Stop(); _bannerTimer.Start();
        }

        private void BannerClose_Click(object sender, RoutedEventArgs e) => Banner.Visibility = Visibility.Collapsed;

        private void RefreshRecent()
        {
            RecentList.Items.Clear();
            // сетевые пути не проверяем: недоступный сервер «подвесил» бы окно на несколько секунд
            var items = S.RememberRecent ? S.Recent.Where(p => p.StartsWith(@"\\") || File.Exists(p)).Take(8).ToList() : new List<string>();
            RecentTitle.Visibility = items.Count > 0 ? Visibility.Visible : Visibility.Collapsed;
            foreach (var p in items)
            {
                var b = new Button { HorizontalContentAlignment = HorizontalAlignment.Left, Margin = new Thickness(0, 2, 0, 2), ToolTip = p };
                b.SetResourceReference(StyleProperty, "GhostBtn");
                var sp = new StackPanel();
                sp.Children.Add(new TextBlock { Text = Path.GetFileName(p), FontWeight = FontWeights.SemiBold, TextTrimming = TextTrimming.CharacterEllipsis });
                var dir = new TextBlock { Text = Path.GetDirectoryName(p), FontSize = 11.5, TextTrimming = TextTrimming.CharacterEllipsis };
                dir.SetResourceReference(TextBlock.ForegroundProperty, "SubFgBrush");
                sp.Children.Add(dir);
                b.Content = sp;
                var path = p;
                b.Click += (s, e) => OpenFile(path);
                RecentList.Items.Add(b);
            }
        }

        private void UpdateDocButtons()
        {
            bool has = _doc != null;
            SaveBtn.IsEnabled = ExportBtn.IsEnabled = PrintBtn.IsEnabled = has;
            UndoBtn.IsEnabled = has && _viewer.CanUndo;
            RedoBtn.IsEnabled = has && _viewer.CanRedo;
            ReadSettingsBtn.IsEnabled = true;
            UpdateTabHeader(_active);
        }

        private void UpdateSecurityBadge()
        {
            if (_doc == null) { SecurityBtn.Visibility = Visibility.Collapsed; return; }
            int danger = _doc.Security.Count(f => f.Severity == Severity.Danger);
            int warn = _doc.Security.Count(f => f.Severity == Severity.Warning);
            SecurityBtn.Visibility = Visibility.Visible;
            if (_doc.Security.Count == 0)
            {
                // проверка большого файла ещё идёт в фоне
                SecurityIcon.Text = ""; SecurityText.Text = "Проверка безопасности…";
                SecurityIcon.Foreground = new SolidColorBrush(Color.FromRgb(140, 170, 255));
            }
            else if (danger > 0)
            {
                SecurityIcon.Text = ""; SecurityText.Text = $"Заблокировано угроз: {danger}";
                SecurityIcon.Foreground = new SolidColorBrush(Color.FromRgb(255, 70, 90));
            }
            else if (warn > 0)
            {
                SecurityIcon.Text = ""; SecurityText.Text = $"Защищено · предупреждений: {warn}";
                SecurityIcon.Foreground = new SolidColorBrush(Color.FromRgb(255, 190, 40));
            }
            else
            {
                SecurityIcon.Text = ""; SecurityText.Text = "Защищено · угроз нет";
                SecurityIcon.Foreground = new SolidColorBrush(Color.FromRgb(60, 230, 140));
            }
        }

        private void SecurityBtn_Click(object sender, RoutedEventArgs e) => ShowProperties(3);

        // ======================= Боковая панель =======================

        private void Sidebar_Click(object sender, RoutedEventArgs e) => SetSidebar(Sidebar.Visibility != Visibility.Visible);

        private void SetSidebar(bool show)
        {
            if (!show && Sidebar.Visibility == Visibility.Visible && SidebarCol.ActualWidth > 100) _sidebarWidth = SidebarCol.ActualWidth;
            Sidebar.Visibility = show ? Visibility.Visible : Visibility.Collapsed;
            SideSplitter.Visibility = Sidebar.Visibility;
            SidebarCol.Width = show ? new GridLength(Math.Max(200, _sidebarWidth)) : new GridLength(0);
            S.ShowSidebar = show;
            Dispatcher.BeginInvoke(new Action(UpdateTabSpacer), DispatcherPriority.Loaded);
        }

        private void SideTab_Checked(object sender, RoutedEventArgs e)
        {
            if (ThumbList == null || TocList == null) return;
            ThumbList.Visibility = TabThumbs.IsChecked == true ? Visibility.Visible : Visibility.Collapsed;
            bool toc = TabToc.IsChecked == true;
            TocList.Visibility = toc && TocList.Items.Count > 0 ? Visibility.Visible : Visibility.Collapsed;
            TocEmpty.Visibility = toc && TocList.Items.Count == 0 ? Visibility.Visible : Visibility.Collapsed;
            BookmarkPanel.Visibility = TabBookmarks.IsChecked == true ? Visibility.Visible : Visibility.Collapsed;
            SearchPanel.Visibility = TabSearch.IsChecked == true ? Visibility.Visible : Visibility.Collapsed;
            AnnPanel.Visibility = TabAnns.IsChecked == true ? Visibility.Visible : Visibility.Collapsed;
            if (TabSearch.IsChecked == true && sender != null) Dispatcher.BeginInvoke(new Action(() => { SearchBox.Focus(); SearchBox.SelectAll(); }), DispatcherPriority.Input);
        }

        private void RebuildSidebar()
        {
            RebuildThumbs();
            RebuildToc();
            RebuildBookmarks();
            RebuildAnnList();
        }

        private void RebuildThumbs()
        {
            foreach (var t in _thumbs) { t.Visible = false; t.Thumb = null; }
            _thumbs.Clear();
            if (_doc == null) return;
            var v = _viewer;
            for (int i = 0; i < v.Pages.Count; i++)
            {
                var r = v.Pages[i];
                var s = _doc.GetPageSize(r.Doc);
                if (r.Rotation % 180 != 0) s = new Size(s.Height, s.Width);
                double k = Math.Min(150 / s.Width, 190 / s.Height);
                _thumbs.Add(new ThumbItem { Owner = v, Ref = r, Index = i, Label = (i + 1).ToString(), BoxWidth = Math.Max(20, s.Width * k), BoxHeight = Math.Max(20, s.Height * k) });
            }
        }

        private async void ThumbItem_Loaded(object sender, RoutedEventArgs e)
        {
            if (!(sender is ListBoxItem li) || !(li.DataContext is ThumbItem item)) return;
            item.Visible = true;
            if (item.Thumb != null || item.Loading) return;
            item.Loading = true;
            try
            {
                await Task.Delay(60);
                var owner = item.Owner;
                if (!item.Visible || owner == null || owner.Document == null) return;
                var bmp = await owner.RenderThumbAsync(item.Ref, 160);
                if (bmp != null && item.Ref.Rotation != 0)
                {
                    var tb = new TransformedBitmap(bmp, new RotateTransform(item.Ref.Rotation));
                    tb.Freeze();
                    bmp = tb;
                }
                if (item.Visible && owner.Document != null) item.Thumb = DocViewer.ApplyMode(bmp, owner.PageMode);
            }
            catch { }
            finally { item.Loading = false; }
        }

        private void ThumbItem_Unloaded(object sender, RoutedEventArgs e)
        {
            if (sender is ListBoxItem li && li.DataContext is ThumbItem item)
            {
                item.Visible = false;
                item.Thumb = null; // освобождаем память
            }
        }

        private bool _syncingThumbs;
        private void ThumbList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (_syncingThumbs) return;
            if (ThumbList.SelectedItem is ThumbItem t && t.Owner == _viewer) _viewer.GoTo(t.Index);
        }

        private void RebuildToc()
        {
            var rows = new List<TocRow>();
            if (_doc != null)
            {
                // индекс страницы документа → позиция в просмотре (быстрый поиск вместо перебора)
                var map = new Dictionary<int, int>();
                for (int i = 0; i < _viewer.Pages.Count; i++)
                    if (!map.ContainsKey(_viewer.Pages[i].Doc)) map[_viewer.Pages[i].Doc] = i;
                Flatten(_doc.Toc, rows, 0, map);
            }
            TocList.ItemsSource = rows;
            SideTab_Checked(null, null);
        }

        private void Flatten(List<TocItem> items, List<TocRow> rows, int depth, Dictionary<int, int> map)
        {
            foreach (var t in items)
            {
                if (rows.Count > 5000) return;
                int view = t.PageIndex >= 0 && map.TryGetValue(t.PageIndex, out var vi) ? vi : -1;
                rows.Add(new TocRow
                {
                    Title = t.Title,
                    View = view,
                    PageLabel = view >= 0 ? (view + 1).ToString() : "",
                    Indent = new Thickness(depth * 14, 0, 0, 0),
                    Weight = depth == 0 ? FontWeights.SemiBold : FontWeights.Normal
                });
                Flatten(t.Children, rows, depth + 1, map);
            }
        }

        private void TocList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (TocList.SelectedItem is TocRow r && r.View >= 0) _viewer.GoTo(r.View);
        }

        private void RebuildBookmarks()
        {
            BookmarkList.Items.Clear();
            if (_doc == null) return;
            for (int i = 0; i < _viewer.Pages.Count; i++)
                if (_viewer.Pages[i].Bookmarked)
                {
                    var text = "";
                    try { text = _doc.GetPageText(_viewer.Pages[i].Doc); } catch { }
                    text = FlowSinkPreview(text);
                    BookmarkList.Items.Add(new BookmarkRow { Page = _viewer.Pages[i], View = i, Text = $"★ Стр. {i + 1}" + (text.Length > 0 ? " — " + text : "") });
                }
        }

        private static string FlowSinkPreview(string t)
        {
            t = (t ?? "").Replace('\n', ' ').Trim();
            return t.Length > 50 ? t.Substring(0, 50) + "…" : t;
        }

        private void BookmarkList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (BookmarkList.SelectedItem is BookmarkRow r)
            {
                int i = _viewer.Pages.IndexOf(r.Page);
                if (i >= 0) _viewer.GoTo(i);
            }
        }

        private void Bookmark_Click(object sender, RoutedEventArgs e)
        {
            if (_doc == null || _viewer.Pages.Count == 0) return;
            var p = _viewer.Pages[_viewer.CurrentPage];
            p.Bookmarked = !p.Bookmarked;
            var ti = _thumbs.FirstOrDefault(t => t.Ref == p);
            ti?.Notify(nameof(ThumbItem.BookmarkVisibility));
            RebuildBookmarks();
            StatusText.Text = p.Bookmarked ? $"Страница {_viewer.CurrentPage + 1} добавлена в закладки." : "Закладка удалена.";
        }

        private void RebuildAnnList()
        {
            AnnList.Items.Clear();
            if (_doc == null) return;
            for (int i = 0; i < _viewer.Pages.Count; i++)
                foreach (var a in _viewer.Pages[i].Anns)
                    AnnList.Items.Add(new AnnRow { Page = _viewer.Pages[i], Ann = a, View = i });
        }

        private void AnnList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (AnnList.SelectedItem is AnnRow r)
            {
                int i = _viewer.Pages.IndexOf(r.Page);
                if (i < 0) return;
                var b = r.Ann.Bounds;
                if (!b.IsEmpty) _viewer.ShowRect(i, b); else _viewer.GoTo(i);
            }
        }

        private void AnnDelete_Click(object sender, RoutedEventArgs e)
        {
            if (AnnList.SelectedItem is AnnRow r) _viewer.RemoveAnnotation(r.Page, r.Ann);
        }

        private void AnnClearPage_Click(object sender, RoutedEventArgs e)
        {
            if (_doc == null || _viewer.Pages.Count == 0) return;
            _viewer.ClearAnnotations(_viewer.Pages[_viewer.CurrentPage]);
        }

        private void OnAnnotationsChanged()
        {
            RebuildAnnList();
            UpdateDocButtons();
            if (_thumbs.Count != _viewer.Pages.Count) RebuildThumbs();
        }

        // ======================= Навигация =======================

        private void OnCurrentPageChanged(int i)
        {
            if (_doc == null) return;
            PageBox.Text = (i + 1).ToString();
            PageCountText.Text = "/ " + _viewer.Pages.Count;
            if (i >= 0 && i < _thumbs.Count)
            {
                _syncingThumbs = true;
                try
                {
                    ThumbList.SelectedIndex = i;
                    if (ThumbList.IsVisible) ThumbList.ScrollIntoView(_thumbs[i]);
                }
                finally { _syncingThumbs = false; }
            }
        }

        private void PageBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key != Key.Enter) return;
            if (_doc != null && int.TryParse(PageBox.Text.Trim(), out var n)) _viewer.GoTo(Math.Max(1, Math.Min(n, _viewer.Pages.Count)) - 1);
            _viewer.Scroll.Focus();
            e.Handled = true;
        }

        private void PrevPage_Click(object sender, RoutedEventArgs e) => _viewer.Prev();
        private void NextPage_Click(object sender, RoutedEventArgs e) => _viewer.Next();

        // ======================= Масштаб и вид =======================

        private void UpdateZoomText() => ZoomBtn.Content = Math.Round(_viewer.Zoom * 100) + " %";

        private void ZoomIn_Click(object sender, RoutedEventArgs e) => _viewer.SetZoom(NextZoom(_viewer.Zoom, true));
        private void ZoomOut_Click(object sender, RoutedEventArgs e) => _viewer.SetZoom(NextZoom(_viewer.Zoom, false));

        private static readonly double[] Steps = { 0.1, 0.25, 0.33, 0.5, 0.67, 0.75, 0.9, 1, 1.1, 1.25, 1.5, 1.75, 2, 2.5, 3, 4, 5, 6, 8 };
        private static double NextZoom(double z, bool up)
        {
            if (up) { foreach (var s in Steps) if (s > z + 0.01) return s; return 8; }
            for (int i = Steps.Length - 1; i >= 0; i--) if (Steps[i] < z - 0.01) return Steps[i];
            return 0.1;
        }

        private void ZoomBtn_Click(object sender, RoutedEventArgs e)
        {
            var m = new ContextMenu();
            foreach (var z in new[] { 0.5, 0.75, 1.0, 1.25, 1.5, 2.0, 3.0, 4.0 })
            {
                var zz = z;
                var mi = new MenuItem { Header = Math.Round(z * 100) + " %" };
                mi.Click += (s, a) => _viewer.SetZoom(zz);
                m.Items.Add(mi);
            }
            var fw = new MenuItem { Header = "По ширине" }; fw.Click += (s, a) => FitWidth_Click(null, null); m.Items.Add(fw);
            var fp = new MenuItem { Header = "Страница целиком" }; fp.Click += (s, a) => FitPage_Click(null, null); m.Items.Add(fp);
            m.PlacementTarget = ZoomBtn; m.Placement = PlacementMode.Bottom; m.IsOpen = true;
        }

        private void FitWidth_Click(object sender, RoutedEventArgs e) { _viewer.FitMode = "width"; S.FitMode = "width"; _viewer.ApplyFit(); }
        private void FitPage_Click(object sender, RoutedEventArgs e) { _viewer.FitMode = "page"; S.FitMode = "page"; _viewer.ApplyFit(); }

        private void RotateLeft_Click(object sender, RoutedEventArgs e) => Rotate(-90);
        private void RotateRight_Click(object sender, RoutedEventArgs e) => Rotate(90);
        private void Rotate(int d)
        {
            if (_doc == null) return;
            bool all = (Keyboard.Modifiers & ModifierKeys.Shift) != 0;
            _viewer.Rotate(d, all);
            RebuildThumbs();
            UpdateDocButtons();
            StatusText.Text = all ? "Все страницы повёрнуты." : $"Страница {_viewer.CurrentPage + 1} повёрнута. Shift — повернуть все.";
        }

        /// <summary>Кнопка «Разворот»: меню выбора — одна страница, разворот, разворот с отдельной обложкой.</summary>
        private void TwoPage_Click(object sender, RoutedEventArgs e)
        {
            // ToggleButton сам переключает состояние — возвращаем его к фактическому режиму, выбор делается в меню
            TwoPageBtn.IsChecked = _viewer.TwoPage;
            var m = new ContextMenu();
            void Add(string text, string hint, bool two, bool cover)
            {
                bool current = _viewer.TwoPage == two && (!two || _viewer.CoverPage == cover);
                var mi = new MenuItem { Header = text, IsCheckable = true, IsChecked = current, ToolTip = hint };
                mi.Click += (s, x) => SetSpread(two, cover);
                m.Items.Add(mi);
            }
            Add("Одна страница", "Страницы идут одна под другой.", false, S.CoverPage);
            Add("Разворот с обложкой", "Первая страница (обложка) отдельно, далее пары 2–3, 4–5… — как в бумажной книге.", true, true);
            Add("Разворот", "Пары страниц 1–2, 3–4, 5–6…", true, false);
            m.Items.Add(new Separator());
            var hint = new MenuItem { Header = "Ctrl+3 — переключить по кругу", IsEnabled = false };
            m.Items.Add(hint);
            m.PlacementTarget = TwoPageBtn; m.Placement = PlacementMode.Bottom; m.IsOpen = true;
        }

        /// <summary>Ctrl+3: одна страница → разворот с обложкой → разворот → одна страница.</summary>
        private void CycleSpread()
        {
            if (!_viewer.TwoPage) SetSpread(true, true);
            else if (_viewer.CoverPage) SetSpread(true, false);
            else SetSpread(false, S.CoverPage);
        }

        private void SetSpread(bool two, bool cover)
        {
            S.TwoPage = two;
            S.CoverPage = cover;
            foreach (var v in AllViewers()) v.CoverPage = cover;
            _viewer.TwoPage = two;
            TwoPageBtn.IsChecked = two;
            if (_viewer.FitMode != "none") _viewer.ApplyFit();
            StatusText.Text = !two ? "Режим: одна страница." : cover ? "Режим: разворот, первая страница (обложка) отдельно." : "Режим: разворот по две страницы.";
        }

        /// <summary>Кнопка «Режим страницы»: меню всех цветовых режимов (Ctrl+N переключает по кругу).</summary>
        private void PageMode_Click(object sender, RoutedEventArgs e)
        {
            if (sender == null) { SetPageMode(PageTint.Next(_viewer.PageMode ?? "normal")); return; }
            var m = new ContextMenu();
            FillPageModeItems(m.Items);
            m.Items.Add(new Separator());
            m.Items.Add(new MenuItem { Header = "Ctrl+N — следующий режим", IsEnabled = false });
            m.PlacementTarget = sender as UIElement ?? PageModeBtn; m.Placement = PlacementMode.Bottom; m.IsOpen = true;
        }

        private void FillPageModeItems(ItemCollection items)
        {
            string cur = _viewer.PageMode ?? S.PageMode ?? "normal";
            foreach (var (code, name, hint) in PageTint.Modes)
            {
                var c = code;
                var mi = new MenuItem { Header = name, IsCheckable = true, IsChecked = cur == code, ToolTip = hint };
                mi.Click += (s, x) => SetPageMode(c);
                items.Add(mi);
            }
        }

        private void SetPageMode(string mode)
        {
            S.PageMode = mode;
            foreach (var v in AllViewers()) v.PageMode = mode;
            foreach (var t in _thumbs) t.Thumb = null;
            RebuildThumbs();
            StatusText.Text = "Цвет страниц: " + PageTint.NameOf(mode) + ".";
        }

        // ======================= Меню «Вид и чтение» =======================

        private void ViewMenu_Click(object sender, RoutedEventArgs e)
        {
            var m = new ContextMenu();
            var iconFont = (FontFamily)FindResource("IconFont");
            MenuItem Item(ItemCollection target, string icon, string text, string keys, Action a, bool enabled = true, bool? check = null, string tip = null)
            {
                var mi = new MenuItem { Header = text, InputGestureText = keys ?? "", IsEnabled = enabled, ToolTip = tip };
                if (check.HasValue) { mi.IsCheckable = true; mi.IsChecked = check.Value; }
                else if (!string.IsNullOrEmpty(icon)) mi.Icon = new TextBlock { Text = icon, FontFamily = iconFont };
                if (a != null) mi.Click += (s, x) => a();
                target.Add(mi);
                return mi;
            }
            bool has = _doc != null;

            var colors = new MenuItem { Header = "Цвет страниц", Icon = new TextBlock { Text = "", FontFamily = iconFont } };
            FillPageModeItems(colors.Items);
            m.Items.Add(colors);
            m.Items.Add(new Separator());

            Item(m.Items, "", "Автопрокрутка", "Ctrl+Shift+A", ToggleAutoScroll, has, _viewer.AutoScrolling,
                "Текст плавно движется вверх с постоянной скоростью — читайте, не прикасаясь к мыши.");
            var speed = new MenuItem { Header = $"Скорость автопрокрутки: {Math.Round(S.AutoScrollSpeed)} пикс./с", Icon = new TextBlock { Text = "", FontFamily = iconFont } };
            Item(speed.Items, "", "Быстрее", "Ctrl+Shift+↑", () => ChangeAutoScrollSpeed(1.25));
            Item(speed.Items, "", "Медленнее", "Ctrl+Shift+↓", () => ChangeAutoScrollSpeed(1 / 1.25));
            speed.Items.Add(new Separator());
            foreach (var v in new[] { 20, 40, 60, 90, 140, 220 })
            {
                var vv = v;
                Item(speed.Items, null, vv + " пикс./с", null, () => SetAutoScrollSpeed(vv), true, Math.Abs(S.AutoScrollSpeed - vv) < 0.5);
            }
            m.Items.Add(speed);
            Item(m.Items, "", "Линейка чтения", "Ctrl+U", ToggleRuler, true, _ruler,
                "Светлая полоса следует за указателем мыши, остальное затеняется — глазу легче держать строку.");
            Item(m.Items, "", "Показывать пометки", "Ctrl+Shift+H", ToggleAnnotationsVisible, true, S.ShowAnnotations,
                "Временно скрыть все пометки, чтобы увидеть исходную страницу. На сохранение и печать не влияет.");
            m.Items.Add(new Separator());

            Item(m.Items, "", "Назад", "Alt+←", () => GoBack(), has && _viewer.CanGoBack, null, "Вернуться к месту до последнего перехода по оглавлению, закладке, поиску или номеру страницы.");
            Item(m.Items, "", "Вперёд", "Alt+→", () => GoForward(), has && _viewer.CanGoForward);
            Item(m.Items, "", "Перейти к странице…", "Ctrl+G", FocusPageBox, has);
            Item(m.Items, "", "Первая страница", "Ctrl+Home", () => _viewer.GoTo(0), has);
            Item(m.Items, "", "Последняя страница", "Ctrl+End", () => _viewer.GoTo(_viewer.Pages.Count - 1), has);
            m.Items.Add(new Separator());

            Item(m.Items, "", "Обычный масштаб 100 %", "Ctrl+0", () => _viewer.SetZoom(1), has);
            Item(m.Items, "", "По ширине", "Ctrl+2", () => FitWidth_Click(null, null), has);
            Item(m.Items, "", "Страница целиком", "Ctrl+1", () => FitPage_Click(null, null), has);
            Item(m.Items, "", "Разворот: переключить режим", "Ctrl+3", CycleSpread, has);
            m.Items.Add(new Separator());

            Item(m.Items, "", "Все вкладки…", "Ctrl+Shift+Пробел", ShowTabList, _tabs.Count > 0);
            Item(m.Items, "", "Восстановить закрытую вкладку", "Ctrl+Shift+T", ReopenClosedTab, _closedTabs.Count > 0);
            Item(m.Items, "", "Восстанавливать вкладки при запуске", null, () => { S.RestoreSession = !S.RestoreSession; S.Save(); StatusText.Text = S.RestoreSession ? "Вкладки будут открываться снова при следующем запуске." : "Восстановление вкладок при запуске выключено."; }, true, S.RestoreSession);
            m.Items.Add(new Separator());
            Item(m.Items, "", "Настройки просмотра…", null, () => ShowSettings(2));

            m.PlacementTarget = sender as UIElement ?? ViewMenuBtn; m.Placement = PlacementMode.Bottom; m.IsOpen = true;
        }

        private void FocusPageBox()
        {
            if (_doc == null || StatusBar.Visibility != Visibility.Visible) { StatusText.Text = "Введите номер страницы в поле внизу окна."; return; }
            PageBox.Focus();
            PageBox.SelectAll();
        }

        // ---------- история переходов ----------

        private void Back_Click(object sender, RoutedEventArgs e) => GoBack();
        private void Forward_Click(object sender, RoutedEventArgs e) => GoForward();

        private void GoBack()
        {
            if (_doc == null) return;
            if (!_viewer.GoBack()) StatusText.Text = "Назад некуда: переходов по оглавлению, закладкам и поиску ещё не было.";
        }

        private void GoForward()
        {
            if (_doc == null) return;
            _viewer.GoForward();
        }

        private void UpdateNavButtons()
        {
            if (BackBtn == null) return;
            BackBtn.IsEnabled = _doc != null && _viewer.CanGoBack;
            ForwardBtn.IsEnabled = _doc != null && _viewer.CanGoForward;
        }

        // ---------- автопрокрутка ----------

        private void ToggleAutoScroll()
        {
            if (_doc == null) return;
            if (!_viewer.AutoScrolling && _viewer.Scroll.ScrollableHeight - _viewer.Scroll.VerticalOffset < 1)
            {
                StatusText.Text = "Автопрокрутка: вы уже в конце документа.";
                return;
            }
            _viewer.AutoScrollSpeed = S.AutoScrollSpeed;
            _viewer.ToggleAutoScroll();
            if (_viewer.AutoScrolling) StatusText.Text = "Автопрокрутка включена. Ctrl+Shift+↑ / ↓ — скорость, удержание кнопки мыши — пауза, Ctrl+Shift+A — стоп.";
            UpdateAutoScrollUi();
        }

        private void ChangeAutoScrollSpeed(double factor) => SetAutoScrollSpeed(S.AutoScrollSpeed * factor);

        private void SetAutoScrollSpeed(double speed)
        {
            S.AutoScrollSpeed = Math.Round(Math.Max(10, Math.Min(800, speed)));
            foreach (var v in AllViewers()) v.AutoScrollSpeed = S.AutoScrollSpeed;
            StatusText.Text = $"Скорость автопрокрутки: {S.AutoScrollSpeed} пикс./с.";
            UpdateAutoScrollUi();
        }

        private void UpdateAutoScrollUi()
        {
            if (AutoScrollBadge == null) return;
            bool on = _doc != null && _viewer.AutoScrolling;
            AutoScrollBadge.Visibility = on ? Visibility.Visible : Visibility.Collapsed;
            AutoScrollText.Text = $"Автопрокрутка · {Math.Round(S.AutoScrollSpeed)} пикс./с";
        }

        private void AutoScrollBadge_Click(object sender, MouseButtonEventArgs e)
        {
            _viewer.StopAutoScroll();
            UpdateAutoScrollUi();
        }

        // ---------- линейка чтения и пометки ----------

        private void ToggleRuler()
        {
            _ruler = !_ruler;
            foreach (var v in AllViewers()) v.ReadingRuler = _ruler;
            StatusText.Text = _ruler ? "Линейка чтения включена: полоса следует за указателем мыши (Ctrl+U — выключить)." : "Линейка чтения выключена.";
        }

        private void ToggleAnnotationsVisible()
        {
            S.ShowAnnotations = !S.ShowAnnotations;
            OverlayLayer.ShowAnnotations = S.ShowAnnotations;
            foreach (var v in AllViewers()) v.RefreshOverlays();
            StatusText.Text = S.ShowAnnotations ? "Пометки показаны." : "Пометки скрыты (Ctrl+Shift+H — показать). При сохранении и печати они сохраняются.";
        }

        // ---------- горизонтальное колесо (наклон колеса, тачпад) ----------

        protected override void OnSourceInitialized(EventArgs e)
        {
            base.OnSourceInitialized(e);
            try { (PresentationSource.FromVisual(this) as HwndSource)?.AddHook(WndHook); } catch { }
        }

        private IntPtr WndHook(IntPtr hwnd, int msg, IntPtr wParam, IntPtr lParam, ref bool handled)
        {
            const int WM_MOUSEHWHEEL = 0x020E;
            if (msg == WM_MOUSEHWHEEL)
            {
                int delta = unchecked((short)((long)wParam >> 16));
                if (TabStripBar.IsVisible && TabStripBar.IsMouseOver) { ScrollTabsBy(delta * 0.75); handled = true; }
                else if (_doc != null && _viewer.IsMouseOver)
                {
                    var sc = _viewer.Scroll;
                    sc.ScrollToHorizontalOffset(Math.Max(0, Math.Min(sc.ScrollableWidth, sc.HorizontalOffset + delta * 0.75)));
                    handled = true;
                }
            }
            return IntPtr.Zero;
        }

        private void FullScreen_Click(object sender, RoutedEventArgs e) => SetFullScreen(!_fullscreen);

        private void SetFullScreen(bool on)
        {
            if (on == _fullscreen) return;
            _fullscreen = on;
            var vis = on ? Visibility.Collapsed : Visibility.Visible;
            TitleBar.Visibility = vis; ToolbarBar.Visibility = vis; StatusBar.Visibility = vis;
            OptionsBar.Visibility = on ? Visibility.Collapsed : (IsAnnotationTool(_tool) ? Visibility.Visible : Visibility.Collapsed);
            Root.RowDefinitions[0].Height = on ? new GridLength(0) : new GridLength(40);
            Root.RowDefinitions[5].Height = on ? new GridLength(0) : new GridLength(32);
            if (on)
            {
                _stateBeforeFull = WindowState;
                if (Sidebar.Visibility == Visibility.Visible && SidebarCol.ActualWidth > 100) _sidebarWidth = SidebarCol.ActualWidth;
                Sidebar.Visibility = Visibility.Collapsed; SideSplitter.Visibility = Visibility.Collapsed; SidebarCol.Width = new GridLength(0);
                WindowState = WindowState.Normal; WindowState = WindowState.Maximized;
                ShowBanner("Полноэкранный режим. Выход — F11 или Esc.", false);
            }
            else
            {
                SetSidebar(S.ShowSidebar);
                WindowState = _stateBeforeFull;
            }
            UpdateParallelUi();
            UpdateMaxState();
        }

        // ======================= Инструменты =======================

        private static bool IsAnnotationTool(Tool t) => t != Tool.Hand && t != Tool.Select && t != Tool.Eraser;

        private void Tool_Checked(object sender, RoutedEventArgs e)
        {
            if (!(sender is FrameworkElement fe) || !(fe.Tag is string tag) || !Enum.TryParse<Tool>(tag, out var tool)) return;
            if (_idle == null || OptionsBar == null) return;
            _tool = tool;
            foreach (var v in AllViewers()) v.Tool = tool;
            _viewer.ClearSelection();
            var info = ToolCatalog.Get(tag);
            OptTitle.Text = info?.Title ?? "";
            OptHint.Text = info?.Description ?? "";
            bool ann = tool != Tool.Hand && tool != Tool.Select;
            OptionsBar.Visibility = ann && !_fullscreen ? Visibility.Visible : Visibility.Collapsed;
            bool colored = tool != Tool.Redact && tool != Tool.WhiteOut && tool != Tool.Eraser;
            Swatches.Visibility = colored ? Visibility.Visible : Visibility.Collapsed;
            ThicknessPanel.Visibility = tool == Tool.Pen || tool == Tool.Marker || tool == Tool.Rect || tool == Tool.Ellipse || tool == Tool.Arrow || tool == Tool.Line || tool == Tool.Underline || tool == Tool.Strike ? Visibility.Visible : Visibility.Collapsed;
            OpacityPanel.Visibility = colored && tool != Tool.Text && tool != Tool.Note ? Visibility.Visible : Visibility.Collapsed;
            FontPanel.Visibility = tool == Tool.Text || tool == Tool.Stamp ? Visibility.Visible : Visibility.Collapsed;
            StampPanel.Visibility = tool == Tool.Stamp ? Visibility.Visible : Visibility.Collapsed;
            if (tool == Tool.Highlight && _color == Colors.Black) SetColor(Color.FromRgb(255, 230, 0));
            if (_doc != null && IsAnnotationTool(tool) && _doc.IsReflowable)
                StatusText.Text = "Пометки в книгах привязаны к текущей разбивке страниц: изменение шрифта книги удалит их.";
        }

        private Annotation NewAnnotationStyle()
        {
            return new Annotation
            {
                Color = _color,
                Thickness = ThicknessSlider.Value,
                Opacity = OpacitySlider.Value,
                FontSize = FontSlider.Value,
                Text = _tool == Tool.Stamp ? StampText(StampBox.SelectedItem as string ?? "ОДОБРЕНО") : null
            };
        }

        private void BuildSwatches()
        {
            Swatches.Children.Clear();
            foreach (var hex in Palette)
            {
                var c = ThemeColor(hex, Colors.Black);
                var b = new Button { Width = 24, Height = 24, Margin = new Thickness(2, 0, 2, 0), Cursor = Cursors.Hand, ToolTip = hex.Substring(3), Focusable = false, Tag = c };
                var tpl = new ControlTemplate(typeof(Button));
                var el = new FrameworkElementFactory(typeof(Border));
                el.SetValue(Border.CornerRadiusProperty, new CornerRadius(12));
                el.SetValue(Border.BackgroundProperty, new SolidColorBrush(c));
                el.SetValue(Border.BorderThicknessProperty, new Thickness(2));
                el.SetBinding(Border.BorderBrushProperty, new System.Windows.Data.Binding("BorderBrush") { RelativeSource = new System.Windows.Data.RelativeSource(System.Windows.Data.RelativeSourceMode.TemplatedParent) });
                tpl.VisualTree = el;
                b.Template = tpl;
                b.Click += (s, e) => SetColor((Color)((Button)s).Tag);
                Swatches.Children.Add(b);
            }
            SetColor(_color);
        }

        private void SetColor(Color c)
        {
            _color = c;
            S.PenColor = c.ToString();
            foreach (Button b in Swatches.Children)
            {
                bool sel = b.Tag is Color bc && bc == c;
                b.BorderBrush = sel ? (Brush)FindResource("AccentBrush") : new SolidColorBrush(Color.FromArgb(80, 128, 128, 128));
            }
        }

        private void CustomColor_Click(object sender, RoutedEventArgs e)
        {
            using (var dlg = new System.Windows.Forms.ColorDialog { FullOpen = true, Color = System.Drawing.Color.FromArgb(_color.R, _color.G, _color.B) })
            {
                if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                    SetColor(Color.FromRgb(dlg.Color.R, dlg.Color.G, dlg.Color.B));
            }
        }

        private void Opt_Changed(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (!_ready) return;
            S.PenThickness = ThicknessSlider.Value;
            S.AnnOpacity = OpacitySlider.Value;
            S.TextSize = FontSlider.Value;
        }

        private void Stamp_Changed(object sender, SelectionChangedEventArgs e)
        {
            if (!_ready || _stampUpdating) return;
            var sel = StampBox.SelectedItem as string;
            if (sel == StampAddCustom || sel == StampClearCustom)
            {
                // диалог — после закрытия списка, выбор временно возвращается к прежнему штампу
                _stampUpdating = true;
                try { StampBox.SelectedItem = StampBox.Items.Contains(S.Stamp) ? S.Stamp : Stamps[0]; }
                finally { _stampUpdating = false; }
                Dispatcher.BeginInvoke(new Action(() => { if (sel == StampAddCustom) AddCustomStamp(); else ClearCustomStamps(); }), DispatcherPriority.Background);
                return;
            }
            if (sel != null) S.Stamp = sel;
        }

        /// <summary>Список штампов: стандартные, с датой, свои и команды для своих штампов.</summary>
        private void RebuildStampList()
        {
            _stampUpdating = true;
            try
            {
                StampBox.Items.Clear();
                foreach (var st in Stamps) StampBox.Items.Add(st);
                StampBox.Items.Add(StampToday);
                foreach (var st in new[] { "ПОЛУЧЕНО", "ОДОБРЕНО", "ОПЛАЧЕНО", "КОПИЯ ВЕРНА" }) StampBox.Items.Add(st + " + дата");
                foreach (var st in S.CustomStamps.Where(x => !string.IsNullOrWhiteSpace(x)).Distinct()) if (!StampBox.Items.Contains(st)) StampBox.Items.Add(st);
                StampBox.Items.Add(StampAddCustom);
                if (S.CustomStamps.Count > 0) StampBox.Items.Add(StampClearCustom);
                StampBox.SelectedItem = StampBox.Items.Contains(S.Stamp) && S.Stamp != StampAddCustom && S.Stamp != StampClearCustom ? S.Stamp : Stamps[0];
            }
            finally { _stampUpdating = false; }
            StampBox.ToolTip = "Текст штампа. «+ дата» и «Сегодняшняя дата» подставляют дату в момент установки штампа. «Свой штамп…» — любой текст.";
        }

        /// <summary>Текст штампа в момент установки (подстановка сегодняшней даты).</summary>
        private static string StampText(string item)
        {
            string date = DateTime.Now.ToString("dd.MM.yyyy");
            if (item == StampToday) return date;
            const string suffix = " + дата";
            if (item.EndsWith(suffix, StringComparison.Ordinal)) return item.Substring(0, item.Length - suffix.Length) + " " + date;
            return item;
        }

        private void AddCustomStamp()
        {
            var text = InputDialog.Ask(this, "Свой штамп", "Текст штампа (например, «СОГЛАСОВАНО», «ВХ. № 15», «Иванов И. И.»). До 40 символов.", "", false);
            text = (text ?? "").Replace('\r', ' ').Replace('\n', ' ').Trim();
            if (text.Length == 0) return;
            if (text.Length > 40) text = text.Substring(0, 40);
            if (text == StampAddCustom || text == StampClearCustom) return;
            if (!S.CustomStamps.Contains(text) && !Stamps.Contains(text)) S.CustomStamps.Add(text);
            if (S.CustomStamps.Count > 30) S.CustomStamps.RemoveAt(0);
            S.Stamp = text;
            S.Save();
            RebuildStampList();
            StatusText.Text = $"Штамп «{text}» добавлен. Щёлкните по странице, чтобы поставить его.";
        }

        private void ClearCustomStamps()
        {
            if (S.CustomStamps.Count == 0) return;
            if (MessageBox.Show(this, $"Удалить свои штампы ({S.CustomStamps.Count})? Уже поставленные штампы останутся на страницах.", "DocuNova",
                MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes) return;
            S.CustomStamps.Clear();
            if (!Stamps.Contains(S.Stamp)) S.Stamp = Stamps[0];
            S.Save();
            RebuildStampList();
        }

        // ======================= Работа с пометками =======================

        private static bool HasEditableText(Annotation a) => a != null && (a.Kind == Tool.Text || a.Kind == Tool.Note || a.Kind == Tool.Stamp);

        private ContextMenu BuildAnnMenu()
        {
            var m = new ContextMenu();
            var iconFont = (FontFamily)FindResource("IconFont");
            var r = AnnList.SelectedItem as AnnRow;
            bool sel = r != null && _doc != null;
            void Add(string icon, string text, Action a, bool enabled, string tip = null)
            {
                var mi = new MenuItem { Header = text, IsEnabled = enabled, ToolTip = tip, Icon = new TextBlock { Text = icon, FontFamily = iconFont } };
                mi.Click += (s, e) => a();
                m.Items.Add(mi);
            }
            Add("", "Перейти к пометке", () => AnnList_SelectionChanged(null, null), sel);
            Add("", "Изменить текст…", EditAnnText, sel && HasEditableText(r.Ann), "Также — двойной щелчок по пометке в списке или на странице.");
            Add("", "Копировать текст", CopyAnnText, sel, "Текст надписи или заметки, а для выделения, подчёркивания и зачёркивания — текст страницы под пометкой.");
            m.Items.Add(new Separator());
            Add("", "Перекрасить в текущий цвет", () => RestyleAnn(true, false), sel && r.Ann.Kind != Tool.Redact && r.Ann.Kind != Tool.WhiteOut,
                "Цвет выбирается на панели параметров любого инструмента пометок.");
            Add("", "Применить текущую толщину, прозрачность и размер текста", () => RestyleAnn(false, true), sel);
            m.Items.Add(new Separator());
            Add("", "Удалить", () => AnnDelete_Click(null, null), sel);
            Add("", "Удалить все пометки документа…", DeleteAllAnnotations, _doc != null && _viewer.HasAnnotations);
            m.Items.Add(new Separator());
            Add("", "Экспорт пометок и цитат в файл…", ExportAnnotations, _doc != null && _viewer.HasAnnotations);
            return m;
        }

        private void EditAnnText()
        {
            if (!(AnnList.SelectedItem is AnnRow r) || _doc == null) return;
            if (!HasEditableText(r.Ann)) { AnnList_SelectionChanged(null, null); return; }
            string title = r.Ann.Kind == Tool.Note ? "Текст заметки" : r.Ann.Kind == Tool.Stamp ? "Текст штампа" : "Текст надписи";
            var text = InputDialog.Ask(this, title, "Измените текст. Ctrl+Enter — готово.", r.Ann.Text ?? "", r.Ann.Kind != Tool.Stamp);
            if (text == null || string.IsNullOrWhiteSpace(text) || text == r.Ann.Text) return;
            r.Ann.Text = r.Ann.Kind == Tool.Stamp ? text.Replace('\r', ' ').Replace('\n', ' ').Trim() : text;
            AfterAnnEdited(r);
        }

        private void RestyleAnn(bool color, bool style)
        {
            if (!(AnnList.SelectedItem is AnnRow r) || _doc == null) return;
            if (color) r.Ann.Color = _color;
            if (style)
            {
                r.Ann.Thickness = ThicknessSlider.Value;
                r.Ann.Opacity = OpacitySlider.Value;
                if (HasEditableText(r.Ann)) r.Ann.FontSize = FontSlider.Value;
            }
            AfterAnnEdited(r);
        }

        private void AfterAnnEdited(AnnRow r)
        {
            _viewer.Modified = true;
            _viewer.Invalidate(r.Page);
            UpdateTabHeader(_active);
            int idx = AnnList.SelectedIndex;
            RebuildAnnList();
            if (idx >= 0 && idx < AnnList.Items.Count) AnnList.SelectedIndex = idx;
            UpdateDocButtons();
            StatusText.Text = "Пометка изменена.";
        }

        private void DeleteAllAnnotations()
        {
            if (_doc == null || !_viewer.HasAnnotations) return;
            int n = _viewer.Pages.Sum(p => p.Anns.Count);
            if (MessageBox.Show(this, $"Удалить все пометки документа ({n})? Действие можно отменить (Ctrl+Z) по одной пометке.", "DocuNova",
                MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes) return;
            foreach (var p in _viewer.Pages.ToList()) _viewer.ClearAnnotations(p);
        }

        /// <summary>Текст пометки: надпись, заметка, штамп — свой текст; выделение и подчёркивание — текст страницы под ними.</summary>
        private string AnnotationText(PageRef page, Annotation a)
        {
            if (!string.IsNullOrWhiteSpace(a.Text)) return a.Text.Trim();
            if (_doc == null || page == null) return "";
            try
            {
                var rects = a.Rects != null && a.Rects.Count > 0 ? a.Rects : (a.Bounds.IsEmpty ? new List<Rect>() : new List<Rect> { a.Bounds });
                var seen = new HashSet<(char, double, double)>();
                var chars = new List<PageChar>();
                foreach (var rc in rects)
                    foreach (var ch in _doc.CharsInRect(page.Doc, rc))
                        if (seen.Add((ch.C, Math.Round(ch.Box.X, 1), Math.Round(ch.Box.Y, 1)))) chars.Add(ch);
                return DocumentBase.CharsToText(chars).Trim();
            }
            catch { return ""; }
        }

        private void CopyAnnText()
        {
            if (!(AnnList.SelectedItem is AnnRow r)) return;
            var t = AnnotationText(r.Page, r.Ann);
            if (string.IsNullOrEmpty(t)) { StatusText.Text = "У этой пометки нет текста (на странице нет текстового слоя под ней)."; return; }
            try { Clipboard.SetText(t); StatusText.Text = "Текст пометки скопирован."; }
            catch { StatusText.Text = "Буфер обмена занят другой программой."; }
        }

        /// <summary>Сводка пометок: заметки, надписи и цитаты (текст под выделением) по страницам — в TXT или Markdown.</summary>
        private void ExportAnnotations()
        {
            if (_doc == null) return;
            if (!_viewer.HasAnnotations) { StatusText.Text = "В документе нет пометок."; return; }
            var dlg = new SaveFileDialog
            {
                Filter = "Markdown (*.md)|*.md|Текст UTF-8 (*.txt)|*.txt",
                FileName = Path.GetFileNameWithoutExtension(_path) + " — пометки.md",
                Title = "Экспорт пометок и цитат"
            };
            if (dlg.ShowDialog(this) != true) return;
            bool md = dlg.FilterIndex == 1 || dlg.FileName.EndsWith(".md", StringComparison.OrdinalIgnoreCase);
            try
            {
                Mouse.OverrideCursor = Cursors.Wait;
                var sb = new StringBuilder();
                string title = string.IsNullOrWhiteSpace(_doc.Title) ? Path.GetFileName(_path) : _doc.Title;
                sb.AppendLine(md ? "# Пометки: " + title : "Пометки: " + title);
                sb.AppendLine(md ? $"*Файл: {_path} · экспорт {DateTime.Now:dd.MM.yyyy HH:mm}*" : $"Файл: {_path} · экспорт {DateTime.Now:dd.MM.yyyy HH:mm}");
                sb.AppendLine();
                int total = 0;
                for (int i = 0; i < _viewer.Pages.Count; i++)
                {
                    var p = _viewer.Pages[i];
                    if (p.Anns.Count == 0) continue;
                    sb.AppendLine(md ? $"## Страница {i + 1}" : $"— Страница {i + 1} —");
                    foreach (var a in p.Anns.OrderBy(x => x.Bounds.IsEmpty ? 0 : x.Bounds.Top))
                    {
                        total++;
                        var text = AnnotationText(p, a).Replace("\r", "");
                        string kind = a.KindName;
                        if (md)
                        {
                            if (string.IsNullOrEmpty(text)) sb.AppendLine($"- *{kind}*");
                            else if (a.Kind == Tool.Highlight || a.Kind == Tool.Underline || a.Kind == Tool.Strike)
                                sb.AppendLine($"- **{kind}:**\n" + string.Join("\n", text.Split('\n').Select(l => "  > " + l)));
                            else sb.AppendLine($"- **{kind}:** " + text.Replace("\n", "  \n  "));
                        }
                        else sb.AppendLine(string.IsNullOrEmpty(text) ? $"  • {kind}" : $"  • {kind}: " + text.Replace("\n", "\n    "));
                    }
                    sb.AppendLine();
                }
                File.WriteAllText(dlg.FileName, sb.ToString(), new UTF8Encoding(true));
                StatusText.Text = $"Пометки сохранены ({total}): " + dlg.FileName;
            }
            catch (Exception ex) { MessageBox.Show(this, ex.Message, "DocuNova"); }
            finally { Mouse.OverrideCursor = null; }
        }

        private void Undo_Click(object sender, RoutedEventArgs e) { if (_doc == null) return; _viewer.Undo(); UpdateDocButtons(); }
        private void Redo_Click(object sender, RoutedEventArgs e) { if (_doc == null) return; _viewer.Redo(); UpdateDocButtons(); }

        private void SelectTool(Tool t)
        {
            foreach (var child in Toolbar.Children.OfType<RadioButton>())
                if (child.Tag as string == t.ToString()) { child.IsChecked = true; return; }
        }

        // ======================= Контекстное меню страницы =======================

        private ContextMenu BuildPageMenu()
        {
            var m = new ContextMenu();
            void Add(string icon, string text, Action a)
            {
                var mi = new MenuItem { Header = text, Icon = new TextBlock { Text = icon, FontFamily = (FontFamily)FindResource("IconFont") } };
                mi.Click += (s, e) => { if (_doc != null) a(); };
                m.Items.Add(mi);
            }
            Add("", "Копировать выделенный текст", CopySelection);
            Add("", "Выделить весь текст страницы", () => { SelectTool(Tool.Select); _viewer.SelectAllOnPage(); });
            Add("", "Копировать страницу как изображение", CopyPageImage);
            Add("", "Распознать текст на странице (OCR)", () => RunOcr(false));
            Add("", "Закладка на странице", () => Bookmark_Click(null, null));
            Add("", "Повернуть страницу вправо", () => Rotate(90));
            Add("", "Удалить все пометки страницы", () => AnnClearPage_Click(null, null));
            Add("", "Свойства документа", () => ShowProperties(0));
            m.Items.Add(new Separator());
            Add("\uE72B", "Назад (Alt+←)", () => GoBack());
            Add("\uE768", "Автопрокрутка (Ctrl+Shift+A)", ToggleAutoScroll);
            Add("\uE7B3", "Линейка чтения (Ctrl+U)", ToggleRuler);
            return m;
        }

        private ContextMenu BuildThumbMenu()
        {
            var m = new ContextMenu();
            void Add(string icon, string text, Action a)
            {
                var mi = new MenuItem { Header = text, Icon = new TextBlock { Text = icon, FontFamily = (FontFamily)FindResource("IconFont") } };
                mi.Click += (s, e) => { if (_doc != null) a(); };
                m.Items.Add(mi);
            }
            Add("", "Повернуть вправо", () => Rotate(90));
            Add("", "Повернуть влево", () => Rotate(-90));
            Add("", "Переместить выше", () => { _viewer.MovePage(_viewer.CurrentPage, -1); RebuildSidebar(); UpdateDocButtons(); });
            Add("", "Переместить ниже", () => { _viewer.MovePage(_viewer.CurrentPage, 1); RebuildSidebar(); UpdateDocButtons(); });
            Add("", "Убрать страницу (в сохраняемом PDF и печати)", () =>
            {
                if (_viewer.Pages.Count <= 1) return;
                _viewer.DeletePage(_viewer.CurrentPage); RebuildSidebar(); UpdateDocButtons();
                StatusText.Text = "Страница убрана из просмотра. Исходный файл не изменён — сохраните результат в PDF.";
            });
            Add("", "Сохранить страницу как изображение…", ExportCurrentImage);
            Add("\uE8A5", "Открыть в редакторе PDF (порядок, объединение)…", () => OpenPdfEditor(true, false));
            Add("", "Напечатать эту страницу…", () => ShowPrint(true));
            return m;
        }

        protected override void OnContentRendered(EventArgs e)
        {
            base.OnContentRendered(e);
            ThumbList.ContextMenu = BuildThumbMenu();
            AnnList.ContextMenu = new ContextMenu();
            AnnList.ContextMenuOpening += (s, a) => AnnList.ContextMenu = BuildAnnMenu();
            AnnList.MouseDoubleClick += (s, a) => EditAnnText();
            UpdateTabSpacer();
            UpdateTabScrollButtons();
        }

        // ======================= Буфер обмена =======================

        private void CopySelection()
        {
            if (!string.IsNullOrEmpty(_viewer.SelectedText))
            {
                try { Clipboard.SetText(_viewer.SelectedText); StatusText.Text = "Текст скопирован в буфер обмена."; }
                catch { StatusText.Text = "Буфер обмена занят другой программой."; }
            }
            else StatusText.Text = "Сначала выделите текст инструментом «Выделение текста» (V).";
        }

        private void CopyPageImage()
        {
            if (_doc == null || _viewer.Pages.Count == 0) return;
            try
            {
                var bmp = DocViewer.RenderComposite(_doc, _viewer.Pages[_viewer.CurrentPage], 150, true, false);
                Clipboard.SetImage(bmp);
                StatusText.Text = "Изображение страницы скопировано.";
            }
            catch (Exception ex) { StatusText.Text = "Не удалось скопировать: " + ex.Message; }
        }

        // ======================= Поиск =======================

        private void Search_Click(object sender, RoutedEventArgs e)
        {
            if (Sidebar.Visibility != Visibility.Visible) SetSidebar(true);
            TabSearch.IsChecked = true;
            SearchBox.Focus(); SearchBox.SelectAll();
        }

        private void SearchBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                var tab = _active;
                if (tab != null && tab.Hits.Count > 0 && tab.SearchKey == SearchBox.Text + "|" + MatchCase.IsChecked) SearchNext_Click(null, null);
                else RunSearch();
                e.Handled = true;
            }
        }

        private void DoSearch_Click(object sender, RoutedEventArgs e) => RunSearch();

        private void SetSearchStatus(DocTab tab, string text)
        {
            tab.SearchStatus = text;
            if (tab == _active) SearchStatus.Text = text;
        }

        private async void RunSearch()
        {
            var tab = _active;
            if (tab?.Doc == null) return;
            var doc = tab.Doc;
            var viewer = tab.Viewer;
            var q = SearchBox.Text.Trim();
            int gen = ++_searchGen;
            tab.SearchGen = gen;
            tab.Hits = new List<SearchHit>();
            tab.HitIndex = -1;
            tab.HitView = new ObservableCollection<SearchHit>();
            SearchResults.ItemsSource = tab.HitView;
            viewer.SetSearchHits(null);
            if (q.Length == 0) { SetSearchStatus(tab, ""); tab.SearchKey = null; return; }
            tab.SearchKey = SearchBox.Text + "|" + MatchCase.IsChecked;
            bool mc = MatchCase.IsChecked == true;
            var byView = new Dictionary<int, List<Rect>>();
            var results = tab.HitView;
            int pages = viewer.Pages.Count;
            bool noText = true;
            for (int i = 0; i < pages; i++)
            {
                if (gen != _searchGen || tab.Doc != doc)
                {
                    if (tab.SearchGen == gen && tab.Doc == doc) SetSearchStatus(tab, $"Поиск прерван на странице {i + 1} из {pages}. Нажмите Enter, чтобы начать заново.");
                    return;
                }
                if (i % 4 == 0)
                {
                    SetSearchStatus(tab, $"Поиск… страница {i + 1} из {pages}");
                    await Dispatcher.Yield(DispatcherPriority.Background);
                    if (gen != _searchGen || tab.Doc != doc) { i--; continue; }
                }
                if (i >= viewer.Pages.Count) break;
                var docIdx = viewer.Pages[i].Doc;
                List<Rect> found;
                string text;
                try
                {
                    if (doc.CanRenderOffThread)
                    {
                        var res = await Task.Run(() => (doc.Find(docIdx, q, mc), doc.GetPageText(docIdx)));
                        found = res.Item1; text = res.Item2;
                    }
                    else { found = doc.Find(docIdx, q, mc); text = doc.GetPageText(docIdx); }
                }
                catch { continue; }
                if (gen != _searchGen || tab.Doc != doc) { i--; continue; }
                if (!string.IsNullOrEmpty(text)) noText = false;
                if (found.Count == 0) continue;
                byView[i] = found;
                var flat = text.Replace('\n', ' ');
                int pos = 0;
                foreach (var r in found)
                {
                    int at = flat.IndexOf(q, Math.Min(pos, flat.Length), mc ? StringComparison.Ordinal : StringComparison.CurrentCultureIgnoreCase);
                    string snip = flat;
                    if (at >= 0)
                    {
                        int s0 = Math.Max(0, at - 40), e0 = Math.Min(flat.Length, at + q.Length + 50);
                        snip = (s0 > 0 ? "…" : "") + flat.Substring(s0, e0 - s0) + (e0 < flat.Length ? "…" : "");
                        pos = at + q.Length;
                    }
                    else if (snip.Length > 90) snip = snip.Substring(0, 90) + "…";
                    var hit = new SearchHit { View = i, Rect = r, PageLabel = "Страница " + (i + 1), Snippet = snip };
                    tab.Hits.Add(hit);
                    if (results.Count < 1500) results.Add(hit);
                }
                viewer.SetSearchHits(byView);
            }
            if (gen != _searchGen) return;
            viewer.SetSearchHits(byView);
            SetSearchStatus(tab, tab.Hits.Count == 0
                ? (noText ? "В документе нет текстового слоя. Распознайте текст (OCR), затем повторите поиск." : "Ничего не найдено.")
                : $"Найдено: {tab.Hits.Count} на {byView.Count} стр.");
            if (tab.Hits.Count > 0 && tab == _active) { tab.HitIndex = -1; SearchNext_Click(null, null); }
        }

        private void SearchNext_Click(object sender, RoutedEventArgs e) => MoveHit(1);
        private void SearchPrev_Click(object sender, RoutedEventArgs e) => MoveHit(-1);

        private void MoveHit(int d)
        {
            var tab = _active;
            if (tab == null) return;
            if (tab.Hits.Count == 0) { if (SearchBox.Text.Trim().Length > 0) RunSearch(); return; }
            tab.HitIndex = ((tab.HitIndex + d) % tab.Hits.Count + tab.Hits.Count) % tab.Hits.Count;
            var h = tab.Hits[tab.HitIndex];
            tab.Viewer.SetActiveHit(h.View, h.Rect);
            SetSearchStatus(tab, $"Совпадение {tab.HitIndex + 1} из {tab.Hits.Count}");
        }

        private void SearchResults_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var tab = _active;
            if (tab != null && SearchResults.SelectedItem is SearchHit h)
            {
                tab.HitIndex = tab.Hits.IndexOf(h);
                tab.Viewer.SetActiveHit(h.View, h.Rect);
            }
        }

        // ======================= OCR =======================

        private void Ocr_Click(object sender, RoutedEventArgs e)
        {
            if (_doc == null) return;
            var m = new ContextMenu();
            var a = new MenuItem { Header = "Распознать текущую страницу" }; a.Click += (s, x) => RunOcr(false); m.Items.Add(a);
            var b = new MenuItem { Header = "Распознать все страницы" }; b.Click += (s, x) => RunOcr(true); m.Items.Add(b);
            var info = new MenuItem { Header = "Языки распознавания: " + OcrService.AvailableLanguages(), IsEnabled = false }; m.Items.Add(info);
            m.PlacementTarget = sender as UIElement; m.Placement = PlacementMode.Bottom; m.IsOpen = true;
        }

        private async void RunOcr(bool all)
        {
            var tab = _active;
            if (tab?.Doc == null || tab.Viewer.Pages.Count == 0) return;
            var doc = tab.Doc;
            var viewer = tab.Viewer;
            var targets = all ? viewer.Pages.ToList() : new List<PageRef> { viewer.Pages[viewer.CurrentPage] };
            int done = 0, chars = 0;
            ShowLoading("Распознавание текста…");
            try
            {
                foreach (var r in targets)
                {
                    if (tab.Doc != doc) return;
                    int v = viewer.Pages.IndexOf(r);
                    LoadingText.Text = $"Распознавание текста «{tab.FileName}»: страница {v + 1} ({done + 1} из {targets.Count})";
                    var size = doc.GetPageSize(r.Doc);
                    double scale = Math.Min(3.0, 2600 / Math.Max(size.Width, size.Height));
                    int idx = r.Doc;
                    BitmapSource bmp = doc.CanRenderOffThread ? await Task.Run(() => doc.RenderPage(idx, scale)) : doc.RenderPage(idx, scale);
                    if (tab.Doc != doc) return;
                    if (bmp == null) { done++; continue; }
                    // фактический масштаб картинки (отрисовка могла ограничить размер очень больших страниц)
                    double pxPerDip = bmp.PixelWidth / Math.Max(1.0, size.Width);
                    var list = await OcrService.RecognizeAsync(bmp, pxPerDip);
                    bmp = null;
                    doc.SetOcrChars(idx, list);
                    chars += list.Count;
                    done++;
                }
                StatusText.Text = $"Распознано символов: {chars} на {done} стр. Теперь доступны поиск, выделение и копирование.";
                _searchGen++;
                tab.Hits.Clear();
                MemoryTrim.Schedule();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Распознавание не выполнено:\n\n" + ex.Message, "DocuNova", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            finally { HideLoading(); }
        }

        // ======================= Сохранение и экспорт =======================

        private void SavePdf_Click(object sender, RoutedEventArgs e)
        {
            if (_active?.Doc == null) return;
            SavePdf(_active, _viewer.Pages);
        }

        private bool SavePdf(DocTab tab, IList<PageRef> pages)
        {
            if (tab?.Doc == null) return false;
            var dlg = new SaveFileDialog
            {
                Filter = "Документ PDF|*.pdf",
                FileName = Path.GetFileNameWithoutExtension(tab.Path ?? "Документ") + (tab.Doc.IsPdf ? " (с пометками)" : "") + ".pdf",
                Title = "Сохранить как PDF"
            };
            if (dlg.ShowDialog(this) != true) return false;
            string target;
            try { target = Path.GetFullPath(dlg.FileName); } catch { target = dlg.FileName; }
            if (_tabs.Any(t => string.Equals(t.Path, target, StringComparison.OrdinalIgnoreCase)))
            {
                MessageBox.Show(this, "Для безопасности открытые документы не перезаписываются. Выберите другое имя.", "DocuNova", MessageBoxButton.OK, MessageBoxImage.Information);
                return false;
            }
            try
            {
                Mouse.OverrideCursor = Cursors.Wait;
                PdfExport.Save(tab.Doc, pages, target, S.ExportDpi, (i, n) => StatusText.Text = $"Сохранение: страница {i} из {n}");
                if (ReferenceEquals(pages, tab.Viewer.Pages)) tab.Viewer.Modified = false;
                UpdateTabHeader(tab);
                StatusText.Text = "Сохранено: " + target;
                ShowBanner("PDF сохранён: " + Path.GetFileName(target), false);
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Не удалось сохранить PDF:\n\n" + ex.Message, "DocuNova", MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }
            finally { Mouse.OverrideCursor = null; MemoryTrim.Schedule(); }
        }

        private void Export_Click(object sender, RoutedEventArgs e)
        {
            var m = new ContextMenu();
            void Add(string icon, string text, Action a, bool needDoc = true)
            {
                var mi = new MenuItem { Header = text, Icon = new TextBlock { Text = icon, FontFamily = (FontFamily)FindResource("IconFont") }, IsEnabled = !needDoc || _doc != null };
                mi.Click += (s, x) => a();
                m.Items.Add(mi);
            }
            Add("", "Текущую страницу как изображение (PNG/JPEG/TIFF)…", ExportCurrentImage);
            Add("", "Все страницы как изображения в папку…", ExportAllImages);
            Add("", "Текст документа в TXT…", ExportText);
            Add("", "Копировать текст всего документа", CopyAllText);
            Add("", "Выбранные страницы в отдельный PDF…", ExportRange);
            Add("", "Объединить несколько PDF в один…", MergePdfs, false);
            Add("\uE70B", "Пометки, заметки и выделенные цитаты в TXT / Markdown…", ExportAnnotations);
            Add("\uE8A5", "Редактор PDF: порядок, удаление, поворот страниц…", () => OpenPdfEditor(true, false), false);
            m.PlacementTarget = sender as UIElement; m.Placement = PlacementMode.Bottom; m.IsOpen = true;
        }

        private void ExportCurrentImage()
        {
            if (_doc == null || _viewer.Pages.Count == 0) return;
            var dlg = new SaveFileDialog { Filter = "PNG|*.png|JPEG|*.jpg|TIFF|*.tif", FileName = $"{Path.GetFileNameWithoutExtension(_path)} — стр. {_viewer.CurrentPage + 1}.png" };
            if (dlg.ShowDialog(this) != true) return;
            try
            {
                var bmp = DocViewer.RenderComposite(_doc, _viewer.Pages[_viewer.CurrentPage], S.ExportDpi, true, false);
                PdfExport.SaveImage(bmp, dlg.FileName);
                StatusText.Text = "Сохранено: " + dlg.FileName;
            }
            catch (Exception ex) { MessageBox.Show(this, ex.Message, "DocuNova"); }
            finally { MemoryTrim.Schedule(); }
        }

        private async void ExportAllImages()
        {
            var tab = _active;
            if (tab?.Doc == null) return;
            var dlg = new OpenFolderDialog { Title = "Папка для изображений страниц" };
            if (dlg.ShowDialog(this) != true) return;
            var doc = tab.Doc;
            var pages = tab.Viewer.Pages.ToList();
            var name = Path.GetFileNameWithoutExtension(tab.Path);
            ShowLoading("Экспорт изображений…");
            try
            {
                for (int i = 0; i < pages.Count; i++)
                {
                    if (tab.Doc != doc) return;
                    LoadingText.Text = $"Экспорт изображений: {i + 1} из {pages.Count}";
                    await Dispatcher.Yield(DispatcherPriority.Background);
                    if (tab.Doc != doc) return;
                    var bmp = DocViewer.RenderComposite(doc, pages[i], S.ExportDpi, true, false);
                    PdfExport.SaveImage(bmp, Path.Combine(dlg.FolderName, $"{name} — {i + 1:D4}.png"));
                    // каждые несколько страниц возвращаем память, чтобы экспорт больших документов не раздувал процесс
                    if (i % 8 == 7) MemoryTrim.Collect(false);
                }
                StatusText.Text = "Изображения сохранены в " + dlg.FolderName;
            }
            catch (Exception ex) { MessageBox.Show(this, ex.Message, "DocuNova"); }
            finally { HideLoading(); MemoryTrim.Schedule(); }
        }

        private string AllText()
        {
            var sb = new StringBuilder();
            for (int i = 0; i < _viewer.Pages.Count; i++)
            {
                sb.AppendLine(_doc.GetPageText(_viewer.Pages[i].Doc));
                sb.AppendLine();
            }
            return sb.ToString();
        }

        private void ExportText()
        {
            if (_doc == null) return;
            var dlg = new SaveFileDialog { Filter = "Текст (UTF-8)|*.txt", FileName = Path.GetFileNameWithoutExtension(_path) + ".txt" };
            if (dlg.ShowDialog(this) != true) return;
            try
            {
                Mouse.OverrideCursor = Cursors.Wait;
                File.WriteAllText(dlg.FileName, AllText(), new UTF8Encoding(true));
                StatusText.Text = "Текст сохранён: " + dlg.FileName;
            }
            catch (Exception ex) { MessageBox.Show(this, ex.Message, "DocuNova"); }
            finally { Mouse.OverrideCursor = null; }
        }

        private void CopyAllText()
        {
            if (_doc == null) return;
            try
            {
                Mouse.OverrideCursor = Cursors.Wait;
                var t = AllText();
                if (string.IsNullOrWhiteSpace(t)) { StatusText.Text = "В документе нет текстового слоя (используйте OCR)."; return; }
                Clipboard.SetText(t);
                StatusText.Text = $"Скопировано символов: {t.Length:N0}";
            }
            catch (Exception ex) { StatusText.Text = ex.Message; }
            finally { Mouse.OverrideCursor = null; }
        }

        private void ExportRange()
        {
            var tab = _active;
            if (tab?.Doc == null) return;
            var range = InputDialog.Ask(this, "Страницы в отдельный PDF", $"Укажите номера страниц (1–{_viewer.Pages.Count}), например: 1-3, 5, 8-", $"{_viewer.CurrentPage + 1}");
            if (range == null) return;
            var idx = PrintService.ParseRange(range, _viewer.Pages.Count);
            if (idx.Count == 0) { MessageBox.Show(this, "Не распознан диапазон страниц.", "DocuNova"); return; }
            SavePdf(tab, idx.Select(i => _viewer.Pages[i]).ToList());
        }

        /// <summary>Объединение PDF: открывается редактор PDF с выбором файлов (порядок можно поменять перед сохранением).</summary>
        private void MergePdfs() => OpenPdfEditor(false, true);

        private void PdfEditor_Click(object sender, RoutedEventArgs e) => OpenPdfEditor(true, false);

        /// <summary>
        /// Открывает редактор PDF. <paramref name="seedCurrent"/> — взять открытый PDF (с текущим порядком и поворотами
        /// страниц), <paramref name="askFiles"/> — сразу предложить выбрать файлы для объединения.
        /// </summary>
        private async void OpenPdfEditor(bool seedCurrent, bool askFiles)
        {
            var w = new PdfEditorWindow
            {
                Owner = this,
                RasterDpi = S.ExportDpi,
                OpenResult = path => { Activate(); OpenFile(path); },
                IsFileOpen = path => _tabs.Any(t => string.Equals(t.Path, path, StringComparison.OrdinalIgnoreCase))
            };
            w.Show();
            try
            {
                var tab = _active;
                if (seedCurrent && tab?.Doc is PdfDoc pdf && !string.IsNullOrEmpty(tab.Path) && File.Exists(tab.Path))
                {
                    var seed = new EditorSeed
                    {
                        Path = tab.Path,
                        Password = pdf.Password,
                        Pages = tab.Viewer.Pages.Select(p => (p.Doc, p.Rotation)).ToList()
                    };
                    await w.LoadSeedAsync(seed);
                    if (tab.Viewer.HasAnnotations)
                        ShowBanner("Пометки в редактор PDF не переносятся — чтобы сохранить их, используйте «Сохранить как PDF» (Ctrl+S).", false);
                }
                if (askFiles)
                {
                    var open = new OpenFileDialog { Filter = "PDF и изображения|*.pdf;*.jpg;*.jpeg;*.png;*.tif;*.tiff;*.bmp;*.gif|PDF|*.pdf|Все файлы|*.*", Multiselect = true, Title = "Выберите файлы для объединения" };
                    if (open.ShowDialog(w) == true && open.FileNames.Length > 0)
                        await w.AddFilesAsync(open.FileNames.OrderBy(f => f, new DocumentLoader.NaturalComparer()));
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(w, "Не удалось открыть файлы в редакторе PDF:\n\n" + ex.Message, "DocuNova", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        // ======================= Печать, свойства, настройки, справка =======================

        private void Print_Click(object sender, RoutedEventArgs e) => ShowPrint(false);

        private async void ShowPrint(bool currentOnly)
        {
            if (_doc == null) return;
            await WaitLoadingAsync();
            if (_doc == null) return;
            var w = new PrintWindow(_doc, _viewer.Pages, _viewer.CurrentPage, currentOnly) { Owner = this };
            w.ShowDialog();
            MemoryTrim.Schedule();
        }

        private void Properties_Click(object sender, RoutedEventArgs e) => ShowProperties(0);

        private async void ShowProperties(int tab)
        {
            if (_doc == null) return;
            await WaitLoadingAsync();
            if (_doc == null) return;
            var w = new PropertiesWindow(_doc, _path, _viewer.Pages.Count, tab) { Owner = this };
            w.ShowDialog();
        }

        private void Settings_Click(object sender, RoutedEventArgs e) => ShowSettings(0);
        private void ReadSettings_Click(object sender, RoutedEventArgs e) => ShowSettings(1);

        private void ShowSettings(int tab)
        {
            var before = System.Text.Json.JsonSerializer.Serialize(S.Reflow);
            var w = new SettingsWindow(tab) { Owner = this };
            w.ShowDialog();
            ApplyViewSettings();
            ApplyTabWidth();
            RebuildStampList();
            foreach (var t in _thumbs) t.Thumb = null;
            RebuildThumbs();
            BuildSwatches();
            UpdateSecurityBadge();
            var books = _tabs.Where(t => t.Doc != null && t.Doc.IsReflowable).ToList();
            if (books.Count > 0 && before != System.Text.Json.JsonSerializer.Serialize(S.Reflow))
            {
                if (books.Any(t => t.Viewer.HasAnnotations) &&
                    MessageBox.Show(this, "Изменение параметров чтения перестроит страницы открытых книг, и пометки в них будут удалены. Продолжить?", "DocuNova", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes)
                    return;
                ShowLoading("Перестроение страниц…");
                Dispatcher.BeginInvoke(new Action(() =>
                {
                    try
                    {
                        var rs = S.Reflow.Clone(); rs.Light = false;
                        foreach (var t in books)
                        {
                            if (t.Doc == null) continue;
                            try
                            {
                                t.Doc.Reflow(rs);
                                t.Viewer.ReloadPagesAfterReflow();
                                UpdatePaneTitle(t);
                            }
                            catch (Exception ex) { ShowError($"Не удалось перестроить страницы «{t.FileName}»", ex); }
                        }
                        RebuildSidebar();
                        if (_doc != null) OnCurrentPageChanged(_viewer.CurrentPage);
                    }
                    finally { HideLoading(); MemoryTrim.Schedule(); }
                }), DispatcherPriority.Background);
            }
            else foreach (var t in VisibleTabs()) t.Viewer.RerenderAll();
            RefreshRecent();
        }

        private void Help_Click(object sender, RoutedEventArgs e)
        {
            new HelpWindow { Owner = this }.ShowDialog();
        }

        // ======================= Клавиатура =======================

        protected override void OnPreviewKeyDown(KeyEventArgs e)
        {
            base.OnPreviewKeyDown(e);
            if (e.Handled) return;
            var mods = Keyboard.Modifiers;
            bool ctrl = (mods & ModifierKeys.Control) != 0, shift = (mods & ModifierKeys.Shift) != 0, alt = (mods & ModifierKeys.Alt) != 0;
            bool inText = IsKeyboardFocusWithinTextBox();
            var key = e.Key == Key.System ? e.SystemKey : e.Key;

            if (ctrl)
            {
                switch (key)
                {
                    case Key.Tab: NextTab(shift ? -1 : 1); e.Handled = true; return;
                    case Key.T when shift: ReopenClosedTab(); e.Handled = true; return;
                    case Key.A when shift && !inText: ToggleAutoScroll(); e.Handled = true; return;
                    case Key.Up when shift: ChangeAutoScrollSpeed(1.25); e.Handled = true; return;
                    case Key.Down when shift: ChangeAutoScrollSpeed(1 / 1.25); e.Handled = true; return;
                    case Key.H when shift: ToggleAnnotationsVisible(); e.Handled = true; return;
                    case Key.Space when shift: ShowTabList(); e.Handled = true; return;
                    case Key.U: ToggleRuler(); e.Handled = true; return;
                    case Key.G: FocusPageBox(); e.Handled = true; return;
                    case Key.PageDown: NextTab(1); e.Handled = true; return;
                    case Key.PageUp: NextTab(-1); e.Handled = true; return;
                    case Key.Oem5: case Key.OemBackslash: Parallel_Click(null, null); e.Handled = true; return;
                    case Key.O when shift: RunOcr(false); e.Handled = true; return;
                    case Key.O: case Key.T: Open_Click(null, null); e.Handled = true; return;
                    case Key.S: SavePdf_Click(null, null); e.Handled = true; return;
                    case Key.P: Print_Click(null, null); e.Handled = true; return;
                    case Key.E: if (_doc != null) Export_Click(ExportBtn, null); e.Handled = true; return;
                    case Key.M: OpenPdfEditor(true, false); e.Handled = true; return;
                    case Key.W: case Key.F4: if (_active != null) CloseTab(_active); e.Handled = true; return;
                    case Key.F: Search_Click(null, null); e.Handled = true; return;
                    case Key.B: Bookmark_Click(null, null); e.Handled = true; return;
                    case Key.Z when !inText: Undo_Click(null, null); e.Handled = true; return;
                    case Key.Y when !inText: Redo_Click(null, null); e.Handled = true; return;
                    case Key.C when !inText: CopySelection(); e.Handled = true; return;
                    case Key.A when !inText: SelectTool(Tool.Select); _viewer.SelectAllOnPage(); e.Handled = true; return;
                    case Key.OemPlus: case Key.Add: ZoomIn_Click(null, null); e.Handled = true; return;
                    case Key.OemMinus: case Key.Subtract: ZoomOut_Click(null, null); e.Handled = true; return;
                    case Key.D0: case Key.NumPad0: _viewer.SetZoom(1); e.Handled = true; return;
                    case Key.D1: FitPage_Click(null, null); e.Handled = true; return;
                    case Key.D2: FitWidth_Click(null, null); e.Handled = true; return;
                    case Key.D3: CycleSpread(); e.Handled = true; return;
                    case Key.L: Rotate(-90); e.Handled = true; return;
                    case Key.R: Rotate(90); e.Handled = true; return;
                    case Key.N: PageMode_Click(null, null); e.Handled = true; return;
                    case Key.OemComma: Settings_Click(null, null); e.Handled = true; return;
                    case Key.Home when !inText: _viewer.GoTo(0); e.Handled = true; return;
                    case Key.End when !inText: _viewer.GoTo(_viewer.Pages.Count - 1); e.Handled = true; return;
                }
                return;
            }
            if (alt && key == Key.Enter) { Properties_Click(null, null); e.Handled = true; return; }
            if (alt && !shift)
            {
                switch (key)
                {
                    case Key.Left: GoBack(); e.Handled = true; return;
                    case Key.Right: GoForward(); e.Handled = true; return;
                    case Key.D1: case Key.D2: case Key.D3: case Key.D4: case Key.D5: case Key.D6: case Key.D7: case Key.D8: case Key.D9:
                        SelectTabByNumber(key - Key.D0); e.Handled = true; return;
                }
            }

            switch (key)
            {
                case Key.F1: Help_Click(null, null); e.Handled = true; return;
                case Key.F3: if (shift) SearchPrev_Click(null, null); else SearchNext_Click(null, null); e.Handled = true; return;
                case Key.F6: FocusNextPane(); e.Handled = true; return;
                case Key.F9: Sidebar_Click(null, null); e.Handled = true; return;
                case Key.F11: SetFullScreen(!_fullscreen); e.Handled = true; return;
                case Key.BrowserBack: GoBack(); e.Handled = true; return;
                case Key.BrowserForward: GoForward(); e.Handled = true; return;
                case Key.Escape:
                    if (_doc != null && _viewer.AutoScrolling) { _viewer.StopAutoScroll(); UpdateAutoScrollUi(); e.Handled = true; return; }
                    if (_fullscreen) { SetFullScreen(false); e.Handled = true; return; }
                    if (!inText) { HandTool.IsChecked = true; _viewer.ClearSelection(); }
                    return;
            }
            if (inText || _doc == null || alt) return;
            switch (key)
            {
                case Key.Right: if (_viewer.Scroll.ScrollableWidth < 1) { _viewer.Next(); e.Handled = true; } return;
                case Key.Left: if (_viewer.Scroll.ScrollableWidth < 1) { _viewer.Prev(); e.Handled = true; } return;
                case Key.Home: _viewer.GoTo(0); e.Handled = true; return;
                case Key.End: _viewer.GoTo(_viewer.Pages.Count - 1); e.Handled = true; return;
                case Key.Delete:
                    if (AnnList.IsKeyboardFocusWithin) { AnnDelete_Click(null, null); e.Handled = true; }
                    return;
            }
            Tool? t = null;
            switch (key)
            {
                case Key.H: t = Tool.Hand; break;
                case Key.V: t = Tool.Select; break;
                case Key.M: t = Tool.Highlight; break;
                case Key.U: t = Tool.Underline; break;
                case Key.K: t = Tool.Strike; break;
                case Key.P: t = Tool.Pen; break;
                case Key.F: t = Tool.Marker; break;
                case Key.R: t = Tool.Rect; break;
                case Key.O: t = Tool.Ellipse; break;
                case Key.A: t = Tool.Arrow; break;
                case Key.L: t = Tool.Line; break;
                case Key.T: t = Tool.Text; break;
                case Key.N: t = Tool.Note; break;
                case Key.S: t = Tool.Stamp; break;
                case Key.D: t = Tool.Redact; break;
                case Key.W: t = Tool.WhiteOut; break;
                case Key.E: t = Tool.Eraser; break;
            }
            if (t.HasValue) { SelectTool(t.Value); e.Handled = true; }
        }
    }
}
