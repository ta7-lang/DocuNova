using System;
using System.Collections.Generic;
using System.Linq;
using System.Printing;
using System.Windows;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Xps;
using DocuNova.Core;
using DocuNova.Viewer;

namespace DocuNova.Services
{
    public sealed class PrintOptions
    {
        public List<PageRef> Pages = new List<PageRef>();
        public int Copies = 1;
        public bool Collate = true;
        public string Orientation = "auto";   // auto | portrait | landscape
        public string Scaling = "fit";        // fit | actual | fill | custom
        public double CustomScale = 1;
        public int PerSheet = 1;
        public bool Gray;
        public string Duplex = "none";        // none | long | short
        public bool Annotations = true;
        public int Dpi = 300;
        public bool Reverse;
        public bool Borders = true;
        public double Margin = 24;            // DIP
    }

    /// <summary>Пагинатор листов печати: несколько страниц на листе, масштабирование, поворот, Ч/Б.</summary>
    public sealed class SheetPaginator : DocumentPaginator
    {
        private readonly DocumentBase _doc;
        private readonly PrintOptions _o;
        private Size _sheet;
        public bool Landscape { get; }

        public SheetPaginator(DocumentBase doc, PrintOptions o, Size portraitSheet)
        {
            _doc = doc; _o = o;
            Landscape = o.Orientation == "landscape" || (o.Orientation == "auto" && AutoLandscape(portraitSheet));
            _sheet = Landscape ? new Size(portraitSheet.Height, portraitSheet.Width) : portraitSheet;
        }

        private bool AutoLandscape(Size portrait)
        {
            if (_o.Pages.Count == 0) return false;
            var s = RotatedSize(_o.Pages[0]);
            bool pageLandscape = s.Width > s.Height;
            var (c, r) = Grid(_o.PerSheet, portrait, s);
            var (c2, r2) = Grid(_o.PerSheet, new Size(portrait.Height, portrait.Width), s);
            double fitP = Math.Min(portrait.Width / c / s.Width, portrait.Height / r / s.Height);
            double fitL = Math.Min(portrait.Height / c2 / s.Width, portrait.Width / r2 / s.Height);
            return _o.PerSheet == 1 ? pageLandscape : fitL > fitP * 1.01;
        }

        private Size RotatedSize(PageRef r)
        {
            var s = _doc.GetPageSize(r.Doc);
            return r.Rotation % 180 != 0 ? new Size(s.Height, s.Width) : s;
        }

        public static (int cols, int rows) Grid(int n, Size sheet, Size page)
        {
            if (n <= 1) return (1, 1);
            (int, int) best = (1, n);
            double bestScale = 0;
            for (int c = 1; c <= n; c++)
            {
                int r = (int)Math.Ceiling((double)n / c);
                if (c * r - n >= c) continue;
                double scale = Math.Min(sheet.Width / c / page.Width, sheet.Height / r / page.Height);
                if (scale > bestScale) { bestScale = scale; best = (c, r); }
            }
            return best;
        }

        public override bool IsPageCountValid => true;
        public override int PageCount => Math.Max(1, (int)Math.Ceiling((double)_o.Pages.Count / Math.Max(1, _o.PerSheet)));
        public override Size PageSize { get => _sheet; set => _sheet = value; }
        public override IDocumentPaginatorSource Source => null;

        public override DocumentPage GetPage(int pageNumber)
        {
            int sheetIndex = _o.Reverse ? PageCount - 1 - pageNumber : pageNumber;
            var dv = new DrawingVisual();
            RenderOptions.SetBitmapScalingMode(dv, BitmapScalingMode.HighQuality);
            using (var dc = dv.RenderOpen())
            {
                dc.DrawRectangle(Brushes.White, null, new Rect(_sheet));
                double m = _o.Margin;
                var area = new Rect(m, m, Math.Max(10, _sheet.Width - 2 * m), Math.Max(10, _sheet.Height - 2 * m));
                int start = sheetIndex * _o.PerSheet;
                var first = _o.Pages[Math.Min(start, _o.Pages.Count - 1)];
                var (cols, rows) = Grid(_o.PerSheet, area.Size, RotatedSize(first));
                double gap = _o.PerSheet > 1 ? 10 : 0;
                double cw = (area.Width - gap * (cols - 1)) / cols, ch = (area.Height - gap * (rows - 1)) / rows;
                for (int k = 0; k < _o.PerSheet; k++)
                {
                    int idx = start + k;
                    if (idx >= _o.Pages.Count) break;
                    var pr = _o.Pages[idx];
                    int col = k % cols, row = k / cols;
                    var cell = new Rect(area.X + col * (cw + gap), area.Y + row * (ch + gap), cw, ch);
                    var ps = RotatedSize(pr);
                    double scale;
                    switch (_o.Scaling)
                    {
                        case "actual": scale = 1; break;
                        case "custom": scale = Math.Max(0.1, Math.Min(4, _o.CustomScale)); break;
                        case "fill": scale = Math.Max(cell.Width / ps.Width, cell.Height / ps.Height); break;
                        default: scale = Math.Min(cell.Width / ps.Width, cell.Height / ps.Height); break;
                    }
                    if (_o.PerSheet > 1) scale = Math.Min(cell.Width / ps.Width, cell.Height / ps.Height);
                    double w = ps.Width * scale, h = ps.Height * scale;
                    var target = new Rect(cell.X + (cell.Width - w) / 2, cell.Y + (cell.Height - h) / 2, w, h);
                    BitmapSource bmp = null;
                    try { bmp = DocViewer.RenderComposite(_doc, pr, _o.Dpi, _o.Annotations, _o.Gray); }
                    catch { }
                    dc.PushClip(new RectangleGeometry(cell));
                    if (bmp != null) dc.DrawImage(bmp, target);
                    dc.Pop();
                    if (_o.Borders && _o.PerSheet > 1)
                    {
                        var pen = new Pen(new SolidColorBrush(Color.FromRgb(180, 180, 180)), 0.6);
                        pen.Freeze();
                        dc.DrawRectangle(null, pen, target);
                    }
                }
            }
            return new DocumentPage(dv, _sheet, new Rect(_sheet), new Rect(_sheet));
        }
    }

    public static class PrintService
    {
        public static List<PrintQueue> GetPrinters(out PrintQueue def)
        {
            def = null;
            var list = new List<PrintQueue>();
            try
            {
                var server = new LocalPrintServer();
                try { def = LocalPrintServer.GetDefaultPrintQueue(); } catch { }
                foreach (var q in server.GetPrintQueues(new[] { EnumeratedPrintQueueTypes.Local, EnumeratedPrintQueueTypes.Connections }))
                    list.Add(q);
            }
            catch { }
            return list;
        }

        /// <summary>Разбор строки диапазона: «1-3, 5, 8-» (номера с 1).</summary>
        public static List<int> ParseRange(string s, int count)
        {
            var res = new List<int>();
            if (string.IsNullOrWhiteSpace(s)) return res;
            foreach (var part in s.Split(new[] { ',', ';', ' ' }, StringSplitOptions.RemoveEmptyEntries))
            {
                var p = part.Trim();
                int dash = p.IndexOf('-');
                if (dash < 0) dash = p.IndexOf('–');
                if (dash >= 0)
                {
                    var a = p.Substring(0, dash).Trim(); var b = p.Substring(dash + 1).Trim();
                    int from = a.Length == 0 ? 1 : int.TryParse(a, out var x) ? x : -1;
                    int to = b.Length == 0 ? count : int.TryParse(b, out var y) ? y : -1;
                    if (from < 1 || to < 1) continue;
                    if (from > to) { var t = from; from = to; to = t; }
                    for (int i = from; i <= Math.Min(to, count); i++) res.Add(i - 1);
                }
                else if (int.TryParse(p, out var n) && n >= 1 && n <= count) res.Add(n - 1);
            }
            return res.Distinct().ToList();
        }

        public static PrintTicket BuildTicket(PrintQueue q, PrintOptions o, bool landscape)
        {
            PrintTicket baseTicket = null;
            try { baseTicket = q.UserPrintTicket ?? q.DefaultPrintTicket; } catch { }
            var t = baseTicket != null ? baseTicket.Clone() : new PrintTicket();
            t.CopyCount = Math.Max(1, Math.Min(999, o.Copies));
            t.Collation = o.Collate ? Collation.Collated : Collation.Uncollated;
            t.PageOrientation = landscape ? PageOrientation.Landscape : PageOrientation.Portrait;
            t.OutputColor = o.Gray ? OutputColor.Grayscale : OutputColor.Color;
            t.Duplexing = o.Duplex == "long" ? Duplexing.TwoSidedLongEdge : o.Duplex == "short" ? Duplexing.TwoSidedShortEdge : Duplexing.OneSided;
            try
            {
                var res = q.MergeAndValidatePrintTicket(baseTicket ?? t, t);
                if (res.ValidatedPrintTicket != null) t = res.ValidatedPrintTicket;
            }
            catch { }
            return t;
        }

        public static Size PortraitSheet(PrintQueue q, PrintTicket t)
        {
            double w = 793.7, h = 1122.5; // A4
            try
            {
                var ms = t?.PageMediaSize;
                if (ms != null && ms.Width.HasValue && ms.Height.HasValue && ms.Width > 50 && ms.Height > 50) { w = ms.Width.Value; h = ms.Height.Value; }
            }
            catch { }
            return new Size(Math.Min(w, h), Math.Max(w, h));
        }

        public static double SafeMargin(PrintQueue q, PrintTicket t)
        {
            try
            {
                var caps = q.GetPrintCapabilities(t);
                var area = caps?.PageImageableArea;
                if (area != null) return Math.Max(16, Math.Max(area.OriginWidth, area.OriginHeight) + 4);
            }
            catch { }
            return 24;
        }

        public static XpsDocumentWriter Print(PrintQueue q, DocumentBase doc, PrintOptions o)
        {
            var probe = new SheetPaginator(doc, o, new Size(793.7, 1122.5));
            var ticket = BuildTicket(q, o, probe.Landscape);
            o.Margin = Math.Max(o.Margin, SafeMargin(q, ticket));
            var pag = new SheetPaginator(doc, o, PortraitSheet(q, ticket));
            var writer = PrintQueue.CreateXpsDocumentWriter(q);
            writer.WriteAsync(pag, ticket);
            return writer;
        }
    }
}
