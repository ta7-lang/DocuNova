using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;

namespace DocuNova.Services
{
    /// <summary>
    /// Усиление защиты процесса средствами Windows: безопасный поиск DLL, запрет загрузки
    /// библиотек из сети и с низким уровнем целостности, отключение точек внедрения (AppInit и др.).
    /// </summary>
    public static class Hardening
    {
        public static List<string> Status { get; } = new List<string>();

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool SetDefaultDllDirectories(uint flags);

        [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        private static extern bool SetDllDirectory(string path);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool SetSearchPathMode(uint flags);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool SetProcessMitigationPolicy(int policy, ref uint buffer, int length);

        private const uint LOAD_LIBRARY_SEARCH_DEFAULT_DIRS = 0x00001000;
        private const uint BASE_SEARCH_PATH_ENABLE_SAFE_SEARCHMODE = 0x00000001;
        private const uint BASE_SEARCH_PATH_PERMANENT = 0x00008000;
        private const int ProcessExtensionPointDisablePolicy = 6;
        private const int ProcessImageLoadPolicy = 10;

        public static void Apply()
        {
            Status.Clear();
            Try("Безопасный порядок поиска DLL (защита от подмены библиотек)", () => SetDefaultDllDirectories(LOAD_LIBRARY_SEARCH_DEFAULT_DIRS) & SetDllDirectory(""));
            Try("Безопасный режим поиска путей", () => SetSearchPathMode(BASE_SEARCH_PATH_ENABLE_SAFE_SEARCHMODE | BASE_SEARCH_PATH_PERMANENT));
            Try("Запрет внедрения через устаревшие точки расширения (AppInit_DLLs и др.)", () =>
            {
                uint flags = 1; // DisableExtensionPoints
                return SetProcessMitigationPolicy(ProcessExtensionPointDisablePolicy, ref flags, 4);
            });
            Try("Запрет загрузки библиотек из сети и с низким уровнем доверия", () =>
            {
                uint flags = 1 | 2; // NoRemoteImages | NoLowMandatoryLabelImages
                return SetProcessMitigationPolicy(ProcessImageLoadPolicy, ref flags, 4);
            });
            Status.Add("✔ Предотвращение выполнения данных (DEP) и ASLR — включены по умолчанию для 64-битного процесса");
            Status.Add("✔ Приложение не использует сеть: нет сетевого кода, внешние ресурсы документов не загружаются");
            Status.Add("✔ Скрипты (JavaScript), макросы (VBA/Basic), ActiveX, OLE, DDE, формы и автозапуск не исполняются");
            Status.Add("✔ Разбор форматов выполняется управляемым кодом с проверкой границ памяти");
            Status.Add("✔ Ограничения против zip-бомб, XML-бомб (XXE) и «бомб» распаковки изображений");
            Status.Add("✔ Документы открываются только для чтения; исходные файлы никогда не изменяются");
        }

        private static void Try(string name, Func<bool> f)
        {
            bool ok;
            try { ok = f(); } catch { ok = false; }
            Status.Add((ok ? "✔ " : "• ") + name + (ok ? "" : " — недоступно в этой версии Windows"));
        }
    }
}
