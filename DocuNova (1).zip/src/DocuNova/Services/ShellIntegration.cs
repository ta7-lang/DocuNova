using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading;
using Microsoft.Win32;

namespace DocuNova.Services
{
    /// <summary>Интеграция с Проводником: состояние эскизов, очистка системного кэша эскизов, приложения по умолчанию.</summary>
    public static class ShellIntegration
    {
        public const string ThumbClsid = "{4ade8aa0-5fdb-4a79-b9af-dcd6f72acb83}";
        private const string ThumbHandlerKey = "{e357fccd-a995-4576-b01f-234630154e96}";

        public static string[] RegisteredExtensions()
        {
            return Core.DocumentLoader.DocumentExtensions.Where(IsThumbnailRegistered).ToArray();
        }

        public static bool IsThumbnailRegistered(string ext)
        {
            try
            {
                using (var k = Registry.ClassesRoot.OpenSubKey(ext + @"\ShellEx\" + ThumbHandlerKey))
                    return string.Equals(k?.GetValue(null) as string, ThumbClsid, StringComparison.OrdinalIgnoreCase);
            }
            catch { return false; }
        }

        [DllImport("shell32.dll")]
        private static extern void SHChangeNotify(int eventId, uint flags, IntPtr item1, IntPtr item2);

        public static void NotifyAssociationsChanged()
        {
            try { SHChangeNotify(0x08000000, 0x1000, IntPtr.Zero, IntPtr.Zero); } catch { }
        }

        /// <summary>
        /// Очистка системного кэша эскизов Windows (thumbcache_*.db). Проводник перезапускается,
        /// эскизы затем строятся заново — чётко и без «битых» картинок.
        /// </summary>
        public static int ClearThumbnailCache()
        {
            string dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), @"Microsoft\Windows\Explorer");
            int deleted = 0;
            var explorers = Process.GetProcessesByName("explorer");
            foreach (var p in explorers) { try { p.Kill(); p.WaitForExit(5000); } catch { } }
            Thread.Sleep(700);
            try
            {
                foreach (var f in Directory.GetFiles(dir, "thumbcache_*.db"))
                {
                    try { File.Delete(f); deleted++; } catch { }
                }
            }
            catch { }
            Thread.Sleep(1500);
            try
            {
                if (Process.GetProcessesByName("explorer").Length == 0)
                    Process.Start(new ProcessStartInfo(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows), "explorer.exe")) { UseShellExecute = true });
            }
            catch { }
            NotifyAssociationsChanged();
            return deleted;
        }

        public static void OpenDefaultAppsSettings()
        {
            try { Process.Start(new ProcessStartInfo("ms-settings:defaultapps") { UseShellExecute = true }); } catch { }
        }

        public static void ShowInExplorer(string path)
        {
            try
            {
                if (!File.Exists(path)) return;
                Process.Start(new ProcessStartInfo(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows), "explorer.exe"), "/select,\"" + path + "\"") { UseShellExecute = false });
            }
            catch { }
        }
    }
}
