using System;
using System.Collections.Generic;
using System.IO;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using DocuNova.Core;
using PdfSharp.Drawing;
using PdfSharp.Pdf;
using PdfSharp.Pdf.IO;

namespace DocuNova.Services
{
    /// <summary>Исходный файл редактора PDF: PDF-документ или изображение (JPEG, PNG, TIFF…).</summary>
    public sealed class ComposeSource : IDisposable
    {
        public string Path { get; set; }
        public string Name { get; set; }
        public byte[] Data { get; set; }
        public string Password { get; set; }
        public bool IsImage { get; set; }
        /// <summary>Документ для отрисовки эскизов и запасного растрового режима.</summary>
        public DocumentBase Render { get; set; }
        public int PageCount => Render?.PageCount ?? 0;

        public void Dispose()
        {
            try { Render?.Dispose(); } catch { }
            Render = null;
            Data = null;
        }
    }

    /// <summary>Страница итогового документа: страница исходного файла (или пустая), с поворотом.</summary>
    public sealed class ComposePage
    {
        /// <summary>null — пустая страница.</summary>
        public ComposeSource Source { get; set; }
        public int Index { get; set; }
        /// <summary>Дополнительный поворот по часовой стрелке: 0, 90, 180, 270.</summary>
        public int Rotation { get; set; }
        /// <summary>Размер пустой страницы (DIP, 1/96 дюйма).</summary>
        public Size BlankSize { get; set; }
    }

    /// <summary>
    /// Сборка нового PDF из страниц разных файлов (объединение, перестановка, удаление, поворот, вставка пустых страниц).
    /// Страницы PDF переносятся без потери качества (текст остаётся текстом); если файл не удаётся перенести так
    /// (повреждённая структура, запрет на извлечение), его страницы сохраняются картинкой в заданном разрешении.
    /// Исходные файлы никогда не изменяются.
    /// </summary>
    public static class PdfComposer
    {
        /// <summary>Наибольшая сторона страницы PDF — 200 дюймов (ограничение формата).</summary>
        private const double MaxPagePt = 14400;
        private const double MinPagePt = 36;

        /// <summary>Сохраняет страницы в новый PDF. Возвращает предупреждения (например, о растровом режиме).</summary>
        public static List<string> Save(IList<ComposePage> pages, string path, string title, int rasterDpi, Action<int, int> progress)
        {
            if (pages == null || pages.Count == 0) throw new InvalidOperationException("Нет страниц для сохранения.");
            var warnings = new List<string>();
            var imports = new Dictionary<ComposeSource, PdfDocument>();
            var importFailed = new HashSet<ComposeSource>();
            var rasterized = new HashSet<ComposeSource>();
            var keepAlive = new List<object>(); // потоки изображений должны жить до сохранения документа
            var output = new PdfDocument();
            output.Info.Creator = "DocuNova";
            if (!string.IsNullOrWhiteSpace(title)) output.Info.Title = title;
            // временный файл рядом с итоговым: при ошибке на середине не остаётся «битого» PDF
            string temp = path + ".docunova-tmp";
            try
            {
                for (int i = 0; i < pages.Count; i++)
                {
                    progress?.Invoke(i + 1, pages.Count);
                    var p = pages[i];
                    int rot = Norm(p.Rotation);
                    var src = p.Source;
                    if (src == null)
                    {
                        AddBlank(output, p.BlankSize, rot);
                        continue;
                    }
                    if (src.IsImage)
                    {
                        AddImagePage(output, src, p.Index, rot, keepAlive);
                        continue;
                    }
                    var imp = GetImport(src, imports, importFailed);
                    if (imp != null && p.Index >= 0 && p.Index < imp.PageCount)
                    {
                        try
                        {
                            var page = output.AddPage(imp.Pages[p.Index]);
                            page.Rotate = (Norm(page.Rotate) + rot) % 360;
                            continue;
                        }
                        catch
                        {
                            // страница не переносится — ниже она будет сохранена картинкой
                        }
                    }
                    rasterized.Add(src);
                    AddRasterPage(output, src, p.Index, rot, rasterDpi, keepAlive);
                }
                foreach (var s in rasterized)
                    warnings.Add($"«{s.Name}»: часть страниц не удалось перенести без потерь — они сохранены изображением ({rasterDpi} точек на дюйм), текст на них не выделяется.");

                try { if (File.Exists(temp)) File.Delete(temp); } catch { }
                output.Save(temp);
                output.Dispose();
                output = null;
                File.Move(temp, path, true);
            }
            finally
            {
                try { output?.Dispose(); } catch { }
                foreach (var d in imports.Values) { try { d.Dispose(); } catch { } }
                foreach (var k in keepAlive) { try { (k as IDisposable)?.Dispose(); } catch { } }
                try { if (File.Exists(temp)) File.Delete(temp); } catch { }
            }
            return warnings;
        }

        private static int Norm(int r) => ((r % 360) + 360) % 360 / 90 * 90;

        private static PdfDocument GetImport(ComposeSource src, Dictionary<ComposeSource, PdfDocument> cache, HashSet<ComposeSource> failed)
        {
            if (cache.TryGetValue(src, out var d)) return d;
            if (failed.Contains(src) || src.Data == null) return null;
            try
            {
                var ms = new MemoryStream(src.Data, false);
                d = string.IsNullOrEmpty(src.Password)
                    ? PdfReader.Open(ms, PdfDocumentOpenMode.Import)
                    : PdfReader.Open(ms, src.Password, PdfDocumentOpenMode.Import);
                cache[src] = d;
                return d;
            }
            catch
            {
                failed.Add(src);
                return null;
            }
        }

        private static PdfPage AddBlank(PdfDocument output, Size dip, int rot)
        {
            double w = dip.Width > 1 ? dip.Width * 72 / 96 : 595.28, h = dip.Height > 1 ? dip.Height * 72 / 96 : 841.89;
            FitPage(ref w, ref h);
            var page = output.AddPage();
            page.Width = XUnit.FromPoint(w);
            page.Height = XUnit.FromPoint(h);
            if (rot != 0) page.Rotate = rot;
            return page;
        }

        /// <summary>Подгоняет размер страницы под допустимые пределы PDF с сохранением пропорций.</summary>
        private static void FitPage(ref double w, ref double h)
        {
            w = Math.Max(1, w); h = Math.Max(1, h);
            double k = Math.Min(1, MaxPagePt / Math.Max(w, h));
            w *= k; h *= k;
            double k2 = Math.Max(1, MinPagePt / Math.Min(w, h));
            if (Math.Max(w, h) * k2 <= MaxPagePt) { w *= k2; h *= k2; }
        }

        /// <summary>Страница-изображение: размер страницы соответствует физическому размеру картинки (по её DPI).</summary>
        private static void AddImagePage(PdfDocument output, ComposeSource src, int index, int rot, List<object> keepAlive)
        {
            BitmapFrame frame;
            int frames;
            using (var ms = new MemoryStream(src.Data, false))
            {
                var dec = BitmapDecoder.Create(ms, BitmapCreateOptions.PreservePixelFormat | BitmapCreateOptions.IgnoreColorProfile, BitmapCacheOption.OnLoad);
                frames = dec.Frames.Count;
                frame = dec.Frames[Math.Max(0, Math.Min(index, frames - 1))];
            }
            double dpiX = frame.DpiX >= 10 && frame.DpiX <= 4800 ? frame.DpiX : 96;
            double dpiY = frame.DpiY >= 10 && frame.DpiY <= 4800 ? frame.DpiY : dpiX;
            double w = frame.PixelWidth * 72.0 / dpiX, h = frame.PixelHeight * 72.0 / dpiY;
            FitPage(ref w, ref h);

            byte[] bytes;
            bool jpeg = frames == 1 && src.Data.Length > 3 && src.Data[0] == 0xFF && src.Data[1] == 0xD8 && src.Data[2] == 0xFF;
            if (jpeg && (frame.Format == PixelFormats.Bgr24 || frame.Format == PixelFormats.Gray8 || frame.Format == PixelFormats.Bgr32))
                bytes = src.Data; // обычный JPEG переносится как есть, без пережатия
            else
            {
                var f = frame.Format;
                bool alpha = f == PixelFormats.Bgra32 || f == PixelFormats.Pbgra32 || f == PixelFormats.Rgba64 || f == PixelFormats.Prgba64 || f == PixelFormats.Rgba128Float || f == PixelFormats.Prgba128Float;
                BitmapSource conv = new FormatConvertedBitmap(frame, alpha ? PixelFormats.Bgra32 : PixelFormats.Bgr24, null, 0);
                // 8 бит на канал, без чересстрочности — формат, который PDFsharp встраивает без ошибок
                var enc = new PngBitmapEncoder { Interlace = PngInterlaceOption.Off };
                enc.Frames.Add(BitmapFrame.Create(conv));
                using (var o = new MemoryStream()) { enc.Save(o); bytes = o.ToArray(); }
            }
            DrawFullPageImage(output, bytes, w, h, rot, keepAlive);
        }

        /// <summary>Запасной режим: страница PDF рисуется картинкой (JPEG) в заданном разрешении.</summary>
        private static void AddRasterPage(PdfDocument output, ComposeSource src, int index, int rot, int dpi, List<object> keepAlive)
        {
            var doc = src.Render;
            if (doc == null || index < 0 || index >= doc.PageCount)
            {
                AddBlank(output, new Size(0, 0), rot);
                return;
            }
            var size = doc.GetPageSize(index);
            double scale = VisualTools.ClampScale(size, Math.Max(72, Math.Min(600, dpi)) / 96.0);
            var pix = doc.RenderPagePixels(index, scale, "normal", 0);
            if (pix?.Data == null)
            {
                AddBlank(output, size, rot);
                return;
            }
            var data = pix.Data;
            if (pix.Alpha)
            {
                // прозрачные области — на белую бумагу (данные premultiplied BGRA)
                data = (byte[])data.Clone();
                for (int i = 0; i + 3 < data.Length; i += 4)
                {
                    int inv = 255 - data[i + 3];
                    data[i] = (byte)Math.Min(255, data[i] + inv);
                    data[i + 1] = (byte)Math.Min(255, data[i + 1] + inv);
                    data[i + 2] = (byte)Math.Min(255, data[i + 2] + inv);
                    data[i + 3] = 255;
                }
            }
            var bmp = BitmapSource.Create(pix.Width, pix.Height, 96, 96, pix.Alpha ? PixelFormats.Pbgra32 : PixelFormats.Bgr32, null, data, pix.Stride);
            var enc = new JpegBitmapEncoder { QualityLevel = 90 };
            enc.Frames.Add(BitmapFrame.Create(new FormatConvertedBitmap(bmp, PixelFormats.Bgr24, null, 0)));
            byte[] bytes;
            using (var o = new MemoryStream()) { enc.Save(o); bytes = o.ToArray(); }
            double w = size.Width * 72 / 96, h = size.Height * 72 / 96;
            FitPage(ref w, ref h);
            DrawFullPageImage(output, bytes, w, h, rot, keepAlive);
        }

        private static void DrawFullPageImage(PdfDocument output, byte[] bytes, double wPt, double hPt, int rot, List<object> keepAlive)
        {
            var page = output.AddPage();
            page.Width = XUnit.FromPoint(wPt);
            page.Height = XUnit.FromPoint(hPt);
            var ms = new MemoryStream(bytes, false);
            keepAlive.Add(ms);
            var img = XImage.FromStream(ms);
            keepAlive.Add(img);
            using (var gfx = XGraphics.FromPdfPage(page))
                gfx.DrawImage(img, 0, 0, wPt, hPt);
            if (rot != 0) page.Rotate = rot;
        }

        /// <summary>Разбор правила разделения: «N» — по N страниц; иначе диапазоны через «;» («1-3; 4-10; 11-»).</summary>
        public static List<List<int>> ParseSplit(string rule, int count)
        {
            var res = new List<List<int>>();
            if (string.IsNullOrWhiteSpace(rule) || count <= 0) return res;
            rule = rule.Trim();
            if (int.TryParse(rule, out int n))
            {
                if (n < 1) return res;
                for (int i = 0; i < count; i += n)
                {
                    var part = new List<int>();
                    for (int k = i; k < Math.Min(count, i + n); k++) part.Add(k);
                    res.Add(part);
                }
                return res;
            }
            foreach (var chunk in rule.Split(new[] { ';', '|', '\n' }, StringSplitOptions.RemoveEmptyEntries))
            {
                var idx = PrintService.ParseRange(chunk, count);
                if (idx.Count > 0) res.Add(idx);
            }
            return res;
        }
    }
}
