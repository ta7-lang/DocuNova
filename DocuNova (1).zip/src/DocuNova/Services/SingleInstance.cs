using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Pipes;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Security.Principal;
using System.Text;
using System.Threading;

namespace DocuNova.Services
{
    /// <summary>
    /// Один экземпляр приложения: документы, открытые из Проводника, передаются уже запущенному окну
    /// и открываются в нём новыми вкладками. Канал связи — локальный именованный канал, доступный
    /// только текущему пользователю (удалённые подключения Windows отклоняет).
    /// </summary>
    public sealed class SingleInstance : IDisposable
    {
        private const string Header = "DOCUNOVA-OPEN-1";
        private const int MaxMessage = 256 * 1024;
        private Mutex _mutex;
        private volatile bool _stop;

        [DllImport("user32.dll")]
        private static extern bool AllowSetForegroundWindow(int processId);
        private const int ASFW_ANY = -1;

        private static string Id
        {
            get
            {
                string sid;
                try { sid = WindowsIdentity.GetCurrent().User?.Value ?? Environment.UserName; }
                catch { sid = Environment.UserName; }
                using (var sha = SHA256.Create())
                {
                    var h = sha.ComputeHash(Encoding.UTF8.GetBytes("DocuNova|" + sid));
                    return "DocuNova-" + BitConverter.ToString(h, 0, 12).Replace("-", "");
                }
            }
        }

        private static string PipeName => Id + ".open";

        /// <summary>Пытается стать единственным экземпляром. null — приложение уже запущено.</summary>
        public static SingleInstance TryAcquire()
        {
            try
            {
                var m = new Mutex(true, @"Local\" + Id, out bool created);
                if (!created) { m.Dispose(); return null; }
                return new SingleInstance { _mutex = m };
            }
            catch { return new SingleInstance(); } // не удалось создать мьютекс — работаем как обычно
        }

        /// <summary>Передаёт файлы запущенному экземпляру. false — передать не удалось.</summary>
        public static bool SendToPrimary(IEnumerable<string> files)
        {
            try
            {
                try { AllowSetForegroundWindow(ASFW_ANY); } catch { }
                var payload = Encoding.UTF8.GetBytes(Header + "\n" + string.Join("\n", files ?? Enumerable.Empty<string>()));
                if (payload.Length > MaxMessage) return false;
                using (var client = new NamedPipeClientStream(".", PipeName, PipeDirection.Out, PipeOptions.CurrentUserOnly))
                {
                    client.Connect(5000);
                    client.Write(payload, 0, payload.Length);
                    client.Flush();
                    try { client.WaitForPipeDrain(); } catch { }
                }
                return true;
            }
            catch { return false; }
        }

        /// <summary>Начинает принимать файлы от новых запусков приложения.</summary>
        public void StartListening(Action<string[]> onFiles)
        {
            if (_mutex == null) return;
            var t = new Thread(() => Loop(onFiles)) { IsBackground = true, Name = "DocuNova single instance" };
            t.Start();
        }

        private void Loop(Action<string[]> onFiles)
        {
            while (!_stop)
            {
                try
                {
                    using (var server = new NamedPipeServerStream(PipeName, PipeDirection.In, 1, PipeTransmissionMode.Byte, PipeOptions.CurrentUserOnly))
                    {
                        server.WaitForConnection();
                        if (_stop) return;
                        var ms = new MemoryStream();
                        var buf = new byte[8192];
                        int n;
                        while ((n = server.Read(buf, 0, buf.Length)) > 0)
                        {
                            ms.Write(buf, 0, n);
                            if (ms.Length > MaxMessage) break;
                        }
                        if (ms.Length > MaxMessage) continue;
                        var lines = Encoding.UTF8.GetString(ms.ToArray()).Split('\n');
                        if (lines.Length == 0 || lines[0].Trim() != Header) continue;
                        var files = lines.Skip(1).Select(l => l.Trim()).Where(l => l.Length > 0 && l.Length < 32768).Take(100).ToArray();
                        try { onFiles(files); } catch { }
                    }
                }
                catch
                {
                    if (_stop) return;
                    Thread.Sleep(300);
                }
            }
        }

        public void Dispose()
        {
            _stop = true;
            try { _mutex?.Dispose(); } catch { }
            _mutex = null;
        }
    }
}
