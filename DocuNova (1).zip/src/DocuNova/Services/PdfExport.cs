using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using DocuNova.Core;
using DocuNova.Viewer;
using PdfSharp.Drawing;
using PdfSharp.Pdf;
using PdfSharp.Pdf.IO;

namespace DocuNova.Services
{
    /// <summary>
    /// Сохранение в PDF. Для исходных PDF страницы переносятся без потери качества (текст остаётся текстом),
    /// пометки накладываются прозрачным слоем. Страницы со «скрытием»/«замазкой» растрируются,
    /// чтобы скрытый текст был удалён по-настоящему.
    /// </summary>
    public static class PdfExport
    {
        public static void Save(DocumentBase doc, IList<PageRef> pages, string path, int dpi, Action<int, int> progress)
        {
            var output = new PdfSharp.Pdf.PdfDocument();
            output.Info.Title = doc.Title ?? Path.GetFileNameWithoutExtension(doc.FilePath ?? "Документ");
            if (!string.IsNullOrEmpty(doc.Author)) output.Info.Author = doc.Author;
            output.Info.Creator = "DocuNova";

            PdfSharp.Pdf.PdfDocument source = null;
            Stream sourceStream = null;
            if (doc.IsPdf)
            {
                try
                {
                    sourceStream = doc.OpenSource();
                    if (sourceStream != null)
                    {
                        var pass = (doc as PdfDoc)?.Password;
                        source = string.IsNullOrEmpty(pass)
                            ? PdfReader.Open(sourceStream, PdfDocumentOpenMode.Import)
                            : PdfReader.Open(sourceStream, pass, PdfDocumentOpenMode.Import);
                    }
                }
                catch { source = null; } // повреждённый или нестандартный PDF — растровый режим
            }
            try
            {

            for (int i = 0; i < pages.Count; i++)
            {
                progress?.Invoke(i + 1, pages.Count);
                var r = pages[i];
                bool raster = source == null || r.Anns.Any(a => a.NeedsRaster) || r.Doc >= (source?.PageCount ?? 0);
                if (!raster)
                {
                    try
                    {
                        var src = source.Pages[r.Doc];
                        var page = output.AddPage(src);
                        int origRot = ((page.Rotate % 360) + 360) % 360;
                        if (r.Anns.Count > 0)
                        {
                            if (origRot != 0) { output.Pages.Remove(page); raster = true; }
                            else
                            {
                                var size = doc.GetPageSize(r.Doc);
                                var overlay = OverlayPng(r.Anns, size, 3.0);
                                using (var gfx = XGraphics.FromPdfPage(page, XGraphicsPdfPageOptions.Append))
                                using (var ms = new MemoryStream(overlay))
                                {
                                    var img = XImage.FromStream(ms);
                                    gfx.DrawImage(img, 0, 0, page.Width.Point, page.Height.Point);
                                }
                            }
                        }
                        if (!raster && r.Rotation != 0) page.Rotate = (origRot + r.Rotation) % 360;
                    }
                    catch { raster = true; }
                }
                if (raster) AddRasterPage(output, doc, r, dpi);
            }
            output.Save(path);
            }
            finally
            {
                output.Dispose();
                try { source?.Dispose(); } catch { }
                try { sourceStream?.Dispose(); } catch { }
            }
        }

        private static void AddRasterPage(PdfSharp.Pdf.PdfDocument output, DocumentBase doc, PageRef r, int dpi)
        {
            var bmp = DocViewer.RenderComposite(doc, r, dpi, true, false);
            var size = doc.GetPageSize(r.Doc);
            bool rotated = r.Rotation % 180 != 0;
            double wPt = (rotated ? size.Height : size.Width) * 72 / 96, hPt = (rotated ? size.Width : size.Height) * 72 / 96;
            var page = output.AddPage();
            page.Width = XUnit.FromPoint(wPt);
            page.Height = XUnit.FromPoint(hPt);
            var enc = new JpegBitmapEncoder { QualityLevel = 92 };
            enc.Frames.Add(BitmapFrame.Create(new FormatConvertedBitmap(bmp, PixelFormats.Bgr24, null, 0)));
            using (var ms = new MemoryStream())
            {
                enc.Save(ms);
                ms.Position = 0;
                using (var gfx = XGraphics.FromPdfPage(page))
                {
                    var img = XImage.FromStream(ms);
                    gfx.DrawImage(img, 0, 0, wPt, hPt);
                }
            }
        }

        private static byte[] OverlayPng(List<Annotation> anns, Size size, double scale)
        {
            scale = VisualTools.ClampScale(size, scale);
            var dv = new DrawingVisual();
            using (var dc = dv.RenderOpen()) AnnotationPainter.Draw(dc, anns);
            var rtb = new RenderTargetBitmap((int)Math.Ceiling(size.Width * scale), (int)Math.Ceiling(size.Height * scale), 96 * scale, 96 * scale, PixelFormats.Pbgra32);
            rtb.Render(dv);
            var enc = new PngBitmapEncoder();
            enc.Frames.Add(BitmapFrame.Create(rtb));
            using (var ms = new MemoryStream()) { enc.Save(ms); return ms.ToArray(); }
        }

        /// <summary>Объединение нескольких PDF в один.</summary>
        public static void Merge(IEnumerable<string> files, string output)
        {
            using (var outDoc = new PdfSharp.Pdf.PdfDocument())
            {
                outDoc.Info.Creator = "DocuNova";
                foreach (var f in files)
                {
                    var bytes = SafeIO.ReadFile(f);
                    using (var src = PdfReader.Open(new MemoryStream(bytes, false), PdfDocumentOpenMode.Import))
                        foreach (var p in src.Pages) outDoc.AddPage(p);
                }
                outDoc.Save(output);
            }
        }

        public static void SaveImage(BitmapSource bmp, string path)
        {
            BitmapEncoder enc;
            var ext = Path.GetExtension(path).ToLowerInvariant();
            if (ext == ".jpg" || ext == ".jpeg") { enc = new JpegBitmapEncoder { QualityLevel = 93 }; bmp = new FormatConvertedBitmap(bmp, PixelFormats.Bgr24, null, 0); }
            else if (ext == ".tif" || ext == ".tiff") enc = new TiffBitmapEncoder { Compression = TiffCompressOption.Lzw };
            else enc = new PngBitmapEncoder();
            enc.Frames.Add(BitmapFrame.Create(bmp));
            using (var fs = new FileStream(path, FileMode.Create, FileAccess.Write)) enc.Save(fs);
        }
    }
}
