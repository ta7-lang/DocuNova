using System;
using System.Runtime;
using System.Runtime.InteropServices;
using System.Windows.Threading;

namespace DocuNova.Services
{
    /// <summary>
    /// Возврат памяти системе. Изображения страниц живут в неуправляемой памяти и освобождаются
    /// только после сборки мусора, поэтому после прокрутки, масштабирования или закрытия вкладки
    /// (с небольшой задержкой, чтобы не мешать работе) выполняется сборка с уплотнением кучи больших объектов.
    /// </summary>
    public static class MemoryTrim
    {
        private static DispatcherTimer _timer;
        private static DateTime _last = DateTime.MinValue;

        [DllImport("kernel32.dll")]
        private static extern IntPtr GetCurrentProcess();

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool SetProcessWorkingSetSize(IntPtr process, IntPtr min, IntPtr max);

        /// <summary>Запланировать очистку (вызовы в течение 2 с объединяются в одну).</summary>
        public static void Schedule()
        {
            var d = Dispatcher.FromThread(System.Threading.Thread.CurrentThread);
            if (d == null || System.Windows.Application.Current == null || d != System.Windows.Application.Current.Dispatcher) return;
            if (_timer == null)
            {
                _timer = new DispatcherTimer(DispatcherPriority.ApplicationIdle) { Interval = TimeSpan.FromSeconds(2) };
                _timer.Tick += (s, e) => { _timer.Stop(); Collect(false); };
            }
            _timer.Stop();
            _timer.Start();
        }

        /// <summary>Немедленная очистка. trimWorkingSet — дополнительно вернуть системе неиспользуемые страницы памяти
        /// (используется, когда окно свёрнуто).</summary>
        public static void Collect(bool trimWorkingSet)
        {
            try
            {
                // не чаще раза в секунду: полная сборка сама по себе занимает время
                if ((DateTime.UtcNow - _last).TotalMilliseconds < 1000 && !trimWorkingSet) return;
                _last = DateTime.UtcNow;
                GCSettings.LargeObjectHeapCompactionMode = GCLargeObjectHeapCompactionMode.CompactOnce;
                GC.Collect(2, GCCollectionMode.Forced, true, true);
                GC.WaitForPendingFinalizers();
                GC.Collect(2, GCCollectionMode.Forced, false, false);
                if (trimWorkingSet) SetProcessWorkingSetSize(GetCurrentProcess(), (IntPtr)(-1), (IntPtr)(-1));
            }
            catch { }
        }
    }
}
