using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using DocuNova.Core;

namespace DocuNova.Services
{
    /// <summary>Описание темы оформления. Цвета хранятся строками #RRGGBB / #AARRGGBB.</summary>
    public sealed class ThemeDef
    {
        public string Name { get; set; } = "Своя тема";
        public string Bg1 { get; set; } = "#0B0420";
        public string Bg2 { get; set; } = "#1A0B3D";
        public string Panel { get; set; } = "#14102A";
        public string Text { get; set; } = "#F2EEFF";
        public string SubText { get; set; } = "#A9A2C9";
        public string Accent1 { get; set; } = "#FF2BD6";
        public string Accent2 { get; set; } = "#00F0FF";
        public string ViewerBg { get; set; } = "#100A24";
        public double Glow { get; set; } = 0.8;
        public double Radius { get; set; } = 10;
        public double GradientAngle { get; set; } = 135;
        public double PanelOpacity { get; set; } = 0.85;
        public bool IsDark { get; set; } = true;

        public ThemeDef Clone() => (ThemeDef)MemberwiseClone();
    }

    public sealed class AppSettings
    {
        public string ThemeName { get; set; } = "Неон Киберпанк";
        public ThemeDef CustomTheme { get; set; }
        public ReflowSettings Reflow { get; set; } = new ReflowSettings();
        public bool RememberRecent { get; set; } = true;
        public List<string> Recent { get; set; } = new List<string>();
        public string PageMode { get; set; } = "normal"; // см. PageTint.Modes
        public bool TwoPage { get; set; }
        /// <summary>В развороте первая страница (обложка) показывается отдельно.</summary>
        public bool CoverPage { get; set; } = true;
        public bool ShowSidebar { get; set; } = true;
        public double PageGap { get; set; } = 18;
        public bool PageShadows { get; set; } = true;
        /// <summary>Сглаживание текста страниц: auto (как в Windows) | cleartype | grayscale.</summary>
        public string TextSmoothing { get; set; } = "auto";
        /// <summary>Усиление контраста тонких шрифтов: 0 — нет, 1 — слабое, 2 — среднее, 3 — сильное.</summary>
        public int TextContrast { get; set; } = 1;
        /// <summary>Плавная прокрутка колесом мыши.</summary>
        public bool SmoothScroll { get; set; } = true;
        public string FitMode { get; set; } = "width"; // width | page | none
        public string PenColor { get; set; } = "#FFFF2BD6";
        public double PenThickness { get; set; } = 3;
        public double AnnOpacity { get; set; } = 1;
        public double TextSize { get; set; } = 16;
        public string Stamp { get; set; } = "ОДОБРЕНО";
        public bool WarnInternetFiles { get; set; } = true;
        public bool ClearRecentOnExit { get; set; }
        public int ExportDpi { get; set; } = 200;
        public double WindowWidth { get; set; } = 1360;
        public double WindowHeight { get; set; } = 860;
        public bool WindowMaximized { get; set; }
        /// <summary>Открывать документы вкладками в одном окне (а не отдельными окнами).</summary>
        public bool SingleWindow { get; set; } = true;
        /// <summary>Расположение параллельного просмотра: columns (рядом) | rows (друг под другом) | grid (сеткой).</summary>
        public string ParallelLayout { get; set; } = "columns";
        public bool SyncScroll { get; set; }
        public double SidebarWidth { get; set; } = 290;

        // ---------- вкладки и сеанс ----------
        /// <summary>При запуске открывать вкладки, которые были открыты при закрытии программы.</summary>
        public bool RestoreSession { get; set; } = true;
        /// <summary>Вкладки последнего сеанса (в порядке на панели вкладок).</summary>
        public List<SessionTab> Session { get; set; } = new List<SessionTab>();
        /// <summary>Индекс активной вкладки последнего сеанса.</summary>
        public int SessionActive { get; set; }
        /// <summary>Индексы вкладок, показанных в параллельном просмотре (пусто — параллельный просмотр был выключен).</summary>
        public List<int> SessionSplit { get; set; } = new List<int>();
        /// <summary>Возвращаться к месту, где документ читали в прошлый раз.</summary>
        public bool RememberPosition { get; set; } = true;
        /// <summary>Место чтения недавних документов (страница, масштаб) — до 100 записей.</summary>
        public List<SessionTab> Positions { get; set; } = new List<SessionTab>();
        /// <summary>Наибольшая ширина заголовка вкладки (px).</summary>
        public double TabMaxWidth { get; set; } = 220;
        /// <summary>Ширина вкладки уменьшается, чтобы как можно больше вкладок помещалось на экране.</summary>
        public bool CompactTabs { get; set; }

        // ---------- чтение ----------
        /// <summary>Скорость автопрокрутки, пикселей экрана в секунду.</summary>
        public double AutoScrollSpeed { get; set; } = 60;
        /// <summary>Высота светлой полосы линейки чтения (px).</summary>
        public double RulerHeight { get; set; } = 72;
        /// <summary>Затемнение вне полосы линейки чтения (0…0,85).</summary>
        public double RulerShade { get; set; } = 0.45;
        /// <summary>Показывать пометки на страницах (на сохранение и печать не влияет).</summary>
        public bool ShowAnnotations { get; set; } = true;
        /// <summary>Свои тексты штампов.</summary>
        public List<string> CustomStamps { get; set; } = new List<string>();
        /// <summary>Шаг колеса мыши при прокрутке (множитель системной настройки).</summary>
        public double WheelStep { get; set; } = 1.0;

        private static string Dir => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "DocuNova");
        private static string FilePath => Path.Combine(Dir, "settings.json");

        public static AppSettings Load()
        {
            try
            {
                if (File.Exists(FilePath))
                {
                    var fi = new FileInfo(FilePath);
                    if (fi.Length < 1024 * 1024)
                    {
                        var s = JsonSerializer.Deserialize<AppSettings>(File.ReadAllText(FilePath));
                        if (s != null)
                        {
                            s.Reflow = s.Reflow ?? new ReflowSettings();
                            s.Reflow.Light = false;
                            s.Recent = s.Recent ?? new List<string>();
                            s.Session = s.Session ?? new List<SessionTab>();
                            s.SessionSplit = s.SessionSplit ?? new List<int>();
                            s.Positions = s.Positions ?? new List<SessionTab>();
                            s.CustomStamps = s.CustomStamps ?? new List<string>();
                            s.Session.RemoveAll(t => t == null || string.IsNullOrWhiteSpace(t.Path));
                            s.Positions.RemoveAll(t => t == null || string.IsNullOrWhiteSpace(t.Path));
                            if (s.Session.Count > 50) s.Session.RemoveRange(50, s.Session.Count - 50);
                            return s;
                        }
                    }
                }
            }
            catch { }
            return new AppSettings();
        }

        public void Save()
        {
            try
            {
                Directory.CreateDirectory(Dir);
                if (!RememberRecent) Recent.Clear();
                if (Recent.Count > 15) Recent.RemoveRange(15, Recent.Count - 15);
                if (!RememberPosition) Positions.Clear();
                if (Positions.Count > 100) Positions.RemoveRange(100, Positions.Count - 100);
                if (!RestoreSession) { Session.Clear(); SessionSplit.Clear(); }
                var tmp = FilePath + ".tmp";
                File.WriteAllText(tmp, JsonSerializer.Serialize(this, new JsonSerializerOptions { WriteIndented = true }));
                File.Copy(tmp, FilePath, true);
                File.Delete(tmp);
            }
            catch { }
        }

        public void AddRecent(string path)
        {
            if (!RememberRecent || string.IsNullOrEmpty(path)) return;
            Recent.RemoveAll(p => string.Equals(p, path, StringComparison.OrdinalIgnoreCase));
            Recent.Insert(0, path);
            if (Recent.Count > 15) Recent.RemoveRange(15, Recent.Count - 15);
        }

        /// <summary>Запоминает место чтения документа (последнее — первым).</summary>
        public void RememberPlace(SessionTab place)
        {
            if (!RememberPosition || place == null || string.IsNullOrEmpty(place.Path)) return;
            Positions.RemoveAll(p => string.Equals(p.Path, place.Path, StringComparison.OrdinalIgnoreCase));
            Positions.Insert(0, place.Clone());
            if (Positions.Count > 100) Positions.RemoveRange(100, Positions.Count - 100);
        }

        public SessionTab FindPlace(string path)
        {
            if (!RememberPosition || string.IsNullOrEmpty(path)) return null;
            return Positions.Find(p => string.Equals(p.Path, path, StringComparison.OrdinalIgnoreCase));
        }
    }

    /// <summary>Состояние открытого документа: файл, место чтения и вид. Используется для восстановления вкладок.</summary>
    public sealed class SessionTab
    {
        public string Path { get; set; }
        /// <summary>Страница у верхнего края окна (с нуля).</summary>
        public int Page { get; set; }
        /// <summary>Доля прокрутки внутри страницы.</summary>
        public double Offset { get; set; }
        public double Zoom { get; set; } = 1;
        /// <summary>width | page | none.</summary>
        public string Fit { get; set; } = "width";
        public bool TwoPage { get; set; }
        /// <summary>Закладки: номера страниц в файле.</summary>
        public List<int> Bookmarks { get; set; }

        public SessionTab Clone()
        {
            var c = (SessionTab)MemberwiseClone();
            c.Bookmarks = Bookmarks == null ? null : new List<int>(Bookmarks);
            return c;
        }
    }
}
