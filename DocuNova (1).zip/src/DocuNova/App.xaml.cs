using System;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;
using DocuNova.Services;
using DocuNova.Themes;

namespace DocuNova
{
    public partial class App : Application
    {
        public static AppSettings Settings { get; private set; }
        private SingleInstance _instance;
        private readonly System.Collections.Generic.List<string> _pending = new System.Collections.Generic.List<string>();

        protected override void OnStartup(StartupEventArgs e)
        {
            // Усиление защиты процесса — до загрузки любых документов
            Hardening.Apply();

            DispatcherUnhandledException += OnUiException;
            TaskScheduler.UnobservedTaskException += (s, a) => a.SetObserved();
            AppDomain.CurrentDomain.UnhandledException += (s, a) =>
            {
                try { MessageBox.Show("Критическая ошибка: " + (a.ExceptionObject as Exception)?.Message, "DocuNova", MessageBoxButton.OK, MessageBoxImage.Error); } catch { }
            };

            base.OnStartup(e);

            // служебный режим для установщика: очистка системного кэша эскизов
            if (e.Args != null && e.Args.Any(a => string.Equals(a, "/clear-thumbcache", StringComparison.OrdinalIgnoreCase)))
            {
                try { ShellIntegration.ClearThumbnailCache(); } catch { }
                Shutdown();
                return;
            }

            Settings = AppSettings.Load();
            var files = (e.Args ?? new string[0])
                .Where(a => !string.IsNullOrWhiteSpace(a) && !a.StartsWith("/") && !a.StartsWith("-"))
                .Select(FullPath).ToList();

            // Уже запущенное окно? Тогда документы открываются в нём новыми вкладками.
            if (Settings.SingleWindow)
            {
                _instance = SingleInstance.TryAcquire();
                if (_instance == null)
                {
                    if (SingleInstance.SendToPrimary(files)) { Shutdown(); return; }
                    // запущенный экземпляр не отвечает — открываем отдельное окно
                }
                else _instance.StartListening(paths => Dispatcher.BeginInvoke(new Action(() => OnFilesFromOtherInstance(paths))));
            }

            ThemeManager.Apply(ThemeManager.Find(Settings.ThemeName, Settings.CustomTheme));

            var w = new MainWindow();
            MainWindow = w;
            w.Show();
            if (_pending.Count > 0) { files.AddRange(_pending); _pending.Clear(); }
            // Вкладки прошлого сеанса восстанавливает только основное окно. Если документы открываются
            // отдельными окнами (настройка выключена), сеанс восстанавливается лишь при запуске без файлов.
            bool restore = Settings.SingleWindow ? _instance != null : files.Count == 0;
            w.StartUp(files, restore);
        }

        private static string FullPath(string p)
        {
            try { return System.IO.Path.GetFullPath(p.Trim().Trim('"')); } catch { return p; }
        }

        private void OnFilesFromOtherInstance(string[] paths)
        {
            if (MainWindow is MainWindow w) w.ReceiveFiles(paths);
            else _pending.AddRange(paths);
        }

        private void OnUiException(object sender, DispatcherUnhandledExceptionEventArgs e)
        {
            e.Handled = true;
            try
            {
                MessageBox.Show(MainWindow, "Произошла ошибка, но приложение продолжает работу:\n\n" + e.Exception.Message,
                    "DocuNova", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
            catch { }
        }

        protected override void OnExit(ExitEventArgs e)
        {
            try { _instance?.Dispose(); } catch { }
            try
            {
                if (Settings != null)
                {
                    if (Settings.ClearRecentOnExit) { Settings.Recent.Clear(); Settings.Positions.Clear(); }
                    Settings.Save();
                }
            }
            catch { }
            base.OnExit(e);
        }
    }
}
