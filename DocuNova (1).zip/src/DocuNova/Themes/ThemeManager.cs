using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Effects;
using DocuNova.Services;

namespace DocuNova.Themes
{
    /// <summary>Темы оформления: готовые пресеты и применение темы к ресурсам приложения.</summary>
    public static class ThemeManager
    {
        public static readonly List<ThemeDef> Presets = new List<ThemeDef>
        {
            new ThemeDef { Name = "Неон Киберпанк", Bg1 = "#0B0420", Bg2 = "#1A0B3D", Panel = "#160F30", Text = "#F4EEFF", SubText = "#B0A6D6", Accent1 = "#FF2BD6", Accent2 = "#00F0FF", ViewerBg = "#0E0822", Glow = 0.9 },
            new ThemeDef { Name = "Синтвейв", Bg1 = "#1B0B2E", Bg2 = "#3A0F3F", Panel = "#24102F", Text = "#FFEFF8", SubText = "#D8A9C8", Accent1 = "#FF6EC7", Accent2 = "#FFB86C", ViewerBg = "#1A0A26", Glow = 0.85 },
            new ThemeDef { Name = "Токсичный неон", Bg1 = "#03110A", Bg2 = "#0A2A1A", Panel = "#0B1E14", Text = "#EAFFF2", SubText = "#93C9A9", Accent1 = "#39FF14", Accent2 = "#00FFC6", ViewerBg = "#06160D", Glow = 0.9 },
            new ThemeDef { Name = "Северное сияние", Bg1 = "#06141F", Bg2 = "#13294A", Panel = "#0C1E30", Text = "#EAF6FF", SubText = "#9BB8D0", Accent1 = "#00FFA3", Accent2 = "#7B61FF", ViewerBg = "#081725", Glow = 0.75 },
            new ThemeDef { Name = "Лазерный лёд", Bg1 = "#020B1A", Bg2 = "#0A1F44", Panel = "#0A1730", Text = "#EAF4FF", SubText = "#93AFD6", Accent1 = "#2E9BFF", Accent2 = "#A4F4FF", ViewerBg = "#06122A", Glow = 0.8 },
            new ThemeDef { Name = "Кровавая луна", Bg1 = "#16030A", Bg2 = "#3A0A16", Panel = "#240812", Text = "#FFEDEF", SubText = "#D69AA6", Accent1 = "#FF1E56", Accent2 = "#FF9A3C", ViewerBg = "#1A050C", Glow = 0.85 },
            new ThemeDef { Name = "Закат", Bg1 = "#2A0E12", Bg2 = "#4A1F0F", Panel = "#33150F", Text = "#FFF3EA", SubText = "#E0B8A0", Accent1 = "#FF512F", Accent2 = "#F09819", ViewerBg = "#250C0C", Glow = 0.6 },
            new ThemeDef { Name = "Океан", Bg1 = "#031B2E", Bg2 = "#06395C", Panel = "#062841", Text = "#E8F7FF", SubText = "#97C3DD", Accent1 = "#00C6FF", Accent2 = "#0072FF", ViewerBg = "#04223A", Glow = 0.5 },
            new ThemeDef { Name = "Полночь", Bg1 = "#121218", Bg2 = "#1E1E2A", Panel = "#1A1A24", Text = "#ECECF4", SubText = "#9C9CB0", Accent1 = "#8A7CFF", Accent2 = "#5AC8FA", ViewerBg = "#15151D", Glow = 0.35 },
            new ThemeDef { Name = "Графит", Bg1 = "#1C1C1C", Bg2 = "#2A2A2A", Panel = "#232323", Text = "#F0F0F0", SubText = "#A8A8A8", Accent1 = "#FFFFFF", Accent2 = "#9A9A9A", ViewerBg = "#1A1A1A", Glow = 0.15 },
            new ThemeDef { Name = "Светлая", Bg1 = "#F4F6FB", Bg2 = "#E3E8F6", Panel = "#FFFFFF", Text = "#1C2033", SubText = "#5F667F", Accent1 = "#4F6BFF", Accent2 = "#B05CFF", ViewerBg = "#DDE2EF", Glow = 0.35, IsDark = false, PanelOpacity = 0.92 },
            new ThemeDef { Name = "Мятная", Bg1 = "#EFFBF6", Bg2 = "#D6F3E7", Panel = "#FFFFFF", Text = "#173328", SubText = "#557A6B", Accent1 = "#00B894", Accent2 = "#0984E3", ViewerBg = "#D2EADF", Glow = 0.3, IsDark = false, PanelOpacity = 0.92 },
            new ThemeDef { Name = "Сепия", Bg1 = "#F3E9D2", Bg2 = "#E6D5AE", Panel = "#FBF4E4", Text = "#3B2F20", SubText = "#7A6A50", Accent1 = "#A0522D", Accent2 = "#D2691E", ViewerBg = "#E2D3B0", Glow = 0.2, IsDark = false, PanelOpacity = 0.95 },
            // однотонные пастельные темы: фон без градиента, мягкие приглушённые цвета
            new ThemeDef { Name = "Пастель · Лаванда", Bg1 = "#EEE8F7", Bg2 = "#EEE8F7", Panel = "#F8F5FC", Text = "#2E2640", SubText = "#6E6386", Accent1 = "#9B87D0", Accent2 = "#B9A6E3", ViewerBg = "#E3DBF0", Glow = 0.12, Radius = 12, PanelOpacity = 0.97, IsDark = false },
            new ThemeDef { Name = "Пастель · Персик", Bg1 = "#FAEDE5", Bg2 = "#FAEDE5", Panel = "#FFF8F3", Text = "#3D2A22", SubText = "#86695C", Accent1 = "#E08F6E", Accent2 = "#EBA88A", ViewerBg = "#F2DFD3", Glow = 0.12, Radius = 12, PanelOpacity = 0.97, IsDark = false },
            new ThemeDef { Name = "Пастель · Мята", Bg1 = "#E4F3EC", Bg2 = "#E4F3EC", Panel = "#F4FBF8", Text = "#20352D", SubText = "#5E7D71", Accent1 = "#5DB394", Accent2 = "#7FC6AC", ViewerBg = "#D5EBE1", Glow = 0.12, Radius = 12, PanelOpacity = 0.97, IsDark = false },
            new ThemeDef { Name = "Пастель · Небо", Bg1 = "#E5EFF9", Bg2 = "#E5EFF9", Panel = "#F5F9FE", Text = "#1F2D3D", SubText = "#5D7188", Accent1 = "#6E9FD6", Accent2 = "#8DB6E3", ViewerBg = "#D6E3F2", Glow = 0.12, Radius = 12, PanelOpacity = 0.97, IsDark = false },
            new ThemeDef { Name = "Пастель · Роза", Bg1 = "#F8E7ED", Bg2 = "#F8E7ED", Panel = "#FEF6F9", Text = "#3B2330", SubText = "#86617A", Accent1 = "#D97F9F", Accent2 = "#E59BB5", ViewerBg = "#EFD6DF", Glow = 0.12, Radius = 12, PanelOpacity = 0.97, IsDark = false },
            new ThemeDef { Name = "Пастель · Лимон", Bg1 = "#F9F5DE", Bg2 = "#F9F5DE", Panel = "#FFFDF2", Text = "#36321C", SubText = "#7D7550", Accent1 = "#C9AA3A", Accent2 = "#D8BE5E", ViewerBg = "#EFE8C9", Glow = 0.12, Radius = 12, PanelOpacity = 0.97, IsDark = false },
            new ThemeDef { Name = "Пастель · Шалфей", Bg1 = "#E8EEE3", Bg2 = "#E8EEE3", Panel = "#F6F9F3", Text = "#2A3324", SubText = "#697861", Accent1 = "#82A070", Accent2 = "#9AB58B", ViewerBg = "#DCE4D5", Glow = 0.12, Radius = 12, PanelOpacity = 0.97, IsDark = false },
            new ThemeDef { Name = "Пастель · Песок", Bg1 = "#F2ECE3", Bg2 = "#F2ECE3", Panel = "#FBF8F3", Text = "#352E25", SubText = "#7B6F60", Accent1 = "#AE906A", Accent2 = "#C3A884", ViewerBg = "#E6DDCF", Glow = 0.12, Radius = 12, PanelOpacity = 0.97, IsDark = false },
            new ThemeDef { Name = "Пастель · Аква", Bg1 = "#E2F4F5", Bg2 = "#E2F4F5", Panel = "#F3FBFB", Text = "#1E3436", SubText = "#5B7C7F", Accent1 = "#4FADB3", Accent2 = "#76C4C9", ViewerBg = "#D2EAEB", Glow = 0.12, Radius = 12, PanelOpacity = 0.97, IsDark = false },
            new ThemeDef { Name = "Пастель · Туман", Bg1 = "#ECEEF2", Bg2 = "#ECEEF2", Panel = "#F8F9FB", Text = "#262A33", SubText = "#697080", Accent1 = "#7F8DAA", Accent2 = "#99A5BE", ViewerBg = "#DEE2E9", Glow = 0.12, Radius = 12, PanelOpacity = 0.97, IsDark = false },
            new ThemeDef { Name = "Пастель · Сумерки", Bg1 = "#2C2B36", Bg2 = "#2C2B36", Panel = "#34333F", Text = "#ECE8F5", SubText = "#A9A4BC", Accent1 = "#B8A9E6", Accent2 = "#A6C8E8", ViewerBg = "#25242E", Glow = 0.12, Radius = 12, PanelOpacity = 0.97 },
            new ThemeDef { Name = "Пастель · Мятный графит", Bg1 = "#2A302E", Bg2 = "#2A302E", Panel = "#313836", Text = "#E7F0EC", SubText = "#A3B3AC", Accent1 = "#9ED9C0", Accent2 = "#B5D8E8", ViewerBg = "#232826", Glow = 0.12, Radius = 12, PanelOpacity = 0.97 },
            new ThemeDef { Name = "Высокий контраст", Bg1 = "#000000", Bg2 = "#000000", Panel = "#000000", Text = "#FFFFFF", SubText = "#FFFF00", Accent1 = "#FFFF00", Accent2 = "#00FFFF", ViewerBg = "#000000", Glow = 0, Radius = 2, PanelOpacity = 1 },
        };

        public static ThemeDef Current { get; private set; } = Presets[0];

        public static ThemeDef Find(string name, ThemeDef custom)
        {
            if (custom != null && name == custom.Name) return custom;
            return Presets.FirstOrDefault(p => p.Name == name) ?? Presets[0];
        }

        public static Color C(string hex, Color fallback)
        {
            try
            {
                if (!string.IsNullOrWhiteSpace(hex) && ColorConverter.ConvertFromString(hex.Trim()) is Color c) return c;
            }
            catch { }
            return fallback;
        }

        public static Color WithA(Color c, byte a) => Color.FromArgb(a, c.R, c.G, c.B);

        private static T F<T>(T f) where T : Freezable { f.Freeze(); return f; }

        public static LinearGradientBrush Gradient(Color a, Color b, double angleDeg)
        {
            double rad = angleDeg * Math.PI / 180;
            double dx = Math.Cos(rad) * 0.5, dy = Math.Sin(rad) * 0.5;
            var br = new LinearGradientBrush
            {
                StartPoint = new Point(0.5 - dx, 0.5 - dy),
                EndPoint = new Point(0.5 + dx, 0.5 + dy)
            };
            br.GradientStops.Add(new GradientStop(a, 0));
            br.GradientStops.Add(new GradientStop(b, 1));
            return br;
        }

        public static void Apply(ThemeDef t)
        {
            Current = t;
            var res = Application.Current.Resources;
            var bg1 = C(t.Bg1, Colors.Black); var bg2 = C(t.Bg2, Colors.Black);
            var panel = C(t.Panel, Colors.Black);
            var text = C(t.Text, Colors.White); var sub = C(t.SubText, Colors.Gray);
            var a1 = C(t.Accent1, Colors.Magenta); var a2 = C(t.Accent2, Colors.Cyan);
            var viewer = C(t.ViewerBg, bg1);
            byte pa = (byte)Math.Round(255 * Math.Max(0.4, Math.Min(1, t.PanelOpacity)));

            res["BgBrush"] = F(Gradient(bg1, bg2, t.GradientAngle));
            res["PanelBrush"] = F(new SolidColorBrush(WithA(panel, pa)));
            res["PanelSolidBrush"] = F(new SolidColorBrush(panel));
            res["PanelBorderBrush"] = F(new SolidColorBrush(WithA(a1, (byte)(t.IsDark ? 0x55 : 0x40))));
            res["DividerBrush"] = F(new SolidColorBrush(WithA(text, 0x22)));
            res["FgBrush"] = F(new SolidColorBrush(text));
            res["SubFgBrush"] = F(new SolidColorBrush(sub));
            res["AccentBrush"] = F(Gradient(a1, a2, 0));
            res["AccentDiagBrush"] = F(Gradient(a1, a2, 45));
            res["Accent1Brush"] = F(new SolidColorBrush(a1));
            res["Accent2Brush"] = F(new SolidColorBrush(a2));
            res["AccentSoftBrush"] = F(Gradient(WithA(a1, 0x38), WithA(a2, 0x38), 0));
            res["HoverBrush"] = F(new SolidColorBrush(WithA(text, 0x16)));
            res["PressBrush"] = F(new SolidColorBrush(WithA(text, 0x26)));
            res["ButtonBgBrush"] = F(new SolidColorBrush(WithA(text, 0x0A)));
            res["InputBgBrush"] = F(new SolidColorBrush(t.IsDark ? Color.FromArgb(0x55, 0, 0, 0) : Color.FromArgb(0xFF, 0xFF, 0xFF, 0xFF)));
            res["ViewerBgBrush"] = F(new SolidColorBrush(viewer));
            // на светлых пастельных акцентах белый текст плохо читается — тогда текст на кнопках тёмный
            bool darkOnAccent = (IsLight(a1) && IsLight(a2)) || (!t.IsDark && (Lum(a1) + Lum(a2)) / 2 > 145);
            res["OnAccentBrush"] = F(new SolidColorBrush(darkOnAccent ? Color.FromRgb(15, 15, 25) : Colors.White));
            res["SelectionBrush"] = F(new SolidColorBrush(WithA(a2, 0x55)));
            res["Accent1Color"] = a1;
            res["Accent2Color"] = a2;
            res["FgColor"] = text;
            res["CornerRadius"] = new CornerRadius(t.Radius);
            res["CornerRadiusSmall"] = new CornerRadius(Math.Max(0, t.Radius * 0.6));
            res["CornerRadiusLarge"] = new CornerRadius(t.Radius * 1.6);

            double glow = Math.Max(0, Math.Min(1, t.Glow));
            res["GlowEffect"] = F(new DropShadowEffect { Color = a1, BlurRadius = 6 + 18 * glow, ShadowDepth = 0, Opacity = 0.25 + 0.7 * glow });
            res["GlowEffect2"] = F(new DropShadowEffect { Color = a2, BlurRadius = 6 + 18 * glow, ShadowDepth = 0, Opacity = 0.25 + 0.7 * glow });
            res["SoftShadow"] = F(new DropShadowEffect { Color = Colors.Black, BlurRadius = 18, ShadowDepth = 3, Opacity = t.IsDark ? 0.55 : 0.18, Direction = 270 });
            res["PageShadow"] = F(new DropShadowEffect { Color = glow > 0.5 && t.IsDark ? a1 : Colors.Black, BlurRadius = 22, ShadowDepth = glow > 0.5 && t.IsDark ? 0 : 4, Opacity = t.IsDark ? 0.45 * Math.Max(0.4, glow) : 0.25, Direction = 270 });
            res["TextGlow"] = F(new DropShadowEffect { Color = a1, BlurRadius = 4 + 12 * glow, ShadowDepth = 0, Opacity = glow });
        }

        private static double Lum(Color c) => 0.299 * c.R + 0.587 * c.G + 0.114 * c.B;

        private static bool IsLight(Color c) => Lum(c) > 170;
    }
}
