using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Media;

namespace DocuNova.Viewer
{
    public enum Tool
    {
        Hand, Select, Highlight, Underline, Strike, Pen, Marker, Rect, Ellipse, Arrow, Line, Text, Note, Stamp, Redact, WhiteOut, Eraser
    }

    /// <summary>Пометка на странице. Координаты — в DIP исходной (неповёрнутой пользователем) страницы.</summary>
    public sealed class Annotation
    {
        public Tool Kind { get; set; }
        public Color Color { get; set; }
        public double Thickness { get; set; } = 3;
        public double Opacity { get; set; } = 1;
        public List<Point> Points { get; set; } = new List<Point>();
        public List<Rect> Rects { get; set; } = new List<Rect>();
        public string Text { get; set; }
        public double FontSize { get; set; } = 16;
        public DateTime Created { get; } = DateTime.Now;

        public Rect Bounds
        {
            get
            {
                Rect r = Rect.Empty;
                foreach (var p in Points) r.Union(p);
                foreach (var x in Rects) r.Union(x);
                if (Kind == Tool.Text || Kind == Tool.Note || Kind == Tool.Stamp)
                {
                    var sz = TextSize(this);
                    if (Points.Count > 0) r.Union(new Rect(Points[0], sz));
                }
                if (!r.IsEmpty) r.Inflate(Thickness / 2 + 2, Thickness / 2 + 2);
                return r;
            }
        }

        public bool NeedsRaster => Kind == Tool.Redact || Kind == Tool.WhiteOut;

        public string KindName
        {
            get
            {
                switch (Kind)
                {
                    case Tool.Highlight: return "Выделение";
                    case Tool.Underline: return "Подчёркивание";
                    case Tool.Strike: return "Зачёркивание";
                    case Tool.Pen: return "Перо";
                    case Tool.Marker: return "Фломастер";
                    case Tool.Rect: return "Прямоугольник";
                    case Tool.Ellipse: return "Овал";
                    case Tool.Arrow: return "Стрелка";
                    case Tool.Line: return "Линия";
                    case Tool.Text: return "Текст";
                    case Tool.Note: return "Заметка";
                    case Tool.Stamp: return "Штамп";
                    case Tool.Redact: return "Скрытие";
                    case Tool.WhiteOut: return "Замазка";
                    default: return Kind.ToString();
                }
            }
        }

        public static Size TextSize(Annotation a)
        {
            var ft = Format(a);
            if (a.Kind == Tool.Note) return new Size(Math.Max(140, ft.Width + 24), ft.Height + 30);
            if (a.Kind == Tool.Stamp) return new Size(ft.Width + 28, ft.Height + 14);
            return new Size(ft.Width + 4, ft.Height + 2);
        }

        internal static FormattedText Format(Annotation a)
        {
            var weight = a.Kind == Tool.Stamp ? FontWeights.Black : FontWeights.Normal;
            var ft = new FormattedText(a.Text ?? "", CultureInfo.CurrentUICulture, FlowDirection.LeftToRight,
                new Typeface(new FontFamily("Segoe UI"), FontStyles.Normal, weight, FontStretches.Normal),
                Math.Max(6, a.Kind == Tool.Note ? 13 : a.FontSize), new SolidColorBrush(a.Color), 1.0);
            if (a.Kind == Tool.Note) ft.MaxTextWidth = 220;
            return ft;
        }
    }

    /// <summary>Отрисовка пометок — общая для экрана, экспорта и печати.</summary>
    public static class AnnotationPainter
    {
        public static void Draw(DrawingContext dc, IEnumerable<Annotation> anns)
        {
            foreach (var a in anns) Draw(dc, a);
        }

        public static void Draw(DrawingContext dc, Annotation a)
        {
            var color = a.Color;
            var brush = new SolidColorBrush(color); brush.Freeze();
            switch (a.Kind)
            {
                case Tool.Highlight:
                {
                    var hb = new SolidColorBrush(Color.FromArgb((byte)(110 * a.Opacity), color.R, color.G, color.B)); hb.Freeze();
                    foreach (var r in a.Rects) dc.DrawRoundedRectangle(hb, null, r, 2, 2);
                    break;
                }
                case Tool.Underline:
                case Tool.Strike:
                {
                    var pen = new Pen(brush, Math.Max(1, a.Thickness * 0.6)) { StartLineCap = PenLineCap.Round, EndLineCap = PenLineCap.Round };
                    pen.Freeze();
                    foreach (var r in a.Rects)
                    {
                        double y = a.Kind == Tool.Underline ? r.Bottom - 1 : r.Top + r.Height * 0.55;
                        dc.DrawLine(pen, new Point(r.Left, y), new Point(r.Right, y));
                    }
                    break;
                }
                case Tool.Pen:
                case Tool.Marker:
                {
                    if (a.Points.Count < 2) break;
                    var b2 = a.Kind == Tool.Marker ? new SolidColorBrush(Color.FromArgb((byte)(120 * a.Opacity), color.R, color.G, color.B)) : new SolidColorBrush(Color.FromArgb((byte)(255 * a.Opacity), color.R, color.G, color.B));
                    b2.Freeze();
                    var pen = new Pen(b2, a.Kind == Tool.Marker ? a.Thickness * 4 : a.Thickness)
                    { StartLineCap = PenLineCap.Round, EndLineCap = PenLineCap.Round, LineJoin = PenLineJoin.Round };
                    pen.Freeze();
                    var g = new StreamGeometry();
                    using (var ctx = g.Open())
                    {
                        ctx.BeginFigure(a.Points[0], false, false);
                        ctx.PolyLineTo(a.Points.Skip(1).ToList(), true, true);
                    }
                    g.Freeze();
                    dc.DrawGeometry(null, pen, g);
                    break;
                }
                case Tool.Rect:
                case Tool.Ellipse:
                {
                    if (a.Points.Count < 2) break;
                    var r = new Rect(a.Points[0], a.Points[a.Points.Count - 1]);
                    var pen = new Pen(new SolidColorBrush(Color.FromArgb((byte)(255 * a.Opacity), color.R, color.G, color.B)), a.Thickness) { LineJoin = PenLineJoin.Round };
                    pen.Freeze();
                    if (a.Kind == Tool.Rect) dc.DrawRoundedRectangle(null, pen, r, 2, 2);
                    else dc.DrawEllipse(null, pen, new Point(r.Left + r.Width / 2, r.Top + r.Height / 2), r.Width / 2, r.Height / 2);
                    break;
                }
                case Tool.Line:
                case Tool.Arrow:
                {
                    if (a.Points.Count < 2) break;
                    var p1 = a.Points[0]; var p2 = a.Points[a.Points.Count - 1];
                    var pen = new Pen(new SolidColorBrush(Color.FromArgb((byte)(255 * a.Opacity), color.R, color.G, color.B)), a.Thickness) { StartLineCap = PenLineCap.Round, EndLineCap = PenLineCap.Round };
                    pen.Freeze();
                    dc.DrawLine(pen, p1, p2);
                    if (a.Kind == Tool.Arrow)
                    {
                        var v = p2 - p1;
                        if (v.Length > 0.1)
                        {
                            v.Normalize();
                            double len = 10 + a.Thickness * 3;
                            var n = new Vector(-v.Y, v.X);
                            var b1 = p2 - v * len + n * len * 0.5;
                            var b3 = p2 - v * len - n * len * 0.5;
                            var g = new StreamGeometry();
                            using (var ctx = g.Open())
                            {
                                ctx.BeginFigure(p2, true, true);
                                ctx.LineTo(b1, true, true);
                                ctx.LineTo(b3, true, true);
                            }
                            g.Freeze();
                            dc.DrawGeometry(pen.Brush, null, g);
                        }
                    }
                    break;
                }
                case Tool.Text:
                {
                    if (a.Points.Count == 0) break;
                    dc.DrawText(Annotation.Format(a), a.Points[0]);
                    break;
                }
                case Tool.Note:
                {
                    if (a.Points.Count == 0) break;
                    var ft = Annotation.Format(new Annotation { Kind = Tool.Note, Text = a.Text, Color = Color.FromRgb(40, 36, 10) });
                    var sz = Annotation.TextSize(a);
                    var r = new Rect(a.Points[0], sz);
                    var bg = new SolidColorBrush(Color.FromRgb(255, 236, 120)); bg.Freeze();
                    var edge = new Pen(new SolidColorBrush(Color.FromRgb(214, 180, 40)), 1); edge.Freeze();
                    dc.DrawRoundedRectangle(bg, edge, r, 4, 4);
                    var bar = new SolidColorBrush(Color.FromRgb(245, 200, 40)); bar.Freeze();
                    dc.DrawRectangle(bar, null, new Rect(r.Left, r.Top, r.Width, 6));
                    dc.DrawText(ft, new Point(r.Left + 10, r.Top + 14));
                    break;
                }
                case Tool.Stamp:
                {
                    if (a.Points.Count == 0) break;
                    var ft = Annotation.Format(a);
                    var sz = Annotation.TextSize(a);
                    var r = new Rect(a.Points[0], sz);
                    var pen = new Pen(brush, 3); pen.Freeze();
                    dc.PushTransform(new RotateTransform(-8, r.Left + r.Width / 2, r.Top + r.Height / 2));
                    dc.PushOpacity(0.85 * a.Opacity);
                    dc.DrawRoundedRectangle(null, pen, r, 6, 6);
                    var inner = r; inner.Inflate(-4, -4);
                    var pen2 = new Pen(brush, 1); pen2.Freeze();
                    dc.DrawRoundedRectangle(null, pen2, inner, 4, 4);
                    dc.DrawText(ft, new Point(r.Left + 14, r.Top + 7));
                    dc.Pop(); dc.Pop();
                    break;
                }
                case Tool.Redact:
                case Tool.WhiteOut:
                {
                    if (a.Points.Count < 2) break;
                    var r = new Rect(a.Points[0], a.Points[a.Points.Count - 1]);
                    dc.DrawRectangle(a.Kind == Tool.Redact ? Brushes.Black : Brushes.White, null, r);
                    break;
                }
            }
        }

        public static bool HitTest(Annotation a, Point p)
        {
            var b = a.Bounds;
            if (b.IsEmpty) return false;
            b.Inflate(4, 4);
            if (!b.Contains(p)) return false;
            if (a.Kind == Tool.Pen || a.Kind == Tool.Marker || a.Kind == Tool.Line || a.Kind == Tool.Arrow)
            {
                double tol = Math.Max(6, a.Thickness * (a.Kind == Tool.Marker ? 2.5 : 1.5));
                for (int i = 1; i < a.Points.Count; i++)
                    if (DistToSegment(p, a.Points[i - 1], a.Points[i]) <= tol) return true;
                return false;
            }
            return true;
        }

        private static double DistToSegment(Point p, Point a, Point b)
        {
            var ab = b - a; var ap = p - a;
            double len2 = ab.LengthSquared;
            if (len2 < 1e-6) return ap.Length;
            double t = Math.Max(0, Math.Min(1, (ap.X * ab.X + ap.Y * ab.Y) / len2));
            var proj = a + ab * t;
            return (p - proj).Length;
        }
    }
}
