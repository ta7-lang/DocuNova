using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using DocuNova.Core;
using DocuNova.Services;

namespace DocuNova.Views
{
    /// <summary>Справка: все инструменты с пояснениями и горячими клавишами, форматы, о программе.</summary>
    public sealed class HelpWindow : ThemedWindow
    {
        public HelpWindow()
        {
            Heading = "Справка DocuNova";
            Width = 820; Height = 760; MinWidth = 600; MinHeight = 420;
            var tabs = new TabControl { Margin = new Thickness(16, 0, 16, 14) };
            tabs.Items.Add(new TabItem { Header = "Инструменты", Content = Wrap(ToolsPage()) });
            tabs.Items.Add(new TabItem { Header = "Форматы", Content = Wrap(FormatsPage()) });
            tabs.Items.Add(new TabItem { Header = "О программе", Content = Wrap(AboutPage()) });
            Body.Children.Add(tabs);
        }

        private static ScrollViewer Wrap(UIElement e) => new ScrollViewer { Content = e, VerticalScrollBarVisibility = ScrollBarVisibility.Auto, Padding = new Thickness(0, 4, 8, 0) };

        private UIElement ToolsPage()
        {
            var sp = new StackPanel();
            var iconFont = (FontFamily)FindResource("IconFont");
            foreach (var group in ToolCatalog.All.GroupBy(t => t.Group))
            {
                var head = new TextBlock { Text = group.Key };
                head.SetResourceReference(StyleProperty, "SectionTitle");
                sp.Children.Add(head);
                foreach (var t in group)
                {
                    var card = new Border { Margin = new Thickness(0, 3, 0, 3), Padding = new Thickness(12, 9, 12, 9) };
                    card.SetResourceReference(StyleProperty, "Card");
                    var dp = new DockPanel();
                    var icon = new Border { Width = 38, Height = 38, CornerRadius = new CornerRadius(9), Margin = new Thickness(0, 0, 12, 0), VerticalAlignment = VerticalAlignment.Top };
                    icon.SetResourceReference(Border.BackgroundProperty, "AccentBrush");
                    icon.SetResourceReference(EffectProperty, "GlowEffect");
                    var glyph = new TextBlock { Text = t.Icon, FontFamily = iconFont, FontSize = 18, HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center };
                    glyph.SetResourceReference(TextBlock.ForegroundProperty, "OnAccentBrush");
                    icon.Child = glyph;
                    DockPanel.SetDock(icon, Dock.Left);
                    dp.Children.Add(icon);
                    if (!string.IsNullOrEmpty(t.Hotkey))
                    {
                        var hk = new Border { CornerRadius = new CornerRadius(5), Padding = new Thickness(8, 2, 8, 2), VerticalAlignment = VerticalAlignment.Top, Margin = new Thickness(10, 0, 0, 0) };
                        hk.SetResourceReference(Border.BackgroundProperty, "HoverBrush");
                        hk.Child = new TextBlock { Text = t.Hotkey, FontFamily = new FontFamily("Consolas, Segoe UI"), FontSize = 12 };
                        DockPanel.SetDock(hk, Dock.Right);
                        dp.Children.Add(hk);
                    }
                    var text = new StackPanel();
                    text.Children.Add(new TextBlock { Text = t.Title, FontWeight = FontWeights.SemiBold, FontSize = 14 });
                    var d = new TextBlock { Text = t.Description, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 2, 0, 0) };
                    d.SetResourceReference(TextBlock.ForegroundProperty, "SubFgBrush");
                    text.Children.Add(d);
                    dp.Children.Add(text);
                    card.Child = dp;
                    sp.Children.Add(card);
                }
            }
            var more = new TextBlock { Text = "Ещё: колесо мыши с Ctrl — масштаб, с Shift — горизонтальная прокрутка; двойной щелчок по надписи или заметке (инструмент «Рука») — изменить текст; Alt+←/→ или боковые кнопки мыши — назад / вперёд по переходам; Ctrl+G — к странице; Ctrl+U — линейка чтения; Ctrl+Shift+A — автопрокрутка; правый щелчок по странице или эскизу — быстрые действия; ←/→ — листание, Home/End — начало и конец документа.", TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 12, 0, 8) };
            more.SetResourceReference(StyleProperty, "Hint");
            sp.Children.Add(more);
            return sp;
        }

        private UIElement FormatsPage()
        {
            var sp = new StackPanel();
            foreach (var f in DocumentLoader.Formats)
            {
                var card = new Border { Margin = new Thickness(0, 3, 0, 3), Padding = new Thickness(12, 8, 12, 8) };
                card.SetResourceReference(StyleProperty, "Card");
                var s2 = new StackPanel();
                s2.Children.Add(new TextBlock { Text = f.Name, FontWeight = FontWeights.SemiBold });
                var e = new TextBlock { Text = string.Join("  ", f.Ext), TextWrapping = TextWrapping.Wrap };
                e.SetResourceReference(TextBlock.ForegroundProperty, "SubFgBrush");
                s2.Children.Add(e);
                card.Child = s2;
                sp.Children.Add(card);
            }
            var note = new TextBlock
            {
                Text = "Формат определяется по содержимому файла, а не только по расширению — подмена расширения распознаётся. Книги с DRM (защитой правообладателя) не открываются. Для DjVu, CBR и старых XLS/PPT используйте конвертацию в PDF, CBZ, XLSX, PPTX.",
                TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 12, 0, 8)
            };
            note.SetResourceReference(StyleProperty, "Hint");
            sp.Children.Add(note);
            return sp;
        }

        private UIElement AboutPage()
        {
            var sp = new StackPanel { Margin = new Thickness(0, 10, 0, 0) };
            var title = new TextBlock { Text = "DocuNova " + (System.Reflection.Assembly.GetEntryAssembly()?.GetName().Version?.ToString(3) ?? ""), FontSize = 30, FontWeight = FontWeights.Bold };
            title.SetResourceReference(TextBlock.ForegroundProperty, "AccentBrush");
            title.SetResourceReference(EffectProperty, "TextGlow");
            sp.Children.Add(title);
            var lines = new[]
            {
                "Безопасный офлайн-просмотрщик документов для Windows 10/11 (x64).",
                "",
                "• Работает без интернета: в программе нет сетевого кода.",
                "• Не исполняет содержимое документов: JavaScript, макросы, OLE, ActiveX, DDE, формы и автозапуск отключены всегда.",
                "• Не создаёт кэш на диске: страницы рисуются в памяти и выгружаются, когда не видны.",
                "• Исходные файлы никогда не изменяются — результат правок сохраняется в новый PDF.",
                "• Эскизы документов в Проводнике (включая обложки книг) — в изолированном процессе Windows.",
                "",
                "Используемые компоненты: PDFium (BSD), Windows.Data.Pdf и Windows.Media.Ocr (встроены в Windows), PdfPig (Apache 2.0), PDFsharp (MIT), .NET 8 / WPF (MIT)."
            };
            foreach (var l in lines) sp.Children.Add(new TextBlock { Text = l, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 2, 0, 2) });
            var langs = new TextBlock { Text = "Языки распознавания текста (OCR) в этой системе: " + OcrService.AvailableLanguages(), TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 12, 0, 0) };
            langs.SetResourceReference(StyleProperty, "Hint");
            sp.Children.Add(langs);
            return sp;
        }
    }
}
