using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using DocuNova.Core;
using DocuNova.Services;
using Microsoft.Win32;

namespace DocuNova.Views
{
    /// <summary>Страница в редакторе: ссылка на страницу исходного файла (или пустая), поворот и эскиз.</summary>
    public sealed class EditorPage : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        private void On(string n) => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(n));

        public ComposeSource Source { get; set; }
        public int Index { get; set; }
        /// <summary>Размер страницы без поворота (DIP); уточняется по готовому эскизу.</summary>
        public Size BaseSize { get; set; }
        public Brush SourceBrush { get; set; }

        private int _rotation;
        public int Rotation { get => _rotation; set { _rotation = ((value % 360) + 360) % 360; On(nameof(Rotation)); } }

        private BitmapSource _thumb;
        public BitmapSource Thumb { get => _thumb; set { _thumb = value; On(nameof(Thumb)); On(nameof(PlaceholderVisibility)); } }
        public Visibility PlaceholderVisibility => _thumb == null ? Visibility.Visible : Visibility.Collapsed;

        private double _w, _h;
        public double DisplayWidth { get => _w; set { _w = value; On(nameof(DisplayWidth)); } }
        public double DisplayHeight { get => _h; set { _h = value; On(nameof(DisplayHeight)); } }

        private double _tileW, _tileH;
        public double TileWidth { get => _tileW; set { _tileW = value; On(nameof(TileWidth)); } }
        public double TileHeight { get => _tileH; set { _tileH = value; On(nameof(TileHeight)); } }

        private string _number;
        public string Number { get => _number; set { _number = value; On(nameof(Number)); } }
        public string Caption => Source == null ? "Пустая страница" : (Source.IsImage && Source.PageCount <= 1 ? ShortName : $"{ShortName} · стр. {Index + 1}");
        public string ShortName
        {
            get
            {
                var n = Source?.Name ?? "";
                return n.Length > 22 ? n.Substring(0, 20) + "…" : n;
            }
        }

        private Visibility _dropBefore = Visibility.Collapsed, _dropAfter = Visibility.Collapsed;
        public Visibility DropBefore { get => _dropBefore; set { if (_dropBefore != value) { _dropBefore = value; On(nameof(DropBefore)); } } }
        public Visibility DropAfter { get => _dropAfter; set { if (_dropAfter != value) { _dropAfter = value; On(nameof(DropAfter)); } } }

        internal bool Queued;
        public bool IsBlank => Source == null;

        /// <summary>Размер изображения страницы в плитке с учётом поворота.</summary>
        public void Fit(double tileW, double tileH)
        {
            TileWidth = tileW;
            TileHeight = tileH;
            double w = Math.Max(1, BaseSize.Width), h = Math.Max(1, BaseSize.Height);
            bool swap = Rotation % 180 != 0;
            double rw = swap ? h : w, rh = swap ? w : h;
            double k = Math.Min(tileW / rw, tileH / rh);
            DisplayWidth = Math.Max(4, w * k);
            DisplayHeight = Math.Max(4, h * k);
        }
    }

    /// <summary>Исходный файл в списке слева.</summary>
    public sealed class EditorSourceItem
    {
        public ComposeSource Source { get; set; }
        public Brush Brush { get; set; }
        public string Name { get; set; }
        public string Detail { get; set; }
    }

    /// <summary>Начальное содержимое редактора: открытый в просмотре PDF с его порядком и поворотами страниц.</summary>
    public sealed class EditorSeed
    {
        public string Path { get; set; }
        public string Password { get; set; }
        /// <summary>Страницы (индекс в файле, поворот); null — все страницы по порядку.</summary>
        public List<(int index, int rotation)> Pages { get; set; }
    }

    /// <summary>
    /// Редактор PDF: объединение нескольких PDF и изображений в один документ, перестановка страниц (перетаскиванием
    /// или кнопками), удаление, поворот, дублирование, вставка пустых страниц, извлечение выбранных страниц и
    /// разделение документа на части. Результат сохраняется в новый файл — исходные файлы не изменяются.
    /// </summary>
    public sealed class PdfEditorWindow : ThemedWindow
    {
        private static readonly Color[] Palette =
        {
            Color.FromRgb(0xFF, 0x8A, 0x1E), Color.FromRgb(0x2E, 0x9C, 0xFF), Color.FromRgb(0x3C, 0xC4, 0x6A),
            Color.FromRgb(0xC0, 0x5C, 0xFF), Color.FromRgb(0xFF, 0x4D, 0x6D), Color.FromRgb(0x00, 0xC2, 0xC7),
            Color.FromRgb(0xE8, 0xB4, 0x00), Color.FromRgb(0x8D, 0x6E, 0x63)
        };
        private static readonly Size A4 = new Size(595.28 * 96 / 72, 841.89 * 96 / 72);

        private readonly ObservableCollection<EditorPage> _pages = new ObservableCollection<EditorPage>();
        private readonly ObservableCollection<EditorSourceItem> _sourceItems = new ObservableCollection<EditorSourceItem>();
        private readonly List<ComposeSource> _sources = new List<ComposeSource>();
        private readonly Stack<List<(EditorPage page, int rotation)>> _undo = new Stack<List<(EditorPage, int)>>();
        private readonly Stack<List<(EditorPage page, int rotation)>> _redo = new Stack<List<(EditorPage, int)>>();
        private readonly ListBox _list;
        private readonly ListBox _sourceList;
        private readonly TextBlock _status;
        private readonly TextBlock _counts;
        private readonly TextBlock _emptyHint;
        private readonly Slider _sizeSlider;
        private readonly Button _undoBtn, _redoBtn, _saveBtn, _saveSelBtn, _splitBtn;
        private readonly DispatcherTimer _thumbTimer;
        private ScrollViewer _scroll;
        private bool _busy, _rendering, _closed;
        private int _colorIndex;
        private double _tileW = 150, _tileH = 200;

        /// <summary>Открыть сохранённый файл в программе (вкладкой).</summary>
        public Action<string> OpenResult { get; set; }
        /// <summary>Проверка: файл сейчас открыт во вкладке (такие файлы не перезаписываются).</summary>
        public Func<string, bool> IsFileOpen { get; set; }
        public int RasterDpi { get; set; } = 200;

        public PdfEditorWindow()
        {
            Heading = "Редактор PDF — объединение и правка страниц";
            Width = 1180; Height = 780; MinWidth = 760; MinHeight = 480;
            ShowInTaskbar = true;
            AllowDrop = true;
            try { Icon = BitmapFrame.Create(new Uri("pack://application:,,,/Assets/app.ico", UriKind.Absolute)); } catch { }

            var root = new DockPanel { Margin = new Thickness(10, 0, 10, 10) };

            // ---------- панель инструментов ----------
            var bar = new WrapPanel { VerticalAlignment = VerticalAlignment.Center };
            var barBorder = new Border { Padding = new Thickness(6, 2, 6, 2), Margin = new Thickness(0, 0, 0, 8), BorderThickness = new Thickness(1), Child = bar };
            barBorder.SetResourceReference(Border.BackgroundProperty, "PanelBrush");
            barBorder.SetResourceReference(Border.BorderBrushProperty, "PanelBorderBrush");
            barBorder.SetResourceReference(Border.CornerRadiusProperty, "CornerRadiusLarge");
            DockPanel.SetDock(barBorder, Dock.Top);
            root.Children.Add(barBorder);

            Button Tool(string icon, string tip, Action a)
            {
                var b = new Button { Content = icon, ToolTip = tip };
                b.SetResourceReference(StyleProperty, "ToolBtn");
                b.Click += (s, e) => { if (!_busy) a(); };
                bar.Children.Add(b);
                return b;
            }
            void Divider()
            {
                var r = new System.Windows.Shapes.Rectangle { Width = 1, Height = 26, Margin = new Thickness(6, 0, 6, 0) };
                r.SetResourceReference(System.Windows.Shapes.Shape.FillProperty, "DividerBrush");
                bar.Children.Add(r);
            }

            var add = new Button { Margin = new Thickness(2, 4, 6, 4), Padding = new Thickness(12, 6, 12, 6), ToolTip = "Добавить PDF или изображения (JPEG, PNG, TIFF…) в конец документа или после выделенной страницы. Файлы можно также перетащить в окно." };
            add.Content = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Children =
                {
                    new TextBlock { Text = "", FontFamily = (FontFamily)Application.Current.Resources["IconFont"], VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 0, 8, 0) },
                    new TextBlock { Text = "Добавить файлы…", VerticalAlignment = VerticalAlignment.Center }
                }
            };
            add.SetResourceReference(StyleProperty, "AccentBtn");
            add.Click += (s, e) => { if (!_busy) AddFilesDialog(); };
            bar.Children.Add(add);
            Tool("", "Вставить пустую страницу после выделенной (Ctrl+Shift+N)", InsertBlank);
            Divider();
            var rl = Tool("", "Повернуть выделенные страницы влево (Ctrl+L)", () => RotateSelected(-90));
            rl.Content = new TextBlock { Text = "", RenderTransformOrigin = new Point(0.5, 0.5), RenderTransform = new ScaleTransform(-1, 1) };
            Tool("", "Повернуть выделенные страницы вправо (Ctrl+R)", () => RotateSelected(90));
            Tool("", "Дублировать выделенные страницы (Ctrl+D)", DuplicateSelected);
            Tool("", "Удалить выделенные страницы (Delete)", DeleteSelected);
            Divider();
            Tool("", "Переместить выделенные страницы влево (Ctrl+←)", () => MoveSelected(-1));
            Tool("", "Переместить выделенные страницы вправо (Ctrl+→)", () => MoveSelected(1));
            Tool("", "Переместить выделенные страницы в начало (Ctrl+Home)", () => MoveSelectedTo(true));
            Tool("", "Переместить выделенные страницы в конец (Ctrl+End)", () => MoveSelectedTo(false));
            Tool("", "Обратный порядок выделенных страниц (или всех, если ничего не выделено)", ReverseOrder);
            Divider();
            _undoBtn = Tool("", "Отменить (Ctrl+Z)", Undo);
            _redoBtn = Tool("", "Повторить (Ctrl+Y)", Redo);
            Divider();
            Tool("", "Выделить все страницы (Ctrl+A)", () => _list.SelectAll());

            var sizePanel = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(10, 0, 4, 0) };
            var sizeIcon = new TextBlock { Text = "", FontFamily = (FontFamily)Application.Current.Resources["IconFont"], VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 0, 6, 0) };
            sizeIcon.SetResourceReference(TextBlock.ForegroundProperty, "SubFgBrush");
            sizePanel.Children.Add(sizeIcon);
            _sizeSlider = new Slider { Width = 120, Minimum = 90, Maximum = 300, Value = 150, VerticalAlignment = VerticalAlignment.Center, ToolTip = "Размер эскизов" };
            _sizeSlider.ValueChanged += (s, e) => SetTileSize(e.NewValue);
            sizePanel.Children.Add(_sizeSlider);
            bar.Children.Add(sizePanel);

            // ---------- нижняя панель ----------
            var bottom = new DockPanel { Margin = new Thickness(0, 8, 0, 0), LastChildFill = true };
            DockPanel.SetDock(bottom, Dock.Bottom);
            var right = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right };
            DockPanel.SetDock(right, Dock.Right);
            _splitBtn = MakeButton("Разделить на файлы…", false);
            _splitBtn.ToolTip = "Сохранить документ несколькими файлами: по N страниц или по диапазонам";
            _splitBtn.Click += async (s, e) => { if (!_busy) await SplitAsync(); };
            _saveSelBtn = MakeButton("Сохранить выделенные…", false);
            _saveSelBtn.ToolTip = "Извлечь выделенные страницы в отдельный PDF";
            _saveSelBtn.Click += async (s, e) => { if (!_busy) await SaveAsync(true); };
            _saveBtn = MakeButton("Сохранить PDF…", true);
            _saveBtn.ToolTip = "Сохранить все страницы в новый PDF (Ctrl+S). Исходные файлы не изменяются.";
            _saveBtn.Click += async (s, e) => { if (!_busy) await SaveAsync(false); };
            right.Children.Add(_splitBtn); right.Children.Add(_saveSelBtn); right.Children.Add(_saveBtn);
            bottom.Children.Add(right);
            _counts = new TextBlock { VerticalAlignment = VerticalAlignment.Center, FontWeight = FontWeights.SemiBold, Margin = new Thickness(4, 0, 12, 0) };
            DockPanel.SetDock(_counts, Dock.Left);
            bottom.Children.Add(_counts);
            _status = new TextBlock { VerticalAlignment = VerticalAlignment.Center, TextTrimming = TextTrimming.CharacterEllipsis, Margin = new Thickness(0, 0, 8, 0),
                                      Text = "Перетаскивайте страницы мышью, чтобы изменить порядок. Правый щелчок — действия со страницами." };
            _status.SetResourceReference(TextBlock.ForegroundProperty, "SubFgBrush");
            bottom.Children.Add(_status);
            root.Children.Add(bottom);

            // ---------- список исходных файлов ----------
            var side = new DockPanel { Width = 230, Margin = new Thickness(0, 0, 8, 0) };
            var sideBorder = new Border { Padding = new Thickness(4, 8, 4, 6), BorderThickness = new Thickness(1), Child = side };
            sideBorder.SetResourceReference(Border.BackgroundProperty, "PanelBrush");
            sideBorder.SetResourceReference(Border.BorderBrushProperty, "PanelBorderBrush");
            sideBorder.SetResourceReference(Border.CornerRadiusProperty, "CornerRadiusLarge");
            DockPanel.SetDock(sideBorder, Dock.Left);
            var sideTitle = new TextBlock { Text = "Файлы", FontWeight = FontWeights.SemiBold, Margin = new Thickness(8, 0, 8, 6) };
            DockPanel.SetDock(sideTitle, Dock.Top);
            side.Children.Add(sideTitle);
            var sideButtons = new UniformGrid { Rows = 1 };
            DockPanel.SetDock(sideButtons, Dock.Bottom);
            var selFile = MakeButton("Выделить", false); selFile.MinWidth = 0; selFile.Padding = new Thickness(8, 5, 8, 5);
            selFile.ToolTip = "Выделить все страницы выбранного файла";
            selFile.Click += (s, e) => SelectSourcePages();
            var remFile = MakeButton("Убрать", false); remFile.MinWidth = 0; remFile.Padding = new Thickness(8, 5, 8, 5);
            remFile.ToolTip = "Убрать из документа все страницы выбранного файла";
            remFile.Click += (s, e) => { if (!_busy) RemoveSourcePages(); };
            sideButtons.Children.Add(selFile); sideButtons.Children.Add(remFile);
            side.Children.Add(sideButtons);
            _sourceList = new ListBox { ItemsSource = _sourceItems };
            _sourceList.ItemTemplate = (DataTemplate)XamlReader.Parse(SourceTemplateXaml);
            _sourceList.MouseDoubleClick += (s, e) => SelectSourcePages();
            side.Children.Add(_sourceList);
            root.Children.Add(sideBorder);

            // ---------- страницы ----------
            var host = new Grid();
            var listBorder = new Border { BorderThickness = new Thickness(1), Child = host, ClipToBounds = true };
            listBorder.SetResourceReference(Border.BackgroundProperty, "ViewerBgBrush");
            listBorder.SetResourceReference(Border.BorderBrushProperty, "PanelBorderBrush");
            listBorder.SetResourceReference(Border.CornerRadiusProperty, "CornerRadiusLarge");
            _list = new ListBox
            {
                ItemsSource = _pages,
                SelectionMode = SelectionMode.Extended,
                AllowDrop = true,
                Padding = new Thickness(6),
                Focusable = true
            };
            ScrollViewer.SetHorizontalScrollBarVisibility(_list, ScrollBarVisibility.Disabled);
            ScrollViewer.SetCanContentScroll(_list, false);
            VirtualizingPanel.SetIsVirtualizing(_list, false);
            _list.ItemsPanel = new ItemsPanelTemplate(new FrameworkElementFactory(typeof(WrapPanel)));
            _list.ItemTemplate = (DataTemplate)XamlReader.Parse(PageTemplateXaml);
            var itemStyle = new Style(typeof(ListBoxItem), (Style)Application.Current.TryFindResource(typeof(ListBoxItem)));
            itemStyle.Setters.Add(new Setter(Control.PaddingProperty, new Thickness(6)));
            itemStyle.Setters.Add(new Setter(Control.HorizontalContentAlignmentProperty, HorizontalAlignment.Center));
            _list.ItemContainerStyle = itemStyle;
            _list.SelectionChanged += (s, e) => UpdateUi();
            _list.PreviewMouseLeftButtonDown += List_PreviewMouseLeftButtonDown;
            _list.PreviewMouseLeftButtonUp += List_PreviewMouseLeftButtonUp;
            _list.PreviewMouseMove += List_PreviewMouseMove;
            _list.DragOver += List_DragOver;
            _list.DragLeave += (s, e) => ClearDropMarkers();
            _list.Drop += List_Drop;
            _list.ContextMenu = BuildPageMenu();
            _list.Loaded += (s, e) =>
            {
                _scroll = FindChild<ScrollViewer>(_list);
                if (_scroll != null) _scroll.ScrollChanged += (s2, e2) => ScheduleThumbs();
                ScheduleThumbs();
            };
            _list.SizeChanged += (s, e) => ScheduleThumbs();
            host.Children.Add(_list);

            _emptyHint = new TextBlock
            {
                Text = "Добавьте PDF-файлы или изображения кнопкой «Добавить файлы…» или перетащите их сюда.\n\n" +
                       "Страницы можно переставлять мышью, поворачивать, дублировать и удалять, вставлять пустые страницы.\n" +
                       "Результат сохраняется в новый PDF — исходные файлы не изменяются.",
                TextWrapping = TextWrapping.Wrap,
                TextAlignment = TextAlignment.Center,
                MaxWidth = 520,
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center,
                IsHitTestVisible = false,
                FontSize = 14.5
            };
            _emptyHint.SetResourceReference(TextBlock.ForegroundProperty, "SubFgBrush");
            host.Children.Add(_emptyHint);
            root.Children.Add(listBorder);

            Body.Children.Add(root);

            _thumbTimer = new DispatcherTimer(DispatcherPriority.Background) { Interval = TimeSpan.FromMilliseconds(70) };
            _thumbTimer.Tick += (s, e) => { _thumbTimer.Stop(); UpdateThumbQueue(); };

            DragOver += Window_DragOver;
            Drop += Window_Drop;
            Closing += OnClosingWindow;
            Closed += (s, e) => Cleanup();
            _pages.CollectionChanged += (s, e) => { ScheduleRenumber(); ScheduleThumbs(); };
            UpdateUi();
        }

        private const string SourceTemplateXaml =
            "<DataTemplate xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation'>" +
            "  <DockPanel>" +
            "    <Border DockPanel.Dock='Left' Width='10' Height='10' CornerRadius='5' Margin='0,4,8,0' VerticalAlignment='Top' Background='{Binding Brush}'/>" +
            "    <StackPanel>" +
            "      <TextBlock Text='{Binding Name}' TextTrimming='CharacterEllipsis' ToolTip='{Binding Name}'/>" +
            "      <TextBlock Text='{Binding Detail}' FontSize='11.5' Opacity='0.7'/>" +
            "    </StackPanel>" +
            "  </DockPanel>" +
            "</DataTemplate>";

        private const string PageTemplateXaml =
            "<DataTemplate xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation'>" +
            "  <Grid>" +
            "    <StackPanel>" +
            "      <Grid Width='{Binding TileWidth}' Height='{Binding TileHeight}'>" +
            "        <Border Width='{Binding DisplayWidth}' Height='{Binding DisplayHeight}' Background='White' BorderBrush='#40000000' BorderThickness='1'" +
            "                HorizontalAlignment='Center' VerticalAlignment='Center' SnapsToDevicePixels='True'>" +
            "          <Border.LayoutTransform><RotateTransform Angle='{Binding Rotation}'/></Border.LayoutTransform>" +
            "          <Grid>" +
            "            <Image Source='{Binding Thumb}' Stretch='Fill' RenderOptions.BitmapScalingMode='HighQuality'/>" +
            "            <TextBlock Text='…' Foreground='#80000000' FontSize='18' HorizontalAlignment='Center' VerticalAlignment='Center' Visibility='{Binding PlaceholderVisibility}'/>" +
            "          </Grid>" +
            "        </Border>" +
            "      </Grid>" +
            "      <DockPanel Margin='0,6,0,0' Width='{Binding TileWidth}'>" +
            "        <Border DockPanel.Dock='Left' Width='8' Height='8' CornerRadius='4' Margin='0,0,6,0' VerticalAlignment='Center' Background='{Binding SourceBrush}'/>" +
            "        <TextBlock DockPanel.Dock='Left' Text='{Binding Number}' FontWeight='SemiBold' Margin='0,0,6,0'/>" +
            "        <TextBlock Text='{Binding Caption}' FontSize='11.5' Opacity='0.7' TextTrimming='CharacterEllipsis' VerticalAlignment='Center' ToolTip='{Binding Caption}'/>" +
            "      </DockPanel>" +
            "    </StackPanel>" +
            "    <Border Width='4' CornerRadius='2' HorizontalAlignment='Left' Margin='-9,0,0,0' Background='#FFFF8A1E' Visibility='{Binding DropBefore}'/>" +
            "    <Border Width='4' CornerRadius='2' HorizontalAlignment='Right' Margin='0,0,-9,0' Background='#FFFF8A1E' Visibility='{Binding DropAfter}'/>" +
            "  </Grid>" +
            "</DataTemplate>";

        // ======================= файлы =======================

        /// <summary>Начальное содержимое: открытый в просмотре PDF.</summary>
        public async Task LoadSeedAsync(EditorSeed seed)
        {
            if (seed == null || string.IsNullOrEmpty(seed.Path)) return;
            var src = await OpenSourceAsync(seed.Path, seed.Password);
            if (src == null) return;
            var pages = new List<EditorPage>();
            if (seed.Pages != null && seed.Pages.Count > 0)
            {
                foreach (var (index, rotation) in seed.Pages)
                    if (index >= 0 && index < src.PageCount) pages.Add(NewPage(src, index, rotation));
            }
            else for (int i = 0; i < src.PageCount; i++) pages.Add(NewPage(src, i, 0));
            InsertPages(pages, _pages.Count, false);
        }

        /// <summary>Добавляет файлы (после выделенной страницы или в конец).</summary>
        public async Task AddFilesAsync(IEnumerable<string> files, int insertAt = -1)
        {
            var list = (files ?? Enumerable.Empty<string>()).Where(f => !string.IsNullOrWhiteSpace(f)).ToList();
            if (list.Count == 0) return;
            var all = new List<EditorPage>();
            _busy = true;
            UpdateUi();
            try
            {
                int n = 0;
                foreach (var f in list)
                {
                    n++;
                    _status.Text = $"Открытие файла {n} из {list.Count}: {Path.GetFileName(f)}";
                    var src = await OpenSourceAsync(f, null);
                    if (src == null) continue;
                    for (int i = 0; i < src.PageCount; i++) all.Add(NewPage(src, i, 0));
                }
            }
            finally { _busy = false; }
            if (all.Count > 0)
            {
                if (insertAt < 0) insertAt = InsertPosition();
                InsertPages(all, insertAt, true);
                _status.Text = $"Добавлено страниц: {all.Count}.";
            }
            UpdateUi();
        }

        private void AddFilesDialog()
        {
            var dlg = new OpenFileDialog
            {
                Title = "Добавить PDF или изображения",
                Multiselect = true,
                Filter = "PDF и изображения|*.pdf;*.jpg;*.jpeg;*.png;*.tif;*.tiff;*.bmp;*.gif;*.webp;*.jxr;*.wdp|PDF|*.pdf|Изображения|*.jpg;*.jpeg;*.png;*.tif;*.tiff;*.bmp;*.gif;*.webp|Все файлы|*.*"
            };
            if (dlg.ShowDialog(this) != true) return;
            _ = AddFilesAsync(dlg.FileNames.OrderBy(f => f, new DocumentLoader.NaturalComparer()));
        }

        /// <summary>Открывает файл для редактора: PDF (с запросом пароля) или изображение. null — не удалось.</summary>
        private async Task<ComposeSource> OpenSourceAsync(string path, string password)
        {
            byte[] data;
            string code;
            try
            {
                path = Path.GetFullPath(path);
                data = await Task.Run(() => SafeIO.ReadFile(path));
                code = DocumentLoader.Detect(data, Path.GetExtension(path).ToLowerInvariant());
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, $"Не удалось прочитать «{Path.GetFileName(path)}»:\n\n{ex.Message}", "Редактор PDF", MessageBoxButton.OK, MessageBoxImage.Warning);
                return null;
            }
            if (code != "pdf" && code != "image")
            {
                MessageBox.Show(this, $"«{Path.GetFileName(path)}» — не PDF и не изображение. В редактор можно добавлять PDF, JPEG, PNG, TIFF, BMP, GIF.\n\nДругие документы сначала откройте в DocuNova и сохраните в PDF (Ctrl+S).", "Редактор PDF", MessageBoxButton.OK, MessageBoxImage.Information);
                return null;
            }
            bool wrong = false;
            while (true)
            {
                try
                {
                    string pw = password;
                    DocumentBase doc = code == "pdf"
                        ? await Task.Run(() => (DocumentBase)PdfDoc.Open(data, pw, false))
                        : await Task.Run(() => (DocumentBase)ImageDoc.FromMultiFrame(data, false));
                    if (doc.PageCount <= 0) { doc.Dispose(); throw new UnsupportedFormatException("В файле нет страниц."); }
                    var src = new ComposeSource { Path = path, Name = Path.GetFileName(path), Data = data, Password = password, IsImage = code == "image", Render = doc };
                    if (_closed) { src.Dispose(); return null; }
                    _sources.Add(src);
                    var color = Palette[_colorIndex++ % Palette.Length];
                    var brush = new SolidColorBrush(color); brush.Freeze();
                    _brushes[src] = brush;
                    RefreshSources();
                    return src;
                }
                catch (PasswordRequiredException ex)
                {
                    password = PasswordDialog.Ask(this, Path.GetFileName(path), wrong || ex.WrongPassword);
                    if (password == null) return null;
                    wrong = true;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, $"Не удалось открыть «{Path.GetFileName(path)}»:\n\n{ex.Message}", "Редактор PDF", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return null;
                }
            }
        }

        private readonly Dictionary<ComposeSource, Brush> _brushes = new Dictionary<ComposeSource, Brush>();

        private EditorPage NewPage(ComposeSource src, int index, int rotation)
        {
            var p = new EditorPage
            {
                Source = src,
                Index = index,
                BaseSize = src.Render.GetPageSize(index),
                SourceBrush = src != null && _brushes.TryGetValue(src, out var b) ? b : Brushes.Gray,
                Rotation = rotation
            };
            p.Fit(_tileW, _tileH);
            return p;
        }

        private EditorPage NewBlank(Size size)
        {
            var p = new EditorPage { Source = null, Index = 0, BaseSize = size, SourceBrush = Brushes.Silver };
            p.Fit(_tileW, _tileH);
            return p;
        }

        private void RefreshSources()
        {
            var used = _pages.GroupBy(p => p.Source).Where(g => g.Key != null).ToDictionary(g => g.Key, g => g.Count());
            var selected = (_sourceList.SelectedItem as EditorSourceItem)?.Source;
            _sourceItems.Clear();
            foreach (var s in _sources)
            {
                used.TryGetValue(s, out int n);
                if (n == 0) continue; // файл, все страницы которого убраны, не показывается (Ctrl+Z вернёт их)
                var item = new EditorSourceItem
                {
                    Source = s,
                    Brush = _brushes.TryGetValue(s, out var b) ? b : Brushes.Gray,
                    Name = s.Name,
                    Detail = (s.IsImage ? (s.PageCount > 1 ? $"изображение, кадров: {s.PageCount}" : "изображение") : $"PDF, страниц: {s.PageCount}") + (n != s.PageCount ? $" · в документе: {n}" : "")
                };
                _sourceItems.Add(item);
                if (s == selected) _sourceList.SelectedItem = item;
            }
        }

        private void SelectSourcePages()
        {
            var src = (_sourceList.SelectedItem as EditorSourceItem)?.Source;
            if (src == null) return;
            _list.SelectedItems.Clear();
            EditorPage first = null;
            foreach (var p in _pages.Where(p => p.Source == src)) { _list.SelectedItems.Add(p); first = first ?? p; }
            if (first != null) _list.ScrollIntoView(first);
            _list.Focus();
        }

        private void RemoveSourcePages()
        {
            var src = (_sourceList.SelectedItem as EditorSourceItem)?.Source;
            if (src == null) return;
            var victims = _pages.Where(p => p.Source == src).ToList();
            if (victims.Count == 0) return;
            PushUndo();
            foreach (var p in victims) _pages.Remove(p);
            RefreshSources();
            _status.Text = $"Убрано страниц файла «{src.Name}»: {victims.Count}. Ctrl+Z — вернуть.";
        }

        // ======================= операции со страницами =======================

        private List<EditorPage> Selected() => _list.SelectedItems.Cast<EditorPage>().OrderBy(p => _pages.IndexOf(p)).ToList();

        private int InsertPosition()
        {
            var sel = Selected();
            return sel.Count > 0 ? _pages.IndexOf(sel[sel.Count - 1]) + 1 : _pages.Count;
        }

        private void InsertPages(List<EditorPage> pages, int at, bool recordUndo)
        {
            if (pages.Count == 0) return;
            if (recordUndo) PushUndo();
            at = Math.Max(0, Math.Min(_pages.Count, at));
            foreach (var p in pages) _pages.Insert(at++, p);
            RefreshSources();
            _list.SelectedItems.Clear();
            foreach (var p in pages) _list.SelectedItems.Add(p);
            _list.ScrollIntoView(pages[0]);
        }

        private void InsertBlank()
        {
            int at = InsertPosition();
            Size size = A4;
            var near = at > 0 ? _pages[at - 1] : (_pages.Count > 0 ? _pages[0] : null);
            if (near != null)
            {
                // пустая страница — того же размера и ориентации, что и соседняя
                var s = near.BaseSize;
                size = near.Rotation % 180 != 0 ? new Size(s.Height, s.Width) : s;
            }
            InsertPages(new List<EditorPage> { NewBlank(size) }, at, true);
            _status.Text = "Вставлена пустая страница.";
        }

        private void RotateSelected(int delta)
        {
            var sel = Selected();
            if (sel.Count == 0) { _status.Text = "Выделите страницы, которые нужно повернуть."; return; }
            PushUndo();
            foreach (var p in sel) { p.Rotation += delta; p.Fit(_tileW, _tileH); }
            _status.Text = $"Повёрнуто страниц: {sel.Count}.";
        }

        private void DuplicateSelected()
        {
            var sel = Selected();
            if (sel.Count == 0) return;
            int at = _pages.IndexOf(sel[sel.Count - 1]) + 1;
            var copies = sel.Select(p =>
            {
                var c = p.IsBlank ? NewBlank(p.BaseSize) : NewPage(p.Source, p.Index, p.Rotation);
                c.BaseSize = p.BaseSize;
                c.Rotation = p.Rotation;
                c.Thumb = p.Thumb;
                c.Fit(_tileW, _tileH);
                return c;
            }).ToList();
            InsertPages(copies, at, true);
            _status.Text = $"Скопировано страниц: {copies.Count}.";
        }

        private void DeleteSelected()
        {
            var sel = Selected();
            if (sel.Count == 0) return;
            int first = _pages.IndexOf(sel[0]);
            PushUndo();
            foreach (var p in sel) _pages.Remove(p);
            RefreshSources();
            if (_pages.Count > 0) _list.SelectedItem = _pages[Math.Min(first, _pages.Count - 1)];
            _status.Text = $"Удалено страниц: {sel.Count}. Ctrl+Z — вернуть.";
        }

        private void MoveSelected(int dir)
        {
            var sel = Selected();
            if (sel.Count == 0) return;
            var idx = sel.Select(p => _pages.IndexOf(p)).ToList();
            if (dir < 0 && idx[0] == 0) return;
            if (dir > 0 && idx[idx.Count - 1] == _pages.Count - 1) return;
            PushUndo();
            if (dir < 0)
                foreach (var i in idx) _pages.Move(i, i - 1);
            else
                for (int k = idx.Count - 1; k >= 0; k--) _pages.Move(idx[k], idx[k] + 1);
            RestoreSelection(sel);
        }

        private void MoveSelectedTo(bool start)
        {
            var sel = Selected();
            if (sel.Count == 0) return;
            PushUndo();
            foreach (var p in sel) _pages.Remove(p);
            int at = start ? 0 : _pages.Count;
            foreach (var p in sel) _pages.Insert(at++, p);
            RestoreSelection(sel);
        }

        private void MovePagesTo(List<EditorPage> moving, int target)
        {
            // target — позиция вставки в текущем списке (до удаления перемещаемых страниц)
            int before = moving.Count(p => _pages.IndexOf(p) < target);
            PushUndo();
            foreach (var p in moving) _pages.Remove(p);
            int at = Math.Max(0, Math.Min(_pages.Count, target - before));
            foreach (var p in moving) _pages.Insert(at++, p);
            RestoreSelection(moving);
        }

        private void ReverseOrder()
        {
            var sel = Selected();
            if (sel.Count < 2) sel = _pages.ToList();
            if (sel.Count < 2) return;
            PushUndo();
            var positions = sel.Select(p => _pages.IndexOf(p)).OrderBy(i => i).ToList();
            var reversed = sel.AsEnumerable().Reverse().ToList();
            // убираем страницы и вставляем обратно в те же позиции (по возрастанию) — без временных дубликатов в списке
            foreach (var p in sel) _pages.Remove(p);
            for (int k = 0; k < positions.Count; k++) _pages.Insert(Math.Min(positions[k], _pages.Count), reversed[k]);
            RestoreSelection(reversed);
            _status.Text = "Порядок страниц изменён на обратный.";
        }

        private void RestoreSelection(IEnumerable<EditorPage> pages)
        {
            _list.SelectedItems.Clear();
            EditorPage first = null;
            foreach (var p in pages) { _list.SelectedItems.Add(p); first = first ?? p; }
            if (first != null) _list.ScrollIntoView(first);
        }

        private bool _renumberPending;

        /// <summary>Нумерация и счётчики обновляются один раз после серии изменений (добавление сотен страниц).</summary>
        private void ScheduleRenumber()
        {
            if (_renumberPending) return;
            _renumberPending = true;
            Dispatcher.BeginInvoke(new Action(() =>
            {
                _renumberPending = false;
                for (int i = 0; i < _pages.Count; i++)
                {
                    var num = (i + 1).ToString();
                    if (_pages[i].Number != num) _pages[i].Number = num;
                }
                UpdateUi();
            }), DispatcherPriority.Loaded);
        }

        private void SetTileSize(double w)
        {
            _tileW = Math.Round(w);
            _tileH = Math.Round(w * 1.33);
            foreach (var p in _pages) p.Fit(_tileW, _tileH);
            // эскизы перерисовываются в новом размере только при заметном увеличении
            foreach (var p in _pages)
                if (p.Thumb != null && Math.Max(p.Thumb.PixelWidth, p.Thumb.PixelHeight) < ThumbPixels() * 0.7) p.Thumb = null;
            ScheduleThumbs();
        }

        // ======================= отмена =======================

        private List<(EditorPage, int)> Snapshot() => _pages.Select(p => (p, p.Rotation)).ToList();

        private void PushUndo()
        {
            _undo.Push(Snapshot());
            _redo.Clear();
            _saved = false;
            while (_undo.Count > 200) TrimStack(_undo);
            UpdateUi();
        }

        private static void TrimStack(Stack<List<(EditorPage, int)>> st)
        {
            var arr = st.ToArray(); // от новых к старым
            st.Clear();
            for (int i = arr.Length - 2; i >= 0; i--) st.Push(arr[i]);
        }

        private void Restore(List<(EditorPage page, int rotation)> state)
        {
            _pages.Clear();
            foreach (var (page, rotation) in state)
            {
                page.Rotation = rotation;
                page.Fit(_tileW, _tileH);
                _pages.Add(page);
            }
            RefreshSources();
        }

        private void Undo()
        {
            if (_undo.Count == 0) return;
            _redo.Push(Snapshot());
            Restore(_undo.Pop());
            _status.Text = "Действие отменено.";
            UpdateUi();
        }

        private void Redo()
        {
            if (_redo.Count == 0) return;
            _undo.Push(Snapshot());
            Restore(_redo.Pop());
            _status.Text = "Действие повторено.";
            UpdateUi();
        }

        private void UpdateUi()
        {
            if (_list == null) return;
            int n = _pages.Count, sel = _list.SelectedItems.Count;
            _emptyHint.Visibility = n == 0 ? Visibility.Visible : Visibility.Collapsed;
            _undoBtn.IsEnabled = !_busy && _undo.Count > 0;
            _redoBtn.IsEnabled = !_busy && _redo.Count > 0;
            _saveBtn.IsEnabled = !_busy && n > 0;
            _saveSelBtn.IsEnabled = !_busy && sel > 0;
            _splitBtn.IsEnabled = !_busy && n > 1;
            _counts.Text = n == 0 ? "" : $"Страниц: {n}" + (sel > 0 ? $" · выделено: {sel}" : "");
        }

        // ======================= эскизы =======================

        private double Dpi { get { try { return VisualTreeHelper.GetDpi(this).DpiScaleX; } catch { return 1; } } }
        private double ThumbPixels() => Math.Max(_tileW, _tileH) * Dpi;

        private void ScheduleThumbs()
        {
            if (_closed) return;
            _thumbTimer.Stop();
            _thumbTimer.Start();
        }

        /// <summary>Эскизы рисуются только для видимых страниц (и небольшого запаса); дальние эскизы освобождаются.</summary>
        private void UpdateThumbQueue()
        {
            if (_closed || _scroll == null) return;
            double vh = Math.Max(1, _scroll.ViewportHeight);
            var view = new Rect(0, -vh * 0.75, Math.Max(1, _scroll.ViewportWidth), vh * 2.5);
            var keep = new Rect(0, -vh * 4, Math.Max(1, _scroll.ViewportWidth), vh * 9);
            int withThumb = 0;
            for (int i = 0; i < _pages.Count; i++)
            {
                var p = _pages[i];
                var c = _list.ItemContainerGenerator.ContainerFromIndex(i) as FrameworkElement;
                if (c == null || !c.IsVisible) continue;
                Rect r;
                try { r = c.TransformToAncestor(_scroll).TransformBounds(new Rect(0, 0, c.ActualWidth, c.ActualHeight)); }
                catch { continue; }
                if (p.Thumb != null)
                {
                    withThumb++;
                    if (!r.IntersectsWith(keep) && withThumb > 120) { p.Thumb = null; withThumb--; }
                    continue;
                }
                if (r.IntersectsWith(view) && !p.IsBlank) p.Queued = true;
            }
            if (!_rendering) _ = RenderLoopAsync();
        }

        private async Task RenderLoopAsync()
        {
            _rendering = true;
            try
            {
                while (!_closed)
                {
                    var p = NextQueued();
                    if (p == null) break;
                    p.Queued = false;
                    var src = p.Source;
                    var doc = src?.Render;
                    if (doc == null) continue;
                    int idx = p.Index;
                    var size = doc.GetPageSize(idx);
                    double scale = ThumbPixels() / Math.Max(1, Math.Max(size.Width, size.Height));
                    PagePixels pix = null;
                    try { pix = await Task.Run(() => doc.RenderPagePixels(idx, scale, "normal", 0)); }
                    catch { }
                    if (_closed) return;
                    if (pix == null) continue;
                    var bmp = pix.ToBitmap();
                    // один и тот же эскиз — всем копиям этой страницы
                    foreach (var same in _pages.Where(x => x.Source == src && x.Index == idx && x.Thumb == null))
                    {
                        same.Thumb = bmp;
                        same.Queued = false;
                        if (bmp != null && bmp.PixelWidth > 0 && bmp.PixelHeight > 0)
                        {
                            // точные пропорции — по готовой картинке
                            double k = Math.Max(size.Width, size.Height) / Math.Max(bmp.PixelWidth, bmp.PixelHeight);
                            same.BaseSize = new Size(bmp.PixelWidth * k, bmp.PixelHeight * k);
                            same.Fit(_tileW, _tileH);
                        }
                    }
                }
            }
            finally { _rendering = false; }
        }

        private EditorPage NextQueued()
        {
            foreach (var p in _pages) if (p.Queued && p.Thumb == null) return p;
            return null;
        }

        // ======================= перетаскивание =======================

        private Point _dragStart;
        private EditorPage _pressed;
        private bool _pressedWasSelected;

        private EditorPage ItemAt(DependencyObject d, out ListBoxItem container)
        {
            container = null;
            while (d != null && !(d is ListBoxItem))
                d = d is Visual || d is System.Windows.Media.Media3D.Visual3D ? VisualTreeHelper.GetParent(d) : LogicalTreeHelper.GetParent(d);
            container = d as ListBoxItem;
            return container?.DataContext as EditorPage;
        }

        private void List_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            _dragStart = e.GetPosition(_list);
            _pressed = ItemAt(e.OriginalSource as DependencyObject, out var c);
            _pressedWasSelected = c != null && c.IsSelected;
            // щелчок по уже выделенной странице без клавиш-модификаторов сохраняет группу выделения для перетаскивания
            if (_pressed != null && _pressedWasSelected && Keyboard.Modifiers == ModifierKeys.None && _list.SelectedItems.Count > 1)
            {
                e.Handled = true;
                _list.Focus();
            }
        }

        private void List_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (_pressed != null && _pressedWasSelected && Keyboard.Modifiers == ModifierKeys.None && _list.SelectedItems.Count > 1)
            {
                // перетаскивания не было — обычный щелчок выделяет одну страницу
                _list.SelectedItems.Clear();
                _list.SelectedItem = _pressed;
            }
            _pressed = null;
        }

        private void List_PreviewMouseMove(object sender, MouseEventArgs e)
        {
            if (e.LeftButton != MouseButtonState.Pressed || _pressed == null || _busy) return;
            var pos = e.GetPosition(_list);
            if (Math.Abs(pos.X - _dragStart.X) < SystemParameters.MinimumHorizontalDragDistance &&
                Math.Abs(pos.Y - _dragStart.Y) < SystemParameters.MinimumVerticalDragDistance) return;
            if (!_list.SelectedItems.Contains(_pressed))
            {
                _list.SelectedItems.Clear();
                _list.SelectedItem = _pressed;
            }
            var moving = Selected();
            _pressed = null;
            if (moving.Count == 0) return;
            var data = new DataObject("DocuNovaEditorPages", moving);
            try { DragDrop.DoDragDrop(_list, data, DragDropEffects.Move); }
            catch { }
            finally { ClearDropMarkers(); }
        }

        /// <summary>Позиция вставки по положению мыши: перед или после страницы под курсором.</summary>
        private int DropIndex(DragEventArgs e, out EditorPage marker, out bool after)
        {
            marker = null; after = false;
            var item = ItemAt(e.OriginalSource as DependencyObject, out var c);
            if (item == null || c == null)
            {
                // пустое место — в конец списка
                if (_pages.Count > 0) { marker = _pages[_pages.Count - 1]; after = true; }
                return _pages.Count;
            }
            var pt = e.GetPosition(c);
            after = pt.X > c.ActualWidth / 2;
            marker = item;
            int idx = _pages.IndexOf(item);
            return after ? idx + 1 : idx;
        }

        private EditorPage _markBefore, _markAfter;

        private void ClearDropMarkers()
        {
            if (_markBefore != null) _markBefore.DropBefore = Visibility.Collapsed;
            if (_markAfter != null) _markAfter.DropAfter = Visibility.Collapsed;
            _markBefore = _markAfter = null;
        }

        private void List_DragOver(object sender, DragEventArgs e)
        {
            bool pages = e.Data.GetDataPresent("DocuNovaEditorPages");
            bool files = e.Data.GetDataPresent(DataFormats.FileDrop);
            if ((!pages && !files) || _busy) { e.Effects = DragDropEffects.None; e.Handled = true; return; }
            e.Effects = pages ? DragDropEffects.Move : DragDropEffects.Copy;
            DropIndex(e, out var marker, out bool after);
            ClearDropMarkers();
            if (marker != null)
            {
                if (after) { marker.DropAfter = Visibility.Visible; _markAfter = marker; }
                else { marker.DropBefore = Visibility.Visible; _markBefore = marker; }
            }
            AutoScroll(e);
            e.Handled = true;
        }

        private void AutoScroll(DragEventArgs e)
        {
            if (_scroll == null) return;
            var y = e.GetPosition(_scroll).Y;
            if (y < 40) _scroll.ScrollToVerticalOffset(_scroll.VerticalOffset - 20);
            else if (y > _scroll.ActualHeight - 40) _scroll.ScrollToVerticalOffset(_scroll.VerticalOffset + 20);
        }

        private async void List_Drop(object sender, DragEventArgs e)
        {
            int target = DropIndex(e, out _, out _);
            ClearDropMarkers();
            e.Handled = true;
            if (_busy) return;
            if (e.Data.GetData("DocuNovaEditorPages") is List<EditorPage> moving && moving.Count > 0)
            {
                MovePagesTo(moving, target);
                _status.Text = $"Перемещено страниц: {moving.Count}.";
            }
            else if (e.Data.GetData(DataFormats.FileDrop) is string[] files && files.Length > 0)
                await AddFilesAsync(files.OrderBy(f => f, new DocumentLoader.NaturalComparer()), target);
        }

        private void Window_DragOver(object sender, DragEventArgs e)
        {
            if (e.Handled) return;
            e.Effects = e.Data.GetDataPresent(DataFormats.FileDrop) && !_busy ? DragDropEffects.Copy : DragDropEffects.None;
            e.Handled = true;
        }

        private async void Window_Drop(object sender, DragEventArgs e)
        {
            if (e.Handled || _busy) return;
            if (e.Data.GetData(DataFormats.FileDrop) is string[] files && files.Length > 0)
            {
                e.Handled = true;
                await AddFilesAsync(files.OrderBy(f => f, new DocumentLoader.NaturalComparer()));
            }
        }

        // ======================= меню и клавиатура =======================

        private ContextMenu BuildPageMenu()
        {
            var m = new ContextMenu();
            void Add(string icon, string text, Action a)
            {
                var mi = new MenuItem { Header = text, Icon = new TextBlock { Text = icon, FontFamily = (FontFamily)Application.Current.Resources["IconFont"] } };
                mi.Click += (s, e) => { if (!_busy) a(); };
                m.Items.Add(mi);
            }
            Add("", "Повернуть вправо", () => RotateSelected(90));
            Add("", "Повернуть влево", () => RotateSelected(-90));
            Add("", "Дублировать", DuplicateSelected);
            Add("", "Вставить пустую страницу после", InsertBlank);
            Add("", "Вставить файлы после…", AddFilesDialog);
            m.Items.Add(new Separator());
            Add("", "В начало", () => MoveSelectedTo(true));
            Add("", "В конец", () => MoveSelectedTo(false));
            m.Items.Add(new Separator());
            Add("", "Сохранить выделенные в PDF…", async () => await SaveAsync(true));
            Add("", "Удалить", DeleteSelected);
            return m;
        }

        protected override void OnPreviewKeyDown(KeyEventArgs e)
        {
            base.OnPreviewKeyDown(e);
            if (e.Handled || _busy) return;
            if (Keyboard.FocusedElement is TextBox) return;
            bool ctrl = (Keyboard.Modifiers & ModifierKeys.Control) != 0, shift = (Keyboard.Modifiers & ModifierKeys.Shift) != 0;
            var key = e.Key == Key.System ? e.SystemKey : e.Key;
            if (ctrl)
            {
                switch (key)
                {
                    case Key.Z: Undo(); break;
                    case Key.Y: Redo(); break;
                    case Key.A: _list.SelectAll(); break;
                    case Key.D: DuplicateSelected(); break;
                    case Key.L: RotateSelected(-90); break;
                    case Key.R: RotateSelected(90); break;
                    case Key.O: AddFilesDialog(); break;
                    case Key.N when shift: InsertBlank(); break;
                    case Key.S: _ = SaveAsync(false); break;
                    case Key.Left: MoveSelected(-1); break;
                    case Key.Right: MoveSelected(1); break;
                    case Key.Home: MoveSelectedTo(true); break;
                    case Key.End: MoveSelectedTo(false); break;
                    default: return;
                }
                e.Handled = true;
                return;
            }
            if (key == Key.Delete && _list.IsKeyboardFocusWithin) { DeleteSelected(); e.Handled = true; }
        }

        // ======================= сохранение =======================

        private List<ComposePage> ToCompose(IEnumerable<EditorPage> pages) =>
            pages.Select(p => new ComposePage { Source = p.Source, Index = p.Index, Rotation = p.Rotation, BlankSize = p.BaseSize }).ToList();

        private string DefaultName()
        {
            var used = _pages.Where(p => p.Source != null).Select(p => p.Source).Distinct().ToList();
            if (used.Count == 1) return Path.GetFileNameWithoutExtension(used[0].Name) + " (изменён).pdf";
            return "Объединённый документ.pdf";
        }

        /// <summary>Нельзя перезаписать исходный файл редактора или документ, открытый во вкладке.</summary>
        private bool IsProtectedTarget(string target)
        {
            if (_sources.Any(s => string.Equals(s.Path, target, StringComparison.OrdinalIgnoreCase))) return true;
            try { return IsFileOpen?.Invoke(target) == true; } catch { return false; }
        }

        private async Task SaveAsync(bool selectedOnly)
        {
            var pages = selectedOnly ? Selected() : _pages.ToList();
            if (pages.Count == 0) { _status.Text = selectedOnly ? "Выделите страницы для сохранения." : "Нет страниц для сохранения."; return; }
            var dlg = new SaveFileDialog
            {
                Filter = "Документ PDF|*.pdf",
                FileName = selectedOnly ? Path.GetFileNameWithoutExtension(DefaultName()) + " — выбранные страницы.pdf" : DefaultName(),
                Title = selectedOnly ? "Сохранить выделенные страницы" : "Сохранить PDF"
            };
            if (dlg.ShowDialog(this) != true) return;
            string target;
            try { target = Path.GetFullPath(dlg.FileName); } catch { target = dlg.FileName; }
            if (IsProtectedTarget(target))
            {
                MessageBox.Show(this, "Нельзя сохранить результат поверх исходного или открытого файла. Выберите другое имя.", "Редактор PDF", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            var job = ToCompose(pages);
            var warnings = await RunSaveAsync(new[] { (job, target) }, Path.GetFileNameWithoutExtension(target));
            if (warnings == null) return;
            ReportSaved(new[] { target }, warnings);
        }

        private async Task SplitAsync()
        {
            int n = _pages.Count;
            if (n < 2) return;
            var rule = InputDialog.Ask(this, "Разделить на файлы",
                $"Страниц в документе: {n}.\n\nУкажите, по сколько страниц в каждом файле (например, 1 — каждая страница отдельным файлом), " +
                "или диапазоны частей через точку с запятой, например: 1-3; 4-10; 11-", "1");
            if (rule == null) return;
            var parts = PdfComposer.ParseSplit(rule, n);
            if (parts.Count == 0) { MessageBox.Show(this, "Не удалось разобрать правило разделения.", "Редактор PDF"); return; }
            var folder = new OpenFolderDialog { Title = "Папка для частей документа" };
            if (folder.ShowDialog(this) != true) return;
            string baseName = Path.GetFileNameWithoutExtension(DefaultName()).Replace(" (изменён)", "");
            int digits = Math.Max(2, parts.Count.ToString().Length);
            var jobs = new List<(List<ComposePage>, string)>();
            for (int i = 0; i < parts.Count; i++)
            {
                var part = parts[i];
                string range = part.Count == 1 ? $"стр. {part[0] + 1}" : $"стр. {part[0] + 1}-{part[part.Count - 1] + 1}";
                string file = Path.Combine(folder.FolderName, $"{baseName} — часть {(i + 1).ToString().PadLeft(digits, '0')} ({range}).pdf");
                if (IsProtectedTarget(file))
                {
                    MessageBox.Show(this, "Имя одной из частей совпадает с исходным или открытым файлом. Выберите другую папку.", "Редактор PDF", MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }
                jobs.Add((ToCompose(part.Select(k => _pages[k])), file));
            }
            var existing = jobs.Count(j => File.Exists(j.Item2));
            if (existing > 0 && MessageBox.Show(this, $"В папке уже есть файлы с такими именами ({existing}). Заменить их?", "Редактор PDF", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes)
                return;
            var warnings = await RunSaveAsync(jobs, baseName);
            if (warnings == null) return;
            ReportSaved(jobs.Select(j => j.Item2).ToList(), warnings);
        }

        /// <summary>Сохранение в фоне с индикацией; null — ошибка (сообщение уже показано).</summary>
        private async Task<List<string>> RunSaveAsync(IEnumerable<(List<ComposePage> pages, string path)> jobs, string title)
        {
            var list = jobs.ToList();
            _busy = true;
            UpdateUi();
            Mouse.OverrideCursor = Cursors.AppStarting;
            var warnings = new List<string>();
            try
            {
                int dpi = RasterDpi;
                for (int j = 0; j < list.Count; j++)
                {
                    var (pages, path) = list[j];
                    string prefix = list.Count > 1 ? $"Файл {j + 1} из {list.Count}: " : "";
                    var progress = new Progress<(int, int)>(t => _status.Text = $"{prefix}сохранение страницы {t.Item1} из {t.Item2}…");
                    IProgress<(int, int)> rep = progress;
                    var w = await Task.Run(() => PdfComposer.Save(pages, path, title, dpi, (a, b) => rep.Report((a, b))));
                    foreach (var x in w) if (!warnings.Contains(x)) warnings.Add(x);
                }
                return warnings;
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Не удалось сохранить PDF:\n\n" + ex.Message, "Редактор PDF", MessageBoxButton.OK, MessageBoxImage.Warning);
                _status.Text = "Сохранение не выполнено.";
                return null;
            }
            finally
            {
                Mouse.OverrideCursor = null;
                _busy = false;
                UpdateUi();
                MemoryTrim.Schedule();
            }
        }

        private void ReportSaved(IList<string> files, List<string> warnings)
        {
            _saved = true;
            _status.Text = files.Count == 1 ? "Сохранено: " + files[0] : $"Сохранено файлов: {files.Count} в папку {Path.GetDirectoryName(files[0])}";
            var text = (files.Count == 1 ? "PDF сохранён:\n" + files[0] : $"Сохранено файлов: {files.Count}.") +
                       (warnings.Count > 0 ? "\n\n" + string.Join("\n", warnings) : "");
            if (OpenResult != null && files.Count == 1)
            {
                if (MessageBox.Show(this, text + "\n\nОткрыть результат в DocuNova?", "Редактор PDF", MessageBoxButton.YesNo, MessageBoxImage.Information) == MessageBoxResult.Yes)
                    OpenResult(files[0]);
            }
            else MessageBox.Show(this, text, "Редактор PDF", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private bool _saved;

        // ======================= закрытие =======================

        private bool _closeConfirmed;

        /// <summary>Можно ли закрыть редактор: не идёт сохранение, а несохранённые изменения пользователь согласен потерять.</summary>
        public bool ConfirmClose()
        {
            if (_closeConfirmed) return true;
            if (_busy)
            {
                MessageBox.Show(this, "Идёт сохранение PDF — дождитесь его окончания.", "Редактор PDF", MessageBoxButton.OK, MessageBoxImage.Information);
                return false;
            }
            if (!_saved && _undo.Count > 0 && _pages.Count > 0)
            {
                var r = MessageBox.Show(this, "Изменения в редакторе PDF не сохранены. Закрыть редактор без сохранения?", "Редактор PDF", MessageBoxButton.YesNo, MessageBoxImage.Question);
                if (r != MessageBoxResult.Yes) return false;
            }
            _closeConfirmed = true;
            return true;
        }

        private void OnClosingWindow(object sender, CancelEventArgs e)
        {
            if (!ConfirmClose()) e.Cancel = true;
        }

        private void Cleanup()
        {
            _closed = true;
            _thumbTimer.Stop();
            foreach (var p in _pages) p.Thumb = null;
            _pages.Clear();
            foreach (var s in _sources) s.Dispose();
            _sources.Clear();
            _undo.Clear(); _redo.Clear();
            MemoryTrim.Schedule();
        }

        private static T FindChild<T>(DependencyObject d) where T : DependencyObject
        {
            if (d == null) return null;
            int n = VisualTreeHelper.GetChildrenCount(d);
            for (int i = 0; i < n; i++)
            {
                var c = VisualTreeHelper.GetChild(d, i);
                if (c is T t) return t;
                var r = FindChild<T>(c);
                if (r != null) return r;
            }
            return null;
        }
    }
}
