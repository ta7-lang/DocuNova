using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shell;

namespace DocuNova.Views
{
    /// <summary>Базовое окно в стиле приложения (свой заголовок, тема, градиентный фон).</summary>
    public class ThemedWindow : Window
    {
        protected readonly Grid Body = new Grid();
        private readonly TextBlock _title = new TextBlock();

        public ThemedWindow()
        {
            WindowStyle = WindowStyle.None;
            ResizeMode = ResizeMode.CanResize;
            WindowStartupLocation = WindowStartupLocation.CenterOwner;
            ShowInTaskbar = false;
            UseLayoutRounding = true;
            SetResourceReference(BackgroundProperty, "BgBrush");
            SetResourceReference(ForegroundProperty, "FgBrush");
            FontFamily = (FontFamily)Application.Current.Resources["UiFont"];
            FontSize = 13.5;
            WindowChrome.SetWindowChrome(this, new WindowChrome { CaptionHeight = 42, ResizeBorderThickness = new Thickness(6), GlassFrameThickness = new Thickness(0), UseAeroCaptionButtons = false });

            var root = new Grid();
            root.RowDefinitions.Add(new RowDefinition { Height = new GridLength(42) });
            root.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
            var border = new Border { BorderThickness = new Thickness(1), Child = root };
            border.SetResourceReference(Border.BorderBrushProperty, "PanelBorderBrush");

            var head = new Grid();
            _title.FontSize = 15; _title.FontWeight = FontWeights.SemiBold;
            _title.VerticalAlignment = VerticalAlignment.Center; _title.Margin = new Thickness(16, 0, 0, 0);
            _title.SetResourceReference(TextBlock.ForegroundProperty, "AccentBrush");
            head.Children.Add(_title);
            var close = new Button { Content = "\uE8BB", HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Top };
            close.SetResourceReference(StyleProperty, "CloseBtn");
            WindowChrome.SetIsHitTestVisibleInChrome(close, true);
            close.Click += (s, e) => { try { DialogResult = false; } catch { Close(); } };
            head.Children.Add(close);
            root.Children.Add(head);

            Grid.SetRow(Body, 1);
            root.Children.Add(Body);
            Content = border;
            Title = "DocuNova";
        }

        public string Heading { get => _title.Text; set { _title.Text = value; Title = value; } }

        protected static Button MakeButton(string text, bool accent)
        {
            var b = new Button { Content = text, MinWidth = 100 };
            b.SetResourceReference(StyleProperty, accent ? "AccentBtn" : "GhostBtn");
            return b;
        }
    }

    /// <summary>Запрос строки (текст надписи, заметки, диапазон страниц).</summary>
    public sealed class InputDialog : ThemedWindow
    {
        private readonly TextBox _box;
        public string Value => _box.Text;

        private InputDialog(string title, string prompt, string initial, bool multiline)
        {
            Heading = title;
            Width = 460; SizeToContent = SizeToContent.Height; ResizeMode = ResizeMode.NoResize;
            var sp = new StackPanel { Margin = new Thickness(18, 4, 18, 16) };
            if (!string.IsNullOrEmpty(prompt)) sp.Children.Add(new TextBlock { Text = prompt, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 0, 0, 8) });
            _box = new TextBox { Text = initial ?? "", AcceptsReturn = multiline, TextWrapping = multiline ? TextWrapping.Wrap : TextWrapping.NoWrap, MinHeight = multiline ? 90 : 32, VerticalContentAlignment = multiline ? VerticalAlignment.Top : VerticalAlignment.Center };
            sp.Children.Add(_box);
            var buttons = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right, Margin = new Thickness(0, 14, 0, 0) };
            var ok = MakeButton("ОК", true); ok.IsDefault = !multiline;
            ok.Click += (s, e) => { DialogResult = true; };
            var cancel = MakeButton("Отмена", false); cancel.IsCancel = true;
            buttons.Children.Add(cancel); buttons.Children.Add(ok);
            sp.Children.Add(buttons);
            Body.Children.Add(sp);
            Loaded += (s, e) => { _box.Focus(); _box.SelectAll(); };
            PreviewKeyDown += (s, e) => { if (multiline && e.Key == Key.Enter && (Keyboard.Modifiers & ModifierKeys.Control) != 0) { DialogResult = true; e.Handled = true; } };
        }

        public static string Ask(Window owner, string title, string prompt, string initial = "", bool multiline = false)
        {
            var d = new InputDialog(title, prompt, initial, multiline) { Owner = owner };
            return d.ShowDialog() == true ? d.Value : null;
        }
    }

    /// <summary>Запрос пароля документа.</summary>
    public sealed class PasswordDialog : ThemedWindow
    {
        private readonly PasswordBox _box;

        private PasswordDialog(string fileName, bool wrong)
        {
            Heading = "Документ защищён паролем";
            Width = 440; SizeToContent = SizeToContent.Height; ResizeMode = ResizeMode.NoResize;
            var sp = new StackPanel { Margin = new Thickness(18, 4, 18, 16) };
            sp.Children.Add(new TextBlock { Text = (wrong ? "Неверный пароль. Попробуйте ещё раз.\n\n" : "") + "Введите пароль для открытия «" + fileName + "».", TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 0, 0, 10) });
            _box = new PasswordBox { MinHeight = 32 };
            sp.Children.Add(_box);
            sp.Children.Add(new TextBlock { Text = "Пароль используется только для расшифровки в памяти и нигде не сохраняется.", TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 8, 0, 0), FontSize = 12, Opacity = 0.7 });
            var buttons = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right, Margin = new Thickness(0, 14, 0, 0) };
            var ok = MakeButton("Открыть", true); ok.IsDefault = true; ok.Click += (s, e) => DialogResult = true;
            var cancel = MakeButton("Отмена", false); cancel.IsCancel = true;
            buttons.Children.Add(cancel); buttons.Children.Add(ok);
            sp.Children.Add(buttons);
            Body.Children.Add(sp);
            Loaded += (s, e) => _box.Focus();
        }

        public static string Ask(Window owner, string fileName, bool wrong)
        {
            var d = new PasswordDialog(fileName, wrong) { Owner = owner };
            return d.ShowDialog() == true ? d._box.Password : null;
        }
    }
}
