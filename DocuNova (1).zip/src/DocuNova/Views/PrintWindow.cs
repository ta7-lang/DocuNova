using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Printing;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using DocuNova.Core;
using DocuNova.Services;
using DocuNova.Viewer;

namespace DocuNova.Views
{
    /// <summary>Печать: принтер, диапазон, копии, ориентация, масштаб, N страниц на листе, двусторонняя, Ч/Б, предпросмотр.</summary>
    public sealed class PrintWindow : ThemedWindow
    {
        private readonly DocumentBase _doc;
        private readonly List<PageRef> _pages;
        private readonly int _current;
        private readonly ComboBox _printer = new ComboBox();
        private readonly List<PrintQueue> _queues;
        private readonly TextBox _range = new TextBox { Width = 140 };
        private readonly TextBox _copies = new TextBox { Width = 60, Text = "1" };
        private readonly TextBox _custom = new TextBox { Width = 60, Text = "100" };
        private readonly CheckBox _collate = new CheckBox { Content = "Разбирать по копиям", IsChecked = true };
        private readonly CheckBox _ann = new CheckBox { Content = "Печатать пометки", IsChecked = true };
        private readonly CheckBox _reverse = new CheckBox { Content = "В обратном порядке" };
        private readonly CheckBox _borders = new CheckBox { Content = "Рамки вокруг страниц (при нескольких на листе)", IsChecked = true };
        private string _pagesMode = "all", _orient = "auto", _scale = "fit", _duplex = "none";
        private int _perSheet = 1, _dpi = 300;
        private bool _gray;
        private readonly Image _preview = new Image { Stretch = Stretch.Uniform };
        private readonly TextBlock _sheetText = new TextBlock { HorizontalAlignment = HorizontalAlignment.Center, Margin = new Thickness(0, 6, 0, 0) };
        private readonly TextBlock _status = new TextBlock { TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 8, 0, 0) };
        private int _sheet;
        private Button _printBtn;
        private bool _printing;

        public PrintWindow(DocumentBase doc, List<PageRef> pages, int current, bool currentOnly)
        {
            _doc = doc; _pages = pages; _current = current;
            Heading = "Печать";
            Width = 1000; Height = 760; MinWidth = 820; MinHeight = 560;
            if (currentOnly) _pagesMode = "current";

            _queues = PrintService.GetPrinters(out var def);
            foreach (var q in _queues) _printer.Items.Add(q.FullName);
            int di = def != null ? _queues.FindIndex(q => q.FullName == def.FullName) : -1;
            _printer.SelectedIndex = di >= 0 ? di : (_queues.Count > 0 ? 0 : -1);
            _range.Text = $"1-{pages.Count}";

            var root = new Grid { Margin = new Thickness(16, 0, 16, 14) };
            root.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(430) });
            root.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

            var left = new StackPanel();
            left.Children.Add(Caption("Принтер"));
            left.Children.Add(_printer);
            if (_queues.Count == 0) left.Children.Add(Hint("Принтеры не найдены. Установите принтер или «Microsoft Print to PDF» в параметрах Windows."));
            left.Children.Add(Hint("Совет: «Microsoft Print to PDF» сохраняет результат печати в PDF-файл."));

            left.Children.Add(Caption("Страницы"));
            left.Children.Add(Segments("pages", new[] { ("all", "Все"), ("current", "Текущая"), ("range", "Диапазон"), ("odd", "Нечётные"), ("even", "Чётные") }, _pagesMode, v => { _pagesMode = v; Refresh(); }));
            var rr = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 4, 0, 0) };
            rr.Children.Add(new TextBlock { Text = "Диапазон: ", VerticalAlignment = VerticalAlignment.Center });
            rr.Children.Add(_range);
            rr.Children.Add(new TextBlock { Text = "  например 1-3, 5, 8-", VerticalAlignment = VerticalAlignment.Center, Opacity = 0.7 });
            left.Children.Add(rr);
            _range.TextChanged += (s, e) => { if (_pagesMode == "range") Refresh(); };

            var cp = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 10, 0, 0) };
            cp.Children.Add(new TextBlock { Text = "Копий: ", VerticalAlignment = VerticalAlignment.Center });
            cp.Children.Add(_copies);
            cp.Children.Add(new Border { Width = 16 });
            cp.Children.Add(_collate);
            left.Children.Add(cp);

            left.Children.Add(Caption("Ориентация"));
            left.Children.Add(Segments("or", new[] { ("auto", "Авто"), ("portrait", "Книжная"), ("landscape", "Альбомная") }, _orient, v => { _orient = v; Refresh(); }));
            left.Children.Add(Caption("Масштаб"));
            var sc = Segments("sc", new[] { ("fit", "Вписать"), ("actual", "100 %"), ("fill", "Заполнить"), ("custom", "Свой") }, _scale, v => { _scale = v; Refresh(); });
            left.Children.Add(sc);
            var cs = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 4, 0, 0) };
            cs.Children.Add(new TextBlock { Text = "Свой масштаб, %: ", VerticalAlignment = VerticalAlignment.Center });
            cs.Children.Add(_custom);
            _custom.TextChanged += (s, e) => { if (_scale == "custom") Refresh(); };
            left.Children.Add(cs);
            left.Children.Add(Caption("Страниц на листе"));
            left.Children.Add(Segments("ps", new[] { ("1", "1"), ("2", "2"), ("4", "4"), ("6", "6"), ("9", "9") }, "1", v => { _perSheet = int.Parse(v); Refresh(); }));
            left.Children.Add(Caption("Цвет"));
            left.Children.Add(Segments("col", new[] { ("color", "Цветная"), ("gray", "Чёрно-белая") }, "color", v => { _gray = v == "gray"; Refresh(); }));
            left.Children.Add(Caption("Двусторонняя печать"));
            left.Children.Add(Segments("dup", new[] { ("none", "Нет"), ("long", "Переплёт по длинному краю"), ("short", "По короткому") }, "none", v => _duplex = v));
            left.Children.Add(Caption("Качество"));
            left.Children.Add(Segments("dpi", new[] { ("150", "Черновик 150"), ("300", "Обычное 300"), ("600", "Высокое 600 DPI") }, "300", v => _dpi = int.Parse(v)));
            left.Children.Add(_ann);
            left.Children.Add(_reverse);
            left.Children.Add(_borders);
            _ann.Checked += (s, e) => Refresh(); _ann.Unchecked += (s, e) => Refresh();
            _borders.Checked += (s, e) => Refresh(); _borders.Unchecked += (s, e) => Refresh();
            left.Children.Add(_status);

            var leftScroll = new ScrollViewer { Content = left, VerticalScrollBarVisibility = ScrollBarVisibility.Auto, Padding = new Thickness(0, 0, 10, 0) };
            root.Children.Add(leftScroll);

            // предпросмотр
            var right = new DockPanel { Margin = new Thickness(14, 0, 0, 0) };
            var btns = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right, Margin = new Thickness(0, 10, 0, 0) };
            var cancel = MakeButton("Отмена", false); cancel.IsCancel = true; cancel.Click += (s, e) => { if (!_printing) Close(); };
            _printBtn = MakeButton("Печать", true); _printBtn.IsDefault = true; _printBtn.Click += (s, e) => DoPrint();
            _printBtn.IsEnabled = _queues.Count > 0;
            btns.Children.Add(cancel); btns.Children.Add(_printBtn);
            DockPanel.SetDock(btns, Dock.Bottom);
            right.Children.Add(btns);
            var nav = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Center };
            var prev = MakeButton("‹", false); prev.MinWidth = 44; prev.Click += (s, e) => { if (_sheet > 0) { _sheet--; RenderPreview(); } };
            var next = MakeButton("›", false); next.MinWidth = 44; next.Click += (s, e) => { _sheet++; RenderPreview(); };
            nav.Children.Add(prev); nav.Children.Add(_sheetText); nav.Children.Add(next);
            _sheetText.VerticalAlignment = VerticalAlignment.Center; _sheetText.Margin = new Thickness(10, 0, 10, 0);
            DockPanel.SetDock(nav, Dock.Bottom);
            right.Children.Add(nav);
            var previewBox = new Border { Padding = new Thickness(16), CornerRadius = new CornerRadius(10) };
            previewBox.SetResourceReference(Border.BackgroundProperty, "ViewerBgBrush");
            var shadowed = new Border { Child = _preview, HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center };
            shadowed.SetResourceReference(EffectProperty, "PageShadow");
            RenderOptions.SetBitmapScalingMode(_preview, BitmapScalingMode.HighQuality);
            previewBox.Child = shadowed;
            right.Children.Add(previewBox);
            Grid.SetColumn(right, 1);
            root.Children.Add(right);
            Body.Children.Add(root);

            _printer.SelectionChanged += (s, e) => Refresh();
            Loaded += (s, e) => Refresh();
            Closing += (s, e) => { if (_printing) e.Cancel = true; };
        }

        private static TextBlock Caption(string t) => new TextBlock { Text = t, FontWeight = FontWeights.SemiBold, Margin = new Thickness(0, 12, 0, 4) };

        private static TextBlock Hint(string t)
        {
            var tb = new TextBlock { Text = t, Margin = new Thickness(0, 4, 0, 0) };
            tb.SetResourceReference(StyleProperty, "Hint");
            return tb;
        }

        private static WrapPanel Segments(string group, (string code, string name)[] items, string selected, Action<string> changed)
        {
            var wp = new WrapPanel();
            foreach (var (code, name) in items)
            {
                var rb = new RadioButton { Content = name, GroupName = group + Guid.NewGuid().ToString("N"), IsChecked = code == selected, Tag = code };
                rb.SetResourceReference(StyleProperty, "Segment");
                wp.Children.Add(rb);
            }
            // одна группа на панель
            string g = group + Guid.NewGuid().ToString("N");
            foreach (RadioButton rb in wp.Children)
            {
                rb.GroupName = g;
                rb.Checked += (s, e) => changed((string)((RadioButton)s).Tag);
            }
            return wp;
        }

        private PrintOptions BuildOptions()
        {
            var o = new PrintOptions();
            List<int> idx;
            switch (_pagesMode)
            {
                case "current": idx = new List<int> { _current }; break;
                case "range": idx = PrintService.ParseRange(_range.Text, _pages.Count); break;
                case "odd": idx = Enumerable.Range(0, _pages.Count).Where(i => i % 2 == 0).ToList(); break;
                case "even": idx = Enumerable.Range(0, _pages.Count).Where(i => i % 2 == 1).ToList(); break;
                default: idx = Enumerable.Range(0, _pages.Count).ToList(); break;
            }
            o.Pages = idx.Where(i => i >= 0 && i < _pages.Count).Select(i => _pages[i]).ToList();
            o.Copies = int.TryParse(_copies.Text.Trim(), out var c) ? Math.Max(1, Math.Min(999, c)) : 1;
            o.Collate = _collate.IsChecked == true;
            o.Orientation = _orient;
            o.Scaling = _scale;
            o.CustomScale = double.TryParse(_custom.Text.Trim().Replace(',', '.'), NumberStyles.Float, CultureInfo.InvariantCulture, out var cc) ? cc / 100 : 1;
            o.PerSheet = _perSheet;
            o.Gray = _gray;
            o.Duplex = _duplex;
            o.Annotations = _ann.IsChecked == true;
            o.Dpi = _dpi;
            o.Reverse = _reverse.IsChecked == true;
            o.Borders = _borders.IsChecked == true;
            return o;
        }

        private void Refresh()
        {
            if (!IsLoaded) return;
            _sheet = 0;
            RenderPreview();
        }

        private void RenderPreview()
        {
            try
            {
                var o = BuildOptions();
                if (o.Pages.Count == 0) { _preview.Source = null; _sheetText.Text = "Нет страниц для печати"; _status.Text = "Проверьте диапазон страниц."; return; }
                o.Dpi = 110; // предпросмотр — быстро
                Size sheet = new Size(793.7, 1122.5);
                var q = SelectedQueue();
                if (q != null)
                {
                    try { sheet = PrintService.PortraitSheet(q, q.UserPrintTicket ?? q.DefaultPrintTicket); } catch { }
                }
                var pag = new SheetPaginator(_doc, o, sheet);
                _sheet = Math.Max(0, Math.Min(_sheet, pag.PageCount - 1));
                var page = pag.GetPage(_sheet);
                double k = 560 / Math.Max(pag.PageSize.Width, pag.PageSize.Height);
                var rtb = new RenderTargetBitmap((int)(pag.PageSize.Width * k * 1.5), (int)(pag.PageSize.Height * k * 1.5), 96 * k * 1.5, 96 * k * 1.5, PixelFormats.Pbgra32);
                rtb.Render(page.Visual);
                rtb.Freeze();
                _preview.Source = rtb;
                _preview.Width = pag.PageSize.Width * k; _preview.Height = pag.PageSize.Height * k;
                _sheetText.Text = $"Лист {_sheet + 1} из {pag.PageCount}";
                int sheets = pag.PageCount * o.Copies;
                _status.Text = $"Будет напечатано страниц документа: {o.Pages.Count}, листов: {pag.PageCount}" + (o.Copies > 1 ? $" × {o.Copies} копий = {sheets}" : "") +
                               (_duplex != "none" ? $" (двусторонняя: около {Math.Ceiling(sheets / 2.0)} листов бумаги)" : "") + (pag.Landscape ? ". Ориентация: альбомная." : ". Ориентация: книжная.");
            }
            catch (Exception ex) { _status.Text = "Предпросмотр недоступен: " + ex.Message; }
        }

        private PrintQueue SelectedQueue() => _printer.SelectedIndex >= 0 && _printer.SelectedIndex < _queues.Count ? _queues[_printer.SelectedIndex] : null;

        private void DoPrint()
        {
            var q = SelectedQueue();
            if (q == null) { MessageBox.Show(this, "Выберите принтер.", "DocuNova"); return; }
            var o = BuildOptions();
            if (o.Pages.Count == 0) { MessageBox.Show(this, "Нет страниц для печати — проверьте диапазон.", "DocuNova"); return; }
            try
            {
                _printing = true;
                _printBtn.IsEnabled = false;
                _status.Text = "Отправка на принтер…";
                var writer = PrintService.Print(q, _doc, o);
                writer.WritingProgressChanged += (s, e) => _status.Text = $"Отправка на принтер: лист {e.Number}…";
                writer.WritingCompleted += (s, e) =>
                {
                    _printing = false;
                    if (e.Error != null) { _status.Text = "Ошибка печати: " + e.Error.Message; _printBtn.IsEnabled = true; return; }
                    if (e.Cancelled) { _status.Text = "Печать отменена."; _printBtn.IsEnabled = true; return; }
                    Close();
                };
            }
            catch (Exception ex)
            {
                _printing = false;
                _printBtn.IsEnabled = true;
                _status.Text = "Ошибка печати: " + ex.Message;
            }
        }
    }
}
